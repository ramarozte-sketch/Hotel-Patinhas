# Hotel Patinhas 3D

Jogo para Android: andas pelo hotel com a tua personagem, atendes os donos na receção e cuidas dos animais nos quartos. Com o dinheiro que ganhas constróis quartos e compras melhorias.

## Como instalar no telemóvel

1. Descompacta esta pasta e abre-a no **Android Studio** (File → Open → pasta `HotelPatinhas`).
2. Deixa o Android Studio sincronizar o Gradle. Na primeira compilação precisas de internet: o projeto descarrega sozinho o motor 3D (three.js) e as letras para dentro da app.
3. Liga o telemóvel por USB com a depuração USB ativa e carrega em **Run ▶**.
   Para gerar um ficheiro APK: Build → Build App Bundle(s) / APK(s) → Build APK(s).

Depois de instalado, o jogo funciona sem internet e guarda o progresso no telemóvel.

## Como jogar

- **Joystick** (canto inferior esquerdo): anda com a personagem.
- **Receção**: aproxima-te do balcão para aceitar ou recusar os donos que chegam.
- **Quartos**: entra num quarto para dar comida (€1), banho e brincar. Os avisos no topo mostram que animal precisa de ti.
- **Quartos novos**: vai ao quarto em obras 🏗️ e constrói-o.
- **🛠️ Melhorias**: camas, comedouro e duche automáticos, tratador, publicidade, decoração e novos espaços (aviário, lago, estábulo e suite real para o unicórnio).
- **🔊 Som**: toca para alternar entre música e efeitos, só efeitos ou silêncio.
- **👕 Personagem**: muda a pele, o cabelo, a roupa e o chapéu quando quiseres.

## Onde mexer

- O jogo todo está em `app/src/main/assets/index.html`.
- A app Android é só `MainActivity.java`, que abre o jogo num WebView em ecrã inteiro.
