# Hotel Patinhas 3D

Jogo para Android: andas pelo hotel com a tua personagem, atendes os donos na receção e cuidas dos animais nos quartos. Com o dinheiro que ganhas constróis quartos e compras melhorias.

## Como instalar no telemóvel

1. Descompacta esta pasta e abre-a no **Android Studio** (File → Open → pasta `HotelPatinhas`).
2. Deixa o Android Studio sincronizar o Gradle. Na primeira compilação precisas de internet: o projeto descarrega sozinho o motor 3D (three.js), os modelos 3D animados (cavalo e raposa) e as letras para dentro da app.
3. Liga o telemóvel por USB com a depuração USB ativa e carrega em **Run ▶**.
   Para gerar um ficheiro APK: Build → Build App Bundle(s) / APK(s) → Build APK(s).

Depois de instalado, o jogo funciona sem internet e guarda o progresso no telemóvel.

## Não perder o progresso entre versões

- Todas as versões são assinadas com a mesma chave (`app/hotelpatinhas.jks`), por isso cada APK novo instala **por cima** do anterior e o progresso fica. Não apagues esse ficheiro do repositório.
- Antes de atualizar, abre ☰ → **💾 Guardar e cópias** → **📤 Exportar progresso** e guarda o ficheiro `.json` (por exemplo em Transferências).
- Se alguma vez tiveres de desinstalar, instala a versão nova e usa **📥 Importar progresso** com esse ficheiro.

## Como jogar

- **Menu principal**: Continuar, Novo jogo, Missões, Avaliações, Álbum, Franquias, O meu animal, Modo foto, Personagem, Opções e Como jogar. Durante o jogo, o botão ☰ abre o menu de pausa.
- **Joystick** (canto inferior esquerdo): anda com a personagem.
- **Receção** (sala redonda à entrada): aproxima-te do balcão curvo para aceitar ou recusar os donos que chegam.
- **Átrio e quartos**: os quartos estão em leque à volta de um átrio com fonte. Cada quarto tem comedouro, bebedouro, banheira e cama. Entra no quarto e aparece um cartão compacto com o animal, a cor do humor, o tempo que falta, as quatro barras de necessidades e botões redondos para dar ração (€1), água, banho, brincar ou mandar o animal ao parque.
- **🌳 Parque de acrobacias** (nas traseiras): barreira, túnel, slalom, rampa, pneu e pódio. Os animais voltam muito mais contentes e os donos pagam mais.
- **🦮 Ida e volta ao parque pela trela**: no quarto, carrega em 🌳 e o animal segue-te pela trela (vê-se a trela vermelha). Quando entram os dois no parque, ele faz o percurso sozinho e depois fica à espera junto à entrada. Aproxima-te dele para o levares de volta: ao entrar no quarto, fica lá. Enquanto vais a caminho, o botão passa a 🦮 Soltar. Os animadores fazem o mesmo trajeto, ida e volta, com o animal pela trela.
- **🧹 Cocós e xixis**: os animais sujam o quarto de vez em quando. Cada sujidade deixa o animal mais triste e o dono paga menos. Limpa com o botão 🧹 Limpar (o número mostra quantas há). Os quartos sujos aparecem nos avisos do topo com 💩. Os banhistas também limpam.
- **Quartos novos**: vai ao quarto em obras 🏗️ e constrói-o.
- **🛠️ Melhorias → Ajudantes**: tratadores de comida, banhistas, animadores (também levam os animais ao parque) e rececionista.
- **🛠️ Melhorias → Ampliações**: Pavilhão Nascente e Pavilhão Poente (4 quartos cada, até 16 quartos), piscina no parque de acrobacias e luzes de festa (+10% à noite).
- **🛠️ Melhorias → O hotel**: camas melhores, doseador automático, fonte de água, publicidade, decoração e novos espaços.
- **📱 Ecrã** (⚙️ Opções → Ecrã do jogo): vertical, horizontal ou automático (roda com o telemóvel). Na horizontal, os menus e o cartão do animal arrumam-se para o ecrã largo.
- **⚙️ Opções**: escolhe entre 6 músicas (ou nenhuma) e ajusta o volume da música e dos efeitos. Os animais fazem sons de contentes e de tristes.
- **🏠 Telhados**: o hotel, a receção e os pavilhões têm telhado de telha com claraboia; desaparece quando aproximas a câmara e volta quando te afastas.
- **🏘️ Bairro**: estrada em anel com curvas mesmo à volta do hotel (avenida à frente, ruas dos lados e nas traseiras, por isso vês os carros a passar) e quatro ruas sem saída com praceta redonda. Cerca de 50 moradias portuguesas e algarvias (paredes caiadas ou pastel, barras coloridas, persianas, varandas, telhados de telha ou açoteias com chaminé algarvia, muros, sebes, palmeiras, garagens e azulejos), lojas na avenida, estacionamento e paragem de autocarro. Mais de 20 carros a circular sempre na estrada, nos dois sentidos (param para te deixar passar) e pessoas a passear, algumas com cão. Os donos chegam pelo passeio.
- **🗺️ Mapa**: minimapa no canto superior direito. Toca nele (ou em 🗺️) para abrir o mapa completo: arrasta para navegar, dois dedos ou + e − para o zoom, 📍 para te centrares. Os quartos aparecem com o animal e a cor do estado (verde contente, amarelo precisa de atenção, vermelho triste). Toca num sítio e usa **🚶 Ir para aqui** para lá chegares num instante.
- **🔊 Sons dos animais**: cada animal cumprimenta quando entras no quarto, faz sons de contente ou triste e ouve-se de mais longe. Em Opções há **Testar sons dos animais**.
- **🎥 Câmara 360°**: o botão 🎥 no topo troca entre vista de cima, terceira pessoa e primeira pessoa. Arrasta o dedo para olhar em todas as direções (esquerda, direita, cima e baixo). Em primeira pessoa, o botão 📱 deixa olhar à volta movendo o telemóvel (giroscópio).
- **🔍 Zoom e rotação**: dois dedos no ecrã ou os botões + e − para o zoom; arrasta um dedo no ecrã ou usa ⟲ ⟳ para rodar o mundo. O joystick segue a direção da câmara.
- **☀️ Céu**: céu em gradiente que muda com a hora, sol e lua a atravessar o céu (as sombras acompanham o sol), nuvens, bandos de pássaros, aviões com rasto, balão de ar quente, estrelas, estrelas cadentes e pirilampos no parque. Pássaros a cantar de dia e grilos à noite.
- **🌙 Dia e noite**: o hotel segue a hora do telemóvel. À noite acendem-se os candeeiros, as janelas e as luzes dos quartos, aparecem a lua e as estrelas e os animais dormem mais. Em Opções podes fixar sempre dia ou sempre noite.
- **✨ Gráficos** (Opções): *Alta* tem materiais realistas com reflexos, cor de cinema, sombras suaves, relva, nuvens e animais com modelos 3D animados; *Clássica* é o aspeto das versões anteriores; *Leve* é para telemóveis mais fracos. Os modelos 3D também se podem desligar.
- **🌍 Idiomas**: português, inglês e francês. O jogo escolhe sozinho o idioma do telemóvel; podes mudá-lo em ⚙️ Opções → Idioma, sem perder o progresso.
- **🚪 Portas**: cada quarto tem uma porta dupla de madeira alta (com vidro em cima, almofadas, puxadores e chapa metálica) que está fechada e abre sozinha quando alguém se aproxima. A receção tem uma porta de entrada automática de vidro que desliza.
- **🛋️ Sala de espera**: os donos esperam sentados em bancos almofadados e, de vez em quando, levantam-se para ir buscar 💧 água, ☕ café ou ir à 🚻 casa de banho. Assim aguentam mais tempo na fila (paciência de 60 s, mais 12 s por cada pausa).
- **🦄 Unicórnio**: o chifre e a crina colorida seguem a cabeça do modelo animado em cada imagem, por isso ficam sempre na testa e no pescoço, mesmo a galopar.
- **🐴 Estábulos**: quando um cavalo ou unicórnio ocupa um quarto, este transforma-se num estábulo: chão de palha, tábuas de madeira nas paredes, manjedoura com feno, grade de feno, bebedouro de madeira, zona de lavagem com mangueira e balde, cama de palha com manta, ferradura, sela e lanterna. Quando sai, volta a ser um quarto normal.
- **🚻 Casa de banho completa**: atrás da porta da receção há uma WC a sério, com sanita, lavatório, espelho, secador de mãos, papel, barra de apoio e caixote. Os donos entram, sentam-se e voltam ao banco; a porta abre e fecha sozinha.
- **🛋️ Sala de descanso**: nas traseiras do hotel há uma sala para a equipa com sofá de 3 lugares, poltrona, mesa de centro, televisão ligada, cacifos, copa (bancada com lava-loiça, máquina de café e micro-ondas), frigorífico, mesa com 4 cadeiras, água e planta. Os ajudantes sem trabalho sentam-se lá e de vez em quando vão buscar café ou um lanche.
- **⭐ Avaliações**: toca no nome do hotel (ou no menu) para ver a nota média, a distribuição das estrelas e o comentário de cada dono, escrito a partir do que aconteceu na estadia (parque, mimos, limpeza, fome, doenças, pedidos, estábulo, decoração, espera na receção).
- **🎓 Tutorial**: num jogo novo, uma faixa no topo e uma seta ⬇️ guiam-te pelo primeiro hóspede (receção, aceitar, ração, limpeza, parque e volta ao quarto). Podes saltá-lo.
- **🎯 Missões e conquistas**: todos os dias há 3 missões novas com prémios em dinheiro (e um bónus se fizeres as três). Há 12 conquistas para desbloquear. Abre-se no 🎯 do topo ou no menu.
- **📝 Pedidos especiais**: alguns donos pedem algo (ir 2× ao parque, 2 banhos, 3 mimos, quarto sempre limpo, sair muito contente). Se cumprires pagam +35%; se não, a reputação baixa.
- **⭐ Clientes habituais**: donos que saíram contentes voltam com o mesmo animal e pagam +8% por cada visita anterior (até +32%).
- **🤒 Doenças e 🩺 veterinário**: animais com fome ou em quartos muito sujos podem adoecer (ficam tristes). Carrega em 🩺 e leva-os pela trela até à 🐾 Veterinário da avenida (segue a seta). A consulta é paga e depois trazes o animal de volta.
- **🤗 Mimos**: novo botão no cartão do animal, com corações e sons de contente.
- **💼 Salários**: cada ajudante recebe a cada 4 minutos de jogo. Se faltar dinheiro, a reputação baixa.
- **🌧️ Chuva**: às vezes chove (céu escuro, gotas, som de chuva e trovões). Os animais voltam do parque cheios de lama. Em Opções → Meteorologia podes escolher sempre sol.
- **📳 Vibração**: o telemóvel vibra nos momentos importantes (pode desligar-se em Opções).
- **🎨 Decorar quartos**: no cartão do animal (ou num quarto livre), escolhe a cor do chão, do tapete e da cama e compra extras (planta, casota, peluche, torre de brincar). Cada extra faz o quarto render +4%.
- **🎵 Músicas novas**: 6 canções compostas com secções, acordes, baixo, bateria e melodias que se repetem, tocadas por piano, sinos, flauta, guitarra, cordas e sintetizadores, com eco e reverberação: Manhã no hotel, Patinhas felizes, Jardim ao sol, Noite tranquila (lo-fi), Grande aventura (orquestral) e Bossa algarvia.
- **👕 Personagem**: muda a pele, o cabelo, a roupa e o chapéu quando quiseres.
- **🧍 Personagens realistas ou básicas** (⚙️ Opções → Personagens): *Realistas* têm corpo arredondado com joelhos e cotovelos, mãos, sapatos e rosto com olhos, sobrancelhas, nariz e orelhas; *Básicas* são os bonecos de blocos das versões anteriores, mais leves para telemóveis fracos. Aplica-se à tua personagem, aos donos, aos ajudantes e às pessoas na rua.

## Novidades da versão 4.1

- **🚪 Ligações interiores**: cada pavilhão tem uma galeria coberta (paredes, janelas, telhado, chão do hotel, bancos, plantas e luzes) que parte de uma porta de vidro automática na receção, ao lado da entrada principal, e vai até à entrada do pavilhão. Tu, os ajudantes e os animais passam por dentro, sem ir pela rua. A porta de cada lado fica fechada até construíres o pavilhão. A galeria tem também uma porta lateral para o caminho do jardim.

## Novidades da versão 4.0 (longevidade)

- **📖 Álbum de animais** (menu): regista cada espécie e pelagem. Há pelagens raras ✨ (6%) e prémios por espécie nova, pelagem rara e coleção completa.
- **🏙️ Franquias** (menu): Lisboa (4★), Porto, Alentejo e Serra da Estrela (5★). Cada uma tem 5 níveis, rende dinheiro por minuto (também com o jogo fechado, até 8 horas) e traz uma espécie exclusiva ao hotel: gato persa, cão de água, lince-ibérico e cão da Serra da Estrela.
- **🏆 Prémio do mês**: com média de 4,5★ e pelo menos 8 avaliações num mês ganhas um troféu e €1000. Os troféus aparecem no balcão e numa estátua à entrada. O progresso está em Missões e conquistas.
- **🎃 🎄 ☀️ Épocas do ano** (pela data do telemóvel): Halloween (1 de outubro a 2 de novembro), Natal com neve (1 de dezembro a 6 de janeiro) e verão (15 de junho a 15 de setembro), cada uma com decoração e bónus.
- **🏅 Concursos** de beleza e provas de agilidade a cada poucos minutos, com 2 minutos para preparar os animais.
- **🕵️ 📸 🌟 Visitas surpresa**: inspetores incógnitos, influenciadores (trazem mais clientes) e animais famosos (pagam o triplo).
- **⚠️ Imprevistos**: um animal foge pela entrada (segue a seta e apanha-o), falta de luz à noite (vai ao quadro elétrico ⚡ na sala de descanso) e fugas de água nos quartos (🔧 Reparar no cartão do animal).
- **👥 Equipa**: os ajudantes ganham experiência e sobem até ao nível 5, têm personalidade (rápido, alegre, preguiçoso ou perfeccionista) e energia; descansam na sala de descanso. O salário sobe €2 por nível. A lista está em 🛠️ Melhorias.
- **🛒 Produtos** (em 🛠️ Melhorias): ração premium, champô de luxo e brinquedos novos, gastos automaticamente por ti e pelos ajudantes.
- **🐾 O meu animal** (menu): adota um animal teu (€150) com nome e coleira; segue-te e recebe festinhas.
- **🎁 Recompensa diária** com sequência de 7 dias e resumo do que a equipa e as franquias ganharam enquanto estiveste fora.
- **📷 Modo foto** (menu): esconde os botões, tira fotografias, mostra uma galeria e guarda a imagem no telemóvel (escolhes a pasta).

## Ecrã

- As notificações aparecem pequenas no canto superior esquerdo, por baixo dos avisos, para taparem o mínimo possível. No parque só aparece um aviso pequeno quando há animais à espera de voltar.
- A barra do topo é mais compacta: o nome do hotel e as estrelas cabem sempre (em duas linhas se for preciso).

## Desempenho

- As peças paradas de cada parte do mundo (paredes, árvores, candeeiros, jardim, mobília dos quartos, carros e as partes rígidas das pessoas e dos animais) são juntas num só desenho por material. Há menos de metade dos desenhos por imagem e cerca de um terço das sombras.
- Resolução adaptativa: o jogo começa com nitidez 1,5× (1× em *Leve*). Se o telemóvel não aguentar 40 imagens por segundo, baixa a nitidez aos poucos e, se preciso, atualiza as sombras um quadro sim, outro não. Volta a subir quando há folga.
- As pessoas e os carros longe da câmara não são desenhados nem animados. As pessoas na rua não fazem sombra (têm a sombra redonda).

## Onde mexer

- O jogo todo está em `app/src/main/assets/index.html`.
- A app Android é só `MainActivity.java`, que abre o jogo num WebView em ecrã inteiro.
