# Hotel Patinhas 3D

Jogo para Android: andas pelo hotel com a tua personagem, atendes os donos na receção e cuidas dos animais nos quartos. Com o dinheiro que ganhas constróis quartos e compras melhorias.

## Como instalar no telemóvel

1. Descompacta esta pasta e abre-a no **Android Studio** (File → Open → pasta `HotelPatinhas`).
2. Deixa o Android Studio sincronizar o Gradle. Na primeira compilação precisas de internet: o projeto descarrega sozinho o motor 3D (three.js) e as letras para dentro da app.
3. Liga o telemóvel por USB com a depuração USB ativa e carrega em **Run ▶**.
   Para gerar um ficheiro APK: Build → Build App Bundle(s) / APK(s) → Build APK(s).

Depois de instalado, o jogo funciona sem internet e guarda o progresso no telemóvel.

## Não perder o progresso entre versões

- Todas as versões são assinadas com a mesma chave (`app/hotelpatinhas.jks`), por isso cada APK novo instala **por cima** do anterior e o progresso fica. Não apagues esse ficheiro do repositório.
- Antes de atualizar, abre ☰ → **💾 Guardar e cópias** → **📤 Exportar progresso** e guarda o ficheiro `.json` (por exemplo em Transferências).
- Se alguma vez tiveres de desinstalar, instala a versão nova e usa **📥 Importar progresso** com esse ficheiro.

## Como jogar

- **Menu principal**: Continuar, Novo jogo, Personagem, Opções e Como jogar. Durante o jogo, o botão ☰ abre o menu de pausa.
- **Joystick** (canto inferior esquerdo): anda com a personagem.
- **Receção** (sala redonda à entrada): aproxima-te do balcão curvo para aceitar ou recusar os donos que chegam.
- **Átrio e quartos**: os quartos estão em leque à volta de um átrio com fonte. Cada quarto tem comedouro, bebedouro, banheira e cama. Entra no quarto para dar ração (€1), água, banho, brincar ou mandar o animal ao parque.
- **🌳 Parque de acrobacias** (nas traseiras): barreira, túnel, slalom, rampa, pneu e pódio. Os animais voltam muito mais contentes e os donos pagam mais.
- **Quartos novos**: vai ao quarto em obras 🏗️ e constrói-o.
- **🛠️ Melhorias → Ajudantes**: tratadores de comida, banhistas, animadores (também levam os animais ao parque) e rececionista.
- **🛠️ Melhorias → Ampliações**: Pavilhão Nascente e Pavilhão Poente (4 quartos cada, até 16 quartos), piscina no parque de acrobacias e luzes de festa (+10% à noite).
- **🛠️ Melhorias → O hotel**: camas melhores, doseador automático, fonte de água, publicidade, decoração e novos espaços.
- **⚙️ Opções**: escolhe entre 5 músicas (ou nenhuma) e ajusta o volume da música e dos efeitos. Os animais fazem sons de contentes e de tristes.
- **🔍 Zoom e rotação**: dois dedos no ecrã ou os botões + e − para o zoom; arrasta um dedo no ecrã ou usa ⟲ ⟳ para rodar o mundo. O joystick segue a direção da câmara.
- **🌙 Dia e noite**: o hotel segue a hora do telemóvel. À noite acendem-se os candeeiros, as janelas e as luzes dos quartos, aparecem a lua e as estrelas e os animais dormem mais. Em Opções podes fixar sempre dia ou sempre noite.
- **👕 Personagem**: muda a pele, o cabelo, a roupa e o chapéu quando quiseres.

## Onde mexer

- O jogo todo está em `app/src/main/assets/index.html`.
- A app Android é só `MainActivity.java`, que abre o jogo num WebView em ecrã inteiro.
