# Hotel Patinhas 3D

Jogo para Android: andas pelo hotel com a tua personagem, atendes os donos na receção e cuidas dos animais nos quartos. Com o dinheiro que ganhas constróis quartos e compras melhorias.

## Como instalar no telemóvel

1. Descompacta esta pasta e abre-a no **Android Studio** (File → Open → pasta `HotelPatinhas`).
2. Deixa o Android Studio sincronizar o Gradle. Na primeira compilação precisas de internet: o projeto descarrega sozinho o motor 3D (three.js), os modelos 3D animados (cavalo e raposa) e as letras para dentro da app.
3. Liga o telemóvel por USB com a depuração USB ativa e carrega em **Run ▶**.
   Para gerar um ficheiro APK: Build → Build App Bundle(s) / APK(s) → Build APK(s).

Depois de instalado, o jogo funciona sem internet e guarda o progresso no telemóvel.

## Não perder o progresso entre versões

- Todas as versões são assinadas com a mesma chave (`app/hotelpatinhas.jks`), por isso cada APK novo instala **por cima** do anterior e o progresso fica. Não apagues esse ficheiro do repositório.
- Antes de atualizar, abre ☰ → **💾 Guardar e cópias** → **📤 Exportar progresso** e guarda o ficheiro `.json` (por exemplo em Transferências).
- Se alguma vez tiveres de desinstalar, instala a versão nova e usa **📥 Importar progresso** com esse ficheiro.

## Como jogar

- **Menu principal**: Continuar, Novo jogo, Personagem, Opções e Como jogar. Durante o jogo, o botão ☰ abre o menu de pausa.
- **Joystick** (canto inferior esquerdo): anda com a personagem.
- **Receção** (sala redonda à entrada): aproxima-te do balcão curvo para aceitar ou recusar os donos que chegam.
- **Átrio e quartos**: os quartos estão em leque à volta de um átrio com fonte. Cada quarto tem comedouro, bebedouro, banheira e cama. Entra no quarto e aparece um cartão compacto com o animal, a cor do humor, o tempo que falta, as quatro barras de necessidades e botões redondos para dar ração (€1), água, banho, brincar ou mandar o animal ao parque.
- **🌳 Parque de acrobacias** (nas traseiras): barreira, túnel, slalom, rampa, pneu e pódio. Os animais voltam muito mais contentes e os donos pagam mais.
- **Quartos novos**: vai ao quarto em obras 🏗️ e constrói-o.
- **🛠️ Melhorias → Ajudantes**: tratadores de comida, banhistas, animadores (também levam os animais ao parque) e rececionista.
- **🛠️ Melhorias → Ampliações**: Pavilhão Nascente e Pavilhão Poente (4 quartos cada, até 16 quartos), piscina no parque de acrobacias e luzes de festa (+10% à noite).
- **🛠️ Melhorias → O hotel**: camas melhores, doseador automático, fonte de água, publicidade, decoração e novos espaços.
- **⚙️ Opções**: escolhe entre 5 músicas (ou nenhuma) e ajusta o volume da música e dos efeitos. Os animais fazem sons de contentes e de tristes.
- **🏠 Telhados**: o hotel, a receção e os pavilhões têm telhado de telha com claraboia; desaparece quando aproximas a câmara e volta quando te afastas.
- **🏘️ Bairro**: estrada em anel com curvas mesmo à volta do hotel (avenida à frente, ruas dos lados e nas traseiras, por isso vês os carros a passar) e quatro ruas sem saída com praceta redonda. Cerca de 50 moradias portuguesas e algarvias (paredes caiadas ou pastel, barras coloridas, persianas, varandas, telhados de telha ou açoteias com chaminé algarvia, muros, sebes, palmeiras, garagens e azulejos), lojas na avenida, estacionamento e paragem de autocarro. Mais de 20 carros a circular sempre na estrada, nos dois sentidos (param para te deixar passar) e pessoas a passear, algumas com cão. Os donos chegam pelo passeio.
- **🗺️ Mapa**: minimapa no canto superior direito. Toca nele (ou em 🗺️) para abrir o mapa completo: arrasta para navegar, dois dedos ou + e − para o zoom, 📍 para te centrares. Os quartos aparecem com o animal e a cor do estado (verde contente, amarelo precisa de atenção, vermelho triste). Toca num sítio e usa **🚶 Ir para aqui** para lá chegares num instante.
- **🔊 Sons dos animais**: cada animal cumprimenta quando entras no quarto, faz sons de contente ou triste e ouve-se de mais longe. Em Opções há **Testar sons dos animais**.
- **🎥 Câmara 360°**: o botão 🎥 no topo troca entre vista de cima, terceira pessoa e primeira pessoa. Arrasta o dedo para olhar em todas as direções (esquerda, direita, cima e baixo). Em primeira pessoa, o botão 📱 deixa olhar à volta movendo o telemóvel (giroscópio).
- **🔍 Zoom e rotação**: dois dedos no ecrã ou os botões + e − para o zoom; arrasta um dedo no ecrã ou usa ⟲ ⟳ para rodar o mundo. O joystick segue a direção da câmara.
- **☀️ Céu**: céu em gradiente que muda com a hora, sol e lua a atravessar o céu (as sombras acompanham o sol), nuvens, bandos de pássaros, aviões com rasto, balão de ar quente, estrelas, estrelas cadentes e pirilampos no parque. Pássaros a cantar de dia e grilos à noite.
- **🌙 Dia e noite**: o hotel segue a hora do telemóvel. À noite acendem-se os candeeiros, as janelas e as luzes dos quartos, aparecem a lua e as estrelas e os animais dormem mais. Em Opções podes fixar sempre dia ou sempre noite.
- **✨ Gráficos** (Opções): *Alta* tem materiais realistas com reflexos, cor de cinema, sombras suaves, relva, nuvens e animais com modelos 3D animados; *Clássica* é o aspeto das versões anteriores; *Leve* é para telemóveis mais fracos. Os modelos 3D também se podem desligar.
- **🌍 Idiomas**: português, inglês e francês. O jogo escolhe sozinho o idioma do telemóvel; podes mudá-lo em ⚙️ Opções → Idioma, sem perder o progresso.
- **👕 Personagem**: muda a pele, o cabelo, a roupa e o chapéu quando quiseres.
- **🧍 Personagens realistas ou básicas** (⚙️ Opções → Personagens): *Realistas* têm corpo arredondado com joelhos e cotovelos, mãos, sapatos e rosto com olhos, sobrancelhas, nariz e orelhas; *Básicas* são os bonecos de blocos das versões anteriores, mais leves para telemóveis fracos. Aplica-se à tua personagem, aos donos, aos ajudantes e às pessoas na rua.

## Onde mexer

- O jogo todo está em `app/src/main/assets/index.html`.
- A app Android é só `MainActivity.java`, que abre o jogo num WebView em ecrã inteiro.
