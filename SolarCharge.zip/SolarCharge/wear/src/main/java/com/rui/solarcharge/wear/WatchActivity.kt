package com.rui.solarcharge.wear

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.rui.solarcharge.wear.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.PositionIndicator
import androidx.wear.compose.material.Scaffold
import androidx.wear.compose.material.TimeText
import androidx.wear.compose.material.Vignette
import androidx.wear.compose.material.VignettePosition
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.platform.LocalConfiguration
import androidx.wear.compose.material.Text

class WatchActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WatchState.load(this)
        WatchState.pull(this)
        WatchLink.hello(this)
        setContent { WatchApp() }
    }

    override fun onResume() { super.onResume(); WatchLink.hello(this) }
}

@Composable
fun WatchApp() {
    val ctx = LocalContext.current
    val s = WatchState.snap
    val sun = Color(0xFFFBBF24)
    val teal = Color(0xFF14B8A6)
    val w = LocalConfiguration.current.screenWidthDp
    val k = (w / 200f).coerceIn(0.85f, 1.3f)
    val side = (w * 0.10f).dp
    val listState = rememberScalingLazyListState()
    MaterialTheme {
      Scaffold(
        timeText = { TimeText() },
        vignette = { Vignette(vignettePosition = VignettePosition.TopAndBottom) },
        positionIndicator = { PositionIndicator(scalingLazyListState = listState) },
      ) {
        ScalingLazyColumn(
            state = listState,
            contentPadding = PaddingValues(top = (w * 0.17f).dp, bottom = (w * 0.17f).dp, start = side, end = side),
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (s.t == 0L) {
                item { Text(stringResource(R.string.waiting), textAlign = TextAlign.Center, fontSize = (13 * k).sp, modifier = Modifier) }
            } else {
                item { Text(WatchState.kw(s.pv), color = sun, fontSize = (30 * k).sp, fontWeight = FontWeight.Bold, maxLines = 1) }
                item {
                    val st = WatchState.stateLabel(ctx, s.st)
                    Text(
                        stringResource(R.string.car) + " " + WatchState.kwCar(s.car) + if (st.isNotEmpty()) " · $st" else "",
                        textAlign = TextAlign.Center, fontSize = (13 * k).sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        
                    )
                }
                if (s.house >= 0) item { Text(stringResource(R.string.house) + " " + WatchState.kw(s.house), fontSize = (12 * k).sp, color = Color(0xFF9AA4B2), maxLines = 1) }
                if (s.err.isNotEmpty()) item {
                    Text(stringResource(R.string.open_phone), color = Color(0xFFF87171), fontSize = (12 * k).sp, textAlign = TextAlign.Center, modifier = Modifier)
                } else if (s.msg.isNotEmpty()) item {
                    Text(s.msg, fontSize = (11 * k).sp, color = Color(0xFF9AA4B2), textAlign = TextAlign.Center, modifier = Modifier)
                }
            }
            listOf("solar", "minpv", "fast", "off").forEach { m ->
                item {
                    Chip(
                        onClick = { WatchLink.mode(ctx, m) },
                        label = { Text(WatchState.modeLabel(ctx, m), fontSize = (14 * k).sp, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                        colors = if (s.mode == m) ChipDefaults.primaryChipColors(backgroundColor = teal, contentColor = Color(0xFF06201C)) else ChipDefaults.secondaryChipColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
      }
    }
}
