package com.rui.solarcharge.wear

import android.app.PendingIntent
import android.content.Intent
import androidx.wear.watchface.complications.data.ComplicationData
import androidx.wear.watchface.complications.data.ComplicationType
import androidx.wear.watchface.complications.data.PlainComplicationText
import androidx.wear.watchface.complications.data.ShortTextComplicationData
import androidx.wear.watchface.complications.datasource.ComplicationRequest
import androidx.wear.watchface.complications.datasource.SuspendingComplicationDataSourceService
import java.util.Locale

/** Watch-face complication: current solar production (e.g. "3,2kW"). */
class PvComplication : SuspendingComplicationDataSourceService() {
    private fun build(text: String, title: String): ComplicationData {
        val open = PendingIntent.getActivity(this, 0, Intent(this, WatchActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return ShortTextComplicationData.Builder(PlainComplicationText.Builder(text).build(), PlainComplicationText.Builder("SolarCharge $text").build())
            .setTitle(PlainComplicationText.Builder(title).build())
            .setTapAction(open)
            .build()
    }

    override fun getPreviewData(type: ComplicationType): ComplicationData? =
        if (type == ComplicationType.SHORT_TEXT) build("3,2kW", "PV") else null

    override suspend fun onComplicationRequest(request: ComplicationRequest): ComplicationData? {
        if (request.complicationType != ComplicationType.SHORT_TEXT) return null
        WatchState.load(this)
        val w = WatchState.snap.pv
        val t = if (w < 1000) "${w}W" else String.format(Locale.getDefault(), "%.1fkW", w / 1000.0)
        return build(t, "PV")
    }
}
