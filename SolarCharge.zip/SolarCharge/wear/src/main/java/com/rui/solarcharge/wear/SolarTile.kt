package com.rui.solarcharge.wear

import androidx.wear.protolayout.ActionBuilders
import androidx.wear.protolayout.ColorBuilders.argb
import androidx.wear.protolayout.DimensionBuilders.dp
import androidx.wear.protolayout.DimensionBuilders.expand
import androidx.wear.protolayout.DimensionBuilders.sp
import androidx.wear.protolayout.DimensionBuilders.wrap
import androidx.wear.protolayout.LayoutElementBuilders
import androidx.wear.protolayout.LayoutElementBuilders.Box
import androidx.wear.protolayout.LayoutElementBuilders.Column
import androidx.wear.protolayout.LayoutElementBuilders.FontStyle
import androidx.wear.protolayout.LayoutElementBuilders.LayoutElement
import androidx.wear.protolayout.LayoutElementBuilders.Row
import androidx.wear.protolayout.LayoutElementBuilders.Spacer
import androidx.wear.protolayout.ModifiersBuilders.Background
import androidx.wear.protolayout.ModifiersBuilders.Clickable
import androidx.wear.protolayout.ModifiersBuilders.Corner
import androidx.wear.protolayout.ModifiersBuilders.Modifiers
import androidx.wear.protolayout.ModifiersBuilders.Padding
import androidx.wear.protolayout.ResourceBuilders
import androidx.wear.protolayout.TimelineBuilders
import androidx.wear.tiles.RequestBuilders
import androidx.wear.tiles.TileBuilders
import androidx.wear.tiles.TileService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/** Tile: solar production, car and four mode buttons. Tapping a button asks the phone to change mode. */
class SolarTile : TileService() {
    private var k = 1f
    private var wDp = 192

    override fun onTileRequest(requestParams: RequestBuilders.TileRequest): ListenableFuture<TileBuilders.Tile> {
        WatchState.load(this)
        wDp = requestParams.deviceConfiguration.screenWidthDp.takeIf { it > 0 } ?: 192
        k = (wDp / 192f).coerceIn(0.85f, 1.3f)
        val id = requestParams.currentState.lastClickableId
        if (id.startsWith("mode:")) WatchLink.mode(this, id.removePrefix("mode:"))
        val tile = TileBuilders.Tile.Builder()
            .setResourcesVersion("1")
            .setFreshnessIntervalMillis(300_000)
            .setTileTimeline(TimelineBuilders.Timeline.fromLayoutElement(layout()))
            .build()
        return Futures.immediateFuture(tile)
    }

    override fun onTileResourcesRequest(requestParams: RequestBuilders.ResourcesRequest): ListenableFuture<ResourceBuilders.Resources> =
        Futures.immediateFuture(ResourceBuilders.Resources.Builder().setVersion("1").build())

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false, lines: Int = 1): LayoutElement {
        val f = FontStyle.Builder().setSize(sp(size * k)).setColor(argb(color))
        if (bold) f.setWeight(LayoutElementBuilders.FONT_WEIGHT_BOLD)
        return LayoutElementBuilders.Text.Builder().setText(s).setMaxLines(lines)
            .setOverflow(LayoutElementBuilders.TEXT_OVERFLOW_ELLIPSIZE_END)
            .setMultilineAlignment(LayoutElementBuilders.TEXT_ALIGN_CENTER)
            .setFontStyle(f.build()).build()
    }

    private fun button(mode: String, selected: Boolean): LayoutElement {
        val mods = Modifiers.Builder()
            .setBackground(Background.Builder().setColor(argb(if (selected) 0xFF14B8A6.toInt() else 0xFF2A2F36.toInt()))
                .setCorner(Corner.Builder().setRadius(dp(16f * k)).build()).build())
            .setPadding(Padding.Builder().setAll(dp(4f * k)).build())
            .setClickable(Clickable.Builder().setId("mode:$mode").setOnClick(ActionBuilders.LoadAction.Builder().build()).build())
            .build()
        return Box.Builder().setWidth(expand()).setHeight(wrap())
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
            .setModifiers(mods)
            .addContent(text(WatchState.modeLabel(this, mode), 11f, if (selected) 0xFF06201C.toInt() else 0xFFFFFFFF.toInt(), true, 2))
            .build()
    }

    private fun gap(h: Float = 0f, w: Float = 0f): LayoutElement = Spacer.Builder().setHeight(dp(h)).setWidth(dp(w)).build()

    private fun row(a: LayoutElement, b: LayoutElement): LayoutElement =
        Row.Builder().setWidth(expand()).setHeight(wrap())
            .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
            .addContent(a).addContent(gap(w = 4f * k)).addContent(b).build()

    private fun layout(): LayoutElement {
        val s = WatchState.snap
        val st = WatchState.stateLabel(this, s.st)
        val car = getString(R.string.car) + " " + WatchState.kwCar(s.car) + if (st.isNotEmpty()) " · $st" else ""
        val top = if (s.t == 0L) text(getString(R.string.waiting), 12f, 0xFFFFFFFF.toInt(), lines = 3)
        else text(WatchState.kw(s.pv), 26f, 0xFFFBBF24.toInt(), true)
        val col = Column.Builder().setWidth(expand()).setHeight(wrap())
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .addContent(top)
        if (s.t != 0L) col.addContent(text(car, 12f, 0xFFFFFFFF.toInt(), lines = 2))
        if (s.err.isNotEmpty()) col.addContent(text(getString(R.string.open_phone), 10f, 0xFFF87171.toInt(), lines = 2))
        col.addContent(gap(h = 6f * k))
            .addContent(row(button("off", s.mode == "off"), button("solar", s.mode == "solar")))
            .addContent(gap(h = 4f * k))
            .addContent(row(button("minpv", s.mode == "minpv"), button("fast", s.mode == "fast")))
        return Box.Builder().setWidth(expand()).setHeight(expand())
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
            .setModifiers(Modifiers.Builder().setPadding(Padding.Builder().setAll(dp(wDp * 0.13f)).build()).build())
            .addContent(col.build()).build()
    }
}
