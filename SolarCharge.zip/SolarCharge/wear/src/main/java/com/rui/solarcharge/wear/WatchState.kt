package com.rui.solarcharge.wear

import android.content.ComponentName
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.wear.tiles.TileService
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceUpdateRequester
import com.google.android.gms.wearable.DataMap
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.Wearable
import java.util.Locale

/** Last state received from the phone. */
data class Snap(
    val pv: Int = 0, val car: Double = 0.0, val house: Int = -1, val bat: Int = -1, val st: String = "",
    val amps: Int = 0, val mode: String = "off", val msg: String = "", val err: String = "",
    val upd: String = "", val fc: Double = -1.0, val t: Long = 0L,
)

object WatchState {
    var snap by mutableStateOf(Snap())
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("watch", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        snap = Snap(p.getInt("pv", 0), p.getFloat("car", 0f).toDouble(), p.getInt("house", -1), p.getInt("bat", -1),
            p.getString("st", "") ?: "", p.getInt("amps", 0), p.getString("mode", "off") ?: "off", p.getString("msg", "") ?: "",
            p.getString("err", "") ?: "", p.getString("upd", "") ?: "", p.getFloat("fc", -1f).toDouble(), p.getLong("t", 0L))
    }

    private fun store(ctx: Context, s: Snap) {
        snap = s
        prefs(ctx).edit().putInt("pv", s.pv).putFloat("car", s.car.toFloat()).putInt("house", s.house).putInt("bat", s.bat)
            .putString("st", s.st).putInt("amps", s.amps).putString("mode", s.mode).putString("msg", s.msg).putString("err", s.err)
            .putString("upd", s.upd).putFloat("fc", s.fc.toFloat()).putLong("t", s.t).apply()
    }

    fun apply(ctx: Context, d: DataMap) {
        store(ctx, Snap(d.getInt("pv"), d.getDouble("car"), d.getInt("house", -1), d.getInt("bat", -1), d.getString("st", "") ?: "",
            d.getInt("amps"), d.getString("mode", "off") ?: "off", d.getString("msg", "") ?: "", d.getString("err", "") ?: "",
            d.getString("upd", "") ?: "", d.getDouble("fc", -1.0), d.getLong("t")))
        refreshSurfaces(ctx)
    }

    /** Shows the chosen mode at once; the phone confirms with the real state a moment later. */
    fun optimistic(ctx: Context, mode: String) { store(ctx, snap.copy(mode = mode, err = "")); }

    fun pull(ctx: Context) {
        try {
            Wearable.getDataClient(ctx).dataItems.addOnSuccessListener { buf ->
                try { for (it in buf) if (it.uri.path == "/state") apply(ctx, DataMapItem.fromDataItem(it).dataMap) } finally { buf.release() }
            }
        } catch (_: Throwable) {}
    }

    fun refreshSurfaces(ctx: Context) {
        try { TileService.getUpdater(ctx).requestUpdate(SolarTile::class.java) } catch (_: Throwable) {}
        try { ComplicationDataSourceUpdateRequester.create(ctx, ComponentName(ctx, PvComplication::class.java)).requestUpdateAll() } catch (_: Throwable) {}
    }

    fun kw(w: Int): String = if (w < 1000) "$w W" else String.format(Locale.getDefault(), "%.1f kW", w / 1000.0)
    fun kwCar(k: Double): String = String.format(Locale.getDefault(), "%.1f kW", k)

    fun stateLabel(ctx: Context, st: String): String {
        if (st.isBlank() || st == "—") return ""
        val id = ctx.resources.getIdentifier("st_$st", "string", ctx.packageName)
        return if (id != 0) ctx.getString(id) else st
    }

    fun modeLabel(ctx: Context, m: String): String {
        val id = ctx.resources.getIdentifier("m_$m", "string", ctx.packageName)
        return if (id != 0) ctx.getString(id) else m
    }
}

/** Commands to the phone. */
object WatchLink {
    private fun send(ctx: Context, path: String, data: ByteArray, done: (Boolean) -> Unit = {}) {
        try {
            Wearable.getNodeClient(ctx).connectedNodes.addOnSuccessListener { nodes ->
                if (nodes.isEmpty()) { done(false); return@addOnSuccessListener }
                nodes.forEach { Wearable.getMessageClient(ctx).sendMessage(it.id, path, data) }
                done(true)
            }.addOnFailureListener { done(false) }
        } catch (_: Throwable) { done(false) }
    }

    fun mode(ctx: Context, m: String) {
        WatchState.optimistic(ctx, m)
        send(ctx, "/mode", m.toByteArray()) { ok ->
            if (!ok) WatchState.snap = WatchState.snap.copy(err = "nophone")
        }
    }

    fun hello(ctx: Context) = send(ctx, "/hello", ByteArray(0))
}

class StateListener : com.google.android.gms.wearable.WearableListenerService() {
    override fun onDataChanged(events: com.google.android.gms.wearable.DataEventBuffer) {
        for (e in events) {
            if (e.dataItem.uri.path == "/state") WatchState.apply(this, DataMapItem.fromDataItem(e.dataItem).dataMap)
        }
    }
}
