plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.rui.solarcharge.wear"
    compileSdk = 34
    defaultConfig {
        // same applicationId and same signing key as the phone app: required for the Data Layer to link the two
        applicationId = "com.rui.solarcharge"
        minSdk = 30
        targetSdk = 34
        versionCode = 1050
        versionName = "3.17.2"
    }
    signingConfigs {
        create("release") {
            storeFile = file("../solarcharge.jks")
            storePassword = "HVLc6sk7Gku2O2vVRgwX"
            keyAlias = "solarcharge"
            keyPassword = "HVLc6sk7Gku2O2vVRgwX"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("release") }
        getByName("release") { signingConfig = signingConfigs.getByName("release"); isMinifyEnabled = false }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    buildFeatures { compose = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.wear.compose:compose-material:1.4.0")
    implementation("androidx.wear.compose:compose-foundation:1.4.0")
    implementation("androidx.wear.tiles:tiles:1.4.1")
    implementation("androidx.wear.protolayout:protolayout:1.2.1")
    implementation("androidx.wear.watchface:watchface-complications-data-source-ktx:1.2.1")
    implementation("com.google.android.gms:play-services-wearable:18.2.0")
    implementation("com.google.guava:guava:33.0.0-android")
}
