package com.rui.solarcharge

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

/** Hourly solar forecast from Open-Meteo (free, no key). Downloaded at most once an hour; the dashboard and the charging logic read it. */
object Forecast {
    private val http = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
    private var lastAt = 0L
    private var times = listOf<Long>()
    private var rad = listOf<Double>()
    private var cloud = listOf<Double>()
    @Volatile var ready = false
    private var kwp = 4.0
    private const val EFFICIENCY = 0.8       // base system efficiency (losses, temperature, inverter)
    /** Supplies the daily history (day -> [c,s,...]) used to calibrate the forecast against what the panels really produced. */
    @Volatile var histProvider: (() -> Map<String, DoubleArray>)? = null
    /** Correction factor learned from the last days (real solar / raw forecast); 1.0 when there is not enough data. */
    @Volatile var calib = 1.0
    @Volatile var calibDays = 0

    private fun learn() {
        val h = try { histProvider?.invoke() } catch (_: Exception) { null } ?: return
        if (times.isEmpty() || rad.size != times.size || kwp <= 0) return
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayStr = fmt.format(Date())
        val raw = HashMap<String, Double>(); val cnt = HashMap<String, Int>()
        for (i in times.indices) {
            val d = fmt.format(Date(times[i]))
            raw[d] = (raw[d] ?: 0.0) + rad[i] / 1000.0 * kwp * EFFICIENCY
            cnt[d] = (cnt[d] ?: 0) + 1
        }
        val ratios = ArrayList<Double>()
        for ((d, r) in raw) {
            if (d >= todayStr || (cnt[d] ?: 0) < 24 || r < 2.0) continue   // whole past days with some sun only
            val real = h[d]?.getOrNull(1) ?: continue
            if (real < 1.0) continue
            ratios.add(real / r)
        }
        if (ratios.size < 3) { calib = 1.0; calibDays = 0; return }
        ratios.sort()
        val med = if (ratios.size % 2 == 1) ratios[ratios.size / 2] else (ratios[ratios.size / 2 - 1] + ratios[ratios.size / 2]) / 2
        calib = med.coerceIn(0.7, 1.8); calibDays = ratios.size
        ApiLog.i("Forecast", "Calibração ×${String.format(Locale.US, "%.2f", calib)} com ${ratios.size} dias")
    }

    /** Installed power in kWp from the settings; a value above 100 is taken as watts (4000 -> 4 kWp). */
    fun kwpOf(c: Cfg): Double {
        val v = c.get("kwp").replace(',', '.').toDoubleOrNull()?.takeIf { it > 0 } ?: return 4.0
        return if (v > 100) v / 1000.0 else v
    }

    fun currentKwp(): Double = kwp

    private fun clear() {
        ready = false
        Live.fcOutlook = ""; Live.fcCloud = -1; Live.fcBars = emptyList(); Live.fcTrend = ""
        Live.fcKwh = emptyList(); Live.fcKwhRest = -1.0; Live.fcKwhToday = -1.0; Live.fcKwhTomorrow = -1.0
    }

    fun refresh(c: Cfg) {
        if (c.get("useForecast", "1") == "0") { clear(); return }
        kwp = kwpOf(c)
        val lat = c.get("lat").replace(',', '.').toDoubleOrNull()
        val lon = c.get("lon").replace(',', '.').toDoubleOrNull()
        if (lat == null || lon == null) { clear(); return }
        val now = System.currentTimeMillis()
        if (times.isEmpty() || now - lastAt >= 3_600_000L) {
            lastAt = now
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&hourly=shortwave_radiation,cloud_cover&forecast_days=7&past_days=14&timezone=auto"
                http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    val body = r.body?.string() ?: ""
                    if (!r.isSuccessful) {
                        ApiLog.e("Forecast", "HTTP ${r.code} · ${body.take(150)}")
                        lastAt = now - 50 * 60_000L   // try again in 10 min
                        return@use
                    }
                    val h = JSONObject(body).getJSONObject("hourly")
                    val t = h.getJSONArray("time")
                    val sr = h.getJSONArray("shortwave_radiation")
                    val cc = h.getJSONArray("cloud_cover")
                    val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US)
                    val tt = ArrayList<Long>(); val rr = ArrayList<Double>(); val cl = ArrayList<Double>()
                    for (i in 0 until t.length()) {
                        val ts = f.parse(t.getString(i))?.time ?: continue
                        tt.add(ts); rr.add(sr.optDouble(i, 0.0)); cl.add(cc.optDouble(i, 0.0))
                    }
                    times = tt; rad = rr; cloud = cl
                    ApiLog.i("Forecast", "Open-Meteo: ${tt.size} horas recebidas")
                }
            } catch (e: Exception) {
                ApiLog.e("Forecast", "${e.javaClass.simpleName}: ${e.message}")
                lastAt = now - 50 * 60_000L
            }
        }
        learn()
        compute(now)
    }

    private fun compute(now: Long) {
        val hourStart = now - now % 3_600_000L
        val i0 = times.indexOfFirst { it >= hourStart }
        if (i0 < 0 || rad.size != times.size) { clear(); return }
        val cur = rad[i0]
        val nextVals = (1..2).mapNotNull { rad.getOrNull(i0 + it) }
        val next2 = if (nextVals.isEmpty()) cur else nextVals.average()
        val end = minOf(i0 + 10, rad.size)
        Live.fcBars = (i0 until end).map { (rad[it] / 900.0).coerceIn(0.0, 1.0).toFloat() }
        // expected production in kWh: kWp x radiation (kW/m2) x efficiency, one-hour slots
        fun kwhAt(i: Int) = rad[i] / 1000.0 * kwp * EFFICIENCY * calib
        Live.fcKwh = (i0 until end).map { kwhAt(it) }
        fun dayKey(ts: Long) = Calendar.getInstance().apply { timeInMillis = ts }.let { it.get(Calendar.YEAR) * 1000 + it.get(Calendar.DAY_OF_YEAR) }
        val today = dayKey(now)
        val tomorrow = dayKey(now + 86_400_000L)
        val minutesLeft = 60 - ((now - hourStart) / 60_000L).toInt()      // the running hour only counts for what is left of it
        var rest = 0.0; var whole = 0.0; var tom = 0.0; var tomHours = 0
        for (i in times.indices) {
            val k = dayKey(times[i])
            if (k == today) { whole += kwhAt(i); if (i == i0) rest += kwhAt(i) * minutesLeft / 60.0 else if (i > i0) rest += kwhAt(i) }
            else if (k == tomorrow) { tom += kwhAt(i); tomHours++ }
        }
        Live.fcKwhRest = rest; Live.fcKwhToday = whole; Live.fcKwhTomorrow = if (tomHours >= 20) tom else -1.0
        val cal = Calendar.getInstance().apply { timeInMillis = times[i0] }
        Live.fcStartHour = cal.get(Calendar.HOUR_OF_DAY)
        val sunny = (i0 until minOf(i0 + 8, rad.size)).filter { rad[it] > 20 }
        if (sunny.isEmpty()) {
            Live.fcOutlook = "night"; Live.fcCloud = -1
        } else {
            val avg = sunny.map { cloud[it] }.average()
            Live.fcCloud = avg.toInt()
            Live.fcOutlook = if (avg < 35) "good" else if (avg < 70) "mixed" else "poor"
        }
        Live.fcTrend = when {
            cur > 80 && next2 < 0.6 * cur -> "down"
            next2 > 100 && next2 > 1.3 * maxOf(cur, 50.0) -> "up"
            else -> ""
        }
        ready = true
    }

    /** Expected solar energy (kWh) that the car could use between winStartMin and winEndMin, dayOffset days from today (0 = today, 1 = tomorrow). */
    fun solarKwhForCar(kwp: Double, winStartMin: Int, winEndMin: Int, dayOffset: Int, carMaxKw: Double, houseKw: Double): Double? {
        if (!ready || times.isEmpty()) return null
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, dayOffset)
        val y = cal.get(Calendar.YEAR); val d = cal.get(Calendar.DAY_OF_YEAR)
        var sum = 0.0; var hours = 0
        for (i in times.indices) {
            val c2 = Calendar.getInstance().apply { timeInMillis = times[i] }
            if (c2.get(Calendar.YEAR) != y || c2.get(Calendar.DAY_OF_YEAR) != d) continue
            val m = c2.get(Calendar.HOUR_OF_DAY) * 60
            if (m < winStartMin || m >= winEndMin) continue
            hours++
            val pvKw = rad[i] / 1000.0 * kwp * EFFICIENCY * calib
            sum += (pvKw - houseKw).coerceIn(0.0, carMaxKw)       // one-hour slot -> kWh
        }
        return if (hours == 0) null else sum
    }

    /** One forecast day: radiation, expected kWh and cloud cover per hour of the day (24 values), the day's total and mean cloud cover while the sun is up. */
    class FcDay(val dateMs: Long, val rad: List<Double>, val kwh: List<Double>, val cloud: Double, val total: Double)

    /** Number of whole days available (today included). */
    fun daysAvailable(): Int {
        if (!ready) return 0
        val start = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        return (times.count { it >= start } / 24).coerceAtMost(7)
    }

    fun day(offset: Int): FcDay? {
        if (!ready || times.isEmpty() || rad.size != times.size) return null
        val target = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, offset) }
        val y = target.get(Calendar.YEAR); val d = target.get(Calendar.DAY_OF_YEAR)
        val r = DoubleArray(24); val cl = DoubleArray(24); var n = 0
        for (i in times.indices) {
            val c2 = Calendar.getInstance().apply { timeInMillis = times[i] }
            if (c2.get(Calendar.YEAR) != y || c2.get(Calendar.DAY_OF_YEAR) != d) continue
            val h = c2.get(Calendar.HOUR_OF_DAY)
            r[h] = rad[i]; cl[h] = cloud[i]; n++
        }
        if (n < 20) return null
        val kwh = r.map { it / 1000.0 * kwp * EFFICIENCY * calib }
        val sunny = (0..23).filter { r[it] > 20 }
        return FcDay(target.timeInMillis, r.toList(), kwh, if (sunny.isEmpty()) -1.0 else sunny.map { cl[it] }.average(), kwh.sum())
    }
}
