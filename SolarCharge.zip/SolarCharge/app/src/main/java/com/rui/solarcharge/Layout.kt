package com.rui.solarcharge

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Which cards are collapsed and in which order each tab shows its cards (saved in the settings). */
object Layout {
    private var cfg: Cfg? = null
    val collapsed = mutableStateListOf<String>()
    /** Cards the user chose to hide (shown dimmed, with an eye button, only while arranging). */
    val hidden = mutableStateListOf<String>()
    fun toggleHidden(id: String) {
        if (!hidden.remove(id)) hidden.add(id)
        cfg?.set("hidden", hidden.joinToString(","))
    }
    private val orders = mutableStateMapOf<String, List<String>>()
    var arrange by mutableStateOf(false)
    val allTabs = listOf("dash", "tesla", "hist", "set", "donate", "log")
    /** Order of the bottom tabs (saved in "tabOrder"). */
    val tabOrder = mutableStateListOf<String>().also { it.addAll(allTabs) }

    fun loadTabs(c: Cfg) {
        val saved = c.get("tabOrder").split(",").filter { it in allTabs }.distinct()
        tabOrder.clear(); tabOrder.addAll(saved + allTabs.filter { it !in saved })
    }

    fun moveTab(id: String, delta: Int) {
        val i = tabOrder.indexOf(id); val j = i + delta
        if (i < 0 || j < 0 || j >= tabOrder.size) return
        val t = tabOrder[i]; tabOrder[i] = tabOrder[j]; tabOrder[j] = t
        cfg?.set("tabOrder", tabOrder.joinToString(","))
    }

    /** Tabs shown in the bottom bar, in the chosen order (the Log tab only when enabled). */
    fun visibleTabs(): List<String> = tabOrder.filter { it != "log" || Live.showLog }
    /** Card ids currently shown by each tab (filled by Blocks). */
    val shown = HashMap<String, List<String>>()

    fun allCollapsed(tab: String): Boolean = shown[tab].orEmpty().let { it.isNotEmpty() && it.all { id -> id in collapsed } }

    /** Collapses every card of the tab, or expands them all when they are already all collapsed. */
    fun toggleAll(tab: String) {
        val ids = shown[tab].orEmpty()
        if (allCollapsed(tab)) collapsed.removeAll(ids.toSet()) else ids.forEach { if (it !in collapsed) collapsed.add(it) }
        cfg?.set("collapsed", collapsed.joinToString(","))
    }

    fun init(c: Cfg) {
        cfg = c
        loadTabs(c)
        collapsed.clear(); collapsed.addAll(c.get("collapsed").split(",").filter { it.isNotBlank() })
        hidden.clear(); hidden.addAll(c.get("hidden").split(",").filter { it.isNotBlank() })
        listOf("dash", "tesla", "hist", "set").forEach { t -> orders[t] = c.get("order_$t").split(",").filter { it.isNotBlank() } }
        if (c.get("histInit312").isBlank()) {          // the backup card starts collapsed to keep History simple
            if ("hist_backup" !in collapsed) collapsed.add("hist_backup")
            c.set("collapsed", collapsed.joinToString(",")); c.set("histInit312", "1")
        }
    }

    fun toggle(id: String) {
        if (!collapsed.remove(id)) collapsed.add(id)
        cfg?.set("collapsed", collapsed.joinToString(","))
    }

    /** Default order of each tab's cards (what feels most natural); the user's own order, when saved, wins. */
    val defaults = mapOf(
        "dash" to listOf("flow_title", "ctrl_title", "card_tesla", "card_today", "fc_title"),
        "tesla" to listOf("tsl_battery", "tsl_session", "tsl_ctrl", "tsl_actions", "tsl_climate", "tsl_stats", "tsl_vehicle", "tsl_tires", "tsl_location"),
        "hist" to listOf("hist_chart", "hist_summary", "hist_cal", "sess_title", "hist_hours", "hist_self", "hist_tesla", "hist_car", "hist_records", "hist_lifetime", "hist_backup"),
        "set" to listOf("sec_conn", "sec_local", "sec_charge", "sec_target", "sec_schedule", "sec_tariff", "sec_forecast", "sec_notify", "sec_system", "sec_chat", "sec_look", "sec_lang", "sec_tabs", "sec_backup", "sec_manual")
    )

    fun ordered(tab: String, idsIn: List<String>): List<String> {
        val def = defaults[tab].orEmpty()
        val ids = def.filter { it in idsIn } + idsIn.filter { it !in def }
        val saved = orders[tab] ?: emptyList()
        val res = saved.filter { it in ids }.distinct().toMutableList()
        // cards the saved order doesn't know yet (added by an update) go right after their default predecessor
        ids.forEachIndexed { i, id ->
            if (id in saved) return@forEachIndexed
            val prev = ids.take(i).lastOrNull { it in res }
            res.add(if (prev == null) 0 else res.indexOf(prev) + 1, id)
        }
        return res
    }

    fun move(tab: String, ids: List<String>, id: String, delta: Int) {
        val cur = ids.toMutableList()
        val i = cur.indexOf(id); val j = i + delta
        if (i < 0 || j < 0 || j >= cur.size) return
        val t = cur[i]; cur[i] = cur[j]; cur[j] = t
        orders[tab] = cur
        cfg?.set("order_$tab", cur.joinToString(","))
    }

    private fun loadTabsReset() { tabOrder.clear(); tabOrder.addAll(allTabs) }

    fun reset() {
        collapsed.clear(); hidden.clear(); orders.keys.toList().forEach { orders[it] = emptyList() }
        loadTabsReset()
        cfg?.let { c -> c.set("collapsed", ""); c.set("hidden", ""); c.set("tabOrder", ""); listOf("dash", "tesla", "hist", "set").forEach { c.set("order_$it", "") } }
    }
}

val LocalTab = compositionLocalOf { "" }
val LocalIds = compositionLocalOf { emptyList<String>() }

class BlockScope {
    val items = mutableListOf<Pair<String, @Composable () -> Unit>>()
    fun block(id: String, content: @Composable () -> Unit) { items.add(id to content) }
}

/** Shows the blocks of a tab in the order the user chose. Each block id must be the id of its Panel. */
@Composable
fun Blocks(tab: String, build: BlockScope.() -> Unit) {
    val scope = BlockScope().apply(build)
    val ordered = Layout.ordered(tab, scope.items.map { it.first })
    SideEffect { Layout.shown[tab] = ordered }
    CompositionLocalProvider(LocalTab provides tab, LocalIds provides ordered) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            ordered.forEach { id ->
                val hid = id in Layout.hidden
                if (!hid || Layout.arrange) key(id) {
                    Box(Modifier.fillMaxWidth().then(if (hid) Modifier.alpha(0.4f) else Modifier)) {
                        scope.items.firstOrNull { it.first == id }?.second?.invoke()
                    }
                }
            }
        }
    }
}

/** Card. With an id and a title it gets a header: tap to collapse/expand; in arrange mode it shows up/down arrows. */
@Composable
fun Panel(modifier: Modifier = Modifier.fillMaxWidth(), id: String? = null, title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val tab = LocalTab.current
    val ids = LocalIds.current
    val collapsible = id != null && title != null
    val collapsed = collapsible && id in Layout.collapsed
    Card(
        modifier = modifier, shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
    ) {
        Column(Modifier.padding(20.dp)) {
            if (collapsible) {
                val tc = LocalTitleColors.current
                val c = tc[(id!!.hashCode() and 0x7fffffff) % tc.size]
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(enabled = !Layout.arrange) { Layout.toggle(id) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.width(5.dp).height(22.dp).clip(RoundedCornerShape(3.dp)).background(c))
                    Spacer(Modifier.width(10.dp))
                    Text(title!!, Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    if (Layout.arrange) {
                        Text(if (id in Layout.hidden) "🚫" else "👁", Modifier.clip(RoundedCornerShape(8.dp)).clickable { Layout.toggleHidden(id) }.padding(horizontal = 10.dp, vertical = 6.dp), fontSize = 18.sp)
                        Text("▲", Modifier.clip(RoundedCornerShape(8.dp)).clickable { Layout.move(tab, ids, id, -1) }.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 18.sp)
                        Text("▼", Modifier.clip(RoundedCornerShape(8.dp)).clickable { Layout.move(tab, ids, id, 1) }.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 18.sp)
                    } else {
                        Text(if (collapsed) "▾" else "▴", Modifier.padding(horizontal = 8.dp), fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
                    }
                }
                if (!collapsed) Spacer(Modifier.height(8.dp))
            }
            AnimatedVisibility(visible = !collapsed) { Column(content = content) }
        }
    }
}

@Composable
fun ArrangeToggle(tab: String = "") {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (tab.isNotEmpty() && !Layout.arrange) TextButton({ Layout.toggleAll(tab) }, contentPadding = PaddingValues(horizontal = 8.dp)) {
            Text(if (Layout.allCollapsed(tab)) "⊞" else "⊟", fontSize = 22.sp)
        }
        TextButton({ Layout.arrange = !Layout.arrange }) {
            Text(if (Layout.arrange) L.t("arr_done") else "⇅ " + L.t("arr_edit"))
        }
    }
}

/** Scroll position of each tab, kept while the app runs so that switching tabs does not send the user back to the top. */
private val tabScrolls = HashMap<String, ScrollState>()
fun tabScroll(tab: String): ScrollState = tabScrolls.getOrPut(tab) { ScrollState(0) }

/** History choices kept between tab switches. */
object HistUi {
    var mode = "month"
    var metric = 0
    var cumulative = false
    var ym: java.time.YearMonth? = null
    var year: Int? = null
}
