package com.rui.solarcharge

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// canonical PayPal.Me address (paypal.me/... redirects here and a redirect can drop the amount)
private const val PAYPAL = "https://www.paypal.com/paypalme/ruivascoamaro"

@Composable
fun DonateScreen() {
    val ctx = LocalContext.current
    val presets = listOf(2, 5, 10, 20, 50)
    var preset by remember { mutableStateOf<Int?>(5) }
    var custom by remember { mutableStateOf("") }

    val amount: Double? = if (custom.isNotBlank()) custom.replace(',', '.').toDoubleOrNull()?.takeIf { it > 0 && it <= 5000 } else preset?.toDouble()

    Column(
        Modifier.fillMaxSize().verticalScroll(tabScroll("donate")).padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(L.t("don_title"), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Panel {
            Text("❤️  " + L.t("don_headline"), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Label(L.t("don_text"))
        }
        Panel {
            PanelTitle(L.t("don_choose"), "don_choose")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { v ->
                    FilterChip(selected = custom.isBlank() && preset == v, onClick = { preset = v; custom = "" }, label = { Text("$v €") })
                }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = custom, onValueChange = { custom = it; if (it.isNotBlank()) preset = null },
                label = { Text(L.t("don_other")) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                isError = custom.isNotBlank() && amount == null
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    val a = amount ?: return@Button
                    val txt = if (a == Math.floor(a)) a.toInt().toString() else String.format(java.util.Locale.US, "%.2f", a)
                    val uri = Uri.parse("$PAYPAL/${txt}EUR")
                    try {
                        // open in the browser (the PayPal app tends to ignore the amount in the link)
                        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
                        i.data = uri; i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ctx.startActivity(i)
                    } catch (e: Exception) {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        catch (e2: Exception) { Toast.makeText(ctx, L.t("don_fail"), Toast.LENGTH_LONG).show() }
                    }
                },
                enabled = amount != null, modifier = Modifier.fillMaxWidth()
            ) { Text(if (amount != null) L.t("don_button", L.n(amount, if (amount == Math.floor(amount)) 0 else 2)) else L.t("don_button_none")) }
            Spacer(Modifier.height(6.dp))
            Label(L.t("don_note"))
        }
    }
}
