package com.rui.solarcharge

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import androidx.compose.ui.graphics.toArgb

/** Draws the energy-flow diamond (Solar top, Home left, Tesla right, Grid bottom) as a bitmap for the home-screen widget. */
object WidgetFlow {
    private const val S = 320
    private const val R = 30f
    private val GREEN = 0xFF3DDC84.toInt()
    private val ORANGE = 0xFFE8A53A.toInt()

    private fun kw(w: Double) = L.n(w / 1000.0, 1) + " kW"

    fun render(ctx: android.content.Context): Bitmap {
        val iconSet = Cfg(ctx).get("iconSet", "line")
        val bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val running = Live.running
        val pvW = if (running) Live.pvW else 0.0
        val carW = if (running) Live.teslaKw * 1000.0 else 0.0
        val known = running && Live.houseW >= 0
        val houseW = if (known) maxOf(Live.houseW - carW, 0.0) else 0.0
        val solarCar = minOf(carW, pvW)
        val solarHouse = if (known) minOf(houseW, maxOf(pvW - solarCar, 0.0)) else 0.0
        val gridCar = if (known) carW - solarCar else 0.0
        val gridHouse = if (known) houseW - solarHouse else 0.0
        val importW = gridCar + gridHouse
        val exportW = if (known) maxOf(pvW - solarCar - solarHouse, 0.0) else 0.0
        val on = 50.0

        val sun = 160f to 52f; val home = 58f to 160f; val car = 262f to 160f; val grid = 160f to 268f

        fun line(a: Pair<Float, Float>, b: Pair<Float, Float>, active: Boolean, col: Int) {
            val dx = b.first - a.first; val dy = b.second - a.second
            val len = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            val ux = dx / len; val uy = dy / len
            val gap = R - 8f
            val x1 = a.first + ux * gap; val y1 = a.second + uy * gap
            val x2 = b.first - ux * gap; val y2 = b.second - uy * gap
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; style = Paint.Style.STROKE }
            if (active) {
                p.color = (col and 0x00FFFFFF) or 0x38000000; p.strokeWidth = 14f; cv.drawLine(x1, y1, x2, y2, p)
                p.color = col; p.strokeWidth = 6f; cv.drawLine(x1, y1, x2, y2, p)
                // arrow head near the target end
                val ax = b.first - ux * (R + 1f); val ay = b.second - uy * (R + 1f)
                val path = Path().apply {
                    moveTo(ax, ay)
                    lineTo(ax - ux * 18f - uy * 10f, ay - uy * 18f + ux * 10f)
                    lineTo(ax - ux * 18f + uy * 10f, ay - uy * 18f - ux * 10f)
                    close()
                }
                cv.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; style = Paint.Style.FILL })
            } else {
                p.color = 0x30FFFFFF; p.strokeWidth = 5f; cv.drawLine(x1, y1, x2, y2, p)
            }
        }
        val circles = Path().apply { listOf(sun, home, car, grid).forEach { addCircle(it.first, it.second, R, Path.Direction.CW) } }
        cv.save()
        cv.clipPath(circles, android.graphics.Region.Op.DIFFERENCE)   // lines end flush with the circle edge
        line(sun, home, solarHouse > on, GREEN)
        line(sun, car, solarCar > on, GREEN)
        line(grid, home, gridHouse > on, ORANGE)
        line(grid, car, gridCar > on, ORANGE)
        cv.restore()

        val emoji = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 34f; textAlign = Paint.Align.CENTER }
        fun node(p: Pair<Float, Float>, icon: String, active: Boolean, col: Int) {
            cv.drawCircle(p.first, p.second, R, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (active) (col and 0x00FFFFFF) or 0x40000000 else 0x1FFFFFFF; style = Paint.Style.FILL })
            cv.drawCircle(p.first, p.second, R, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (active) col else 0x40FFFFFF; style = Paint.Style.STROKE; strokeWidth = 3f })
            if (iconSet == "emoji") cv.drawText(icon, p.first, p.second + 12f, emoji)
            else {
                val kind = FlowIcons.kindOf(icon)
                val base = FlowIcons.color(kind, androidx.compose.ui.graphics.Color(GREEN), androidx.compose.ui.graphics.Color(ORANGE)).toArgb()
                FlowIcons.drawAndroid(cv, kind, iconSet, p.first, p.second, 38f, if (active) base else (base and 0x00FFFFFF) or 0x80000000.toInt())
            }
        }
        node(sun, "☀️", pvW > on, GREEN)
        node(home, "🏠", (solarHouse + gridHouse) > on, GREEN)
        node(car, "🚗", carW > on, GREEN)
        node(grid, "⚡", importW > on || exportW > on, ORANGE)

        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = 27f; typeface = Typeface.DEFAULT_BOLD }
        fun text(s: String, x: Float, y: Float, align: Paint.Align) { txt.textAlign = align; cv.drawText(s, x, y, txt) }
        text(kw(pvW), sun.first + R + 8f, sun.second + 9f, Paint.Align.LEFT)
        text(if (known) kw(houseW) else "—", 2f, home.second + R + 30f, Paint.Align.LEFT)
        text(kw(carW), S - 2f, car.second + R + 30f, Paint.Align.RIGHT)
        val g = if (!known) "—" else if (exportW > on) "↑ " + kw(exportW) else if (importW > on) "↓ " + kw(importW) else kw(0.0)
        text(g, grid.first + R + 8f, grid.second + 9f, Paint.Align.LEFT)
        return bmp
    }
}
