package com.rui.solarcharge

import android.Manifest
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List as ListIcon
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.YearMonth
import java.util.Locale

class Scheme(
    val key: String, val primary: Color, val titles: List<Color>,
    val lightBg: Color, val lightSurface: Color, val lightVar: Color,
    val darkBg: Color, val darkSurface: Color, val darkVar: Color
)

val Schemes = listOf(
    Scheme("green", Color(0xFF2E9E5B),
        listOf(Color(0xFF2E9E5B), Color(0xFFE8A53A), Color(0xFF3B82F6), Color(0xFF8B5CF6), Color(0xFFEF5B8A), Color(0xFF14B8A6), Color(0xFFF08A24)),
        Color(0xFFF2F6F4), Color.White, Color(0xFFE3ECE7), Color(0xFF0E1412), Color(0xFF17221E), Color(0xFF22302A)),
    Scheme("blue", Color(0xFF2F6FED),
        listOf(Color(0xFF2F6FED), Color(0xFF06B6D4), Color(0xFF6366F1), Color(0xFF0EA5E9), Color(0xFF14B8A6), Color(0xFF8B5CF6), Color(0xFF3B82F6)),
        Color(0xFFF1F5FB), Color.White, Color(0xFFE2EAF6), Color(0xFF0C1220), Color(0xFF151E33), Color(0xFF212C47)),
    Scheme("orange", Color(0xFFF08A24),
        listOf(Color(0xFFF08A24), Color(0xFFE5484D), Color(0xFFF5B83D), Color(0xFFD9622B), Color(0xFFC2410C), Color(0xFFEAB308), Color(0xFFEF6C57)),
        Color(0xFFFBF5EE), Color.White, Color(0xFFF3E6D6), Color(0xFF17110B), Color(0xFF241A11), Color(0xFF35271A)),
    Scheme("purple", Color(0xFF7B4FD6),
        listOf(Color(0xFF7B4FD6), Color(0xFFD946EF), Color(0xFF6366F1), Color(0xFFA855F7), Color(0xFFEC4899), Color(0xFF8B5CF6), Color(0xFF5B6CF0)),
        Color(0xFFF6F3FB), Color.White, Color(0xFFEAE3F6), Color(0xFF130F1E), Color(0xFF1D1830), Color(0xFF2B2445)),
    Scheme("rose", Color(0xFFE0457B),
        listOf(Color(0xFFE0457B), Color(0xFFF59E0B), Color(0xFFBE185D), Color(0xFFFB7185), Color(0xFF9333EA), Color(0xFFF97316), Color(0xFFDB2777)),
        Color(0xFFFBF3F6), Color.White, Color(0xFFF4E3EA), Color(0xFF1A0F14), Color(0xFF26171E), Color(0xFF38232D)),
    Scheme("graphite", Color(0xFF475569),
        listOf(Color(0xFF475569), Color(0xFF0EA5E9), Color(0xFF64748B), Color(0xFF14B8A6), Color(0xFF94A3B8), Color(0xFF6366F1), Color(0xFF0F766E)),
        Color(0xFFF3F4F6), Color.White, Color(0xFFE5E7EB), Color(0xFF0F1115), Color(0xFF191C22), Color(0xFF262A32))
)

fun schemeOf(key: String) = if (key == "custom") Look.customScheme() else Schemes.firstOrNull { it.key == key } ?: Schemes[0]

val LocalTitleColors = staticCompositionLocalOf { Schemes[0].titles }

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        val cfg = Cfg(this)
        val hist = History(this)
        ApiLog.init(applicationContext)
        CarStats.init(applicationContext)
        L.init(cfg)
        Layout.init(cfg)
        Look.load(cfg)
        Live.showLog = cfg.get("showLog", "1") != "0"
        setContent {
            var mode by remember { mutableStateOf(cfg.get("theme", "system")) }
            var accent by remember { mutableStateOf(cfg.get("accent", "green")) }
            val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
            val sch = schemeOf(accent)
            val col = sch.primary
            val scheme = if (dark)
                darkColorScheme(primary = col, background = sch.darkBg, surface = sch.darkSurface, surfaceVariant = sch.darkVar)
            else
                lightColorScheme(primary = col, background = sch.lightBg, surface = sch.lightSurface, surfaceVariant = sch.lightVar)
            CompositionLocalProvider(LocalTitleColors provides sch.titles) {
            MaterialTheme(colorScheme = scheme, typography = Look.typography()) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(col.copy(alpha = if (dark) 0.22f else 0.16f), Color.Transparent), endY = 1100f)))
                    App(cfg, hist, mode, accent, { mode = it; cfg.set("theme", it) }, { accent = it; cfg.set("accent", it) })
                }
            }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(cfg: Cfg, hist: History, mode: String, accent: String, onMode: (String) -> Unit, onAccent: (String) -> Unit) {
    var tab by remember { mutableStateOf("dash") }
    val tabs = Layout.visibleTabs()
    val cur = if (tab in tabs) tab else tabs.first()
    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEach { id ->
                    NavigationBarItem(cur == id, { tab = id }, { TabIcon(id, cur == id) }, label = { FitText(L.t(navKey(id)), fontSize = 10.sp, minSize = 6.sp, textAlign = TextAlign.Center) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            var refreshing by remember { mutableStateOf(false) }
            PullToRefreshBox(
                isRefreshing = refreshing,
                onRefresh = {
                    refreshing = true
                    Thread {
                        try { refreshAll(cfg) } catch (_: Exception) {}
                        android.os.Handler(android.os.Looper.getMainLooper()).post { refreshing = false }
                    }.start()
                },
                modifier = Modifier.fillMaxSize().pointerInput(tabs, cur) {
                    // swipe left / right to move between tabs (children that handle horizontal drags, such as sliders, get the gesture first)
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = {
                            val i = tabs.indexOf(cur)
                            if (total < -140f && i < tabs.size - 1) tab = tabs[i + 1]
                            else if (total > 140f && i > 0) tab = tabs[i - 1]
                        }
                    ) { _, dx -> total += dx }
                }
            ) {
            AnimatedContent(
                targetState = cur, label = "tab",
                transitionSpec = {
                    val fwd = tabs.indexOf(targetState) > tabs.indexOf(initialState)
                    val d = Look.durationMs()
                    when (Look.transition) {
                        "fade" -> fadeIn(tween(d)) togetherWith fadeOut(tween(d))
                        "zoom" -> (scaleIn(tween(d), initialScale = 0.88f) + fadeIn(tween(d))) togetherWith
                            (scaleOut(tween(d), targetScale = 1.08f) + fadeOut(tween(d)))
                        "vertical" -> (slideInVertically(tween(d)) { if (fwd) it / 4 else -it / 4 } + fadeIn(tween(d))) togetherWith
                            (slideOutVertically(tween(d)) { if (fwd) -it / 4 else it / 4 } + fadeOut(tween(d)))
                        "none" -> EnterTransition.None togetherWith ExitTransition.None
                        else ->
                            if (fwd)
                                slideInHorizontally(tween(d)) { it / 4 } + fadeIn(tween(d)) togetherWith
                                    slideOutHorizontally(tween(d)) { -it / 4 } + fadeOut(tween(d * 2 / 3))
                            else
                                slideInHorizontally(tween(d)) { -it / 4 } + fadeIn(tween(d)) togetherWith
                                    slideOutHorizontally(tween(d)) { it / 4 } + fadeOut(tween(d * 2 / 3))
                    }
                }
            ) { t ->
                when (t) {
                    "dash" -> Dashboard(hist, cfg)
                    "tesla" -> TeslaScreen(cfg)
                    "hist" -> HistoryScreen(hist)
                    "set" -> SettingsScreen(cfg, mode, accent, onMode, onAccent)
                    "donate" -> DonateScreen()
                    else -> LogScreen(cfg)
                }
            }
            }
            ChatFab(cfg, hist, Modifier.fillMaxSize())
        }
    }
}


/** Block title with a coloured bar. The colour comes from a stable key so it does not change with the language. */
@Composable
fun PanelTitle(text: String, key: String = text) {
    val tc = LocalTitleColors.current
    val c = tc[(key.hashCode() and 0x7fffffff) % tc.size]
    Row(Modifier.padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(5.dp).height(22.dp).clip(RoundedCornerShape(3.dp)).background(c))
        Spacer(Modifier.width(10.dp))
        Text(text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Label(t: String) = Text(t, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))

@Composable
fun BigValue(v: String, unit: String) {
    Row(verticalAlignment = Alignment.Bottom) {
        Text(v, fontSize = 40.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(6.dp))
        Text(unit, fontSize = 18.sp, modifier = Modifier.padding(bottom = 6.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
    }
}

fun stateName(s: String): String {
    val r = L.t("st_$s")
    return if (r == "st_$s") s else r
}

/** Power as "850 W" or "3,38 kW". */
fun pw(w: Double): String = if (w >= 1000) L.n(w / 1000.0, 2) + " kW" else L.n(w, 0) + " W"

@Composable
fun Appear(delayMs: Int, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(delayMs.toLong()); shown = true }
    AnimatedVisibility(
        visible = shown, modifier = Modifier.fillMaxWidth(),
        enter = fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 6 }
    ) { content() }
}

/** One node of the energy-flow diagram: round icon + value + name. Text goes above the circle for the top node. */
@Composable
fun FlowNode(icon: String, label: String, value: String, active: Boolean, textFirst: Boolean, modifier: Modifier, tint: Color = Color.Unspecified) {
    val primary = if (tint == Color.Unspecified) MaterialTheme.colorScheme.primary else tint
    Column(
        modifier.height(100.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = if (textFirst) Arrangement.Bottom else Arrangement.Top
    ) {
        if (!textFirst) {
            Box(
                Modifier.size(56.dp).clip(CircleShape).background(primary.copy(alpha = if (active) 0.24f else 0.08f)),
                contentAlignment = Alignment.Center
            ) { Text(icon, fontSize = 26.sp) }
            Spacer(Modifier.height(4.dp))
        }
        FitText(value, fontSize = 16.sp, minSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        FitText(label, fontSize = 12.sp, minSize = 8.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
        if (textFirst) {
            Spacer(Modifier.height(4.dp))
            Box(
                Modifier.size(56.dp).clip(CircleShape).background(primary.copy(alpha = if (active) 0.24f else 0.08f)),
                contentAlignment = Alignment.Center
            ) { Text(icon, fontSize = 26.sp) }
        }
    }
}

/** Compact flow node: 48 dp circle with emoji, value and name (80 dp wide). Text above the circle when textFirst. */
@Composable
fun FlowNodeSm(icon: String, label: String, value: String, active: Boolean, textFirst: Boolean, modifier: Modifier, tint: Color = Color.Unspecified) {
    val primary = if (tint == Color.Unspecified) MaterialTheme.colorScheme.primary else tint
    Column(modifier.width(80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        @Composable fun texts() {
            Text(value, Modifier.wrapContentWidth(unbounded = true), fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1, softWrap = false)
            Text(label, Modifier.wrapContentWidth(unbounded = true), fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1, softWrap = false, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
        }
        @Composable fun circle() {
            Box(Modifier.size(48.dp).clip(CircleShape).background(primary.copy(alpha = if (active) 0.24f else 0.08f)), contentAlignment = Alignment.Center) {
                val kind0 = FlowIcons.kindOf(icon)
                val mv = if (Look.iconAnim) Modifier.iconMotion(kind0, active) else Modifier
                Box(mv, contentAlignment = Alignment.Center) {
                    if (Look.iconSet == "emoji") Text(icon, fontSize = 22.sp)
                    else {
                        val col = FlowIcons.color(kind0, MaterialTheme.colorScheme.primary, if (tint == Color.Unspecified) Color(0xFFE8A53A) else tint)
                        FlowIcon(kind0, col.copy(alpha = if (active) 1f else 0.5f), Look.iconSet, 26.dp)
                    }
                }
            }
        }
        if (textFirst) {
            // the circle is always at the top of a 48 dp box (fixed position); the text hangs above it whatever the font size
            Box(Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.TopCenter) {
                circle()
                Column(
                    Modifier.layout { m, c ->
                        val pl = m.measure(c.copy(minHeight = 0, maxHeight = androidx.compose.ui.unit.Constraints.Infinity))
                        layout(pl.width, 0) { pl.place(0, -pl.height - 4.dp.roundToPx()) }
                    }, horizontalAlignment = Alignment.CenterHorizontally
                ) { texts() }
            }
        } else { circle(); Spacer(Modifier.height(4.dp)); texts() }
    }
}

/** Solar (top) and Grid (bottom), centred, both feed Home (left) and Tesla (right) without crossing lines. */
@Composable
fun FlowCard() {
    val primary = MaterialTheme.colorScheme.primary
    val gridCol = Color(0xFFE8A53A)
    val pvW = Live.pvW
    val carW = Live.teslaKw * 1000.0
    val known = Live.houseW >= 0
    val houseW = if (known) maxOf(Live.houseW - carW, 0.0) else 0.0
    // electrons do not queue: solar and grid power share between house and car in proportion to what each one draws
    val load = carW + houseW
    val solarUsed = if (known && load > 0) minOf(pvW, load) else minOf(carW, pvW)
    val solarCar = if (known && load > 0) solarUsed * carW / load else solarUsed
    val solarHouse = if (known && load > 0) solarUsed * houseW / load else 0.0
    val gridCar = if (known) carW - solarCar else 0.0
    val gridHouse = if (known) houseW - solarHouse else 0.0
    val importW = gridCar + gridHouse
    val exportW = if (known) maxOf(pvW - solarCar - solarHouse, 0.0) else 0.0
    val on = 50.0
    val sunOn = pvW > on
    val houseOn = (solarHouse + gridHouse) > on
    val carOn = carW > on
    val gridOn = importW > on || exportW > on
    val transition = rememberInfiniteTransition(label = "flow")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "phase")
    val pct = if (pvW > on) (solarCar / pvW * 100).toInt() else 0
    val gridPct = if (carW > on) (gridCar / carW * 100).toInt() else 0
    val gridLabel = if (exportW > on) L.t("node_grid_exp") else if (importW > on) L.t("node_grid_imp") else L.t("node_grid")
    val gridValue = if (!known) "—" else pw(if (exportW > on) exportW else importW)

    Panel(id = "flow_title", title = L.t("flow_title")) {
        // Compact square diamond (260 x 260 dp): Solar on top, Home and Tesla in the middle, Grid at the bottom; no line crosses.
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(Modifier.size(260.dp)) {
            Canvas(Modifier.matchParentSize()) {
                val rad = 24.dp.toPx()
                val sun = Offset(130.dp.toPx(), 72.dp.toPx())
                val home = Offset(40.dp.toPx(), 126.dp.toPx())
                val car = Offset(220.dp.toPx(), 126.dp.toPx())
                val grid = Offset(130.dp.toPx(), 190.dp.toPx())
                val period = 60.dp.toPx()
                /** One continuous beam of energy: a faint track plus a gradient that glides from a to b without breaks. */
                fun flow(a: Offset, b: Offset, active: Boolean, col: Color) {
                    val dx = b.x - a.x; val dy = b.y - a.y
                    val len = kotlin.math.sqrt(dx * dx + dy * dy)
                    val ux = dx / len; val uy = dy / len
                    val gap = rad - 6.dp.toPx()   // lines run under the circles and are clipped flush with their edge
                    val p1 = Offset(a.x + ux * gap, a.y + uy * gap)
                    val p2 = Offset(b.x - ux * gap, b.y - uy * gap)
                    drawLine(col.copy(alpha = if (active) 0.22f else 0.10f), p1, p2, strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                    if (active) {
                        val s0 = Offset(p1.x + ux * period * phase, p1.y + uy * period * phase)
                        val s1 = Offset(s0.x + ux * period, s0.y + uy * period)
                        val beam = Brush.linearGradient(listOf(col.copy(alpha = 0.10f), col, col.copy(alpha = 0.10f)), s0, s1, TileMode.Repeated)
                        val pulse = 1f + 0.18f * kotlin.math.sin(phase * 2f * Math.PI.toFloat())
                        drawLine(col.copy(alpha = 0.14f), p1, p2, strokeWidth = 9.dp.toPx() * pulse, cap = StrokeCap.Round)
                        drawLine(beam, p1, p2, strokeWidth = 4.dp.toPx() * pulse, cap = StrokeCap.Round)
                    }
                }
                val circles = androidx.compose.ui.graphics.Path().apply {
                    listOf(sun, home, car, grid).forEach { addOval(androidx.compose.ui.geometry.Rect(it, rad)) }
                }
                clipPath(circles, androidx.compose.ui.graphics.ClipOp.Difference) {
                    flow(sun, home, solarHouse > on, primary)       // solar -> home
                    flow(sun, car, solarCar > on, primary)          // solar -> car
                    flow(grid, home, gridHouse > on, gridCol)       // grid -> home
                    flow(grid, car, gridCar > on, gridCol)          // grid -> car
                }
            }
            // circles are 48 dp; the text of the Solar node sits above its circle, the others below
            FlowNodeSm("☀️", L.t("node_solar"), pw(pvW), sunOn, true, Modifier.offset(90.dp, 48.dp))
            FlowNodeSm("🏠", L.t("node_house"), if (known) pw(houseW) else "—", houseOn, false, Modifier.offset(0.dp, 102.dp))
            FlowNodeSm("🚗", L.t("node_car"), pw(carW), carOn, false, Modifier.offset(180.dp, 102.dp))
            FlowNodeSm("⚡", gridLabel, gridValue, gridOn, false, Modifier.offset(90.dp, 166.dp), gridCol)
        }
        }
        Spacer(Modifier.height(8.dp))
        Label(if (pvW > on) L.t("pct_car", pct) else L.t("no_sun"))
        if (known && carW > on && gridPct > 5) Label(L.t("pct_grid_car", gridPct))
        if (Live.updated.isNotEmpty()) Label(L.t("data_from", Live.updated))
        if (!known && Live.updated.isNotEmpty()) Label(L.t("house_unknown"))
    }
}

@Composable
fun Dashboard(hist: History, cfg: Cfg) {
    val ctx = LocalContext.current
    var today by remember { mutableStateOf(DoubleArray(6)) }
    LaunchedEffect(Unit) { while (true) { today = hist.today(); delay(4000) } }

    Column(
        Modifier.fillMaxSize().verticalScroll(tabScroll("dash")).padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Appear(0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { AppLogo() }
                ArrangeToggle("dash")
            }
        }
        Appear(80) {
            Row {
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    AnimatedContent(targetState = Live.messageText(), label = "msg") { m ->
                        Text(m, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        BatteryWarn()
        Blocks("dash") {
            block("flow_title") { FlowCard() }
            block("ctrl_title") { ControlPanel(cfg) }
            block("card_tesla") { TeslaCard() }
            block("card_today") { TodayCard(today) }
            block("fc_title") { ForecastCard() }
        }
    }
}

@Composable
fun TeslaCard() {
    Panel(id = "card_tesla", title = L.t("card_tesla")) {
        Text(stateName(Live.chargingState), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Label(if (Live.battery >= 0) L.t("battery", Live.battery) else L.t("battery_na"))
        if (Live.amps > 0) Label(L.t("amps_set", Live.amps))
    }
}

@Composable
fun TodayCard(today: DoubleArray) {
    Panel(id = "card_today", title = L.t("card_today")) {
        Text(L.t("today_charged", L.n(today[0])), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Label(L.t("today_solar", L.n(today[1])))
        Label(L.t("today_house", L.n(today[2])))
        if (today[4] > 0) Label(L.t("today_saved", L.n(today[4], 2)))
    }
}

fun startSolar(ctx: android.content.Context, cfg: Cfg): Boolean {
    if (!Providers.configured(cfg) || listOf("teslaToken", "vin").any { cfg.get(it).isBlank() }) { Live.msg("msg_fill_conn"); return false }
    cfg.set("autoOn", "1")
    ctx.startForegroundService(Intent(ctx, SolarService::class.java))
    return true
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun ControlPanel(cfg: Cfg) {
    val ctx = LocalContext.current
    var sel by remember { mutableStateOf(if (cfg.get("mode", "solar") == "minpv") "minpv" else "solar") }
    val cur = when { !Live.running -> "off"; Live.boost -> "fast"; else -> sel }
    fun choose(m: String) {
        if (ModeControl.set(ctx, cfg, m) && (m == "solar" || m == "minpv")) sel = m
    }
    Panel(id = "ctrl_title", title = L.t("ctrl_title")) {
        Spacer(Modifier.height(6.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("off", "solar", "minpv", "fast").forEach { m -> Pill(cur == m, L.t("mode_$m")) { choose(m) } }
        }
        Spacer(Modifier.height(10.dp))
        Label(L.t("mode_help_$cur"))
    }
}

@Composable
fun ForecastCard() {
    var off by remember { mutableIntStateOf(0) }
    Panel(id = "fc_title", title = L.t("fc_title")) {
        Spacer(Modifier.height(6.dp))
        if (Live.fcOutlook.isEmpty()) { Label(L.t("fc_off")); return@Panel }
        val n = Forecast.daysAvailable().coerceAtLeast(1)
        val o = off.coerceIn(0, n - 1)
        val day = Forecast.day(o)
        val tf = remember(L.lang) { java.text.SimpleDateFormat("EEE d MMM", L.locale()) }
        val primary = MaterialTheme.colorScheme.primary
        val amber = Color(0xFFE8A53A)
        // day navigation
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ off = o - 1 }, enabled = o > 0) { Text("‹", fontSize = 26.sp) }
            Text(
                (when (o) { 0 -> L.t("fc_today"); 1 -> L.t("fc_kwh_tomorrow"); else -> (day?.let { tf.format(java.util.Date(it.dateMs)) } ?: "") }).replaceFirstChar { it.uppercase() },
                fontSize = 17.sp, fontWeight = FontWeight.SemiBold
            )
            TextButton({ off = o + 1 }, enabled = o < n - 1) { Text("›", fontSize = 26.sp) }
        }
        // outlook of the chosen day (today: from now on)
        val cloud = if (o == 0) Live.fcCloud.toDouble() else (day?.cloud ?: -1.0)
        val outlook = if (o == 0) Live.fcOutlook else if (cloud < 0) "night" else if (cloud < 35) "good" else if (cloud < 70) "mixed" else "poor"
        val txt = when (outlook) { "good" -> "☀️ " + L.t("fc_good"); "mixed" -> "⛅ " + L.t("fc_mixed"); "poor" -> "☁️ " + L.t("fc_poor"); else -> "🌙 " + L.t("fc_night") }
        Text(txt, fontSize = 17.sp, fontWeight = FontWeight.Medium)
        if (cloud >= 0) Label(L.t("fc_clouds", cloud.toInt()))
        if (o == 0) { if (Live.fcTrend == "down") Label(L.t("fc_down")) else if (Live.fcTrend == "up") Label(L.t("fc_up")) }
        if (day != null) {
            Spacer(Modifier.height(10.dp))
            val peakH = (0..23).maxByOrNull { day.kwh[it] } ?: 0
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (o == 0 && Live.fcKwhRest >= 0) StatTile("☀️", L.t("fc_kwh_rest"), L.n(Live.fcKwhRest, 1) + " kWh", amber, Modifier.weight(1f))
                else StatTile("☀️", L.t("fc_day_total"), L.n(day.total, 1) + " kWh", amber, Modifier.weight(1f))
                if (o == 0) StatTile("📅", L.t("fc_day_total"), L.n(day.total, 1) + " kWh", primary, Modifier.weight(1f))
                else StatTile("⏱", L.t("fc_peak"), if (day.kwh[peakH] >= 0.05) String.format(java.util.Locale.US, "%02d h · ", peakH) + L.n(day.kwh[peakH], 1) + " kWh" else "—", primary, Modifier.weight(1f))
            }
            Spacer(Modifier.height(4.dp))
            Label(L.t("fc_kwh_note2", L.n(Forecast.currentKwp(), 1)))
            if (Forecast.calibDays >= 3) Label(L.t("fc_calib", L.n(Forecast.calib, 2), Forecast.calibDays))
            Spacer(Modifier.height(8.dp))
            // bars: today = the next hours, other days = the hours with sun
            val hours: List<Int> = if (o == 0) (0 until Live.fcBars.size).map { (Live.fcStartHour + it) % 24 } else {
                val sun = (0..23).filter { day.rad[it] > 10 }
                if (sun.isEmpty()) emptyList() else (sun.first()..sun.last()).toList()
            }
            val bars = if (o == 0) Live.fcBars else hours.map { (day.rad[it] / 900.0).coerceIn(0.0, 1.0).toFloat() }
            val kwhs = if (o == 0) Live.fcKwh else hours.map { day.kwh[it] }
            Row(Modifier.fillMaxWidth().height(86.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
                bars.forEachIndexed { i, v ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        val kwhH = kwhs.getOrNull(i)
                        if (kwhH != null && kwhH >= 0.05) Text(L.n(kwhH, 1), fontSize = 8.sp, maxLines = 1, softWrap = false, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Box(Modifier.fillMaxWidth().height(maxOf(2f, 48f * v).dp).clip(RoundedCornerShape(3.dp)).background(primary.copy(alpha = if (v > 0.02f) 1f else 0.25f)))
                        if (bars.size <= 8 || i % 2 == 0) Text("%02d".format(hours.getOrElse(i) { 0 }), fontSize = 8.sp, maxLines = 1, softWrap = false) else Text(" ", fontSize = 8.sp)
                    }
                }
            }
        }
    }
}

/** Values per day (month view) or per month (year view) for metric idx: 0 charged, 1 solar, 2 house. */
fun series(data: Map<String, DoubleArray>, mode: String, ym: YearMonth, year: Int, idx: Int): List<Double> {
    if (mode == "month") {
        return (1..ym.lengthOfMonth()).map { d ->
            data[String.format(Locale.US, "%04d-%02d-%02d", ym.year, ym.monthValue, d)]?.get(idx) ?: 0.0
        }
    }
    val out = DoubleArray(12)
    val prefix = String.format(Locale.US, "%04d-", year)
    data.forEach { (k, v) ->
        if (k.startsWith(prefix)) {
            val m = k.substring(5, 7).toIntOrNull() ?: 0
            if (m in 1..12) out[m - 1] += v[idx]
        }
    }
    return out.toList()
}

fun monthName(m: Int, style: java.time.format.TextStyle): String =
    java.time.Month.of(m).getDisplayName(style, L.locale()).replaceFirstChar { it.uppercase() }

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun HistoryScreen(hist: History) {
    val ctx = LocalContext.current
    val now = remember { YearMonth.now() }
    var data by remember { mutableStateOf(hist.all()) }
    // the choices made in History survive switching tabs (the screen is rebuilt every time)
    var mode by remember { mutableStateOf(HistUi.mode) }
    var metric by remember { mutableIntStateOf(HistUi.metric) }
    var cumulative by remember { mutableStateOf(HistUi.cumulative) }
    var ym by remember { mutableStateOf(HistUi.ym ?: now) }
    var year by remember { mutableIntStateOf(HistUi.year ?: now.year) }
    SideEffect { HistUi.mode = mode; HistUi.metric = metric; HistUi.cumulative = cumulative; HistUi.ym = ym; HistUi.year = year }
    // the calendar opens with today selected (when the month shown is the current one)
    var calSel by remember(ym, mode) { mutableIntStateOf(if (mode == "month" && ym == now) java.time.LocalDate.now().dayOfMonth else -1) }
    var sel by remember(mode, ym, year, metric, cumulative) { mutableIntStateOf(-1) }
    var confirmClear by remember { mutableStateOf(false) }
    var pendingImport by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { TeslaImport.auto(ctx) }
    LaunchedEffect(Unit) { while (true) { data = hist.all(); delay(5000) } }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try {
                ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(hist.exportJson().toByteArray()) } != null
            } catch (e: Exception) { false }
            Toast.makeText(ctx, if (ok) L.t("hist_exported") else L.t("export_fail"), Toast.LENGTH_LONG).show()
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try { ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } } catch (e: Exception) { null }
            if (text == null || !text.contains("\"history\"")) Toast.makeText(ctx, L.t("invalid_file"), Toast.LENGTH_LONG).show()
            else pendingImport = text
        }
    }

    val earliest = remember(data) {
        data.keys.minOrNull()?.let { try { YearMonth.parse(it.substring(0, 7)) } catch (e: Exception) { null } } ?: now
    }
    val vals = series(data, mode, ym, year, listOf(0, 1, 2, 4)[metric])
    // the running total stops today: months / days that have not happened yet stay empty instead of repeating the last total
    val lastPeriod = run {
        val today = java.time.LocalDate.now()
        if (mode == "month") (if (ym == YearMonth.from(today)) today.dayOfMonth else if (ym.isAfter(YearMonth.from(today))) 0 else ym.lengthOfMonth())
        else (if (year == today.year) today.monthValue else if (year > today.year) 0 else 12)
    }
    val shown = if (cumulative) { var acc = 0.0; vals.mapIndexed { i, v -> if (i < lastPeriod) { acc += v; acc } else 0.0 } } else vals
    val total = vals.sum()
    val maxV = maxOf(shown.maxOrNull() ?: 0.0, 0.01)
    // the summary follows the selection: a day of the calendar, a month bar of the year chart, otherwise the whole month / year
    val sumDay = if (mode == "month" && calSel > 0) data[dayKey(ym, calSel)] else null
    val sumMonthIdx = if (mode == "year" && !cumulative && sel in 0..11) sel else -1
    fun scoped(idx: Int): Double =
        if (mode == "month" && calSel > 0) (sumDay?.get(idx) ?: 0.0)
        else if (sumMonthIdx >= 0) series(data, mode, ym, year, idx).getOrElse(sumMonthIdx) { 0.0 }
        else series(data, mode, ym, year, idx).sum()
    val sumLabel = if (mode == "month" && calSel > 0) "$calSel " + monthName(ym.monthValue, java.time.format.TextStyle.SHORT) + " " + ym.year
        else if (sumMonthIdx >= 0) monthName(sumMonthIdx + 1, java.time.format.TextStyle.FULL_STANDALONE) + " " + year
        else if (mode == "month") monthName(ym.monthValue, java.time.format.TextStyle.FULL_STANDALONE) + " " + ym.year else year.toString()
    val sums = (0..2).map { scoped(it) }
    val sumSaved = scoped(4)
    val sumCost = scoped(5)
    val gridSum = scoped(3)
    val ringPct = solarPct(sums[0], gridSum)
    val metricNames = listOf(L.t("m_charged"), L.t("m_solar"), L.t("m_house"), L.t("m_savings"))
    val dataIdx = listOf(0, 1, 2, 4)
    val unit = if (metric == 3) "€" else "kWh"
    val title = if (mode == "month") monthName(ym.monthValue, java.time.format.TextStyle.FULL_STANDALONE) + " " + ym.year else year.toString()
    val canPrev = if (mode == "month") ym.isAfter(earliest) else year > earliest.year
    val canNext = if (mode == "month") ym.isBefore(now) else year < now.year
    val primary = MaterialTheme.colorScheme.primary

    Column(
        Modifier.fillMaxSize().verticalScroll(tabScroll("hist")).padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FitText(L.t("hist_title"), Modifier.weight(1f), fontSize = 28.sp, minSize = 16.sp, fontWeight = FontWeight.Bold)
            TextButton({
                val txt = reportText(sums[0], gridSum, sumSaved, sumCost, sumLabel)
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, txt)
                try { ctx.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            }) { Text("⤴") }
            ArrangeToggle("hist")
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val cum = L.t("cumulative").lowercase()
            val periodOpts = listOf(L.t("mode_month"), L.t("mode_year"), L.t("mode_month") + " · " + cum, L.t("mode_year") + " · " + cum)
            HistDropdown(periodOpts, (if (mode == "year") 1 else 0) + (if (cumulative) 2 else 0), Modifier.weight(1f)) { i ->
                mode = if (i % 2 == 0) "month" else "year"; cumulative = i >= 2
            }
            HistDropdown(metricNames, metric, Modifier.weight(1f)) { metric = it }
        }
        Blocks("hist") {
        block("hist_chart") {
        Panel(id = "hist_chart", title = L.t("hist_chart")) {
            val dec = if (metric == 3) 2 else 1
            val prevTotal = if (mode == "month") series(data, "month", ym.minusMonths(1), year, dataIdx[metric]).sum()
                            else series(data, "year", ym, year - 1, dataIdx[metric]).sum()
            val delta = if (prevTotal > 0 && !cumulative) (total - prevTotal) / prevTotal * 100.0 else null
            // hero strip with period navigation, total and change versus the previous period
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(primary, primary.copy(alpha = 0.72f))))
                    .padding(horizontal = 6.dp, vertical = 10.dp)
            ) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton({ if (mode == "month") ym = ym.minusMonths(1) else year -= 1 }, enabled = canPrev,
                            colors = ButtonDefaults.textButtonColors(contentColor = Color.White, disabledContentColor = Color.White.copy(alpha = 0.35f))) { Text("‹", fontSize = 28.sp) }
                        Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        TextButton({ if (mode == "month") ym = ym.plusMonths(1) else year += 1 }, enabled = canNext,
                            colors = ButtonDefaults.textButtonColors(contentColor = Color.White, disabledContentColor = Color.White.copy(alpha = 0.35f))) { Text("›", fontSize = 28.sp) }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(metricNames[metric], fontSize = 13.sp, color = Color.White.copy(alpha = 0.85f))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(L.n(total, dec), fontSize = 38.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(" $unit", fontSize = 16.sp, color = Color.White.copy(alpha = 0.85f), modifier = Modifier.padding(bottom = 7.dp))
                            }
                        }
                        SolarRing(ringPct)
                    }
                    if (!cumulative) {
                        Spacer(Modifier.height(6.dp))
                        FlowRow(Modifier.padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            DeltaChip(delta, L.t("vs_prev"))
                            if (mode == "month") DeltaChip(deltaPct(total, series(data, "month", ym.minusYears(1), year, dataIdx[metric]).sum()), L.t("vs_year"))
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                if (sel in shown.indices) (if (mode == "month") "${sel + 1} " + monthName(ym.monthValue, java.time.format.TextStyle.SHORT) else monthName(sel + 1, java.time.format.TextStyle.FULL_STANDALONE)) +
                    " · " + L.n(shown[sel], dec) + " " + unit else L.t("tap_bar"),
                fontSize = 13.sp, fontWeight = if (sel in shown.indices) FontWeight.SemiBold else FontWeight.Normal,
                color = if (sel in shown.indices) primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
            )
            Spacer(Modifier.height(4.dp))
            val xl = if (mode == "month") shown.indices.map { i -> if (i == 0 || (i + 1) % 5 == 0) (i + 1).toString() else "" }
                     else shown.indices.map { i -> monthName(i + 1, java.time.format.TextStyle.NARROW) }
            HistChart(shown, xl, sel, { sel = it }, showAvg = !cumulative)
            Spacer(Modifier.height(4.dp))
            Label(if (total > 0) L.t("peak", L.n(maxV, dec) + " " + unit) + (if (!cumulative) " · - - " + L.t("avg") + " " + L.n(shown.filter { it > 0 }.let { if (it.isEmpty()) 0.0 else it.average() }, dec) + " " + unit else "") else L.t("no_data"))
        }
        }
        block("hist_summary") {
        Panel(id = "hist_summary", title = L.t("hist_summary") + " · " + sumLabel) {
            val green = Color(0xFF2E9E5B); val amber = Color(0xFFE8A53A); val blue = Color(0xFF3B82F6)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("🚗", metricNames[0], L.n(sums[0], 1) + " kWh", primary, Modifier.weight(1f))
                StatTile("☀️", metricNames[1], L.n(sums[1], 1) + " kWh", amber, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("🏠", metricNames[2], L.n(sums[2], 1) + " kWh", blue, Modifier.weight(1f))
                StatTile("💶", metricNames[3], L.n(sumSaved, 2) + " €", green, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Spacer(Modifier.height(8.dp))
            Label(L.t("cost_grid") + ": " + L.n(sumCost, 2) + " €")
            Label(L.t("est_note"))
        }
        }
        if (mode == "month") block("hist_cal") {
        Panel(id = "hist_cal", title = L.t("hist_cal")) {
            Spacer(Modifier.height(6.dp))
            HeatCalendar(data, ym, dataIdx[metric], calSel) { calSel = it }
            Spacer(Modifier.height(8.dp))
            val dd = if (calSel > 0) data[dayKey(ym, calSel)] else null
            if (calSel > 0) Text(
                "$calSel " + monthName(ym.monthValue, java.time.format.TextStyle.SHORT) + " · " +
                    (if (dd != null) L.n(dd[0], 1) + " kWh · ☀ " + solarPct(dd[0], dd[3]) + " % · " + L.n(dd[1], 1) + " kWh PV · " + L.n(dd[4], 2) + " €" else L.t("no_data")),
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = primary
            ) else Label(L.t("cal_hint", metricNames[metric]))
        }
        }
        block("sess_title") {
            val dayOn = mode == "month" && calSel > 0
            val monthKey = if (mode == "month") String.format(Locale.US, "%04d-%02d", ym.year, ym.monthValue)
                else if (sumMonthIdx >= 0) String.format(Locale.US, "%04d-%02d", year, sumMonthIdx + 1) else String.format(Locale.US, "%04d", year)
            SessionsPanel(
                day = if (dayOn) dayKey(ym, calSel) else monthKey,
                dayLabel = sumLabel,
                onClear = { calSel = -1 })
        }
        block("hist_hours") {
            val dayOn = mode == "month" && calSel > 0
            HoursPanel(remember(data) { hist.hourly() }, mode, ym, year,
                day = if (dayOn) dayKey(ym, calSel) else null,
                dayLabel = if (dayOn) "$calSel " + monthName(ym.monthValue, java.time.format.TextStyle.SHORT) + " " + ym.year else "",
                onClear = { calSel = -1 })
        }
        block("hist_self") { SelfPanel(data, mode, ym, year) }
        block("hist_tesla") { TeslaPanel(mode, ym, year) }
        block("hist_car") { CarPanel(data) }
        block("hist_records") { RecordsPanel(data, ym, now, dataIdx[metric], metricNames[metric], unit, if (metric == 3) 2 else 1) }
        block("hist_lifetime") { LifetimePanel(data) }
        block("hist_backup") {
        Panel(id = "hist_backup", title = L.t("hist_backup")) {
            Spacer(Modifier.height(6.dp))
            Label(L.t("hist_backup_help"))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({
                    exporter.launch("solarcharge-history-" + java.text.SimpleDateFormat("yyyyMMdd", Locale.US).format(java.util.Date()) + ".json")
                }, Modifier.weight(1f)) { Text(L.t("export")) }
                OutlinedButton(
                    { importer.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
                    Modifier.weight(1f)
                ) { Text(L.t("import")) }
            }
            GrowattImportRow()
        }
        }
        }
        OutlinedButton({ confirmClear = true }, Modifier.fillMaxWidth()) { Text(L.t("hist_clear")) }
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text(L.t("clear_title")) },
        text = { Text(L.t("clear_text")) },
        confirmButton = { TextButton({ hist.clear(); Sessions(ctx).clear(); data = hist.all(); confirmClear = false }) { Text(L.t("delete")) } },
        dismissButton = { TextButton({ confirmClear = false }) { Text(L.t("cancel")) } }
    )
    pendingImport?.let { txt ->
        AlertDialog(
            onDismissRequest = { pendingImport = null },
            title = { Text(L.t("hist_import_title")) },
            text = { Text(L.t("hist_import_text")) },
            confirmButton = {
                TextButton({
                    val n = hist.importJson(txt)
                    pendingImport = null
                    if (n < 0) Toast.makeText(ctx, L.t("invalid_file"), Toast.LENGTH_LONG).show()
                    else { data = hist.all(); Toast.makeText(ctx, L.t("hist_imported", n), Toast.LENGTH_LONG).show() }
                }) { Text(L.t("import")) }
            },
            dismissButton = { TextButton({ pendingImport = null }) { Text(L.t("cancel")) } }
        )
    }
}

@Composable
fun CfgField(cfg: Cfg, key: String, label: String, hint: String = "", secret: Boolean = false, numeric: Boolean = false) {
    var v by remember { mutableStateOf(cfg.get(key)) }
    OutlinedTextField(
        value = v, onValueChange = { v = it; cfg.set(key, it.trim()) },
        label = { Text(label) }, placeholder = { if (hint.isNotEmpty()) Text(hint) },
        singleLine = true, modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text)
    )
}

@Composable
fun CfgSwitch(cfg: Cfg, key: String, label: String, defOn: Boolean, onChange: (Boolean) -> Unit = {}) {
    var on by remember { mutableStateOf(if (defOn) cfg.get(key) != "0" else cfg.get(key) == "1") }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = { on = it; cfg.set(key, if (it) "1" else "0"); onChange(it) })
    }
}

@Composable
fun TimeButton(label: String, key: String, def: Int, cfg: Cfg, modifier: Modifier) {
    val ctx = LocalContext.current
    var m by remember { mutableStateOf(cfg.int(key, def)) }
    OutlinedButton({
        TimePickerDialog(ctx, { _, h, min -> m = h * 60 + min; cfg.set(key, m.toString()) }, m / 60, m % 60, true).show()
    }, modifier) { Text("%s %02d:%02d".format(label, m / 60, m % 60)) }
}

@Composable
fun SettingsScreen(cfg: Cfg, mode: String, accent: String, onMode: (String) -> Unit, onAccent: (String) -> Unit) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }          // bumped after an import so the fields reload
    val manualSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    ) { uri ->
        if (uri != null) {
            val ok = try {
                ctx.assets.open("solarcharge-manual.docx").use { inp -> ctx.contentResolver.openOutputStream(uri, "wt")?.use { out -> inp.copyTo(out) } } != null
            } catch (e: Exception) { false }
            Toast.makeText(ctx, if (ok) L.t("manual_saved") else L.t("manual_fail"), Toast.LENGTH_LONG).show()
            if (ok) try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) { }
        }
    }
    var pendingImport by remember { mutableStateOf<String?>(null) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try {
                ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(cfg.exportJson().toByteArray()) } != null
            } catch (e: Exception) { false }
            Toast.makeText(ctx, if (ok) L.t("set_exported") else L.t("export_fail"), Toast.LENGTH_LONG).show()
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try { ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } } catch (e: Exception) { null }
            if (text == null || !text.contains("\"settings\"")) Toast.makeText(ctx, L.t("invalid_file"), Toast.LENGTH_LONG).show()
            else pendingImport = text
        }
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(tabScroll("set")).padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(L.t("settings_title"), Modifier.weight(1f), fontSize = 28.sp, fontWeight = FontWeight.Bold)
            ArrangeToggle("set")
        }
        key(rev) {
        Blocks("set") {
            block("sec_conn") {
            Panel(id = "sec_conn", title = L.t("sec_conn")) {
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProviderFields(cfg)
                    CfgField(cfg, "teslaToken", L.t("f_teslaToken"), secret = true)
                    CfgField(cfg, "vin", L.t("f_vin"))
                }
            }
            }
            block("sec_charge") {
            Panel(id = "sec_charge", title = L.t("sec_charge")) {
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CfgSwitch(cfg, "manageManual", L.t("sw_manual"), true)
                    CfgField(cfg, "minAmps", L.t("f_minAmps"), "5", numeric = true)
                    CfgField(cfg, "maxAmps", L.t("f_maxAmps"), "16", numeric = true)
                    CfgField(cfg, "phases", L.t("f_phases"), "1", numeric = true)
                    CfgField(cfg, "volts", L.t("f_volts"), "230", numeric = true)
                    CfgField(cfg, "intervalSec", L.t("f_interval"), "120", numeric = true)
                    CfgField(cfg, "nightIntervalSec", L.t("f_night_interval"), "300", numeric = true)
                    CfgSwitch(cfg, "nightAwake", L.t("sw_nightawake"), true)
                    BatteryRow()
                    CfgField(cfg, "startDelaySec", L.t("f_startDelay"), "90", numeric = true)
                    CfgField(cfg, "stopDelaySec", L.t("f_stopDelay"), "300", numeric = true)
                    CfgField(cfg, "bufferW", L.t("f_buffer"), "0")
                    CfgSwitch(cfg, "optExport", L.t("sw_optexport"), true)
                    CfgField(cfg, "growattSec", L.t("f_growattSec"), "300", numeric = true)
                    CfgField(cfg, "pvMult", L.t("f_pvMult"), L.t("hint_auto"), numeric = true)
                }
            }
            }
            block("sec_schedule") {
            Panel(id = "sec_schedule", title = L.t("sec_schedule")) {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TimeButton(L.t("from"), "winStartMin", 540, cfg, Modifier.weight(1f))
                    TimeButton(L.t("to"), "winEndMin", 1080, cfg, Modifier.weight(1f))
                }
            }
            }
            block("sec_target") {
            Panel(id = "sec_target", title = L.t("sec_target")) {
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CfgField(cfg, "targetPct", L.t("f_targetPct"), "100", numeric = true)
                    CfgField(cfg, "capKwh", L.t("f_capKwh"), "60", numeric = true)
                    CfgSwitch(cfg, "departEnabled", L.t("sw_departure"), false)
                    TimeButton(L.t("departure_time"), "departMin", 480, cfg, Modifier.fillMaxWidth())
                    Label(L.t("target_help"))
                }
            }
            }
            block("sec_tariff") {
            Panel(id = "sec_tariff", title = L.t("sec_tariff")) {
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CfgField(cfg, "priceNormal", L.t("f_priceNormal"), "0.20", numeric = true)
                    CfgField(cfg, "priceOff", L.t("f_priceOff"), "0.10", numeric = true)
                    Label(L.t("offpeak_window"))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TimeButton(L.t("from"), "offStartMin", 1320, cfg, Modifier.weight(1f))
                        TimeButton(L.t("to"), "offEndMin", 480, cfg, Modifier.weight(1f))
                    }
                    CfgSwitch(cfg, "offpeakCharge", L.t("sw_offpeak"), false)
                    CfgSwitch(cfg, "planSmart", L.t("sw_plan"), true)
                    CfgField(cfg, "kwp", L.t("f_kwp"), "4", numeric = true)
                    Label(L.t("plan_help"))
                }
            }
            }
            block("sec_forecast") {
            Panel(id = "sec_forecast", title = L.t("sec_forecast")) {
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CfgSwitch(cfg, "useForecast", L.t("sw_forecast"), true)
                    CfgSwitch(cfg, "fcStretch", L.t("sw_fcstretch"), false)
                    CfgField(cfg, "lat", L.t("f_lat"), "38.80")
                    CfgField(cfg, "lon", L.t("f_lon"), "-9.21")
                    Label(L.t("forecast_help"))
                }
            }
            }
            block("sec_notify") {
            Panel(id = "sec_notify", title = L.t("sec_notify")) {
                Spacer(Modifier.height(6.dp))
                CfgSwitch(cfg, "notify", L.t("sw_notify"), true)
                CfgSwitch(cfg, "showLog", L.t("sw_showlog"), true) { Live.showLog = it }
                CfgField(cfg, "tireMinBar", L.t("f_tireMin"), "2.2", numeric = true)
            }
            }
            block("sec_chat") {
            Panel(id = "sec_chat", title = L.t("sec_chat")) {
                Spacer(Modifier.height(6.dp))
                Label(L.t("chat_help"))
                Spacer(Modifier.height(10.dp))
                CfgField(cfg, "anthropicKey", L.t("f_chatkey"), "sk-ant-…", secret = true)
                Spacer(Modifier.height(8.dp))
                CfgField(cfg, "chatModel", L.t("f_chatmodel"), "claude-sonnet-5-5")
            }
            }
            block("sec_local") {
            Panel(id = "sec_local", title = L.t("sec_local")) {
                val ctxL = LocalContext.current
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Label(L.t("local_help"))
                    CfgField(cfg, "localHost", L.t("f_localHost"), "192.168.1.50")
                    CfgField(cfg, "localPort", L.t("f_localPort"), "502", numeric = true)
                    CfgField(cfg, "localUnit", L.t("f_localUnit"), "1", numeric = true)
                    CfgField(cfg, "localFn", L.t("f_localFn"), "4", numeric = true)
                    CfgField(cfg, "localRegPv", L.t("f_localRegPv"), "1", numeric = true)
                    CfgField(cfg, "localRegLoad", L.t("f_localRegLoad"), L.t("hint_auto"), numeric = true)
                    CfgField(cfg, "localScale", L.t("f_localScale"), "0.1", numeric = true)
                    OutlinedButton({
                        Thread {
                            val r = LocalInverter.test(cfg)
                            android.os.Handler(android.os.Looper.getMainLooper()).post { Toast.makeText(ctxL, r, Toast.LENGTH_LONG).show() }
                        }.start()
                    }, Modifier.fillMaxWidth()) { Text(L.t("local_test")) }
                    OutlinedButton({
                        Thread {
                            val r = LocalInverter.dump(cfg)
                            android.os.Handler(android.os.Looper.getMainLooper()).post { Toast.makeText(ctxL, r, Toast.LENGTH_LONG).show() }
                        }.start()
                    }, Modifier.fillMaxWidth()) { Text(L.t("local_dump")) }
                    Label(L.t("local_dump_help"))
                }
            }
            }
            block("sec_system") {
            Panel(id = "sec_system", title = L.t("sec_system")) {
                val ctxS = LocalContext.current
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CfgSwitch(cfg, "autoStart", L.t("sw_autostart"), true)
                    Label(L.t("system_help"))
                    OutlinedButton({
                        try { ctxS.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                    }, Modifier.fillMaxWidth()) { Text(L.t("battery_opt")) }
                }
            }
            }
        block("sec_lang") {
        Panel(id = "sec_lang", title = L.t("sec_lang")) {
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                L.languages.forEach { (code, name) ->
                    FilterChip(selected = L.lang == code, onClick = { L.lang = code; cfg.set("lang", code) }, label = { Text(name) })
                }
            }
        }
        }
        block("sec_look") {
        Panel(id = "sec_look", title = L.t("sec_look")) {
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to L.t("theme_system"), "light" to L.t("theme_light"), "dark" to L.t("theme_dark")).forEach { (k, n) ->
                    FilterChip(selected = mode == k, onClick = { onMode(k) }, label = { Text(n) })
                }
            }
            Spacer(Modifier.height(14.dp))
            Label(L.t("font_label"))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Look.fonts.forEach { k ->
                    FilterChip(selected = Look.font == k, onClick = { Look.font = k; cfg.set("font", k) },
                        label = { Text(L.t("font_$k"), fontFamily = Look.family(k)) })
                }
            }
            Spacer(Modifier.height(14.dp))
            Label(L.t("accent"))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Schemes.forEach { sc ->
                    val sel = accent == sc.key
                    val dk = mode == "dark" || (mode == "system" && isSystemInDarkTheme())
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable { onAccent(sc.key) }.padding(4.dp)) {
                        Box(
                            Modifier.size(width = 84.dp, height = 60.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (dk) sc.darkBg else sc.lightBg)
                                .border(if (sel) 3.dp else 1.dp, if (sel) sc.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                        ) {
                            Box(Modifier.padding(8.dp).fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(sc.primary))
                            Box(Modifier.align(Alignment.BottomStart).padding(8.dp).size(width = 44.dp, height = 18.dp).clip(RoundedCornerShape(6.dp))
                                .background(if (dk) sc.darkSurface else sc.lightSurface))
                            Row(Modifier.align(Alignment.BottomEnd).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                sc.titles.drop(1).take(3).forEach { Box(Modifier.size(9.dp).clip(CircleShape).background(it)) }
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(L.t("scheme_" + sc.key), fontSize = 12.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
                // user-defined scheme
                run {
                    val sel = accent == "custom"
                    val dk = mode == "dark" || (mode == "system" && isSystemInDarkTheme())
                    val cs = Look.customScheme()
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable { onAccent("custom") }.padding(4.dp)) {
                        Box(
                            Modifier.size(width = 84.dp, height = 60.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (dk) cs.darkBg else cs.lightBg)
                                .border(if (sel) 3.dp else 1.dp, if (sel) cs.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                        ) {
                            Box(Modifier.padding(8.dp).fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(cs.primary))
                            Text("🎨", Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp), fontSize = 18.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(L.t("scheme_custom"), fontSize = 12.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }
            if (accent == "custom") {
                Spacer(Modifier.height(14.dp))
                ColorPicker(L.t("custom_primary"), Look.customPrimary) { Look.customPrimary = it; cfg.set("customPrimary", Look.hex(it)) }
                Spacer(Modifier.height(10.dp))
                ColorPicker(L.t("custom_bg"), Look.customBg) { Look.customBg = it; cfg.set("customBg", Look.hex(it)) }
            }
            Spacer(Modifier.height(16.dp))
            Label(L.t("trans_title"))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("slide", "fade", "zoom", "vertical", "none").forEach { k ->
                    Pill(Look.transition == k, L.t("trans_$k")) { Look.transition = k; cfg.set("transition", k) }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("fast", "normal", "slow").forEach { k ->
                    Pill(Look.transSpeed == k, L.t("speed_$k")) { Look.transSpeed = k; cfg.set("transSpeed", k) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Label(L.t("icons_title"))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FlowIcons.sets.forEach { k ->
                    Pill(Look.iconSet == k, L.t("icons_$k")) { Look.iconSet = k; cfg.set("iconSet", k); SolarWidget.refresh(ctx) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Pill(Look.iconAnim, L.t("icons_anim")) { Look.iconAnim = !Look.iconAnim; cfg.set("iconAnim", if (Look.iconAnim) "1" else "0") }
        }
        }
        block("sec_tabs") {
        Panel(id = "sec_tabs", title = L.t("sec_tabs")) {
            Spacer(Modifier.height(6.dp))
            Label(L.t("tabs_help"))
            Spacer(Modifier.height(6.dp))
            Layout.tabOrder.toList().forEach { id ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(36.dp), contentAlignment = Alignment.Center) { TabIcon(id) }
                    Text(L.t(navKey(id)), Modifier.weight(1f).padding(start = 8.dp), fontSize = 16.sp)
                    Text("▲", Modifier.clip(RoundedCornerShape(8.dp)).clickable { Layout.moveTab(id, -1) }.padding(horizontal = 14.dp, vertical = 8.dp), fontSize = 18.sp)
                    Text("▼", Modifier.clip(RoundedCornerShape(8.dp)).clickable { Layout.moveTab(id, 1) }.padding(horizontal = 14.dp, vertical = 8.dp), fontSize = 18.sp)
                }
            }
        }
        }
        block("sec_backup") {
        Panel(id = "sec_backup", title = L.t("sec_backup")) {
            Spacer(Modifier.height(6.dp))
            Label(L.t("backup_help"))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({
                    exporter.launch("solarcharge-settings-" + java.text.SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(java.util.Date()) + ".json")
                }, Modifier.weight(1f)) { Text(L.t("export")) }
                OutlinedButton(
                    { importer.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
                    Modifier.weight(1f)
                ) { Text(L.t("import")) }
            }
        }
        }
        block("sec_manual") {
        Panel(id = "sec_manual", title = L.t("sec_manual")) {
            Spacer(Modifier.height(6.dp))
            Label(L.t("manual_help"))
            Spacer(Modifier.height(10.dp))
            Button({ manualSaver.launch("SolarCharge-Manual.docx") }, Modifier.fillMaxWidth()) { Text("📄 " + L.t("manual_save")) }
        }
        }
        }
        }
        TextButton({ Layout.reset() }) { Text(L.t("arr_reset")) }
        Label(L.t("autosave"))
        Text(
            L.t("footer"), fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.55f), modifier = Modifier.fillMaxWidth()
        )
    }
    pendingImport?.let { txt ->
        AlertDialog(
            onDismissRequest = { pendingImport = null },
            title = { Text(L.t("set_import_title")) },
            text = { Text(L.t("set_import_text")) },
            confirmButton = {
                TextButton({
                    val n = cfg.importJson(txt)
                    pendingImport = null
                    if (n < 0) Toast.makeText(ctx, L.t("invalid_file"), Toast.LENGTH_LONG).show()
                    else {
                        onMode(cfg.get("theme", "system")); onAccent(cfg.get("accent", "green")); Look.load(cfg); Layout.loadTabs(cfg)
                        L.init(cfg)
                        Layout.init(cfg)      // tab order, card order, collapsed and hidden cards come from the file
                        Live.showLog = cfg.get("showLog", "1") != "0"
                        rev++
                        Toast.makeText(ctx, L.t("set_imported", n), Toast.LENGTH_LONG).show()
                    }
                }) { Text(L.t("import")) }
            },
            dismissButton = { TextButton({ pendingImport = null }) { Text(L.t("cancel")) } }
        )
    }
}

@Composable
fun LogScreen(cfg: Cfg) {
    val ctx = LocalContext.current
    var onlyProblems by remember { mutableStateOf(false) }
    val shown = if (onlyProblems) ApiLog.entries.filter { it.level != "I" } else ApiLog.entries.toList()
    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(L.t("log_title"), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ Thread { Api.get(cfg).diagnose() }.start() }) { Text(L.t("test")) }
            OutlinedButton({
                val txt = shown.take(200).reversed().joinToString("\n") { "${it.t} [${it.level}] ${it.tag}: ${it.msg}" }
                ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("SolarCharge", txt))
            }) { Text(L.t("copy")) }
            OutlinedButton({ ApiLog.clear() }) { Text(L.t("clear")) }
        }
        FilterChip(selected = onlyProblems, onClick = { onlyProblems = !onlyProblems }, label = { Text(L.t("only_problems")) })
        if (shown.isEmpty()) Label(L.t("no_logs"))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(shown) { e ->
                val col = when (e.level) {
                    "E" -> MaterialTheme.colorScheme.error
                    "W" -> Color(0xFFF0A020)
                    else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                }
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface).padding(10.dp)
                ) {
                    Text("${e.t} · ${e.tag}", fontSize = 11.sp, color = col, fontWeight = FontWeight.SemiBold)
                    Text(e.msg, fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = col)
                }
            }
        }
    }
}

/** Hue / saturation / brightness sliders with a preview swatch. */
@Composable
fun ColorPicker(label: String, color: Color, onChange: (Color) -> Unit) {
    val init = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(color.toArgb(), it) } }
    var h by remember { mutableFloatStateOf(init[0]) }
    var sat by remember { mutableFloatStateOf(init[1]) }
    var v by remember { mutableFloatStateOf(init[2]) }
    fun push() = onChange(Look.fromHsv(h, sat, v))
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Look.fromHsv(h, sat, v)).border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f), CircleShape))
            Spacer(Modifier.width(10.dp))
            Text(label, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Text(Look.hex(Look.fromHsv(h, sat, v)), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
        Text(L.t("h_hue"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Slider(h, { h = it; push() }, valueRange = 0f..360f)
        Text(L.t("h_sat"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Slider(sat, { sat = it; push() }, valueRange = 0f..1f)
        Text(L.t("h_val"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Slider(v, { v = it; push() }, valueRange = 0f..1f)
    }
}


/** Solar source selector + the fields of the chosen provider. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun ProviderFields(cfg: Cfg) {
    val ctx = LocalContext.current
    var prov by remember { mutableStateOf(Providers.id(cfg)) }
    var auth by remember { mutableStateOf(cfg.get("provAuth", "none")) }
    Label(L.t("prov_label"))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Providers.ids.forEach { id ->
            Pill(prov == id, L.t("prov_$id")) { prov = id; cfg.set("provider", id) }
        }
    }
    when (prov) {
        "growatt" -> {
            CfgField(cfg, "growattToken", L.t("f_growattToken"), secret = true)
            CfgField(cfg, "plantId", L.t("f_plantId"), numeric = true)
            CfgField(cfg, "inverterSn", L.t("f_inverterSn"), "MKP0E6H0GR")
        }
        "solaredge" -> {
            Label(L.t("prov_se_help"))
            CfgField(cfg, "provKey", L.t("f_provKeyApi"), secret = true)
            CfgField(cfg, "provSite", L.t("f_provSite"), numeric = true)
            CfgField(cfg, "provSec", L.t("f_provSec"), "300", numeric = true)
        }
        "fronius" -> {
            Label(L.t("prov_fr_help"))
            CfgField(cfg, "provHost", L.t("f_provHost"), "192.168.1.60")
            CfgField(cfg, "provSec", L.t("f_provSec"), "10", numeric = true)
        }
        else -> {
            Label(L.t("prov_gen_help"))
            CfgField(cfg, "provUrl", L.t("f_provUrl"), "http://192.168.1.60/status")
            Label(L.t("f_provAuth"))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("none", "bearer", "header", "query", "basic").forEach { a ->
                    Pill(auth == a, L.t("auth_$a")) { auth = a; cfg.set("provAuth", a) }
                }
            }
            if (auth == "header" || auth == "query") CfgField(cfg, "provAuthName", L.t("f_provAuthName"), if (auth == "header") "X-API-Key" else "api_key")
            if (auth == "basic") CfgField(cfg, "provUser", L.t("f_provUser"))
            if (auth != "none") CfgField(cfg, "provKey", L.t("f_provKey"), secret = true)
            CfgField(cfg, "provPvPath", L.t("f_provPvPath"), "Body.Data.Site.P_PV")
            CfgField(cfg, "provPvScale", L.t("f_provPvScale"), "1", numeric = true)
            CfgField(cfg, "provLoadPath", L.t("f_provLoadPath"), L.t("hint_optional"))
            CfgField(cfg, "provLoadScale", L.t("f_provLoadScale"), "1", numeric = true)
            CfgField(cfg, "provSec", L.t("f_provSec"), "30", numeric = true)
        }
    }
    if (prov != "growatt") OutlinedButton({
        Thread {
            val r = Providers.test(cfg)
            android.os.Handler(android.os.Looper.getMainLooper()).post { Toast.makeText(ctx, r, Toast.LENGTH_LONG).show() }
        }.start()
    }, Modifier.fillMaxWidth()) { Text(L.t("local_test")) }
}


fun navKey(id: String) = when (id) {
    "dash" -> "nav_dash"; "tesla" -> "nav_tesla"; "hist" -> "nav_hist"; "set" -> "nav_settings"; "donate" -> "nav_donate"; else -> "nav_log"
}

@Composable
fun TabIcon(id: String, selected: Boolean = true) {
    if (Look.iconSet == "emoji") {
        when (id) {
            "dash" -> Icon(Icons.Default.Home, null)
            "tesla" -> Text("🚗", fontSize = 20.sp)
            "hist" -> Icon(Icons.Default.ListIcon, null)
            "set" -> Icon(Icons.Default.Settings, null)
            "donate" -> Text("❤️", fontSize = 20.sp)
            else -> Icon(Icons.Default.Info, null)
        }
        return
    }
    // same icon family and style as the energy-flow diagram
    val kind = when (id) { "dash" -> "home"; "tesla" -> "car"; "hist" -> "chart"; "set" -> "gear"; "donate" -> "heart"; else -> "info" }
    val col = FlowIcons.color(kind, MaterialTheme.colorScheme.primary, Color(0xFFE8A53A))
    FlowIcon(kind, if (selected) col else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), Look.iconSet, 24.dp)
}

/** App logo: the launcher icon (sunrise with bolt, drawn from the same vector data as ic_launcher_*) followed by the "SolarCharge" wordmark. */
@Composable
fun AppLogo() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.foundation.Canvas(Modifier.size(46.dp)) {
            val k = size.minDimension / 108f
            scale(k, k, Offset.Zero) {
                val shape = androidx.compose.ui.graphics.Path().apply { addRoundRect(androidx.compose.ui.geometry.RoundRect(0f, 0f, 108f, 108f, 32f, 32f)) }
                clipPath(shape) {
                    drawRect(Brush.verticalGradient(0f to Color(0xFF312E81), 0.6f to Color(0xFFC2410C), 1f to Color(0xFFFB923C), startY = 0f, endY = 108f))
                    drawRect(Color(0x8C0F172A), Offset(0f, 70f), androidx.compose.ui.geometry.Size(108f, 38f))
                    drawLine(Color(0x40FFFFFF), Offset(0f, 80f), Offset(108f, 80f), strokeWidth = 2f)
                    drawLine(Color(0x40FFFFFF), Offset(0f, 90f), Offset(108f, 90f), strokeWidth = 2f)
                    scale(0.82f, 0.82f, Offset(54f, 54f)) {
                        val ray = Color(0xFFFFE9B0)
                        listOf(54f to 22f to (54f to 28f), 27f to 34f to (31f to 38f), 81f to 34f to (77f to 38f), 16f to 56f to (22f to 56f), 92f to 56f to (86f to 56f))
                            .forEach { (a, b) -> drawLine(ray, Offset(a.first, a.second), Offset(b.first, b.second), strokeWidth = 4f, cap = androidx.compose.ui.graphics.StrokeCap.Round) }
                        val sun = androidx.compose.ui.graphics.Path().apply {
                            moveTo(24f, 70f); arcTo(androidx.compose.ui.geometry.Rect(24f, 40f, 84f, 100f), 180f, 180f, false); close()
                        }
                        drawPath(sun, Brush.linearGradient(listOf(Color(0xFFFFE070), Color(0xFFFF9F1C)), Offset(30f, 40f), Offset(78f, 70f)))
                        val bolt = androidx.compose.ui.graphics.Path().apply {
                            moveTo(57f, 48f); lineTo(47f, 62f); lineTo(53f, 62f); lineTo(50.5f, 74f); lineTo(62f, 58f); lineTo(56f, 58f); close()
                        }
                        drawPath(bolt, Color.White)
                    }
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        FitText(
            androidx.compose.ui.text.buildAnnotatedString {
                withStyle(androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.onBackground)) { append("Solar") }
                withStyle(androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.ExtraBold, color = Color(0xFF14B8A6))) { append("Charge") }
            },
            Modifier.weight(1f, fill = false), fontSize = 30.sp, minSize = 18.sp, letterSpacing = (-0.5).sp
        )
    }
}

/** Asks Android to exempt the app from battery optimisation (Doze), which otherwise delays the night cycles to 15-30 min. */
/** Dashboard warning while Android may suspend the app (battery optimisation on): the night cycles then stop for hours. */
@Composable
fun BatteryWarn() {
    val ctx = LocalContext.current
    val pm = ctx.getSystemService(android.os.PowerManager::class.java)
    var ok by remember { mutableStateOf(pm.isIgnoringBatteryOptimizations(ctx.packageName)) }
    LaunchedEffect(Unit) { while (true) { ok = pm.isIgnoringBatteryOptimizations(ctx.packageName); delay(3000) } }
    if (ok) return
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFFE8A53A).copy(alpha = 0.16f)).padding(14.dp)) {
        Text(L.t("bat_warn"), fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        BatteryRow()
    }
}

@Composable
fun BatteryRow() {
    val ctx = LocalContext.current
    val pm = ctx.getSystemService(android.os.PowerManager::class.java)
    var ok by remember { mutableStateOf(pm.isIgnoringBatteryOptimizations(ctx.packageName)) }
    LaunchedEffect(Unit) { while (true) { ok = pm.isIgnoringBatteryOptimizations(ctx.packageName); delay(2000) } }
    if (ok) Label(L.t("bg_ok"))
    else OutlinedButton({
        try {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            try { ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }, Modifier.fillMaxWidth()) { FitText(L.t("bg_btn")) }
}
