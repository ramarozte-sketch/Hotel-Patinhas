package com.rui.solarcharge

import android.content.Context
import androidx.compose.runtime.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/** Settings in SharedPreferences. */
class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    /** Keys stored encrypted (Android Keystore). Old plain values are encrypted the first time they are read. */
    private val secret = setOf("growattToken", "teslaToken", "anthropicKey", "provKey")

    fun get(k: String, d: String = ""): String {
        val v = p.getString(k, d) ?: d
        if (k !in secret || v.isEmpty()) return v
        if (Secrets.isEncrypted(v)) return Secrets.decrypt(v)
        val e = Secrets.encrypt(v)
        if (e != v) p.edit().putString(k, e).apply()
        return v
    }
    fun set(k: String, v: String) = p.edit().putString(k, if (k in secret) Secrets.encrypt(v) else v).apply()
    fun int(k: String, d: Int) = get(k, "").toIntOrNull() ?: d

    /** Keys that are internal caches, not settings: they are not exported. */
    private val internal = setOf("energySamples", "pvMultLearned", "pvSource")

    /** All settings as a JSON text (includes tokens: keep the file private). */
    fun exportJson(): String {
        val o = JSONObject()
        p.all.forEach { (k, v) -> if (k !in internal && v is String) o.put(k, get(k)) }
        val root = JSONObject()
        root.put("app", "SolarCharge")
        root.put("format", 1)
        root.put("exported", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
        root.put("settings", o)
        return root.toString(2)
    }

    /** Imports settings from exportJson() text. Returns the number of values imported, or -1 if the file is not valid. */
    fun importJson(text: String): Int {
        return try {
            val root = JSONObject(text)
            if (root.optString("app") != "SolarCharge") return -1
            val o = root.getJSONObject("settings")
            val ed = p.edit()
            var n = 0
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                if (k in internal) continue
                ed.putString(k, if (k in secret) Secrets.encrypt(o.optString(k)) else o.optString(k)); n++
            }
            ed.apply()
            n
        } catch (e: Exception) { -1 }
    }
}

/** A translatable status message: key into the L tables plus format arguments. */
class Msg(val key: String, val args: List<Any>)

/** Live values shown on the dashboard (Compose snapshot state, safe to write from the service thread). */
object Live {
    var pvW by mutableDoubleStateOf(0.0)
    var teslaKw by mutableDoubleStateOf(0.0)
    /** Total house consumption in W (includes the car), or -1 when the inverter does not report it. */
    var houseW by mutableDoubleStateOf(-1.0)
    var battery by mutableIntStateOf(-1)
    var chargingState by mutableStateOf("—")
    var amps by mutableIntStateOf(0)
    var message by mutableStateOf(Msg("msg_stopped", emptyList()))
    var running by mutableStateOf(false)
    var updated by mutableStateOf("")
    /** "Charge now" switch: charge at full power from the grid until the target is reached. */
    var boost by mutableStateOf(false)
    /** Solar forecast for the dashboard: outlook "good" | "mixed" | "poor" | "night" | "" (unknown), clouds %, hourly bars 0..1, first hour, trend "up" | "down" | "". */
    var fcOutlook by mutableStateOf("")
    var fcCloud by mutableIntStateOf(-1)
    var fcBars by mutableStateOf<List<Float>>(emptyList())
    var fcStartHour by mutableIntStateOf(0)
    var fcTrend by mutableStateOf("")
    /** Expected production in kWh (installed kWp x radiation x 0.8): per displayed hour, rest of today, whole today and tomorrow (-1 = unknown). */
    var fcKwh by mutableStateOf<List<Double>>(emptyList())
    var fcKwhRest by mutableDoubleStateOf(-1.0)
    var fcKwhToday by mutableDoubleStateOf(-1.0)
    var fcKwhTomorrow by mutableDoubleStateOf(-1.0)
    /** Last full vehicle state from Tessie (for the Tesla tab) and the time it was read. */
    var teslaJson by mutableStateOf<org.json.JSONObject?>(null)
    var teslaAt by mutableStateOf("")
    /** Whether the Log tab is shown in the bottom bar (setting "showLog"). */
    var showLog by mutableStateOf(true)

    fun msg(key: String, vararg args: Any) { message = Msg(key, args.toList()) }
    fun messageText(): String = L.t(message.key, *message.args.toTypedArray())
}

/** Daily history: [0] kWh charged into the Tesla, [1] kWh produced, [2] kWh consumed by the house without the car,
 *  [3] kWh of the car taken from the grid, [4] € saved (car energy from solar x tariff), [5] € paid for the car's grid energy. */
class History(ctx: Context) {
    private val app = ctx.applicationContext
    private val p = ctx.getSharedPreferences("hist", Context.MODE_PRIVATE)
    private val fmt get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val dayRe = Regex("\\d{4}-\\d{2}-\\d{2}")

    @Synchronized
    fun add(chargedKwh: Double, solarKwh: Double, houseKwh: Double, gridKwh: Double, savedEur: Double, costEur: Double) {
        val day = fmt.format(Date())
        val j = JSONObject(p.getString(day, null) ?: "{}")
        j.put("c", j.optDouble("c", 0.0) + chargedKwh)
        j.put("s", j.optDouble("s", 0.0) + solarKwh)
        j.put("h", j.optDouble("h", 0.0) + houseKwh)
        j.put("g", j.optDouble("g", 0.0) + gridKwh)
        j.put("e", j.optDouble("e", 0.0) + savedEur)
        j.put("k", j.optDouble("k", 0.0) + costEur)
        p.edit().putString(day, j.toString()).apply()
    }

    /** The inverter's own counter of today's production can only raise the day's solar total (the sum of samples misses the gaps). */
    @Synchronized
    fun raiseSolarToday(kwh: Double) {
        val day = fmt.format(Date())
        val j = JSONObject(p.getString(day, null) ?: "{}")
        if (kwh > j.optDouble("s", 0.0)) { j.put("s", kwh); p.edit().putString(day, j.toString()).apply() }
    }

    private fun parse(v: String?): DoubleArray {
        val j = try { JSONObject(v ?: "{}") } catch (e: Exception) { JSONObject() }
        return doubleArrayOf(j.optDouble("c", 0.0), j.optDouble("s", 0.0), j.optDouble("h", 0.0), j.optDouble("g", 0.0), j.optDouble("e", 0.0), j.optDouble("k", 0.0),
            j.optDouble("l", 0.0), j.optDouble("u", 0.0), j.optDouble("i", 0.0), j.optDouble("x", 0.0))
    }

    /** House energy flow of the day, only when the inverter reports the house load (no battery modelled):
     *  [6] house load, [7] solar used in the house (self-consumed), [8] imported from the grid, [9] exported to the grid, all in kWh. */
    @Synchronized
    fun addFlow(loadKwh: Double, usedKwh: Double, importKwh: Double, exportKwh: Double) {
        val day = fmt.format(Date())
        val j = JSONObject(p.getString(day, null) ?: "{}")
        j.put("l", j.optDouble("l", 0.0) + loadKwh)
        j.put("u", j.optDouble("u", 0.0) + usedKwh)
        j.put("i", j.optDouble("i", 0.0) + importKwh)
        j.put("x", j.optDouble("x", 0.0) + exportKwh)
        p.edit().putString(day, j.toString()).apply()
    }

    private val hp = ctx.getSharedPreferences("hourly", Context.MODE_PRIVATE)

    /** Adds energy to the hour-of-day profile: car charging and solar production (kWh), kept for the last 400 days. */
    @Synchronized
    fun addHour(hour: Int, carKwh: Double, pvKwh: Double) {
        if (hour !in 0..23) return
        val day = fmt.format(Date())
        val j = try { JSONObject(hp.getString(day, null) ?: "{}") } catch (e: Exception) { JSONObject() }
        val c = j.optJSONArray("c") ?: JSONArray().also { a -> repeat(24) { a.put(0.0) } }
        val s = j.optJSONArray("s") ?: JSONArray().also { a -> repeat(24) { a.put(0.0) } }
        c.put(hour, c.optDouble(hour, 0.0) + carKwh)
        s.put(hour, s.optDouble(hour, 0.0) + pvKwh)
        j.put("c", c).put("s", s)
        val ed = hp.edit().putString(day, j.toString())
        val keys = hp.all.keys.filter { dayRe.matches(it) }.sorted()
        if (keys.size > 400) keys.take(keys.size - 400).forEach { ed.remove(it) }
        ed.apply()
    }

    /** Hour profile per day: date -> (car kWh by hour, solar kWh by hour). */
    @Synchronized
    fun hourly(): Map<String, Pair<DoubleArray, DoubleArray>> {
        val out = HashMap<String, Pair<DoubleArray, DoubleArray>>()
        hp.all.forEach { (k, v) ->
            if (dayRe.matches(k) && v is String) try {
                val j = JSONObject(v)
                val c = j.optJSONArray("c"); val s = j.optJSONArray("s")
                out[k] = DoubleArray(24) { c?.optDouble(it, 0.0) ?: 0.0 } to DoubleArray(24) { s?.optDouble(it, 0.0) ?: 0.0 }
            } catch (_: Exception) {}
        }
        return out
    }

    /** All recorded days: date (yyyy-MM-dd) -> [charged, solar, house] in kWh. */
    @Synchronized
    fun all(): Map<String, DoubleArray> {
        val out = HashMap<String, DoubleArray>()
        p.all.forEach { (k, v) -> if (dayRe.matches(k) && v is String) out[k] = parse(v) }
        return out
    }

    /** Sets the solar production of past days from an external source (day to kWh). Other fields of a day are kept. Returns the days written. */
    @Synchronized
    fun importSolar(map: Map<String, Double>): Int {
        val ed = p.edit()
        var n = 0
        for ((day, kwh) in map) {
            if (!dayRe.matches(day) || kwh <= 0.0) continue
            val j = JSONObject(p.getString(day, null) ?: "{}")
            j.put("s", kwh)
            ed.putString(day, j.toString()); n++
        }
        ed.apply()
        return n
    }

    @Synchronized
    fun today(): DoubleArray = parse(p.getString(fmt.format(Date()), null))

    @Synchronized
    fun exportJson(): String {
        val days = JSONObject()
        all().toSortedMap().forEach { (k, a) ->
            days.put(k, JSONObject().put("c", a[0]).put("s", a[1]).put("h", a[2]).put("g", a[3]).put("e", a[4]).put("k", a[5])
                .put("l", a[6]).put("u", a[7]).put("i", a[8]).put("x", a[9]))
        }
        val hours = JSONObject()
        hourly().toSortedMap().forEach { (k, v) -> hours.put(k, JSONObject().put("c", JSONArray(v.first.toList())).put("s", JSONArray(v.second.toList()))) }
        return JSONObject().put("app", "SolarCharge").put("type", "history").put("format", 1)
            .put("exported", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
            .put("days", days).put("hourly", hours)
            .put("tcharges", TeslaCharges(app).exportArray()).put("tchargesSync", TeslaCharges(app).lastSync)
            .put("sessions", Sessions(app).exportArray()).put("carstats", CarStats.exportJson(app)).toString(2)
    }

    /** Merges days from exportJson() text (file days replace the same days). Returns the number of days, or -1 if invalid. */
    @Synchronized
    fun importJson(text: String): Int {
        return try {
            val root = JSONObject(text)
            if (root.optString("app") != "SolarCharge" || root.optString("type") != "history") return -1
            val days = root.getJSONObject("days")
            val ed = p.edit()
            var n = 0
            val it = days.keys()
            while (it.hasNext()) {
                val k = it.next()
                if (!dayRe.matches(k)) continue
                val d = days.optJSONObject(k) ?: continue
                // solar production imported from Growatt must never be lost: keep the larger of the two values for the day
                val keepS = maxOf(d.optDouble("s", 0.0), p.getString(k, null)?.let { try { JSONObject(it).optDouble("s", 0.0) } catch (_: Exception) { 0.0 } } ?: 0.0)
                ed.putString(k, JSONObject().put("c", d.optDouble("c", 0.0)).put("s", keepS).put("h", d.optDouble("h", 0.0))
                    .put("g", d.optDouble("g", 0.0)).put("e", d.optDouble("e", 0.0)).put("k", d.optDouble("k", 0.0))
                    .put("l", d.optDouble("l", 0.0)).put("u", d.optDouble("u", 0.0)).put("i", d.optDouble("i", 0.0)).put("x", d.optDouble("x", 0.0)).toString())
                n++
            }
            val hours = root.optJSONObject("hourly")
            if (hours != null) {
                val hed = hp.edit()
                val hk = hours.keys()
                while (hk.hasNext()) {
                    val k = hk.next()
                    if (dayRe.matches(k)) hours.optJSONObject(k)?.let { hed.putString(k, it.toString()) }
                }
                hed.apply()
            }
            ed.apply()
            root.optJSONArray("tcharges")?.let { TeslaCharges(app).importArray(it) }
            root.optLong("tchargesSync", 0L).let { v -> val t = TeslaCharges(app); if (v > t.lastSync) t.lastSync = v }
            root.optJSONArray("sessions")?.let { Sessions(app).importArray(it) }
            root.optJSONObject("carstats")?.let { CarStats.importJson(app, it) }
            n
        } catch (e: Exception) { -1 }
    }

    fun clear() { p.edit().clear().apply(); hp.edit().clear().apply() }
}

class LogEntry(val t: String, val level: String, val tag: String, val msg: String)

/** Log of API calls and decisions (newest first). Persisted in a small file so it survives restarts. */
object ApiLog {
    val entries = mutableStateListOf<LogEntry>()
    private var file: File? = null
    private val tf get() = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US)

    @Synchronized
    fun init(ctx: Context) {
        if (file != null) return
        val f = File(ctx.filesDir, "apilog.txt")
        file = f
        try {
            if (f.exists()) f.readLines().takeLast(400).forEach { l ->
                val p = l.split("\t", limit = 4)
                if (p.size == 4) entries.add(0, LogEntry(p[0], p[1], p[2], p[3]))
            }
        } catch (_: Exception) {}
    }

    @Synchronized
    private fun add(level: String, tag: String, msg: String) {
        val e = LogEntry(tf.format(Date()), level, tag, msg.replace("\n", " ").replace("\t", " "))
        entries.add(0, e)
        while (entries.size > 400) entries.removeAt(entries.size - 1)
        try {
            val f = file ?: return
            f.appendText("${e.t}\t${e.level}\t${e.tag}\t${e.msg}\n")
            if (f.length() > 300_000) f.writeText(entries.reversed().joinToString("") { "${it.t}\t${it.level}\t${it.tag}\t${it.msg}\n" })
        } catch (_: Exception) {}
    }

    fun i(tag: String, msg: String) = add("I", tag, msg)
    fun w(tag: String, msg: String) = add("W", tag, msg)
    fun e(tag: String, msg: String) = add("E", tag, msg)

    @Synchronized
    fun clear() { entries.clear(); try { file?.writeText("") } catch (_: Exception) {} }
}
