package com.rui.solarcharge

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.TextButton
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

/** Estimates shared by the report, the lifetime totals and the share text. */
const val CO2_KG_PER_KWH = 0.2
const val KWH_PER_KM = 0.16

fun dayKey(ym: YearMonth, d: Int): String = String.format(Locale.US, "%04d-%02d-%02d", ym.year, ym.monthValue, d)

/** Percentage change of [now] versus [before], or null when there is nothing to compare with. */
fun deltaPct(now: Double, before: Double): Double? = if (before > 0.0001) (now - before) / before * 100.0 else null

/** Share of the car's charging that came from the sun (0..100). */
fun solarPct(charged: Double, grid: Double): Int =
    if (charged > 0.05) ((charged - grid) / charged * 100.0).toInt().coerceIn(0, 100) else 0

/** Text of the period report sent by the share button. */
fun reportText(chargedKwh: Double, gridKwh: Double, saved: Double, cost: Double, period: String): String {
    val solarKwh = maxOf(chargedKwh - gridKwh, 0.0)
    return L.t("rep_text", period, L.n(chargedKwh, 1), solarPct(chargedKwh, gridKwh), L.n(solarKwh, 1), L.n(saved, 2), L.n(cost, 2),
        L.n(solarKwh * CO2_KG_PER_KWH, 0), L.n(chargedKwh / KWH_PER_KM, 0))
}

fun fmtDay(key: String): String = try {
    val d = LocalDate.parse(key)
    "${d.dayOfMonth} " + monthName(d.monthValue, java.time.format.TextStyle.SHORT)
} catch (e: Exception) { key }

/** Ring with the solar share of the charging, drawn white to sit on the coloured header. */
@Composable
fun SolarRing(pct: Int, modifier: Modifier = Modifier) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(pct) { anim.animateTo(pct / 100f, tween(700)) }
    Box(modifier.size(78.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 8.dp.toPx()
            val sz = Size(size.width - sw, size.height - sw)
            val tl = Offset(sw / 2f, sw / 2f)
            drawArc(color = Color.White.copy(alpha = 0.25f), startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(sw))
            drawArc(color = Color.White, startAngle = -90f, sweepAngle = 360f * anim.value, useCenter = false, topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$pct %", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(L.t("solar_word"), fontSize = 10.sp, color = Color.White.copy(alpha = 0.85f))
        }
    }
}

/** Change chip shown on the header (arrow, percentage and what it is compared with). */
@Composable
fun DeltaChip(delta: Double?, what: String) {
    if (delta == null) return
    Text(
        (if (delta >= 0) "▲ " else "▼ ") + L.n(kotlin.math.abs(delta), 0) + " % " + what,
        fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.22f)).padding(horizontal = 10.dp, vertical = 3.dp)
    )
}

/** Month as a calendar: each day coloured by the chosen metric. Tap a day for its detail. */
@Composable
fun HeatCalendar(data: Map<String, DoubleArray>, ym: YearMonth, idx: Int, selected: Int, onSelect: (Int) -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val onSurf = MaterialTheme.colorScheme.onSurface
    val vals = (1..ym.lengthOfMonth()).map { data[dayKey(ym, it)]?.get(idx) ?: 0.0 }
    val mx = maxOf(vals.maxOrNull() ?: 0.0, 0.001)
    val offset = ym.atDay(1).dayOfWeek.value - 1          // Monday = 0
    val rows = (offset + vals.size + 6) / 7
    val today = LocalDate.now()
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (c in 0..6) Text(
                java.time.DayOfWeek.of(c + 1).getDisplayName(java.time.format.TextStyle.NARROW, L.locale()),
                Modifier.weight(1f), fontSize = 10.sp, textAlign = TextAlign.Center, color = onSurf.copy(alpha = 0.55f)
            )
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (c in 0..6) {
                    val d = r * 7 + c - offset + 1
                    if (d in 1..vals.size) {
                        val v = vals[d - 1]
                        val a = if (v > 0) 0.2f + 0.8f * (v / mx).toFloat() else 0f
                        val isSel = d == selected
                        val isToday = ym.atDay(d) == today
                        Box(
                            Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(10.dp))
                                .background(if (v > 0) primary.copy(alpha = a) else onSurf.copy(alpha = 0.06f))
                                .then(if (isSel) Modifier.border(2.dp, onSurf.copy(alpha = 0.85f), RoundedCornerShape(10.dp)) else Modifier)
                                .clickable { onSelect(if (isSel) -1 else d) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                d.toString(), fontSize = 11.sp, fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                                color = if (v > 0 && a > 0.55f) Color.White else onSurf.copy(alpha = 0.75f)
                            )
                        }
                    } else Spacer(Modifier.weight(1f).aspectRatio(1f))
                }
            }
        }
    }
}

@Composable
fun KeyValue(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
    }
}

/** Records and averages over the whole history, plus the end-of-month forecast for the chosen metric. */
@Composable
fun RecordsPanel(data: Map<String, DoubleArray>, ym: YearMonth, now: YearMonth, idx: Int, metricName: String, unit: String, dec: Int) {
    var bestPvK = ""; var bestPv = 0.0
    var bestCarK = ""; var bestCar = 0.0
    var bestSolarK = ""; var bestSolar = 0.0
    var cur = 0; var best = 0
    data.toSortedMap().forEach { (k, a) ->
        if (a[1] > bestPv) { bestPv = a[1]; bestPvK = k }
        if (a[0] > bestCar) { bestCar = a[0]; bestCarK = k }
        if (a[0] >= 1.0) {
            val solar = a[0] - a[3]
            if (solar > bestSolar) { bestSolar = solar; bestSolarK = k }
            if (a[3] <= a[0] * 0.02) { cur++; if (cur > best) best = cur } else cur = 0
        }
    }
    val vals = series(data, "month", ym, ym.year, idx)
    val active = vals.count { it > 0 }
    val avg = if (active > 0) vals.sum() / active else 0.0
    Panel(id = "hist_records", title = L.t("hist_records")) {
        Spacer(Modifier.height(6.dp))
        if (data.isEmpty()) { Label(L.t("no_data")); return@Panel }
        if (active > 0) KeyValue(L.t("rec_avg", metricName), L.n(avg, dec) + " " + unit)
        if (ym == now && active > 0) {
            val elapsed = java.time.LocalDate.now().dayOfMonth.coerceAtLeast(1)
            KeyValue(L.t("rec_forecast"), "≈ " + L.n(vals.sum() / elapsed * ym.lengthOfMonth(), dec) + " " + unit)
        }
        if (bestPv > 0) KeyValue(L.t("rec_best_pv"), L.n(bestPv, 1) + " kWh · " + fmtDay(bestPvK))
        if (bestCar > 0) KeyValue(L.t("rec_best_car"), L.n(bestCar, 1) + " kWh · " + fmtDay(bestCarK))
        if (bestSolar > 0) KeyValue(L.t("rec_best_solar"), L.n(bestSolar, 1) + " kWh · " + fmtDay(bestSolarK))
        KeyValue(L.t("rec_streak"), L.t("rec_days", cur) + "  (" + L.t("rec_best") + " " + L.t("rec_days", best) + ")")
        Spacer(Modifier.height(4.dp))
        Label(L.t("rec_note"))
    }
}

/** Totals since the first recorded day. */
@Composable
fun LifetimePanel(data: Map<String, DoubleArray>) {
    val charged = data.values.sumOf { it[0] }
    val pv = data.values.sumOf { it[1] }
    val grid = data.values.sumOf { it[3] }
    val saved = data.values.sumOf { it[4] }
    val cost = data.values.sumOf { it[5] }
    val solarKwh = maxOf(charged - grid, 0.0)
    val since = data.keys.minOrNull()
    Panel(id = "hist_lifetime", title = L.t("hist_lifetime")) {
        Spacer(Modifier.height(6.dp))
        if (data.isEmpty()) { Label(L.t("no_data")); return@Panel }
        val primary = MaterialTheme.colorScheme.primary
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("🚗", L.t("life_charged"), L.n(charged, 0) + " kWh", primary, Modifier.weight(1f))
            StatTile("☀️", L.t("life_pv"), L.n(pv, 0) + " kWh", Color(0xFFE8A53A), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("💶", L.t("life_saved"), L.n(saved, 0) + " €", Color(0xFF2E9E5B), Modifier.weight(1f))
            StatTile("🌱", L.t("life_co2"), L.n(solarKwh * CO2_KG_PER_KWH, 0) + " kg", Color(0xFF3B82F6), Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Label(L.t("life_note", if (since != null) fmtDay(since) + " " + since.take(4) else "—", solarPct(charged, grid), L.n(cost, 0), L.n(charged / KWH_PER_KM, 0)))
    }
}

private fun durText(ms: Long): String {
    val m = (ms / 60000).toInt().coerceAtLeast(0)
    return if (m >= 60) "${m / 60} h ${String.format(Locale.US, "%02d", m % 60)} min" else "$m min"
}

/** Charging sessions as cards: solar/grid bar, battery change, tap for the detail, filter by mode. */
@Composable
fun SessionsPanel(day: String? = null, dayLabel: String = "", onClear: () -> Unit = {}) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var list by remember { mutableStateOf(Sessions(ctx).all()) }
    var running by remember { mutableStateOf(Sessions(ctx).current()) }
    LaunchedEffect(Unit) { while (true) { list = Sessions(ctx).all(); running = Sessions(ctx).current(); delay(10000) } }
    var filter by remember { mutableStateOf("") }
    var openKey by remember { mutableLongStateOf(0L) }
    var more by remember(day) { mutableStateOf(false) }
    val dayFmt = remember { java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val df = remember(L.lang) { java.text.SimpleDateFormat("dd/MM HH:mm", L.locale()) }
    val tf = remember(L.lang) { java.text.SimpleDateFormat("HH:mm", L.locale()) }
    val primary = MaterialTheme.colorScheme.primary
    val onSurf = MaterialTheme.colorScheme.onSurface
    val own = listOfNotNull(running) + list
    // Tesla (Tessie) charges that the app did not record itself complete the list
    val extra = remember(list, TeslaImport.running, TeslaImport.status) {
        TeslaCharges(ctx).all().filter { t -> own.none { o -> t.start < o.end && o.start < t.end } }
            .map { t -> Session(t.start, t.end, t.kwh, 0.0, 0.0, 0.0, if (t.cost.isNaN()) 0.0 else t.cost, t.b0, t.b1, "tessie") }
    }
    val all = (own + extra).sortedByDescending { it.start }.filter { day == null || dayFmt.format(java.util.Date(it.start)).startsWith(day) }
    val modes = all.map { it.mode }.distinct()
    val shownList = all.filter { filter.isEmpty() || it.mode == filter }
    Panel(id = "sess_title", title = L.t("sess_title")) {
        Spacer(Modifier.height(6.dp))
        if (day != null) Row(verticalAlignment = Alignment.CenterVertically) {
            FitText(dayLabel, Modifier.weight(1f), fontSize = 15.sp, minSize = 10.sp, fontWeight = FontWeight.SemiBold, color = primary)
            if (day.length == 10) TextButton(onClear) { Text("✕") }
        }
        if (all.isEmpty()) { Label(L.t(if (day != null && day.length == 10) "sess_none_day" else if (day != null) "sess_none_period" else "sess_none")); return@Panel }
        if (modes.size > 1) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(filter.isEmpty(), L.t("sess_all")) { filter = "" }
                modes.forEach { m -> Pill(filter == m, L.t("sess_mode_$m")) { filter = m } }
            }
            Spacer(Modifier.height(8.dp))
        }
        (if (more) shownList else shownList.take(5)).forEach { s ->
            val live = s === running
            val pct = if (s.kwh > 0) (s.solarKwh / s.kwh * 100).toInt().coerceIn(0, 100) else 0
            val open = openKey == s.start
            val h = (s.end - s.start) / 3600000.0
            Column(
                Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp))
                    .background(onSurf.copy(alpha = 0.05f)).clickable { openKey = if (open) 0L else s.start }.padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(df.format(java.util.Date(s.start)) + "–" + tf.format(java.util.Date(s.end)), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text((if (live) L.t("tsl_session_now") + " · " else "") + durText(s.end - s.start) + " · " + L.t("sess_mode_" + s.mode),
                            fontSize = 12.sp, color = onSurf.copy(alpha = 0.6f))
                    }
                    Text(L.n(s.kwh, 1) + " kWh", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                if (s.mode != "tessie") Spacer(Modifier.height(8.dp))
                if (s.mode != "tessie") Row(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))) {
                    Box(Modifier.weight(maxOf(pct, 1) / 100f).fillMaxHeight().background(Color(0xFFE8A53A)))
                    Box(Modifier.weight(maxOf(100 - pct, 1) / 100f).fillMaxHeight().background(onSurf.copy(alpha = 0.18f)))
                }
                Spacer(Modifier.height(6.dp))
                Row {
                    if (s.mode == "tessie") Spacer(Modifier.weight(1f))
                    else Text("☀ " + L.t("sess_solar_pct", pct), Modifier.weight(1f), fontSize = 12.sp, color = onSurf.copy(alpha = 0.7f))
                    if (s.b0 >= 0) Text("🔋 ${s.b0} → ${s.b1} %", fontSize = 12.sp, color = primary, fontWeight = FontWeight.SemiBold)
                }
                if (open) {
                    Spacer(Modifier.height(8.dp))
                    if (s.mode != "tessie") {
                        KeyValue(L.t("sess_solar_kwh"), L.n(s.solarKwh, 1) + " kWh")
                        KeyValue(L.t("sess_grid_kwh"), L.n(s.gridKwh, 1) + " kWh")
                    }
                    if (h > 0.02) KeyValue(L.t("sess_avg_power"), L.n(s.kwh / h, 1) + " kW")
                    if (s.mode != "tessie") KeyValue(L.t("sess_saved"), L.n(s.saved, 2) + " €")
                    if (s.mode != "tessie" || s.cost > 0.005) KeyValue(L.t("sess_cost"), L.n(s.cost, 2) + " €" + (if (s.kwh > 0.1) "  (" + L.n(s.cost / s.kwh, 3) + " €/kWh)" else ""))
                }
            }
        }
        if (shownList.size > 5) {
            Spacer(Modifier.height(6.dp))
            OutlinedButton({ more = !more }, Modifier.fillMaxWidth()) { FitText(if (more) L.t("sess_less") else L.t("sess_all_n", shownList.size)) }
        }
    }
}

/** Keys of the days inside the chosen month or year. */
private fun inPeriod(key: String, mode: String, ym: YearMonth, year: Int): Boolean =
    if (mode == "month") key.startsWith(String.format(Locale.US, "%04d-%02d", ym.year, ym.monthValue)) else key.startsWith(String.format(Locale.US, "%04d-", year))

@Composable
private fun MeterRow(label: String, pct: Int, color: Color) {
    val onSurf = MaterialTheme.colorScheme.onSurface
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Row {
            Text(label, Modifier.weight(1f), fontSize = 14.sp, color = onSurf.copy(alpha = 0.7f))
            Text("$pct %", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(onSurf.copy(alpha = 0.1f))) {
            if (pct > 0) Box(Modifier.weight(pct / 100f).fillMaxHeight().background(color))
            if (pct < 100) Spacer(Modifier.weight((100 - pct).coerceAtLeast(1) / 100f))
        }
    }
}

/** House self-sufficiency and self-consumption for the period (needs the inverter to report the house load). */
@Composable
fun SelfPanel(data: Map<String, DoubleArray>, mode: String, ym: YearMonth, year: Int) {
    var load = 0.0; var used = 0.0; var imp = 0.0; var exp = 0.0; var pv = 0.0
    data.forEach { (k, a) ->
        if (inPeriod(k, mode, ym, year) && a[6] > 0) { load += a[6]; used += a[7]; imp += a[8]; exp += a[9]; pv += a[1] }
    }
    Panel(id = "hist_self", title = L.t("hist_self")) {
        Spacer(Modifier.height(6.dp))
        if (load < 0.1) { Label(L.t("self_none")); return@Panel }
        MeterRow(L.t("self_suff"), (used / load * 100).toInt().coerceIn(0, 100), Color(0xFF2E9E5B))
        MeterRow(L.t("self_cons"), if (pv > 0.1) (used / pv * 100).toInt().coerceIn(0, 100) else 0, Color(0xFFE8A53A))
        Spacer(Modifier.height(4.dp))
        KeyValue(L.t("self_load"), L.n(load, 1) + " kWh")
        KeyValue(L.t("self_import"), L.n(imp, 1) + " kWh")
        KeyValue(L.t("self_export"), L.n(exp, 1) + " kWh")
        Spacer(Modifier.height(4.dp))
        Label(L.t("self_note"))
    }
}

/** 24 bars (solar behind, car in front) with the average energy per day for each hour of the day. */
@Composable
fun HourChart(car: List<Double>, pv: List<Double>, selected: Int, onSelect: (Int) -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val onSurf = MaterialTheme.colorScheme.onSurface
    val amber = Color(0xFFE8A53A)
    val mx = maxOf((car + pv).maxOrNull() ?: 0.0, 0.01)
    val measurer = androidx.compose.ui.text.rememberTextMeasurer()
    val style = androidx.compose.ui.text.TextStyle(fontSize = 8.sp, color = onSurf.copy(alpha = 0.6f))
    val curSel by rememberUpdatedState(selected)
    val curPick by rememberUpdatedState(onSelect)
    Canvas(
        Modifier.fillMaxWidth().height(150.dp).pointerInput(Unit) {
            detectTapGestures { off ->
                val i = (off.x / (size.width / 24f)).toInt()
                curPick(if (i in 0..23 && i != curSel) i else -1)
            }
        }
    ) {
        val slot = size.width / 24f
        val base = size.height - 18.dp.toPx()
        val plotH = base - 6.dp.toPx()
        drawLine(onSurf.copy(alpha = 0.2f), Offset(0f, base), Offset(size.width, base), strokeWidth = 1.dp.toPx())
        for (h in 0..23) {
            val x = slot * h + slot * 0.15f
            val w = slot * 0.7f
            val dim = selected >= 0 && h != selected
            val hp = (pv[h] / mx * plotH).toFloat()
            val hc = (car[h] / mx * plotH).toFloat()
            if (hp > 0) drawRoundRect(amber.copy(alpha = if (dim) 0.2f else 0.4f), Offset(x, base - hp), Size(w, hp), androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
            if (hc > 0) drawRoundRect(primary.copy(alpha = if (dim) 0.5f else 1f), Offset(x + w * 0.2f, base - hc), Size(w * 0.6f, hc), androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
            if (h % 3 == 0) {
                val t = measurer.measure(h.toString(), style)
                drawText(t, topLeft = Offset(slot * h + (slot - t.size.width) / 2f, base + 4.dp.toPx()))
            }
        }
    }
}

/** AC charging energy per hour of each day rebuilt from Tessie sessions, assuming constant power between start and end. Superchargers are left out. */
fun teslaHourly(list: List<TCharge>): Map<String, DoubleArray> {
    val zone = java.time.ZoneId.systemDefault()
    val out = HashMap<String, DoubleArray>()
    for (t in list) {
        if (t.dc || t.kwh <= 0.0) continue
        val dur = (t.end - t.start).coerceAtLeast(60_000L)
        val end = t.start + dur
        var cur = t.start
        while (cur < end) {
            val z = java.time.Instant.ofEpochMilli(cur).atZone(zone)
            val slotEnd = minOf(end, z.truncatedTo(java.time.temporal.ChronoUnit.HOURS).plusHours(1).toInstant().toEpochMilli())
            out.getOrPut(z.toLocalDate().toString()) { DoubleArray(24) }[z.hour] += t.kwh * (slotEnd - cur) / dur
            cur = slotEnd
        }
    }
    return out
}

/** When the sun produces and when the car charges, averaged over the days of the period. */
@Composable
fun HoursPanel(
    hourly: Map<String, Pair<DoubleArray, DoubleArray>>, mode: String, ym: YearMonth, year: Int,
    day: String? = null, dayLabel: String = "", onClear: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val tesla = remember(TeslaImport.running, TeslaImport.status) {
        val l = TeslaCharges(ctx).all()
        Pair(teslaHourly(l), l.minOfOrNull { it.start })
    }
    val tDays = tesla.first
    val today = java.time.LocalDate.now()
    val tFirst = tesla.second?.let { java.time.Instant.ofEpochMilli(it).atZone(java.time.ZoneId.systemDefault()).toLocalDate() }
    val periodDays: List<String> = when {
        day != null -> listOf(day)
        mode == "month" -> (1..ym.lengthOfMonth()).map { dayKey(ym, it) }
        else -> (1..java.time.Year.of(year).length()).map { java.time.LocalDate.ofYearDay(year, it).toString() }
    }
    val pvDays = periodDays.filter { hourly.containsKey(it) }
    // days the app did not measure are rebuilt from the Tessie sessions (from the first session until today; no session = no charging)
    val carDays = periodDays.filter {
        hourly.containsKey(it) || (tFirst != null && java.time.LocalDate.parse(it).let { d -> !d.isBefore(tFirst) && !d.isAfter(today) })
    }
    val usesTesla = carDays.any { !hourly.containsKey(it) && tDays.containsKey(it) }
    val n = maxOf(carDays.size, pvDays.size)
    // car: only the hours in which the car really charged count; each hour is averaged over the days that had charging in that hour
    val carVals = (0..23).map { h -> carDays.map { d -> hourly[d]?.first?.get(h) ?: tDays[d]?.get(h) ?: 0.0 }.filter { it > 0.005 } }
    val car = carVals.map { v -> if (v.isNotEmpty()) v.sum() / v.size else 0.0 }
    val carCount = carVals.map { it.size }
    val pv = (0..23).map { h -> if (pvDays.isNotEmpty()) pvDays.sumOf { d -> hourly[d]?.second?.get(h) ?: 0.0 } / pvDays.size else 0.0 }
    var sel by remember(mode, ym, year, day) { mutableIntStateOf(-1) }
    // totals shown while no hour is selected: the day itself, or the daily average of the period
    val pvTotal = if (pvDays.isNotEmpty()) pvDays.sumOf { d -> hourly[d]?.second?.sum() ?: 0.0 } / pvDays.size else 0.0
    val carTotal = if (carDays.isNotEmpty()) carDays.sumOf { d -> (hourly[d]?.first?.toList() ?: tDays[d]?.toList() ?: emptyList()).sum() } / carDays.size else 0.0
    Panel(id = "hist_hours", title = L.t("hist_hours")) {
        Spacer(Modifier.height(6.dp))
        if (day != null) Row(verticalAlignment = Alignment.CenterVertically) {
            FitText(dayLabel, Modifier.weight(1f), fontSize = 15.sp, minSize = 10.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            TextButton(onClear) { Text("✕") }
        }
        if (n == 0 || (car.sum() + pv.sum()) < 0.01) { Label(L.t("hours_none")); return@Panel }
        Text(
            if (sel in 0..23) String.format(Locale.US, "%02d:00 · ☀ %s kWh · 🚗 %s kWh", sel, L.n(pv[sel], 2), L.n(car[sel], 2)) + (if (day == null && carCount[sel] > 0) " (" + carCount[sel] + "×)" else "") else L.t(if (day != null) "hours_total_day" else "hours_total_avg") + String.format(Locale.US, " · ☀ %s kWh · 🚗 %s kWh", L.n(pvTotal, 1), L.n(carTotal, 1)),
            fontSize = 13.sp, fontWeight = if (sel >= 0) FontWeight.SemiBold else FontWeight.Normal,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(4.dp))
        HourChart(car, pv, sel) { sel = it }
        Spacer(Modifier.height(4.dp))
        val pvPeak = pv.indices.maxByOrNull { pv[it] } ?: 0
        val carPeak = car.indices.maxByOrNull { car[it] } ?: 0
        Label("☀ " + L.t("hours_pv_peak", pvPeak) + (if (car.sum() > 0.01) "  ·  🚗 " + L.t("hours_car_peak", carPeak) else ""))
        if (day == null) Label(L.t("hours_note", n))
        if (day == null) Label(L.t("hours_car_note"))
        if (usesTesla) Label(L.t("hours_tesla_note"))
    }
}

/** Simple line with area fill for a short series (consumption, range). */
@Composable
fun SparkLine(values: List<Double>, color: Color, modifier: Modifier = Modifier) {
    val onSurf = MaterialTheme.colorScheme.onSurface
    Canvas(modifier.fillMaxWidth().height(80.dp)) {
        if (values.size < 2) return@Canvas
        val lo = values.min(); val hi = values.max()
        val span = maxOf(hi - lo, hi * 0.02, 0.0001)
        val pad = 6.dp.toPx()
        val w = size.width - pad * 2; val h = size.height - pad * 2
        fun pt(i: Int) = Offset(pad + w * i / (values.size - 1), pad + h * (1f - ((values[i] - lo) / span).toFloat()))
        val line = androidx.compose.ui.graphics.Path()
        val area = androidx.compose.ui.graphics.Path()
        values.indices.forEach { i ->
            val p = pt(i)
            if (i == 0) { line.moveTo(p.x, p.y); area.moveTo(p.x, size.height); area.lineTo(p.x, p.y) } else { line.lineTo(p.x, p.y); area.lineTo(p.x, p.y) }
        }
        area.lineTo(pt(values.size - 1).x, size.height); area.close()
        drawPath(area, color.copy(alpha = 0.14f))
        drawPath(line, color, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
        drawCircle(color, 4.dp.toPx(), pt(values.size - 1))
        drawLine(onSurf.copy(alpha = 0.08f), Offset(0f, size.height - 1f), Offset(size.width, size.height - 1f), strokeWidth = 1.dp.toPx())
    }
}

/** Car efficiency and estimated battery health, from the readings kept by CarStats. */
@Composable
fun CarPanel(data: Map<String, DoubleArray>) {
    val cons = remember { CarStats.consLog() }
    val rng = remember { CarStats.range100Log() }
    Panel(id = "hist_car", title = L.t("hist_car")) {
        Spacer(Modifier.height(6.dp))
        if (cons.isEmpty() && rng.size < 2) { Label(L.t("car_none")); return@Panel }
        val primary = MaterialTheme.colorScheme.primary
        if (cons.isNotEmpty()) {
            val last = cons.takeLast(10).map { it.second }
            val avg = last.average()
            val charged = data.values.sumOf { it[0] }
            val cost = data.values.sumOf { it[5] }
            Text(L.t("car_cons"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            KeyValue(L.t("car_avg"), L.n(avg / 10.0, 1) + " kWh/100 km  (" + L.n(avg, 0) + " Wh/km)")
            if (charged > 5) KeyValue(L.t("car_eur100"), L.n(avg / 10.0 * cost / charged, 2) + " €")
            if (cons.size >= 2) { Spacer(Modifier.height(4.dp)); SparkLine(cons.map { it.second }, primary) }
            Spacer(Modifier.height(10.dp))
        }
        if (rng.size >= 2) {
            val now = rng.last().second; val best = rng.maxOf { it.second }
            Text(L.t("car_batt"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            MeterRow(L.t("car_health"), (now / best * 100).toInt().coerceIn(0, 100), Color(0xFF2E9E5B))
            KeyValue(L.t("car_range100"), L.n(now, 0) + " km  (" + L.t("car_best") + " " + L.n(best, 0) + " km)")
            Spacer(Modifier.height(4.dp))
            SparkLine(rng.map { it.second }, Color(0xFF2E9E5B))
        }
        Spacer(Modifier.height(6.dp))
        Label(L.t("car_note"))
    }
}

/** Compact drop-down selector: shows the chosen option and opens a menu with all of them. The text shrinks instead of being cut. */
@Composable
fun HistDropdown(options: List<String>, selected: Int, modifier: Modifier = Modifier, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val primary = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(14.dp)
    Box(modifier) {
        Row(
            Modifier.fillMaxWidth().clip(shape).border(1.dp, primary.copy(alpha = 0.5f), shape).clickable { open = true }
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FitText(options.getOrElse(selected) { "" }, Modifier.weight(1f), fontSize = 15.sp, minSize = 9.sp, fontWeight = FontWeight.SemiBold, color = primary)
            Spacer(Modifier.width(6.dp))
            Text("▾", color = primary, fontSize = 14.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEachIndexed { i, o ->
                DropdownMenuItem(
                    text = { Text(o, fontWeight = if (i == selected) FontWeight.Bold else FontWeight.Normal) },
                    onClick = { open = false; onSelect(i) }
                )
            }
        }
    }
}

/** Import of the past daily production from Growatt (only shown when Growatt is the source and is configured). */
@Composable
fun GrowattImportRow() {
    val ctx = LocalContext.current
    val cfg = remember { Cfg(ctx) }
    if (!Providers.isGrowatt(cfg) || cfg.get("growattToken").isBlank() || cfg.get("plantId").isBlank()) return
    var from by remember { mutableStateOf(cfg.get("pvSince", "2020-01-01")) }
    val valid = remember(from) { try { java.time.LocalDate.parse(from); true } catch (_: Exception) { false } }
    Spacer(Modifier.height(14.dp))
    Text(L.t("gi_title"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    Spacer(Modifier.height(4.dp))
    Label(L.t("gi_help"))
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(from, { from = it.trim() }, Modifier.fillMaxWidth(), label = { Text(L.t("gi_from")) }, singleLine = true, isError = !valid, enabled = !GrowattImport.running)
    Spacer(Modifier.height(8.dp))
    if (GrowattImport.running) OutlinedButton({ GrowattImport.cancel() }, Modifier.fillMaxWidth()) { FitText(L.t("cancel")) }
    else Button({ cfg.set("pvSince", from); GrowattImport.start(ctx, java.time.LocalDate.parse(from)) }, Modifier.fillMaxWidth(), enabled = valid) { FitText(L.t("gi_btn")) }
    GrowattImport.status?.let { Spacer(Modifier.height(6.dp)); Label(L.t(it.key, *it.args.toTypedArray())) }
}

/** Charging sessions reported by Tessie: totals for the selected period, home (AC) versus Supercharger, and the session list. */
@Composable
fun TeslaPanel(mode: String, ym: YearMonth, year: Int) {
    val ctx = LocalContext.current
    val cfg = remember { Cfg(ctx) }
    val store = remember { TeslaCharges(ctx) }
    val status = TeslaImport.status
    val list = remember(TeslaImport.running, status) { store.all() }
    var all by remember { mutableStateOf(false) }
    var from by remember { mutableStateOf(store.lastSync.let { if (it > 0) java.time.Instant.ofEpochMilli(it).atZone(java.time.ZoneId.systemDefault()).toLocalDate().minusDays(7).toString() else cfg.get("tcSince", "2021-01-01") }) }
    val valid = remember(from) { try { java.time.LocalDate.parse(from); true } catch (_: Exception) { false } }
    val dayFmt = remember { java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val inP = list.filter { inPeriod(dayFmt.format(java.util.Date(it.start)), mode, ym, year) }
    val primary = MaterialTheme.colorScheme.primary
    val configured = cfg.get("teslaToken").isNotBlank() && cfg.get("vin").isNotBlank()
    Panel(id = "hist_tesla", title = L.t("tc_title")) {
        Spacer(Modifier.height(6.dp))
        if (list.isEmpty()) Label(L.t("tc_help"))
        else if (inP.isEmpty()) Label(L.t("tc_none_period"))
        else {
            val amber = Color(0xFFE8A53A); val green = Color(0xFF2E9E5B); val blue = Color(0xFF3B82F6)
            val kwh = inP.sumOf { it.kwh }
            val ac = inP.filter { !it.dc }; val dc = inP.filter { it.dc }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("🔌", L.t("tc_sessions"), inP.size.toString(), primary, Modifier.weight(1f))
                StatTile("⚡", L.t("tc_kwh"), L.n(kwh, 1) + " kWh", amber, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("🏠", L.t("tc_home"), L.n(ac.sumOf { it.kwh }, 1) + " kWh", green, Modifier.weight(1f))
                StatTile("🚀", L.t("tc_dc"), L.n(dc.sumOf { it.kwh }, 1) + " kWh", blue, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            if (kwh > 0) MeterRow(L.t("tc_home_share"), (ac.sumOf { it.kwh } / kwh * 100).toInt().coerceIn(0, 100), green)
            KeyValue(L.t("tc_avg"), L.n(kwh / inP.size, 1) + " kWh")
            val used = inP.sumOf { it.used }
            val usedBase = inP.filter { it.used > 0 }.sumOf { it.kwh }
            if (used > 0 && usedBase > 0) KeyValue(L.t("tc_eff"), L.n(usedBase / used * 100, 0) + " %")
            val acHours = ac.sumOf { (it.end - it.start).coerceAtLeast(0L) } / 3_600_000.0
            if (acHours > 0.1) KeyValue(L.t("tc_power"), L.n(ac.sumOf { it.kwh } / acHours, 1) + " kW")
            val cost = inP.sumOf { if (it.cost.isNaN()) 0.0 else it.cost }
            if (cost > 0.005) KeyValue(L.t("tc_cost"), L.n(cost, 2) + " €")
            Spacer(Modifier.height(8.dp))
            val df = remember { java.text.SimpleDateFormat("d MMM · HH:mm", L.locale()) }
            (if (all) inP else inP.take(8)).forEach { t ->
                val mins = ((t.end - t.start) / 60_000L).coerceAtLeast(0L)
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text((if (t.dc) "🚀 " else "🏠 ") + df.format(java.util.Date(t.start)), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            (if (t.place.isNotBlank()) t.place + " · " else "") +
                                (if (t.b0 >= 0 && t.b1 >= 0) "${t.b0} → ${t.b1} % · " else "") + "${mins / 60}h%02d".format(mins % 60),
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("+" + L.n(t.kwh, 1) + " kWh", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = primary)
                }
            }
            if (inP.size > 8) TextButton({ all = !all }) { Text(if (all) L.t("tc_less") else L.t("tc_more", inP.size)) }
        }
        if (configured) {
            Spacer(Modifier.height(10.dp))
            if (list.isNotEmpty()) Label(L.t("tc_help_short"))
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(from, { from = it.trim() }, Modifier.fillMaxWidth(), label = { Text(L.t("gi_from")) }, singleLine = true, isError = !valid, enabled = !TeslaImport.running)
            Spacer(Modifier.height(8.dp))
            if (TeslaImport.running) OutlinedButton({ TeslaImport.cancel() }, Modifier.fillMaxWidth()) { FitText(L.t("cancel")) }
            else Button({ cfg.set("tcSince", from); TeslaImport.start(ctx, java.time.LocalDate.parse(from)) }, Modifier.fillMaxWidth(), enabled = valid) { FitText(L.t("tc_btn")) }
            status?.let { Spacer(Modifier.height(6.dp)); Label(L.t(it.key, *it.args.toTypedArray())) }
        }
    }
}
