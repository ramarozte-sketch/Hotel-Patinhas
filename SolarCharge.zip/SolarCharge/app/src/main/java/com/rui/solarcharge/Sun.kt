package com.rui.solarcharge

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

enum class SunMood { Normal, Happy, Worried, Curious }

/** Friendly animated sun: floats, rotates its rays (tinted by the colour scheme), blinks, looks up while thinking,
 *  moves its mouth while talking and shows moods (happy / worried / curious). */
@Composable
fun SunMascot(thinking: Boolean, talking: Boolean, modifier: Modifier = Modifier, boxSize: Dp = 120.dp, mood: SunMood = SunMood.Normal) {
    var t by remember { mutableFloatStateOf(0f) }
    var rot by remember { mutableFloatStateOf(0f) }
    val thinkingNow by rememberUpdatedState(thinking)
    val tint = MaterialTheme.colorScheme.primary
    val rayColor = lerp(Color(0xFFFFB627), tint, 0.4f)
    val glowColor = lerp(Color(0xFFFFD54A), tint, 0.4f).copy(alpha = 0.33f)
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (last != 0L) {
                    val dt = ((n - last) / 1_000_000_000f).coerceAtMost(0.1f)
                    t += dt
                    rot += dt * (if (thinkingNow) 140f else 22f)
                }
                last = n
            }
        }
    }
    Canvas(modifier.size(boxSize)) {
        val m = size.minDimension
        val happy = mood == SunMood.Happy
        val worried = mood == SunMood.Worried
        val curious = mood == SunMood.Curious
        val cx = size.width / 2 + (if (worried) sin(t * 34f) * m * 0.004f else 0f)
        val cy = size.height / 2 + sin(t * 2.2f) * m * 0.025f - (if (happy) abs(sin(t * 6f)) * m * 0.04f else 0f)
        val c = Offset(cx, cy)
        val r = m * 0.27f

        // glow
        drawCircle(Brush.radialGradient(listOf(glowColor, Color.Transparent), center = c, radius = m * 0.5f), radius = m * 0.5f, center = c)

        // rays
        rotate(rot, c) {
            for (i in 0 until 12) {
                val a = i * (2 * PI / 12).toFloat()
                val pulse = 0.5f + 0.5f * sin(t * (if (happy) 6f else 3f) + i)
                val r1 = r * 1.28f
                val r2 = r * (1.5f + 0.18f * pulse)
                drawLine(rayColor, Offset(cx + cos(a) * r1, cy + sin(a) * r1), Offset(cx + cos(a) * r2, cy + sin(a) * r2),
                    strokeWidth = m * 0.045f, cap = StrokeCap.Round)
            }
        }

        // face
        drawCircle(Brush.radialGradient(listOf(Color(0xFFFFE680), Color(0xFFFFC22E), Color(0xFFFF9F1C)), center = Offset(cx - r * 0.3f, cy - r * 0.35f), radius = r * 1.6f), radius = r, center = c)

        // cheeks
        val cheek = Color(if (happy) 0x99FF5C5C else 0x66FF6B6B)
        drawCircle(cheek, r * 0.16f, Offset(cx - r * 0.58f, cy + r * 0.2f))
        drawCircle(cheek, r * 0.16f, Offset(cx + r * 0.58f, cy + r * 0.2f))

        // eyes
        val dark = Color(0xFF3B2A1A)
        val blink = if (t % 3.6f > 3.46f) 0.12f else 1f
        val lookY = if (thinking) -r * 0.06f else 0f
        val lookX = if (thinking) sin(t * 2.5f) * r * 0.05f else if (curious) r * 0.05f else 0f
        for (s in listOf(-1f, 1f)) {
            val ex = cx + s * r * 0.34f
            val ey = cy - r * 0.12f
            val w = r * 0.2f
            if (happy) {
                val p = Path().apply { moveTo(ex - w * 0.8f, ey + r * 0.05f); quadraticBezierTo(ex, ey - r * 0.2f, ex + w * 0.8f, ey + r * 0.05f) }
                drawPath(p, dark, style = Stroke(width = m * 0.022f, cap = StrokeCap.Round))
            } else {
                val h = r * 0.3f * blink
                drawOval(dark, Offset(ex - w / 2 + lookX, ey - h / 2 + lookY), Size(w, h))
                if (blink > 0.5f) drawCircle(Color.White, r * 0.045f, Offset(ex + lookX + r * 0.03f, ey + lookY - r * 0.07f))
            }
            // eyebrows
            if (worried) {
                val y0 = ey - r * 0.26f
                drawLine(dark, Offset(ex + s * w * 0.9f, y0 + r * 0.02f), Offset(ex - s * w * 0.9f, y0 - r * 0.09f), strokeWidth = m * 0.018f, cap = StrokeCap.Round)
            } else if (curious && s > 0) {
                val y0 = ey - r * 0.36f
                drawLine(dark, Offset(ex - w * 0.9f, y0), Offset(ex + w * 0.9f, y0 - r * 0.05f), strokeWidth = m * 0.018f, cap = StrokeCap.Round)
            }
        }

        // mouth
        val my = cy + r * 0.3f
        val brown = Color(0xFF7A2E1B)
        when {
            talking -> {
                val open = 0.5f + 0.5f * sin(t * 16f)
                val mh = r * (0.1f + 0.26f * open)
                drawOval(brown, Offset(cx - r * 0.19f, my - mh / 2), Size(r * 0.38f, mh))
                drawOval(Color(0xFFFF8A80), Offset(cx - r * 0.1f, my + mh * 0.05f), Size(r * 0.2f, mh * 0.4f))
            }
            happy -> {
                val p = Path().apply {
                    moveTo(cx - r * 0.28f, my - r * 0.06f)
                    quadraticBezierTo(cx, my + r * 0.5f, cx + r * 0.28f, my - r * 0.06f)
                    close()
                }
                drawPath(p, brown)
            }
            worried -> {
                val p = Path().apply {
                    moveTo(cx - r * 0.2f, my + r * 0.08f)
                    quadraticBezierTo(cx, my - r * 0.14f, cx + r * 0.2f, my + r * 0.08f)
                }
                drawPath(p, brown, style = Stroke(width = m * 0.018f, cap = StrokeCap.Round))
            }
            thinking || curious -> drawCircle(brown, r * 0.06f, Offset(cx + r * 0.1f, my), style = Stroke(width = m * 0.014f))
            else -> {
                val p = Path().apply {
                    moveTo(cx - r * 0.26f, my - r * 0.04f)
                    quadraticBezierTo(cx, my + r * 0.26f, cx + r * 0.26f, my - r * 0.04f)
                }
                drawPath(p, brown, style = Stroke(width = m * 0.018f, cap = StrokeCap.Round))
            }
        }
    }
}
