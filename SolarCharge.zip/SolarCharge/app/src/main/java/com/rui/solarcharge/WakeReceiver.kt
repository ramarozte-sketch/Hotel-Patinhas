package com.rui.solarcharge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Alarm that wakes the control loop at night: the loop's own timer does not advance while the CPU sleeps. */
class WakeReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action != SolarService.ACTION_WAKE) return
        SolarService.holdAfterAlarm(ctx)
        SolarService.wakeSignal?.complete(Unit)
    }
}
