package com.rui.solarcharge

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** Simple translation table: Portuguese (default), English, French. Reading L.lang inside a composable makes it recompose on change. */
object L {
    var lang by mutableStateOf("pt")

    val languages = listOf("pt" to "Português", "en" to "English", "fr" to "Français")

    fun init(cfg: Cfg) {
        val saved = cfg.get("lang")
        lang = if (languages.any { it.first == saved }) saved else when (Locale.getDefault().language) {
            "pt" -> "pt"; "fr" -> "fr"; else -> "en"
        }
    }

    fun locale(): Locale = when (lang) { "pt" -> Locale("pt", "PT"); "fr" -> Locale.FRANCE; else -> Locale.US }

    /** Number with d decimals using the selected language's separators. */
    fun n(x: Double, d: Int = 1): String = String.format(locale(), "%." + d + "f", x)

    fun t(key: String, vararg a: Any?): String {
        val s = LX.tables[lang]?.get(key) ?: tables[lang]?.get(key) ?: LX.tables.getValue("en")[key] ?: tables.getValue("en")[key] ?: return key
        if (a.isEmpty()) return s
        return try { String.format(locale(), s, *a) } catch (e: Exception) { s }
    }

    private val tables: Map<String, Map<String, String>> = mapOf(
        "pt" to mapOf(
            "nav_dash" to "Painel", "nav_hist" to "Histórico", "nav_settings" to "Definições", "nav_log" to "Registo",
            "author" to "por Rui Amaro", "footer" to "SolarCharge v1.1 · Criado por Rui Amaro",
            "node_solar" to "Solar", "node_house" to "Casa", "node_car" to "Tesla", "node_grid" to "Rede (exportação)",
            "data_from" to "Dados solares de %s", "pct_car" to "%d%% da produção solar vai para o carro",
            "no_sun" to "Sem produção solar de momento", "house_unknown" to "Consumo da casa indisponível",
            "card_tesla" to "Tesla", "card_today" to "Hoje", "battery" to "Bateria %d%%", "battery_na" to "Bateria —",
            "amps_set" to "%d A definidos", "today_charged" to "%s kWh carregados", "today_solar" to "%s kWh solar", "today_house" to "%s kWh casa",
            "start" to "Iniciar", "stop" to "Parar",
            "st_Charging" to "A carregar", "st_Stopped" to "Em pausa", "st_Complete" to "Completo",
            "st_Disconnected" to "Desligado", "st_NoPower" to "Sem energia", "st_Starting" to "A iniciar",
            "msg_stopped" to "Parado", "msg_fill_conn" to "Preenche primeiro as Ligações nas Definições",
            "msg_collecting" to "A recolher dados solares (cerca de 10 min)…",
            "msg_outside" to "Fora do horário (%s–%s)", "msg_unplugged" to "Tesla não está ligado à tomada",
            "msg_manual" to "Carregamento manual em curso — a app não interfere",
            "msg_stale" to "Sem dados solares recentes — carregamento parado",
            "msg_confirm" to "Excedente detetado, a confirmar (%d s)", "msg_charging" to "A carregar a %d A com energia solar",
            "msg_low" to "Excedente solar insuficiente (%d W)", "msg_waiting" to "Excedente baixo, a aguardar antes de parar (%d s)",
            "msg_nosurplus" to "Carregamento parado: sem excedente solar", "msg_error" to "Erro: %s",
            "notif_active" to "SolarCharge ativo", "notif_text" to "%s kW solar · %s kW Tesla · %s",
            "hist_title" to "Histórico", "mode_month" to "Mês", "mode_year" to "Ano", "cumulative" to "Acumulado",
            "m_charged" to "Carregado", "m_solar" to "Solar", "m_house" to "Casa",
            "period_total" to "Total do período", "peak" to "Máximo: %s kWh", "no_data" to "Sem dados neste período",
            "hist_backup" to "Cópia do histórico", "hist_backup_help" to "Exporta ou importa o histórico diário (carregado, solar e casa). Ao importar, os dias do ficheiro substituem os dias iguais; os restantes mantêm-se.",
            "export" to "Exportar", "import" to "Importar", "hist_clear" to "Apagar histórico",
            "clear_title" to "Apagar histórico?", "clear_text" to "Todos os dias registados serão removidos.",
            "delete" to "Apagar", "cancel" to "Cancelar",
            "hist_import_title" to "Importar histórico?", "hist_import_text" to "Os dias, o perfil por hora, as sessões, os carregamentos Tesla e as estatísticas do carro do ficheiro vão ser adicionados ao histórico atual.",
            "hist_imported" to "%d dias importados", "hist_exported" to "Histórico exportado",
            "export_fail" to "Não foi possível exportar", "invalid_file" to "Ficheiro inválido",
            "settings_title" to "Definições", "sec_conn" to "Ligações", "sec_charge" to "Carregamento", "sec_schedule" to "Horário de carregamento",
            "sec_look" to "Aparência", "sec_lang" to "Idioma", "sec_backup" to "Cópia de segurança",
            "f_growattToken" to "Token API Growatt", "f_plantId" to "ID da central Growatt", "f_inverterSn" to "Nº de série do inversor (opcional)",
            "f_teslaToken" to "Token API Tessie", "f_vin" to "VIN do Tesla",
            "f_manageManual" to "Controlar carregamentos manuais (1 = sim, 0 = não)", "f_minAmps" to "Amperes mínimos", "f_maxAmps" to "Amperes máximos",
            "f_phases" to "Fases (1 ou 3)", "f_volts" to "Tensão (V)", "f_interval" to "Intervalo de atualização (s)",
            "f_startDelay" to "Atraso para iniciar (s)", "f_stopDelay" to "Atraso para parar (s)",
            "f_growattSec" to "Consulta à Growatt (s, mín. 60)", "f_pvMult" to "Unidade Growatt (vazio = automático)", "hint_auto" to "auto",
            "from" to "De", "to" to "Até",
            "theme_system" to "Sistema", "theme_light" to "Claro", "theme_dark" to "Escuro", "accent" to "Cor de destaque",
            "backup_help" to "Guarda todas as definições num ficheiro para as reutilizares noutra versão ou telemóvel. O ficheiro inclui os tokens: guarda-o num sítio privado.",
            "autosave" to "As alterações guardam-se automaticamente. Carrega em Parar e Iniciar no Painel para as aplicar.",
            "set_exported" to "Definições exportadas", "set_import_title" to "Importar definições?",
            "set_import_text" to "As definições atuais serão substituídas pelas do ficheiro. Carrega em Parar e Iniciar no Painel depois de importar.",
            "set_imported" to "%d definições importadas",
            "log_title" to "Registo", "test" to "Testar", "copy" to "Copiar", "clear" to "Limpar",
            "only_problems" to "Só avisos e erros", "no_logs" to "Sem registos. Carrega em Iniciar no Painel ou em Testar."
        ),
        "en" to mapOf(
            "nav_dash" to "Dashboard", "nav_hist" to "History", "nav_settings" to "Settings", "nav_log" to "Log",
            "author" to "by Rui Amaro", "footer" to "SolarCharge v1.1 · Created by Rui Amaro",
            "node_solar" to "Solar", "node_house" to "Home", "node_car" to "Tesla", "node_grid" to "Grid (export)",
            "data_from" to "Solar data from %s", "pct_car" to "%d%% of solar production is going to the car",
            "no_sun" to "No solar production right now", "house_unknown" to "Home consumption unavailable",
            "card_tesla" to "Tesla", "card_today" to "Today", "battery" to "Battery %d%%", "battery_na" to "Battery —",
            "amps_set" to "%d A set", "today_charged" to "%s kWh charged", "today_solar" to "%s kWh solar", "today_house" to "%s kWh home",
            "start" to "Start", "stop" to "Stop",
            "st_Charging" to "Charging", "st_Stopped" to "Paused", "st_Complete" to "Complete",
            "st_Disconnected" to "Unplugged", "st_NoPower" to "No power", "st_Starting" to "Starting",
            "msg_stopped" to "Stopped", "msg_fill_conn" to "First fill in the Connections in Settings",
            "msg_collecting" to "Collecting solar data (about 10 min)…",
            "msg_outside" to "Outside schedule (%s–%s)", "msg_unplugged" to "Tesla is not plugged in",
            "msg_manual" to "Manual charge in progress — the app does not interfere",
            "msg_stale" to "No recent solar data — charging stopped",
            "msg_confirm" to "Surplus detected, confirming (%d s)", "msg_charging" to "Charging at %d A with solar energy",
            "msg_low" to "Not enough solar surplus (%d W)", "msg_waiting" to "Low surplus, waiting before stopping (%d s)",
            "msg_nosurplus" to "Charging stopped: no solar surplus", "msg_error" to "Error: %s",
            "notif_active" to "SolarCharge running", "notif_text" to "%s kW solar · %s kW Tesla · %s",
            "hist_title" to "History", "mode_month" to "Month", "mode_year" to "Year", "cumulative" to "Cumulative",
            "m_charged" to "Charged", "m_solar" to "Solar", "m_house" to "Home",
            "period_total" to "Period total", "peak" to "Peak: %s kWh", "no_data" to "No data in this period",
            "hist_backup" to "History backup", "hist_backup_help" to "Export or import the daily history (charged, solar and home). When importing, days in the file replace matching days; the others are kept.",
            "export" to "Export", "import" to "Import", "hist_clear" to "Delete history",
            "clear_title" to "Delete history?", "clear_text" to "All recorded days will be removed.",
            "delete" to "Delete", "cancel" to "Cancel",
            "hist_import_title" to "Import history?", "hist_import_text" to "The days, hourly profile, sessions, Tesla charges and car statistics in the file will be added to the current history.",
            "hist_imported" to "%d days imported", "hist_exported" to "History exported",
            "export_fail" to "Could not export", "invalid_file" to "Invalid file",
            "settings_title" to "Settings", "sec_conn" to "Connections", "sec_charge" to "Charging", "sec_schedule" to "Charging schedule",
            "sec_look" to "Appearance", "sec_lang" to "Language", "sec_backup" to "Backup",
            "f_growattToken" to "Growatt API token", "f_plantId" to "Growatt plant ID", "f_inverterSn" to "Inverter serial number (optional)",
            "f_teslaToken" to "Tessie API token", "f_vin" to "Tesla VIN",
            "f_manageManual" to "Control manual charges (1 = yes, 0 = no)", "f_minAmps" to "Minimum amps", "f_maxAmps" to "Maximum amps",
            "f_phases" to "Phases (1 or 3)", "f_volts" to "Voltage (V)", "f_interval" to "Update interval (s)",
            "f_startDelay" to "Start delay (s)", "f_stopDelay" to "Stop delay (s)",
            "f_growattSec" to "Growatt polling (s, min. 60)", "f_pvMult" to "Growatt unit (empty = automatic)", "hint_auto" to "auto",
            "from" to "From", "to" to "To",
            "theme_system" to "System", "theme_light" to "Light", "theme_dark" to "Dark", "accent" to "Accent colour",
            "backup_help" to "Saves all settings to a file so you can reuse them in another version or phone. The file includes the tokens: keep it somewhere private.",
            "autosave" to "Changes are saved automatically. Press Stop and Start on the Dashboard to apply them.",
            "set_exported" to "Settings exported", "set_import_title" to "Import settings?",
            "set_import_text" to "The current settings will be replaced by the ones in the file. Press Stop and Start on the Dashboard after importing.",
            "set_imported" to "%d settings imported",
            "log_title" to "Log", "test" to "Test", "copy" to "Copy", "clear" to "Clear",
            "only_problems" to "Warnings and errors only", "no_logs" to "No entries. Press Start on the Dashboard or Test."
        ),
        "fr" to mapOf(
            "nav_dash" to "Tableau", "nav_hist" to "Historique", "nav_settings" to "Réglages", "nav_log" to "Journal",
            "author" to "par Rui Amaro", "footer" to "SolarCharge v1.1 · Créé par Rui Amaro",
            "node_solar" to "Solaire", "node_house" to "Maison", "node_car" to "Tesla", "node_grid" to "Réseau (export)",
            "data_from" to "Données solaires de %s", "pct_car" to "%d%% de la production solaire va vers la voiture",
            "no_sun" to "Pas de production solaire pour le moment", "house_unknown" to "Consommation de la maison indisponible",
            "card_tesla" to "Tesla", "card_today" to "Aujourd'hui", "battery" to "Batterie %d%%", "battery_na" to "Batterie —",
            "amps_set" to "%d A réglés", "today_charged" to "%s kWh chargés", "today_solar" to "%s kWh solaire", "today_house" to "%s kWh maison",
            "start" to "Démarrer", "stop" to "Arrêter",
            "st_Charging" to "En charge", "st_Stopped" to "En pause", "st_Complete" to "Terminé",
            "st_Disconnected" to "Débranchée", "st_NoPower" to "Sans courant", "st_Starting" to "Démarrage",
            "msg_stopped" to "Arrêté", "msg_fill_conn" to "Renseignez d'abord les Connexions dans les Réglages",
            "msg_collecting" to "Collecte des données solaires (environ 10 min)…",
            "msg_outside" to "Hors plage horaire (%s–%s)", "msg_unplugged" to "La Tesla n'est pas branchée",
            "msg_manual" to "Charge manuelle en cours — l'appli n'intervient pas",
            "msg_stale" to "Pas de données solaires récentes — charge arrêtée",
            "msg_confirm" to "Surplus détecté, confirmation (%d s)", "msg_charging" to "Charge à %d A avec l'énergie solaire",
            "msg_low" to "Surplus solaire insuffisant (%d W)", "msg_waiting" to "Surplus faible, attente avant l'arrêt (%d s)",
            "msg_nosurplus" to "Charge arrêtée : pas de surplus solaire", "msg_error" to "Erreur : %s",
            "notif_active" to "SolarCharge actif", "notif_text" to "%s kW solaire · %s kW Tesla · %s",
            "hist_title" to "Historique", "mode_month" to "Mois", "mode_year" to "Année", "cumulative" to "Cumulé",
            "m_charged" to "Chargé", "m_solar" to "Solaire", "m_house" to "Maison",
            "period_total" to "Total de la période", "peak" to "Maximum : %s kWh", "no_data" to "Aucune donnée sur cette période",
            "hist_backup" to "Sauvegarde de l'historique", "hist_backup_help" to "Exportez ou importez l'historique quotidien (chargé, solaire et maison). À l'import, les jours du fichier remplacent les jours identiques ; les autres sont conservés.",
            "export" to "Exporter", "import" to "Importer", "hist_clear" to "Effacer l'historique",
            "clear_title" to "Effacer l'historique ?", "clear_text" to "Tous les jours enregistrés seront supprimés.",
            "delete" to "Effacer", "cancel" to "Annuler",
            "hist_import_title" to "Importer l'historique ?", "hist_import_text" to "Les jours, le profil horaire, les sessions, les charges Tesla et les statistiques de la voiture du fichier seront ajoutés à l'historique actuel.",
            "hist_imported" to "%d jours importés", "hist_exported" to "Historique exporté",
            "export_fail" to "Export impossible", "invalid_file" to "Fichier invalide",
            "settings_title" to "Réglages", "sec_conn" to "Connexions", "sec_charge" to "Recharge", "sec_schedule" to "Plage horaire de charge",
            "sec_look" to "Apparence", "sec_lang" to "Langue", "sec_backup" to "Sauvegarde",
            "f_growattToken" to "Jeton API Growatt", "f_plantId" to "ID de la centrale Growatt", "f_inverterSn" to "N° de série de l'onduleur (facultatif)",
            "f_teslaToken" to "Jeton API Tessie", "f_vin" to "VIN de la Tesla",
            "f_manageManual" to "Contrôler les charges manuelles (1 = oui, 0 = non)", "f_minAmps" to "Ampères minimum", "f_maxAmps" to "Ampères maximum",
            "f_phases" to "Phases (1 ou 3)", "f_volts" to "Tension (V)", "f_interval" to "Intervalle de mise à jour (s)",
            "f_startDelay" to "Délai de démarrage (s)", "f_stopDelay" to "Délai d'arrêt (s)",
            "f_growattSec" to "Interrogation Growatt (s, min. 60)", "f_pvMult" to "Unité Growatt (vide = automatique)", "hint_auto" to "auto",
            "from" to "De", "to" to "À",
            "theme_system" to "Système", "theme_light" to "Clair", "theme_dark" to "Sombre", "accent" to "Couleur d'accent",
            "backup_help" to "Enregistre tous les réglages dans un fichier pour les réutiliser dans une autre version ou sur un autre téléphone. Le fichier contient les jetons : gardez-le dans un endroit privé.",
            "autosave" to "Les modifications sont enregistrées automatiquement. Appuyez sur Arrêter puis Démarrer dans le Tableau pour les appliquer.",
            "set_exported" to "Réglages exportés", "set_import_title" to "Importer les réglages ?",
            "set_import_text" to "Les réglages actuels seront remplacés par ceux du fichier. Appuyez sur Arrêter puis Démarrer dans le Tableau après l'import.",
            "set_imported" to "%d réglages importés",
            "log_title" to "Journal", "test" to "Tester", "copy" to "Copier", "clear" to "Effacer",
            "only_problems" to "Alertes et erreurs seulement", "no_logs" to "Aucune entrée. Appuyez sur Démarrer dans le Tableau ou sur Tester."
        )
    )
}
