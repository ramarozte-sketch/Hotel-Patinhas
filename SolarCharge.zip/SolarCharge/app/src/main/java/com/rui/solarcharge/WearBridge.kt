package com.rui.solarcharge

import android.content.Context
import android.content.Intent
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import com.google.android.gms.wearable.WearableListenerService
import com.google.android.gms.wearable.MessageEvent

/** Mode switching shared by the app screen and the watch: "off" | "solar" | "minpv" | "fast". */
object ModeControl {
    fun current(cfg: Cfg): String = when {
        !Live.running -> "off"
        Live.boost -> "fast"
        cfg.get("mode", "solar") == "minpv" -> "minpv"
        else -> "solar"
    }

    /** Returns false when the mode could not be applied (missing settings, or Android refused to start the service in the background). */
    fun set(ctx: Context, cfg: Cfg, m: String): Boolean = try {
        when (m) {
            "off" -> {
                // a charge that this app started (solar, boost, guarantee, off-peak) is stopped with it; manual charges are left alone
                if (SolarService.ownsCharge) Thread { try { Api.get(cfg).command("stop_charging") } catch (_: Exception) {} }.start()
                cfg.set("autoOn", "0"); Live.boost = false
                ctx.stopService(Intent(ctx, SolarService::class.java))
                true
            }
            "fast" -> if (Live.running || startSolar(ctx, cfg)) { Live.boost = true; true } else false
            else -> { cfg.set("mode", m); Live.boost = false; if (!Live.running) startSolar(ctx, cfg) else true }
        }
    } catch (e: Exception) { ApiLog.e("App", "Modo $m não aplicado: ${e.message}"); false }
}

/** Publishes the live state to a paired Wear OS watch (Data Layer). Silent when there is no watch or no Google Play services. */
object WearBridge {
    private var lastKey = ""
    private var lastAt = 0L

    fun publish(ctx: Context, force: Boolean = false, err: String = "") {
        try {
            val c = Cfg(ctx)
            val mode = ModeControl.current(c)
            val msg = try { Live.messageText() } catch (_: Exception) { "" }
            val key = listOf(Live.pvW.toInt(), (Live.teslaKw * 10).toInt(), Live.houseW.toInt(), Live.battery, Live.chargingState, Live.amps, mode, msg, err, Live.fcKwhToday.toInt()).joinToString("|")
            val now = System.currentTimeMillis()
            if (!force && key == lastKey && now - lastAt < 120_000) return
            lastKey = key; lastAt = now
            val r = PutDataMapRequest.create("/state")
            r.dataMap.apply {
                putInt("pv", Live.pvW.toInt()); putDouble("car", Live.teslaKw); putInt("house", Live.houseW.toInt())
                putInt("bat", Live.battery); putString("st", Live.chargingState); putInt("amps", Live.amps)
                putString("mode", mode); putString("msg", msg); putString("err", err)
                putString("upd", Live.updated); putDouble("fc", Live.fcKwhToday); putLong("t", now)
            }
            Wearable.getDataClient(ctx).putDataItem(r.asPutDataRequest().setUrgent())
        } catch (_: Throwable) {}
    }
}

/** Receives commands from the watch: "/mode" (payload = mode) and "/hello" (watch opened, send the state now). */
class WearListener : WearableListenerService() {
    override fun onMessageReceived(e: MessageEvent) {
        val c = Cfg(this)
        ApiLog.init(applicationContext); L.init(c)
        when (e.path) {
            "/mode" -> {
                val m = String(e.data)
                if (m in listOf("off", "solar", "minpv", "fast")) {
                    val ok = ModeControl.set(this, c, m)
                    WearBridge.publish(this, force = true, err = if (ok) "" else "open")
                }
            }
            "/hello" -> WearBridge.publish(this, force = true)
        }
    }
}
