package com.rui.solarcharge

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** Spoken replies with the phone's own text-to-speech engine (offline, no extra permissions). */
object Voice {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    var speaking by mutableStateOf(false)

    private fun locale(): Locale = when (L.lang) {
        "en" -> Locale.UK
        "fr" -> Locale.FRANCE
        else -> Locale("pt", "PT")
    }

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                ready = true
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { speaking = true }
                    override fun onDone(id: String?) { speaking = false }
                    @Deprecated("Deprecated in Java") override fun onError(id: String?) { speaking = false }
                })
                pending?.let { p -> pending = null; speak(p) }
            }
        }
    }

    /** Removes emoji, markdown marks and symbols that the voice would read out loud. */
    private fun clean(s: String) = s
        .replace(Regex("[\\p{So}\\p{Cn}\\uFE0F\\u200D*_#`>~|]"), " ")
        .replace(Regex("\\s+"), " ").trim().take(3500)

    fun speak(text: String) {
        val t = tts
        val c = clean(text)
        if (c.isEmpty()) return
        if (t == null || !ready) { pending = text; return }
        val r = t.setLanguage(locale())
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
        t.speak(c, TextToSpeech.QUEUE_FLUSH, null, "sun")
    }

    fun stop() { pending = null; tts?.stop(); speaking = false }

    fun shutdown() { tts?.stop(); tts?.shutdown(); tts = null; ready = false; speaking = false }
}


/** Speech to text with the phone's own recognizer (needs the microphone permission). */
object Listen {
    private var rec: SpeechRecognizer? = null
    var active by mutableStateOf(false)

    fun available(ctx: Context) = SpeechRecognizer.isRecognitionAvailable(ctx)

    private fun tag() = when (L.lang) { "en" -> "en-GB"; "fr" -> "fr-FR"; else -> "pt-PT" }

    private fun errorText(code: Int) = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> L.t("chat_mic_nothing")
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> L.t("chat_mic_denied")
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> L.t("chat_mic_network")
        else -> L.t("chat_mic_error", code)
    }

    fun start(ctx: Context, onPartial: (String) -> Unit, onFinal: (String) -> Unit, onError: (String) -> Unit) {
        stop()
        Voice.stop()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                stop(); onFinal(t)
            }
            override fun onError(code: Int) { stop(); onError(errorText(code)) }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag())
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        active = true
        r.startListening(i)
    }

    fun stop() {
        rec?.let { try { it.stopListening() } catch (_: Exception) {}; try { it.destroy() } catch (_: Exception) {} }
        rec = null; active = false
    }
}
