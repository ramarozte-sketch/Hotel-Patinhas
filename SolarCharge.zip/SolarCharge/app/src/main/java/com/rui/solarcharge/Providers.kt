package com.rui.solarcharge

import okhttp3.Credentials
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Solar data sources other than Growatt. "growatt" keeps the original code path in Api.kt; the others are read here:
 *  - generic:   any HTTP GET that returns JSON (URL + optional auth + JSON paths for PV and house load)
 *  - solaredge: SolarEdge monitoring API (currentPowerFlow, kW)
 *  - fronius:   Fronius Solar API on the local network (GetPowerFlowRealtimeData, W)
 */
object Providers {
    val ids = listOf("growatt", "generic", "solaredge", "fronius")
    class Reading(val pvW: Double, val loadW: Double?)

    private val http = OkHttpClient.Builder().callTimeout(15, TimeUnit.SECONDS).build()

    fun id(c: Cfg): String = c.get("provider", "growatt").let { if (it in ids) it else "growatt" }
    fun isGrowatt(c: Cfg) = id(c) == "growatt"

    /** Minimum seconds between two real reads. */
    fun gapSec(c: Cfg): Int {
        val def = when (id(c)) { "solaredge" -> 300; "fronius" -> 10; else -> 30 }
        return (c.get("provSec").toIntOrNull() ?: def).coerceAtLeast(5)
    }

    /** True when the fields needed by the selected provider are filled. */
    fun configured(c: Cfg): Boolean = when (id(c)) {
        "growatt" -> c.get("growattToken").isNotBlank() && c.get("plantId").isNotBlank()
        "generic" -> c.get("provUrl").isNotBlank() && c.get("provPvPath").isNotBlank()
        "solaredge" -> c.get("provKey").isNotBlank() && c.get("provSite").isNotBlank()
        else -> c.get("provHost").isNotBlank()
    }

    // ---- JSON path: a.b[0].c  ----
    private fun pick(root: Any?, path: String): Any? {
        var cur: Any? = root
        for (seg in path.trim().split('.').filter { it.isNotBlank() }) {
            val name = seg.substringBefore('[')
            if (name.isNotEmpty()) {
                val o = cur as? JSONObject ?: error("caminho '$path': '$name' não está num objeto")
                if (!o.has(name)) error("caminho '$path': campo '$name' não existe. Campos: ${o.keys().asSequence().take(20).joinToString(",")}")
                cur = o.get(name)
            }
            var rest = seg.substringAfter('[', "")
            while (rest.isNotEmpty()) {
                val idx = rest.substringBefore(']').trim().toIntOrNull() ?: error("caminho '$path': índice inválido em '$seg'")
                val a = cur as? JSONArray ?: error("caminho '$path': '$seg' não é uma lista")
                if (idx !in 0 until a.length()) error("caminho '$path': índice $idx fora da lista (${a.length()})")
                cur = a.get(idx)
                rest = rest.substringAfter(']', "").substringAfter('[', "")
            }
        }
        return cur
    }

    /** Number at path; JSON null counts as 0 (e.g. Fronius at night). */
    private fun num(root: Any?, path: String): Double {
        val v = pick(root, path)
        if (v == null || v == JSONObject.NULL) return 0.0
        return when (v) {
            is Number -> v.toDouble()
            is String -> v.trim().replace(',', '.').toDoubleOrNull() ?: error("caminho '$path': '$v' não é um número")
            else -> error("caminho '$path': valor não numérico")
        }
    }

    private fun scale(c: Cfg, key: String): Double = c.get(key).replace(',', '.').toDoubleOrNull() ?: 1.0

    private fun fetch(req: Request): Any {
        val t0 = System.currentTimeMillis()
        http.newCall(req).execute().use { r ->
            val b = r.body?.string() ?: ""
            val ms = System.currentTimeMillis() - t0
            ApiLog.i("Solar", "${req.url.host} → HTTP ${r.code} · $ms ms · ${b.take(200).replace("\n", " ")}")
            if (!r.isSuccessful) error("HTTP ${r.code}")
            val t = b.trim()
            return try { if (t.startsWith("[")) JSONArray(t) else JSONObject(t) } catch (_: Exception) { error("a resposta não é JSON") }
        }
    }

    fun read(c: Cfg): Reading = when (id(c)) {
        "solaredge" -> {
            val site = c.get("provSite").trim(); val key = c.get("provKey").trim()
            val url = "https://monitoringapi.solaredge.com/site/$site/currentPowerFlow?api_key=$key&format=json"
            val j = fetch(Request.Builder().url(url).build())
            val unit = try { pick(j, "siteCurrentPowerFlow.unit") as? String ?: "kW" } catch (_: Exception) { "kW" }
            val k = if (unit.equals("W", true)) 1.0 else 1000.0
            val load = try { num(j, "siteCurrentPowerFlow.LOAD.currentPower") * k } catch (_: Exception) { null }
            Reading(num(j, "siteCurrentPowerFlow.PV.currentPower") * k, load)
        }
        "fronius" -> {
            val h = c.get("provHost").trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
            val j = fetch(Request.Builder().url("http://$h/solar_api/v1/GetPowerFlowRealtimeData.fcgi").build())
            val load = try { Math.abs(num(j, "Body.Data.Site.P_Load")) } catch (_: Exception) { null }
            Reading(num(j, "Body.Data.Site.P_PV"), load)
        }
        else -> {
            val raw = c.get("provUrl").trim()
            val url = raw.toHttpUrlOrNull() ?: error("URL inválido")
            val key = c.get("provKey").trim()
            val name = c.get("provAuthName").trim()
            val b = Request.Builder()
            var u = url
            when (c.get("provAuth", "none")) {
                "bearer" -> b.header("Authorization", "Bearer $key")
                "header" -> if (name.isNotEmpty()) b.header(name, key)
                "basic" -> b.header("Authorization", Credentials.basic(c.get("provUser"), key))
                "query" -> if (name.isNotEmpty()) u = url.newBuilder().setQueryParameter(name, key).build()
            }
            val j = fetch(b.url(u).build())
            val pv = num(j, c.get("provPvPath")) * scale(c, "provPvScale")
            val lp = c.get("provLoadPath").trim()
            val load = if (lp.isNotEmpty()) num(j, lp) * scale(c, "provLoadScale") else null
            Reading(pv, load)
        }
    }

    /** Text for the "Test" button. */
    fun test(c: Cfg): String = try {
        val r = read(c)
        "OK · PV ${r.pvW.toInt()} W" + (r.loadW?.let { " · ${it.toInt()} W" } ?: "")
    } catch (e: Exception) { "${e.javaClass.simpleName}: ${e.message}" }
}
