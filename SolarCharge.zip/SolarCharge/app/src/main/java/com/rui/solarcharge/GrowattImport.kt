package com.rui.solarcharge

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.time.LocalDate

/** One-off import of the daily solar production since the installation, from the Growatt plant counter. Runs in the background and can be cancelled. */
object GrowattImport {
    var running by mutableStateOf(false)
    var status by mutableStateOf<Msg?>(null)
    @Volatile private var cancel = false

    fun cancel() { cancel = true }

    fun start(ctx: Context, from: LocalDate) {
        if (running) return
        running = true; cancel = false
        val app = ctx.applicationContext
        Thread {
            var total = 0
            try {
                ApiLog.init(app)
                val c = Cfg(app)
                val hist = History(app)
                val api = Api.get(c)
                val today = LocalDate.now()
                var start = from
                var win = 31
                var retries = 0
                while (!start.isAfter(today) && !cancel) {
                    val end = minOf(start.plusDays(win - 1L), today)
                    status = Msg("gi_run", listOf(start.toString(), total))
                    try {
                        total += hist.importSolar(api.growattEnergy(start, end))
                        start = end.plusDays(1); retries = 0
                    } catch (e: Api.GrowattErr) {
                        val limited = e.code == 10012 || (e.message ?: "").contains("frequen", true)
                        if (limited && retries++ < 8) { Thread.sleep(30_000); continue }
                        if (win > 7) { win = 7; continue }
                        status = Msg("gi_err", listOf(e.message ?: e.code.toString())); running = false; return@Thread
                    } catch (e: Exception) {
                        if (retries++ < 4) { Thread.sleep(10_000); continue }
                        status = Msg("gi_err", listOf(e.message ?: "")); running = false; return@Thread
                    }
                    Thread.sleep(6_000)   // Growatt limits how often the API may be called
                }
                status = Msg(if (cancel) "gi_cancelled" else "gi_done", listOf(total))
                ApiLog.i("Growatt", "Histórico importado: $total dias com produção")
            } catch (e: Exception) {
                status = Msg("gi_err", listOf(e.message ?: ""))
            } finally { running = false }
        }.start()
    }
}
