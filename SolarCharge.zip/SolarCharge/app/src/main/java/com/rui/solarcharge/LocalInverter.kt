package com.rui.solarcharge

import java.io.DataInputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Optional local reading of the inverter over Modbus TCP (no cloud, no 5-minute limit). Register numbers are configurable. */
object LocalInverter {
    class Reading(val pvW: Double, val loadW: Double?)

    private fun readRegs(host: String, port: Int, unit: Int, fn: Int, addr: Int, qty: Int): IntArray {
        Socket().use { s ->
            s.connect(InetSocketAddress(host, port), 3000)
            s.soTimeout = 3000
            val req = byteArrayOf(
                0, 1, 0, 0, 0, 6, unit.toByte(), fn.toByte(),
                (addr shr 8).toByte(), addr.toByte(), (qty shr 8).toByte(), qty.toByte()
            )
            s.getOutputStream().apply { write(req); flush() }
            val inp = DataInputStream(s.getInputStream())
            val head = ByteArray(9)
            inp.readFully(head)                    // MBAP (7) + function + byte count / exception code
            val rfn = head[7].toInt() and 0xFF
            if (rfn and 0x80 != 0) error("Modbus exception ${head[8].toInt() and 0xFF}")
            val bytes = head[8].toInt() and 0xFF
            val data = ByteArray(bytes)
            inp.readFully(data)
            return IntArray(bytes / 2) { ((data[2 * it].toInt() and 0xFF) shl 8) or (data[2 * it + 1].toInt() and 0xFF) }
        }
    }

    /** 32-bit value (high word first, as Growatt does) times scale. */
    private fun read32(c: Cfg, addr: Int): Double {
        val host = c.get("localHost").trim()
        val r = readRegs(host, c.int("localPort", 502), c.int("localUnit", 1), c.int("localFn", 4), addr, 2)
        val raw = (r[0].toLong() shl 16) or r[1].toLong()
        val scale = c.get("localScale", "0.1").replace(',', '.').toDoubleOrNull() ?: 0.1
        return raw * scale
    }

    fun read(c: Cfg): Reading {
        val pv = read32(c, c.int("localRegPv", 1))
        val reg = c.get("localRegLoad").toIntOrNull()
        // a failed load read must not throw away a good PV reading
        val load = if (reg != null) try { read32(c, reg) } catch (_: Exception) { null } else null
        return Reading(pv, load)
    }

    /** Energy produced today (kWh) from the inverter's own counter (registers 3055-3056, 0.1 kWh), for models that keep the 3000 block (the ones where the house load register is 3045). */
    fun solarToday(c: Cfg): Double? {
        if (c.get("localRegLoad").trim() != "3045") return null
        val r = readRegs(c.get("localHost").trim(), c.int("localPort", 502), c.int("localUnit", 1), 4, 3055, 2)
        val kwh = (((r[0].toLong() shl 16) or r[1].toLong()) * 0.1)
        return if (kwh in 0.1..150.0) kwh else null
    }

    /** Text for the "Test" button. */
    fun test(c: Cfg): String = try {
        val r = read(c)
        "OK · PV ${r.pvW.toInt()} W" + (r.loadW?.let { " · ${it.toInt()} W" } ?: "")
    } catch (e: Exception) { "${e.javaClass.simpleName}: ${e.message}" }

    /** Diagnostic: reads blocks of registers and writes the non-zero values to the log, then looks for the ones that match the house load shown by the app, to find the load / grid / energy registers. */
    fun dump(c: Cfg): String {
        val host = c.get("localHost").trim()
        if (host.isBlank()) return "Sem endereço IP"
        val port = c.int("localPort", 502); val unit = c.int("localUnit", 1)
        var okBlocks = 0; var failed = 0
        val seen = java.util.TreeMap<Int, Int>()          // input registers read
        val ref = Live.houseW                              // house load known by the app right now (W), -1 if unknown
        // the 1000+ and 3000+ blocks first: that is where the newer Growatt models keep grid / load power
        val ranges = listOf(1000 to 250, 3000 to 250, 0 to 250)
        ApiLog.i("Registos", "Início do diagnóstico (ID $unit, ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())}), consumo da casa na app: ${if (ref >= 0) ref.toInt().toString() + " W" else "desconhecido"}. Compara com o ShinePhone no mesmo instante.")
        for (fn in listOf(4, 3)) for ((start, len) in ranges) {
            if (fn == 3 && start == 3000) continue
            var addr = start
            while (addr < start + len) {
                val q = minOf(30, start + len - addr)
                var r: IntArray? = null
                var err: Exception? = null
                for (attempt in 1..3) {
                    try { r = readRegs(host, port, unit, fn, addr, q); err = null; break }
                    catch (e: Exception) { err = e; Thread.sleep(400L * attempt) }
                }
                if (r != null) {
                    okBlocks++
                    if (fn == 4) for (k in r.indices) seen[addr + k] = r[k]
                    val nz = r.indices.filter { r[it] != 0 }
                    if (nz.isNotEmpty()) {
                        val txt = nz.joinToString(" ") { "${addr + it}=${r[it]}" }
                        txt.chunked(900).forEach { ApiLog.i("Registos", "${if (fn == 4) "IN" else "HOLD"} $it") }
                    }
                } else {
                    failed++
                    ApiLog.w("Registos", "${if (fn == 4) "IN" else "HOLD"} $addr-${addr + q - 1}: ${err?.javaClass?.simpleName}: ${err?.message}")
                }
                addr += q
                Thread.sleep(120)
            }
        }
        // candidates: a value (16 bit) or a pair (32 bit, high word first) that, with a plausible scale, is close to the house load
        if (ref >= 100) {
            val hits = ArrayList<String>()
            fun near(v: Double) = Math.abs(v - ref) <= ref * 0.06 + 15
            for ((a, v) in seen) {
                if (v != 0) for ((sc, name) in listOf(1.0 to "x1", 0.1 to "x0.1", 10.0 to "x10")) if (near(v * sc)) hits.add("$a (16 bit $name)")
                val lo = seen[a + 1]
                if (lo != null && (v != 0 || lo != 0)) {
                    val raw = (v.toLong() shl 16) or lo.toLong()
                    for ((sc, name) in listOf(0.1 to "x0.1", 1.0 to "x1")) if (near(raw * sc)) hits.add("$a-${a + 1} (32 bit $name)")
                }
            }
            ApiLog.i("Registos", "Candidatos para ${ref.toInt()} W (±6%): " + (if (hits.isEmpty()) "nenhum" else hits.joinToString(", ")))
        }
        ApiLog.i("Registos", "Fim do diagnóstico: $okBlocks blocos lidos, $failed com erro")
        return "Feito: $okBlocks blocos lidos ($failed com erro). Vê o Registo."
    }
}
