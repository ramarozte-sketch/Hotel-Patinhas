package com.rui.solarcharge

import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

/**
 * General rule of the app: text is never cut. A text that does not fit its space shrinks (down to [minSize]) until it does,
 * in any language, font scale or screen width. Only below [minSize] does it fall back to an ellipsis.
 * Use it for every single-line label (tabs, tiles, pills, titles); free-flowing paragraphs simply wrap.
 */
@Composable
fun FitText(
    text: AnnotatedString, modifier: Modifier = Modifier, fontSize: TextUnit = 14.sp, minSize: TextUnit = 8.sp,
    fontWeight: FontWeight? = null, color: Color = Color.Unspecified, textAlign: TextAlign? = null, letterSpacing: TextUnit = TextUnit.Unspecified
) {
    val width = LocalConfiguration.current.screenWidthDp
    var size by remember(text, fontSize, width) { mutableStateOf(fontSize) }
    Text(
        text, modifier, color = color, fontSize = size, fontWeight = fontWeight, textAlign = textAlign, letterSpacing = letterSpacing,
        maxLines = 1, softWrap = false, overflow = if (size <= minSize) TextOverflow.Ellipsis else TextOverflow.Clip,
        onTextLayout = { r -> if ((r.didOverflowWidth || r.didOverflowHeight) && size > minSize) size = (size.value - 0.5f).coerceAtLeast(minSize.value).sp }
    )
}

@Composable
fun FitText(
    text: String, modifier: Modifier = Modifier, fontSize: TextUnit = 14.sp, minSize: TextUnit = 8.sp,
    fontWeight: FontWeight? = null, color: Color = Color.Unspecified, textAlign: TextAlign? = null
) = FitText(AnnotatedString(text), modifier, fontSize, minSize, fontWeight, color, textAlign)
