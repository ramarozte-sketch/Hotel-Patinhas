package com.rui.solarcharge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** One finished charging session. */
class Session(val start: Long, val end: Long, val kwh: Double, val solarKwh: Double, val gridKwh: Double,
              val saved: Double, val cost: Double, val b0: Int, val b1: Int, val mode: String)

/** Detects charging sessions from the service ticks and keeps the last 200 in SharedPreferences ("sessions"). */
class Sessions(ctx: Context) {
    private val p = ctx.getSharedPreferences("sessions", Context.MODE_PRIVATE)

    @Synchronized
    fun tick(charging: Boolean, battery: Int, kwh: Double, solarKwh: Double, gridKwh: Double, saved: Double, cost: Double, mode: String, now: Long) {
        val cur = p.getString("current", null)?.let { try { JSONObject(it) } catch (e: Exception) { null } }
        if (charging) {
            val j = cur ?: JSONObject().put("t0", now).put("b0", battery).put("k", 0.0).put("s", 0.0).put("g", 0.0).put("e", 0.0).put("c", 0.0)
            j.put("k", j.optDouble("k") + kwh).put("s", j.optDouble("s") + solarKwh).put("g", j.optDouble("g") + gridKwh)
                .put("e", j.optDouble("e") + saved).put("c", j.optDouble("c") + cost)
                .put("t1", now).put("b1", battery).put("m", mode)
            p.edit().putString("current", j.toString()).apply()
        } else if (cur != null) {
            if (cur.optDouble("k") >= 0.05) {
                val arr = try { JSONArray(p.getString("list", "[]")) } catch (e: Exception) { JSONArray() }
                arr.put(cur)
                val trimmed = JSONArray()
                for (i in maxOf(0, arr.length() - 1000) until arr.length()) trimmed.put(arr.get(i))
                p.edit().putString("list", trimmed.toString()).remove("current").apply()
            } else p.edit().remove("current").apply()
        }
    }

    /** Finished sessions, newest first. */
    @Synchronized
    fun all(): List<Session> {
        val arr = try { JSONArray(p.getString("list", "[]")) } catch (e: Exception) { JSONArray() }
        return (arr.length() - 1 downTo 0).map { i ->
            val o = arr.getJSONObject(i)
            Session(o.optLong("t0"), o.optLong("t1"), o.optDouble("k"), o.optDouble("s"), o.optDouble("g"),
                o.optDouble("e"), o.optDouble("c"), o.optInt("b0", -1), o.optInt("b1", -1), o.optString("m", "manual"))
        }
    }

    /** The session in progress, or null. */
    @Synchronized
    fun current(): Session? {
        val o = p.getString("current", null)?.let { try { JSONObject(it) } catch (e: Exception) { null } } ?: return null
        return Session(o.optLong("t0"), o.optLong("t1"), o.optDouble("k"), o.optDouble("s"), o.optDouble("g"),
            o.optDouble("e"), o.optDouble("c"), o.optInt("b0", -1), o.optInt("b1", -1), o.optString("m", "manual"))
    }

    /** Finished sessions as raw JSON (oldest first) for the history backup. */
    @Synchronized
    fun exportArray(): JSONArray = try { JSONArray(p.getString("list", "[]")) } catch (e: Exception) { JSONArray() }

    /** Merges sessions from a backup by start time; returns how many were added. */
    @Synchronized
    fun importArray(add: JSONArray): Int {
        val cur = exportArray()
        val have = HashSet<Long>()
        for (i in 0 until cur.length()) have.add(cur.getJSONObject(i).optLong("t0"))
        val all = ArrayList<JSONObject>()
        for (i in 0 until cur.length()) all.add(cur.getJSONObject(i))
        var n = 0
        for (i in 0 until add.length()) { val o = add.optJSONObject(i) ?: continue; if (have.add(o.optLong("t0"))) { all.add(o); n++ } }
        all.sortBy { it.optLong("t0") }
        val out = JSONArray(); all.takeLast(1000).forEach { out.put(it) }
        p.edit().putString("list", out.toString()).apply()
        return n
    }

    fun clear() = p.edit().clear().apply()
}
