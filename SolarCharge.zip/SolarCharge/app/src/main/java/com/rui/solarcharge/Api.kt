package com.rui.solarcharge

import okhttp3.*
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class FrequencyLimit : Exception("error_frequently_access")

class TeslaState(val charging: String, val powerKw: Double, val battery: Int, val reqAmps: Int = -1, val actAmps: Int = -1)

/** All network calls (Growatt + Tessie). Every call is written to ApiLog. Tokens are never logged. */
class Api(private val c: Cfg) {
    companion object {
        private var inst: Api? = null
        /** One shared instance so the service and the "Testar" button share the same cache and rate-limit state. */
        @Synchronized fun get(c: Cfg): Api = inst ?: Api(c).also { inst = it }
    }
    private val http = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS).build()
    private val growatt = "https://openapi.growatt.com/v1"
    private val tessie = "https://api.tessie.com"
    private var lastW = 0.0
    private var lastAt = 0L
    var lastOkAt = 0L
    private var learnedMult: Double? = c.get("pvMultLearned").toDoubleOrNull()

    /** Tessie commands wait for the car (retry_duration=40 s, and waking it takes a while), so they get a longer read timeout than the default 10 s. */
    private val cmdHttp = http.newBuilder().readTimeout(60, TimeUnit.SECONDS).callTimeout(75, TimeUnit.SECONDS).build()

    private fun call(tag: String, name: String, req: Request, maxBody: Int = 300, client: OkHttpClient = http): Pair<Int, String> {
        val t0 = System.currentTimeMillis()
        val r = try { client.newCall(req).execute() } catch (e: Exception) {
            ApiLog.e(tag, "$name → ${e.javaClass.simpleName}: ${e.message}"); throw e
        }
        r.use {
            val body = it.body?.string() ?: ""
            val ms = System.currentTimeMillis() - t0
            val shown = (if (it.isSuccessful) body.take(maxBody) else body.take(300)).replace("\n", " ")
            val msg = "$name → HTTP ${it.code} · $ms ms" + (if (shown.isNotEmpty()) " · $shown" else "")
            if (it.isSuccessful) ApiLog.i(tag, msg) else ApiLog.e(tag, msg)
            return it.code to body
        }
    }

    // ---------------- Growatt ----------------

    class GrowattErr(val code: Int, msg: String) : Exception(msg)

    /** Energy produced per day (kWh) from the plant counter, OpenAPI plant/energy. Used once to import the history. */
    fun growattEnergy(from: java.time.LocalDate, to: java.time.LocalDate): Map<String, Double> {
        val req = Request.Builder()
            .url("$growatt/plant/energy?plant_id=${c.get("plantId")}&start_date=$from&end_date=$to&time_unit=day")
            .header("token", c.get("growattToken")).build()
        val (_, body) = call("Growatt", "plant/energy $from → $to", req, 160)
        val j = JSONObject(body)
        if (j.optInt("error_code") != 0) throw GrowattErr(j.optInt("error_code"), j.optString("error_msg"))
        val arr = j.optJSONObject("data")?.optJSONArray("energys") ?: return emptyMap()
        val out = HashMap<String, Double>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val e = o.optString("energy").toDoubleOrNull() ?: continue
            out[o.optString("date").take(10)] = e
        }
        return out
    }

    private var backoffMs = 0L

    private fun gapMs() = if (Providers.isGrowatt(c)) maxOf(c.int("growattSec", 300).coerceAtLeast(60) * 1000L, backoffMs) else Providers.gapSec(c) * 1000L

    /** Solar power in W. Calls Growatt at most every gap and reuses the last value in between. */
    @Synchronized
    fun solarW(): Double {
        val now = System.currentTimeMillis()
        // optional local reading (Modbus TCP): fresh data on every call, no cloud limit
        var localPv: Double? = null
        if (c.get("localHost").isNotBlank()) {
            try {
                val r = LocalInverter.read(c)
                // an isolated absurd jump (for example 65535 x 0.1 = 6553 W, a register glitch) is ignored once; a second high reading confirms it
                val prev = lastLocalPv
                // a sudden drop to ~0 from a producing state is also held once (Modbus glitch); a second reading confirms it
                val drop = prev != null && prev > 400 && r.pvW < prev * 0.05
                if (prev != null && now - lastLocalAt < 180_000L && (r.pvW > prev * 1.8 + 1000 || drop) && !jumpSeen) {
                    jumpSeen = true
                    ApiLog.w("Local", "Leitura de ${r.pvW.toInt()} W ignorada (salto desde ${prev.toInt()} W); a aguardar confirmação")
                    return lastW
                }
                jumpSeen = false; lastLocalPv = r.pvW; lastLocalAt = now
                localPv = r.pvW; lastW = r.pvW; lastOkAt = now; dataAt = now; solarKnown = true
                ApiLog.i("Local", "Modbus: PV ${r.pvW.toInt()} W" + (r.loadW?.let { " · consumo ${it.toInt()} W" } ?: ""))
                if (r.loadW != null) { liveLoadW = r.loadW; loadAt = now; return lastW }
            } catch (e: Exception) { ApiLog.w("Local", "Leitura local falhou (${e.javaClass.simpleName}: ${e.message}); a usar a cloud") }
        }
        if (lastAt > 0 && now - lastAt < gapMs()) return lastW
        lastAt = now
        try {
            lastW = if (Providers.isGrowatt(c)) fetchSolar() else fetchExternal(); lastOkAt = System.currentTimeMillis()
            if (localPv != null) { lastW = localPv; dataAt = System.currentTimeMillis() }
        } catch (e: Exception) {
            if (localPv != null && e.message?.contains("frequently") != true) { lastW = localPv; return lastW }
            if (e.message?.contains("frequently") != true) throw e
            backoffMs = if (backoffMs < 330_000L) 330_000L else minOf(backoffMs + 60_000L, 900_000L)
            ApiLog.w("Growatt", "Limite de frequência da API: a usar o último valor (${lastW.toInt()} W). Próxima consulta daqui a ${gapMs() / 1000} s")
        }
        return lastW
    }

    /** Seconds until the next real Growatt call is allowed (0 = now). */
    fun secondsToNextCall(): Long = if (lastAt == 0L) 0L else maxOf(0L, (lastAt + gapMs() - System.currentTimeMillis()) / 1000)

    /** Timestamp (ms) of the data used for the last reading (as reported by Growatt), 0 if unknown. */
    var dataAt = 0L

    private fun parseTime(t: String?): Long {
        if (t.isNullOrBlank()) return 0L
        for (f in listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm")) {
            try { return SimpleDateFormat(f, Locale.US).parse(t)?.time ?: continue } catch (_: Exception) {}
        }
        return 0L
    }

    private class Point(val w: Double, val at: Long)

    /** Real house consumption in W (includes the car) when the inverter reports it, else null. */
    @Volatile var liveLoadW: Double? = null
    /** Time (ms) the house-consumption sample was taken by the inverter. */
    @Volatile var loadAt = 0L
    private var lastLocalPv: Double? = null
    private var lastLocalAt = 0L
    private var jumpSeen = false
    private var invBroken = false
    private var invBrokenAt = 0L
    private var discovered = false

    private fun collectSn(x: Any?, out: MutableList<String>) {
        when (x) {
            is JSONObject -> {
                val iter = x.keys()
                while (iter.hasNext()) {
                    val k = iter.next(); val v = x.opt(k)
                    if (v is String && v.isNotBlank() && k.lowercase() in setOf("device_sn", "sn", "serial_number", "serialnum")) out.add(v)
                    else collectSn(v, out)
                }
            }
            is JSONArray -> for (i in 0 until x.length()) collectSn(x.opt(i), out)
        }
    }

    /** Asks Growatt which device serial numbers exist in the plant (avoids typos such as 0 vs O). */
    private fun discoverSns(tok: String): List<String> {
        val out = mutableListOf<String>()
        val plant = c.get("plantId")
        val attempts = listOf(
            "GET" to Request.Builder().url("$growatt/device/list?plant_id=$plant&page=1&perpage=50").header("token", tok).build(),
            "POST" to Request.Builder().url("$growatt/device/list").header("token", tok)
                .post(FormBody.Builder().add("plant_id", plant).add("page", "1").add("perpage", "50").build()).build()
        )
        for ((m, req) in attempts) {
            try {
                val (code, b) = call("Growatt", "device/list $m", req, 1500)
                if (code in 200..299) { collectSn(JSONObject(b), out); if (out.isNotEmpty()) break }
            } catch (e: Exception) { ApiLog.w("Growatt", "device/list $m falhou: ${e.message}") }
        }
        return out.distinct()
    }

    /** One POST to tlx_last_data, trying the two parameter names Growatt has used. Returns the body on success. */
    private fun tryTlx(sn: String, tok: String): String? {
        for (field in listOf("tlx_sn", "device_sn")) {
            try {
                val req = Request.Builder().url("$growatt/device/tlx/tlx_last_data").header("token", tok)
                    .post(FormBody.Builder().add(field, sn).build()).build()
                val (code, b) = call("Growatt", "inversor ($field=$sn)", req, 1500)
                val j = JSONObject(b)
                if (code in 200..299 && j.optInt("error_code") == 0 && j.optJSONObject("data") != null) return b
                val m = j.optString("error_msg")
                if (m.contains("frequently")) throw FrequencyLimit()
            } catch (e: FrequencyLimit) { throw e } catch (e: Exception) { ApiLog.w("Growatt", "inversor $field falhou: ${e.message}") }
        }
        return null
    }

    /**
     * Live data straight from the inverter (Growatt OpenAPI device/tlx/tlx_last_data, MIN/TLX models).
     * Returns PV power in W, or null if unavailable.
     */
    /** Serial numbers found in the plant's device list (used when the configured serial is rejected). */
    private fun discoverSerials(): List<String> {
        val out = mutableListOf<String>()
        try {
            val (code, b) = call("Growatt", "device/list", Request.Builder()
                .url("$growatt/device/list?plant_id=${c.get("plantId")}&page=1").header("token", c.get("growattToken")).build(), 1500)
            if (code in 200..299) collectSerials(JSONObject(b), out)
        } catch (e: FrequencyLimit) { throw e } catch (e: Exception) { ApiLog.w("Growatt", "device/list falhou: ${e.message}") }
        ApiLog.i("Growatt", "Números de série encontrados: ${out.distinct().joinToString(", ").ifEmpty { "nenhum" }}")
        return out.distinct()
    }

    private fun collectSerials(o: Any?, out: MutableList<String>) {
        when (o) {
            is JSONObject -> {
                val keys = o.keys()
                while (keys.hasNext()) {
                    val k = keys.next(); val v = o.opt(k)
                    if (v is String && v.isNotBlank() &&
                        (k.equals("device_sn", true) || k.equals("sn", true) || k.equals("serial_number", true))) out.add(v)
                    else collectSerials(v, out)
                }
            }
            is JSONArray -> for (n in 0 until o.length()) collectSerials(o.opt(n), out)
        }
    }

    private fun fetchInverter(): Double? {
        val tok = c.get("growattToken")
        // a failure used to disable the inverter data (and so the house consumption) until the app restarted: retry every 10 minutes
        if (invBroken) {
            if (System.currentTimeMillis() - invBrokenAt < 10 * 60_000L) return null
            invBroken = false; ApiLog.i("Growatt", "A tentar de novo os dados do inversor (consumo da casa)")
        }
        val queue = mutableListOf(c.get("inverterSn").ifBlank { "MKP0E6H0GR" })
        val tried = mutableSetOf<String>()
        var discovered = false
        var body: String? = null
        var okSn = ""
        while (queue.isNotEmpty() && body == null && tried.size < 4) {
            val sn = queue.removeAt(0)
            if (!tried.add(sn)) continue
            var failed = false
            try {
                val req = Request.Builder().url("$growatt/device/tlx/tlx_last_data").header("token", tok)
                    .post(FormBody.Builder().add("tlx_sn", sn).build()).build()
                val (code, b) = call("Growatt", "inversor $sn", req, 0)
                val j = JSONObject(b)
                if (code in 200..299 && j.optInt("error_code") == 0 && j.optJSONObject("data") != null) { body = b; okSn = sn }
                else {
                    val m = j.optString("error_msg")
                    ApiLog.w("Growatt", "inversor $sn: error_code=${j.optInt("error_code")} $m")
                    if (m.contains("frequently")) throw FrequencyLimit()
                    failed = true
                }
            } catch (e: FrequencyLimit) { throw e } catch (e: Exception) { ApiLog.w("Growatt", "inversor $sn falhou: ${e.message}"); failed = true }
            if (failed && !discovered) { discovered = true; queue.addAll(discoverSerials()) }
        }
        if (body == null) { invBroken = true; invBrokenAt = System.currentTimeMillis(); ApiLog.w("Growatt", "Dados do inversor indisponíveis — a usar energia produzida"); return null }
        if (okSn != c.get("inverterSn")) { c.set("inverterSn", okSn); ApiLog.i("Growatt", "Inversor $okSn guardado nas definições") }
        val d = JSONObject(body).getJSONObject("data")
        fun num(vararg keys: String): Double? {
            for (k in keys) {
                val iter = d.keys()
                while (iter.hasNext()) { val kk = iter.next(); if (kk.equals(k, true)) { val v = d.optString(kk).toDoubleOrNull(); if (v != null) return v } }
            }
            return null
        }
        val ppv = num("ppv", "pvPower") ?: listOf("ppv1", "ppv2", "ppv3", "ppv4").mapNotNull { num(it) }.takeIf { it.isNotEmpty() }?.sum()
        if (ppv == null) {
            invBroken = true; invBrokenAt = System.currentTimeMillis()
            ApiLog.w("Growatt", "Resposta do inversor sem campo ppv. Campos: ${d.keys().asSequence().take(60).joinToString(",")}")
            return null
        }
        val mult = c.get("pvMult").toDoubleOrNull() ?: 1.0
        val t = listOf("time", "lastUpdateTime", "last_update_time").map { parseTime(d.optString(it)) }.firstOrNull { it > 0 } ?: 0L
        dataAt = if (t > 0) t else System.currentTimeMillis()
        liveLoadW = num("pLocalLoad", "plocalLoadTotal", "pLocalLoadTotal", "pacToLocalLoad")?.times(mult)
        if (liveLoadW != null) loadAt = if (t > 0) t else System.currentTimeMillis()
        ApiLog.i("Growatt", "Inversor: ppv=${(ppv * mult).toInt()} W (ppv1=${num("ppv1")?.toInt()}, ppv2=${num("ppv2")?.toInt()}), consumo casa=${liveLoadW?.toInt() ?: "n/d"} W, hora dos dados=${if (t > 0) SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(t)) else "n/d"}")
        return ppv * mult
    }

    // ---- energy-counter fallback: average power from today_energy deltas (0.1 kWh resolution) ----
    private val samples = mutableListOf<Pair<Long, Double>>().also { l ->
        c.get("energySamples").split(";").forEach { x ->
            val p = x.split(":")
            val t = p.getOrNull(0)?.toLongOrNull(); val e = p.getOrNull(1)?.toDoubleOrNull()
            if (t != null && e != null) l.add(t to e)
        }
    }
    /** false while there is not enough data to know the solar power (e.g. first minutes after install). */
    @Volatile var solarKnown = true

    private fun addSample(at: Long, kwh: Double) {
        if (at <= 0 || samples.lastOrNull()?.first == at) return
        samples.add(at to kwh)
        samples.removeAll { it.first < at - 40 * 60_000L }
        c.set("energySamples", samples.joinToString(";") { "${it.first}:${it.second}" })
    }

    private fun estimateFromEnergy(): Pair<Double, String>? {
        val last = samples.lastOrNull() ?: return null
        val ref = samples.lastOrNull { last.first - it.first >= 15 * 60_000L }
            ?: samples.firstOrNull { last.first - it.first >= 10 * 60_000L } ?: return null
        val dtH = (last.first - ref.first) / 3_600_000.0
        val dE = (last.second - ref.second).coerceAtLeast(0.0)
        return (dE / dtH * 1000.0) to "%.1f kWh em %d min".format(dE, ((last.first - ref.first) / 60_000L))
    }

    /** Non-Growatt sources (generic JSON, SolarEdge, Fronius). */
    private fun fetchExternal(): Double {
        solarKnown = true
        val r = Providers.read(c)
        if (r.pvW < 0 || r.pvW > 1_000_000) error("Valor solar inválido: ${r.pvW.toInt()} W")
        liveLoadW = r.loadW
        dataAt = System.currentTimeMillis()
        ApiLog.i("Solar", "${Providers.id(c)}: PV ${r.pvW.toInt()} W" + (r.loadW?.let { " · casa ${it.toInt()} W" } ?: ""))
        return r.pvW
    }

    private fun fetchSolar(): Double {
        solarKnown = true
        fetchInverter()?.let { w -> if (w > 100_000) error("Valor solar inválido: ${w.toInt()} W"); return w }
        liveLoadW = null   // only reached when the inverter gave no data: house load unknown

        val (_, body) = call("Growatt", "plant/data", Request.Builder()
            .url("$growatt/plant/data?plant_id=${c.get("plantId")}").header("token", c.get("growattToken")).build())
        val j = JSONObject(body)
        if (j.optInt("error_code") != 0) {
            val m = j.optString("error_msg")
            ApiLog.e("Growatt", "error_code=${j.optInt("error_code")} $m")
            error("Growatt: $m")
        }
        val data = j.getJSONObject("data")
        val raw = data.optString("current_power", "0").toDoubleOrNull() ?: 0.0
        dataAt = parseTime(data.optString("last_update_time"))
        data.optString("today_energy").toDoubleOrNull()?.let { addSample(dataAt, it) }
        val manual = c.get("pvMult").toDoubleOrNull()
        var w = raw * (manual ?: learnedMult ?: 1.0)
        var how = "plant/data"

        // plant/power (always W) only counts if its last point is recent: it can freeze for hours
        if (manual == null && (w <= 0.0 || learnedMult == null)) {
            val pt = try { latestPlantPower() } catch (e: FrequencyLimit) { null }
            val age = if (pt != null && pt.at > 0) System.currentTimeMillis() - pt.at else Long.MAX_VALUE
            if (pt != null && pt.w > 0 && age <= 15 * 60_000L) {
                if (raw > 0) {
                    val ratio = pt.w / raw
                    val m = if (ratio in 0.5..2.0) 1.0 else if (ratio in 500.0..2000.0) 1000.0 else null
                    if (m != null && m != learnedMult) {
                        learnedMult = m; c.set("pvMultLearned", m.toString())
                        ApiLog.i("Growatt", "Unidade detetada automaticamente: x${m.toInt()}")
                    }
                    w = raw * (learnedMult ?: 1.0)
                } else { w = pt.w; dataAt = pt.at; how = "curva do dia" }
            } else if (pt != null && pt.w > 0) {
                ApiLog.w("Growatt", "A curva do dia está desatualizada (último ponto há ${if (age == Long.MAX_VALUE) "?" else (age / 60_000).toString()} min) — ignorada")
            }
        }
        if (w <= 0.0) {
            val est = estimateFromEnergy()
            if (est != null) { w = est.first; how = "estimativa pela energia produzida (${est.second})" }
            else { solarKnown = false; ApiLog.i("Growatt", "A recolher amostras de energia para estimar a potência (cerca de 10 min)") }
        }
        if (w > 100_000) error("Valor solar inválido: ${w.toInt()} W")
        ApiLog.i("Growatt", "Potência solar: ${w.toInt()} W ($how)")
        return w
    }

    /** Latest non-null point of today's power curve, in W (null if unavailable). */
    private fun latestPlantPower(): Point? = try {
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val (_, body) = call("Growatt", "plant/power", Request.Builder()
            .url("$growatt/plant/power?plant_id=${c.get("plantId")}&date=$day").header("token", c.get("growattToken")).build(), 0)
        val j = JSONObject(body)
        var pt: Point? = null
        if (j.optInt("error_code") != 0) {
            val m = j.optString("error_msg")
            ApiLog.e("Growatt", "plant/power error_code=${j.optInt("error_code")} $m")
            if (m.contains("frequently")) throw FrequencyLimit()
        } else {
            val arr = j.optJSONObject("data")?.optJSONArray("powers")
            if (arr != null) for (i in arr.length() - 1 downTo 0) {
                val o = arr.optJSONObject(i) ?: continue
                val x = o.optString("power").toDoubleOrNull()
                if (x != null) { pt = Point(x, parseTime(o.optString("time"))); break }
            }
        }
        ApiLog.i("Growatt", if (pt != null) "plant/power último ponto: ${pt.w.toInt()} W às ${
            if (pt.at > 0) SimpleDateFormat("HH:mm", Locale.US).format(Date(pt.at)) else "?"}" else "plant/power: sem dados")
        pt
    } catch (e: FrequencyLimit) { throw e } catch (e: Exception) { ApiLog.e("Growatt", "plant/power falhou: ${e.message}"); null }

    // ---------------- Tessie ----------------

    /** Tesla state. By default the cached one (does not wake the car); [fresh] asks the car itself, which is needed right after a start command because the cache can lag by minutes. */
    fun teslaState(fresh: Boolean = false): TeslaState? {
        val req = Request.Builder().url("$tessie/${c.get("vin")}/state?use_cache=${!fresh}")
            .header("Authorization", "Bearer ${c.get("teslaToken")}").build()
        val (code, body) = call("Tessie", if (fresh) "state (direto)" else "state", req, 0, if (fresh) cmdHttp else http)
        if (code !in 200..299) return null
        val whole = JSONObject(body)
        Live.teslaJson = whole
        try { CarStats.update(whole) } catch (_: Exception) {}
        Live.teslaAt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date())
        val cs = whole.optJSONObject("charge_state")
        if (cs == null) { ApiLog.w("Tessie", "Resposta sem charge_state"); return null }
        val st = cs.optString("charging_state", "—")
        // charger_power is rounded to whole kW by Tesla: prefer current x voltage (more exact)
        val amps = cs.optDouble("charger_actual_current", 0.0)
        val volt = cs.optDouble("charger_voltage", 0.0).let { if (it > 100) it else c.int("volts", 230).toDouble() }
        val kwExact = amps * volt * c.int("phases", 1) / 1000.0
        val kw = if (st != "Charging") 0.0 else if (amps > 0) kwExact else cs.optDouble("charger_power", 0.0)
        val bat = cs.optInt("battery_level", -1)
        ApiLog.i("Tessie", "Estado: $st · %.1f kW · bateria $bat%% · ${cs.optInt("charger_actual_current")} A".format(kw))
        return TeslaState(st, kw, bat, cs.optInt("charge_current_request", -1), cs.optInt("charger_actual_current", -1))
    }

    /** Charging sessions between two instants (epoch seconds) from Tessie GET /{vin}/charges. */
    fun teslaCharges(fromSec: Long, toSec: Long): List<TCharge> {
        val req = Request.Builder()
            .url("$tessie/${c.get("vin")}/charges?from=$fromSec&to=$toSec&format=json&superchargers_only=false&exclude_origin=true&distance_format=km")
            .header("Authorization", "Bearer ${c.get("teslaToken")}").build()
        val (code, body) = call("Tessie", "charges", req, 120, cmdHttp)
        if (code !in 200..299) error("Tessie HTTP $code")
        val arr = try { JSONObject(body).optJSONArray("results") } catch (_: Exception) { null } ?: try { org.json.JSONArray(body) } catch (_: Exception) { null } ?: return emptyList()
        fun secs(v: Double) = if (v > 1e12) (v / 1000).toLong() else v.toLong()
        val out = ArrayList<TCharge>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val a0 = secs(o.optDouble("started_at", 0.0)); val z0 = secs(o.optDouble("ended_at", 0.0))
            if (a0 <= 0) continue
            val kwh = o.optDouble("energy_added", 0.0).let { if (it.isNaN()) 0.0 else it }
            if (kwh < 0.05) continue
            val used = o.optDouble("energy_used", 0.0).let { if (it.isNaN()) 0.0 else it }
            val cost = if (o.isNull("cost")) 0.0 else o.optDouble("cost", 0.0).let { if (it.isNaN()) 0.0 else it }
            out.add(TCharge(o.opt("id")?.toString() ?: a0.toString(), a0 * 1000, z0 * 1000, kwh, used,
                o.optInt("starting_battery", -1), o.optInt("ending_battery", -1), o.optBoolean("is_supercharger", false),
                o.optString("location", "").let { if (it == "null") "" else it }, cost))
        }
        return out
    }

    fun command(cmd: String) {
        val sep = if (cmd.contains("?")) "&" else "?"
        val req = Request.Builder()
            .url("$tessie/${c.get("vin")}/command/$cmd${sep}retry_duration=40&wait_for_completion=true")
            .header("Authorization", "Bearer ${c.get("teslaToken")}")
            .post("".toRequestBody(null)).build()
        val (code, body) = call("Tessie", "comando $cmd", req, 200, cmdHttp)
        if (code !in 200..299) error("Tessie $cmd: HTTP $code")
        try { if (!JSONObject(body).optBoolean("result", true)) ApiLog.w("Tessie", "Comando recusado: ${body.take(200)}") } catch (_: Exception) {}
    }

    /** "Testar" button: checks both services without breaking Growatt's rate limit. */
    fun diagnose() {
        ApiLog.i("Teste", "A testar as ligações…")
        val wait = secondsToNextCall()
        val pn = if (Providers.isGrowatt(c)) "Growatt" else Providers.id(c)
        if (wait > 0) {
            ApiLog.i("Teste", "$pn: intervalo mínimo entre consultas. Última leitura: ${lastW.toInt()} W; a próxima consulta real é daqui a $wait s")
        } else {
            try { val w = solarW(); ApiLog.i("Teste", "$pn: leitura de ${w.toInt()} W") }
            catch (e: Exception) { ApiLog.e("Teste", "$pn falhou: ${e.message}") }
        }
        try {
            val s = teslaState()
            if (s != null) ApiLog.i("Teste", "Tessie OK: ${s.charging}, bateria ${s.battery}%")
            else ApiLog.e("Teste", "Tessie falhou (ver linha acima)")
        } catch (e: Exception) { ApiLog.e("Teste", "Tessie falhou: ${e.message}") }
    }
}
