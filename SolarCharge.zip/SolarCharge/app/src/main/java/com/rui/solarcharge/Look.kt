package com.rui.solarcharge

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb

/** User-chosen look: custom colour scheme and screen transitions (kept in the settings and in the backup). */
object Look {
    var customPrimary by mutableStateOf(Color(0xFF2E9E5B))
    var customBg by mutableStateOf(Color(0xFF2E7D6B))
    var transition by mutableStateOf("slide")     // slide | fade | zoom | vertical | none
    var transSpeed by mutableStateOf("normal")    // fast | normal | slow
    var iconAnim by mutableStateOf(true)          // light looping motion of the flow icons
    var font by mutableStateOf("system")           // system | sans | serif | mono | cursive
    var iconSet by mutableStateOf("line")         // line | solid | emoji (flow diagram icons)

    val fonts = listOf("system", "sans", "serif", "mono", "cursive")
    fun family(k: String = font): androidx.compose.ui.text.font.FontFamily = when (k) {
        "sans" -> androidx.compose.ui.text.font.FontFamily.SansSerif
        "serif" -> androidx.compose.ui.text.font.FontFamily.Serif
        "mono" -> androidx.compose.ui.text.font.FontFamily.Monospace
        "cursive" -> androidx.compose.ui.text.font.FontFamily.Cursive
        else -> androidx.compose.ui.text.font.FontFamily.Default
    }
    /** Material typography with the chosen font family on every style. */
    fun typography(): androidx.compose.material3.Typography {
        val f = family(); val t = androidx.compose.material3.Typography()
        return androidx.compose.material3.Typography(
            displayLarge = t.displayLarge.copy(fontFamily = f), displayMedium = t.displayMedium.copy(fontFamily = f), displaySmall = t.displaySmall.copy(fontFamily = f),
            headlineLarge = t.headlineLarge.copy(fontFamily = f), headlineMedium = t.headlineMedium.copy(fontFamily = f), headlineSmall = t.headlineSmall.copy(fontFamily = f),
            titleLarge = t.titleLarge.copy(fontFamily = f), titleMedium = t.titleMedium.copy(fontFamily = f), titleSmall = t.titleSmall.copy(fontFamily = f),
            bodyLarge = t.bodyLarge.copy(fontFamily = f), bodyMedium = t.bodyMedium.copy(fontFamily = f), bodySmall = t.bodySmall.copy(fontFamily = f),
            labelLarge = t.labelLarge.copy(fontFamily = f), labelMedium = t.labelMedium.copy(fontFamily = f), labelSmall = t.labelSmall.copy(fontFamily = f)
        )
    }

    fun hex(c: Color) = "#%06X".format(c.toArgb() and 0xFFFFFF)

    private fun parse(s: String, d: Color): Color =
        try { Color(android.graphics.Color.parseColor(s)) } catch (_: Exception) { d }

    fun load(c: Cfg) {
        customPrimary = parse(c.get("customPrimary"), Color(0xFF2E9E5B))
        customBg = parse(c.get("customBg"), Color(0xFF2E7D6B))
        font = c.get("font", "system").let { if (it in fonts) it else "system" }
        transition = c.get("transition", "slide").ifBlank { "slide" }
        transSpeed = c.get("transSpeed", "normal").ifBlank { "normal" }
        iconAnim = c.get("iconAnim", "1") != "0"
        iconSet = c.get("iconSet", "line").let { if (it in FlowIcons.sets) it else "line" }
    }

    fun durationMs() = when (transSpeed) { "fast" -> 200; "slow" -> 520; else -> 320 }

    fun fromHsv(h: Float, s: Float, v: Float) = Color(android.graphics.Color.HSVToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))))

    /** Scheme built from the two user colours: title bars are hue rotations of the main colour, backgrounds mix the base colour with white / black. */
    fun customScheme(): Scheme {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(customPrimary.toArgb(), hsv)
        val s = hsv[1].coerceAtLeast(0.55f); val v = hsv[2].coerceAtLeast(0.7f)
        val titles = listOf(0f, 40f, 200f, 280f, 330f, 170f, 25f).map { fromHsv(hsv[0] + it, s, v) }
        val base = customBg
        return Scheme(
            "custom", customPrimary, titles,
            lerp(Color.White, base, 0.10f), Color.White, lerp(Color.White, base, 0.20f),
            lerp(Color.Black, base, 0.14f), lerp(Color.Black, base, 0.22f), lerp(Color.Black, base, 0.32f)
        )
    }
}
