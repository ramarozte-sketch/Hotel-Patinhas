package com.rui.solarcharge

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ChatMsg(val fromUser: Boolean, val text: String, val error: Boolean = false)
class PendingCall(val id: String, val name: String, val input: JSONObject)

/** Assistant: answers questions about the system with a live snapshot and can act through tools — every action needs the user's confirmation. */
object ChatBot {
    val msgs = mutableStateListOf<ChatMsg>()
    val pending = mutableStateListOf<PendingCall>()
    var busy by mutableStateOf(false)
    private val http = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build()
    @Volatile private var offline = false
    private val convo = mutableListOf<JSONObject>()      // raw API conversation (incl. tool_use / tool_result)

    private fun f(v: Double, d: Int = 2) = "%.${d}f".format(java.util.Locale.US, v)

    private fun snapshot(c: Cfg, hist: History): String {
        val sb = StringBuilder()
        sb.append("Estado ao vivo (${Live.updated.ifEmpty { "sem leitura" }}):\n")
        sb.append("- Produção solar: ${f(Live.pvW / 1000.0)} kW\n")
        sb.append("- Carro a carregar: ${f(Live.teslaKw)} kW, ${Live.amps} A, estado '${Live.chargingState}', bateria ${Live.battery}%\n")
        if (Live.houseW >= 0) sb.append("- Consumo total da casa (inclui o carro): ${f(Live.houseW / 1000.0)} kW\n")
        sb.append("- Decisão da app: ${Live.messageText()}\n")
        sb.append("- Controlo automático: ${if (Live.running) "ligado" else "desligado"}; carregar já (boost): ${if (Live.boost) "ativo" else "inativo"}; tendência meteorológica: ${Live.fcTrend}\n")
        val t = hist.today()
        sb.append("Hoje: carro ${f(t[0])} kWh, produção ${f(t[1])} kWh, casa sem carro ${f(t[2])} kWh, carro da rede ${f(t[3])} kWh, poupado ${f(t[4])} €, custo rede ${f(t[5])} €\n")
        val all = hist.all().toSortedMap().entries.toList()
        for (n in listOf(7, 30)) {
            val s = DoubleArray(6)
            all.takeLast(n).forEach { e -> for (i in 0..5) s[i] += e.value[i] }
            sb.append("Últimos $n dias registados: carro ${f(s[0], 1)} kWh, produção ${f(s[1], 1)} kWh, casa ${f(s[2], 1)} kWh, rede ${f(s[3], 1)} kWh, poupado ${f(s[4])} €, custo ${f(s[5])} €\n")
        }
        fun hm(k: String, d: Int) = c.int(k, d).let { "%02d:%02d".format(it / 60, it % 60) }
        sb.append("Definições: janela solar ${hm("winStartMin", 540)}–${hm("winEndMin", 1080)}, ${c.int("minAmps", 5)}–${c.int("maxAmps", 16)} A, ")
        sb.append("${c.int("volts", 230)} V x ${c.int("phases", 1)} fase(s), objetivo da app ${c.int("targetPct", 100)}%, ")
        sb.append("tarifa normal ${c.get("priceNormal")} €/kWh, vazio ${c.get("priceOff")} €/kWh (${hm("offStartMin", 1320)}–${hm("offEndMin", 480)}), ")
        sb.append("carregar no vazio ${if (c.get("offpeakCharge") == "1") "sim" else "não"}, previsão ${c.get("kwp")} kWp\n")
        return sb.toString()
    }

    private fun system(c: Cfg, hist: History) =
        "És o assistente da app Android SolarCharge, que lê a produção solar de um inversor (Growatt, SolarEdge, Fronius ou outro configurado) e ajusta a corrente de carregamento de um Tesla (via Tessie) para aproveitar o excedente solar. " +
        "Responde de forma clara e concisa, na língua em que o utilizador escrever (por omissão português europeu). Usa os dados abaixo; se não souberes algo, di-lo. " +
        "Tens ferramentas para agir (carregar, parar, ampères, limite de carga, carregar já, controlo automático, objetivo, sentinela). Usa-as só quando o utilizador pedir uma ação; " +
        "perguntas informativas respondem-se sem ferramentas. A app pede sempre confirmação ao utilizador antes de executar. " +
        "Nota: com o controlo automático ligado, a app pode parar um carregamento manual se não houver excedente solar; para forçar, usa 'carregar já' (set_boost).\n\n" + snapshot(c, hist)

    private fun tool(name: String, desc: String, props: JSONObject = JSONObject(), req: List<String> = emptyList()) =
        JSONObject().put("name", name).put("description", desc)
            .put("input_schema", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req)))

    private fun num(desc: String, min: Int, max: Int) = JSONObject().put("type", "integer").put("description", desc).put("minimum", min).put("maximum", max)
    private fun bool(desc: String) = JSONObject().put("type", "boolean").put("description", desc)

    private val tools = JSONArray()
        .put(tool("start_charging", "Inicia o carregamento do carro agora."))
        .put(tool("stop_charging", "Para o carregamento do carro."))
        .put(tool("set_charging_amps", "Define a corrente de carregamento em ampères.", JSONObject().put("amps", num("Ampères (5 a 32)", 5, 32)), listOf("amps")))
        .put(tool("set_charge_limit", "Define o limite de carga da bateria do carro (Tesla).", JSONObject().put("percent", num("Percentagem (50 a 100)", 50, 100)), listOf("percent")))
        .put(tool("set_boost", "Liga/desliga o 'carregar já': carrega à potência máxima da rede, ignorando o sol.", JSONObject().put("on", bool("true para ligar")), listOf("on")))
        .put(tool("set_auto_control", "Liga/desliga o controlo automático solar da app.", JSONObject().put("on", bool("true para ligar")), listOf("on")))
        .put(tool("set_target_pct", "Define a percentagem alvo de bateria até à qual a app carrega.", JSONObject().put("percent", num("Percentagem (10 a 100)", 10, 100)), listOf("percent")))
        .put(tool("set_sentry", "Liga/desliga o modo sentinela do carro.", JSONObject().put("on", bool("true para ligar")), listOf("on")))

    fun describe(p: PendingCall): String {
        val i = p.input
        return when (p.name) {
            "set_charging_amps" -> L.t("act_set_charging_amps", i.optInt("amps"))
            "set_charge_limit", "set_target_pct" -> L.t("act_" + p.name, i.optInt("percent"))
            "set_boost", "set_auto_control", "set_sentry" -> L.t("act_" + p.name + if (i.optBoolean("on")) "_on" else "_off")
            else -> L.t("act_" + p.name)
        }
    }

    private fun execute(ctx: android.content.Context, c: Cfg, p: PendingCall): String {
        val i = p.input
        return try {
            when (p.name) {
                "start_charging" -> { Api.get(c).command("start_charging"); "ok" }
                "stop_charging" -> { Api.get(c).command("stop_charging"); "ok" }
                "set_charging_amps" -> { Api.get(c).command("set_charging_amps?amps=" + i.getInt("amps").coerceIn(5, 32)); "ok" }
                "set_charge_limit" -> { Api.get(c).command("set_charge_limit?percent=" + i.getInt("percent").coerceIn(50, 100)); "ok" }
                "set_sentry" -> { Api.get(c).command(if (i.getBoolean("on")) "enable_sentry" else "disable_sentry"); "ok" }
                "set_target_pct" -> { c.set("targetPct", i.getInt("percent").coerceIn(10, 100).toString()); "ok" }
                "set_boost" ->
                    if (i.getBoolean("on")) { if (Live.running || startSolar(ctx, c)) { Live.boost = true; "ok" } else "erro: faltam as ligações nas Definições" }
                    else { Live.boost = false; "ok" }
                "set_auto_control" ->
                    if (i.getBoolean("on")) { if (startSolar(ctx, c)) "ok" else "erro: faltam as ligações nas Definições" }
                    else {
                        if (SolarService.ownsCharge) try { Api.get(c).command("stop_charging") } catch (_: Exception) {}
                        c.set("autoOn", "0")
                        ctx.stopService(android.content.Intent(ctx, SolarService::class.java)); "ok"
                    }
                else -> "erro: ação desconhecida"
            }
        } catch (e: Exception) { "erro: " + (e.message ?: "falhou") }
    }

    fun clear() { msgs.clear(); pending.clear(); convo.clear() }

    /** Copy of a message without thinking blocks (they are tied to the system prompt of the turn that produced them and cannot be replayed). */
    private fun plain(m: JSONObject): JSONObject {
        val c = m.opt("content")
        if (m.optString("role") != "assistant" || c !is JSONArray) return m
        val out = JSONArray()
        for (i in 0 until c.length()) {
            val b = c.optJSONObject(i) ?: continue
            val t = b.optString("type")
            if (t != "thinking" && t != "redacted_thinking") out.put(b)
        }
        if (out.length() == 0) out.put(JSONObject().put("type", "text").put("text", "…"))
        return JSONObject().put("role", "assistant").put("content", out)
    }

    private fun trim() {
        while (convo.size > 40) convo.removeAt(0)
        while (convo.isNotEmpty() && !(convo[0].optString("role") == "user" && convo[0].opt("content") is String)) convo.removeAt(0)
    }

    fun send(ctx: android.content.Context, c: Cfg, hist: History, text: String) {
        if (text.isBlank() || busy || pending.isNotEmpty()) return
        msgs.add(ChatMsg(true, text.trim()))
        if (c.get("anthropicKey").isBlank()) {
            // no Claude key: offline assistant (simple questions and commands; actions still need confirmation)
            offline = true
            val r = LocalBot.answer(c, hist, text)
            msgs.add(ChatMsg(false, r.text))
            pending.addAll(r.calls)
            return
        }
        offline = false
        convo.add(JSONObject().put("role", "user").put("content", text.trim()))
        run(c, hist)
    }

    /** The user answers the pending actions: confirm = execute them, otherwise report a refusal to the model. */
    fun resolve(ctx: android.content.Context, c: Cfg, hist: History, confirm: Boolean) {
        if (pending.isEmpty() || busy) return
        val calls = pending.toList(); pending.clear(); busy = true
        Thread {
            val results = JSONArray()
            calls.forEach { p ->
                val r = if (confirm) execute(ctx, c, p) else "recusado pelo utilizador"
                msgs.add(ChatMsg(false, (if (r == "ok") "✅ " else if (confirm) "⚠️ " else "🚫 ") + describe(p) + (if (r != "ok" && confirm) " — $r" else ""), r != "ok" && confirm))
                results.put(JSONObject().put("type", "tool_result").put("tool_use_id", p.id).put("content", r))
            }
            if (offline) { busy = false; return@Thread }
            convo.add(JSONObject().put("role", "user").put("content", results))
            busy = false
            run(c, hist)
        }.start()
    }

    private fun run(c: Cfg, hist: History) {
        busy = true
        val key = c.get("anthropicKey")
        val model = c.get("chatModel").ifBlank { "claude-sonnet-5-5" }
        trim()
        val snap = convo.toList()
        Thread {
            try {
                val arr = JSONArray(); snap.forEach { arr.put(plain(it)) }
                // no extended thinking (this model turns it off with between_tools): its signed blocks are bound to the exact system prompt, which changes with every live snapshot (HTTP 400 "Invalid signature in thinking block")
                val body = JSONObject().put("model", model).put("max_tokens", 1024).put("system", system(c, hist)).put("tools", tools).put("messages", arr)
                    .put("thinking", JSONObject().put("type", "between_tools"))
                val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
                    .header("x-api-key", key).header("anthropic-version", "2023-06-01")
                    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                http.newCall(req).execute().use { r ->
                    val s = r.body?.string() ?: ""
                    if (!r.isSuccessful) {
                        val m = try { JSONObject(s).getJSONObject("error").getString("message") } catch (_: Exception) { s.take(200) }
                        msgs.add(ChatMsg(false, "HTTP ${r.code}: $m", true))
                        // drop an unanswered trailing user message so the next try starts clean
                        if (convo.isNotEmpty() && convo.last().optString("role") == "user" && convo.last().opt("content") is String) convo.removeAt(convo.size - 1)
                    } else {
                        val j = JSONObject(s)
                        val content = j.getJSONArray("content")
                        convo.add(plain(JSONObject().put("role", "assistant").put("content", content)))
                        val out = StringBuilder(); val calls = ArrayList<PendingCall>()
                        for (i in 0 until content.length()) {
                            val b = content.getJSONObject(i)
                            when (b.optString("type")) {
                                "text" -> out.append(b.optString("text"))
                                "tool_use" -> calls.add(PendingCall(b.getString("id"), b.getString("name"), b.optJSONObject("input") ?: JSONObject()))
                            }
                        }
                        if (out.isNotBlank()) msgs.add(ChatMsg(false, out.toString().trim()))
                        if (calls.isNotEmpty()) pending.addAll(calls)
                        else if (out.isBlank()) msgs.add(ChatMsg(false, "…"))
                    }
                }
            } catch (e: Exception) {
                msgs.add(ChatMsg(false, e.message ?: "erro", true))
                if (convo.isNotEmpty() && convo.last().optString("role") == "user" && convo.last().opt("content") is String) convo.removeAt(convo.size - 1)
            } finally { busy = false }
        }.start()
    }
}

/** Draggable chat button: hold and drag it anywhere on the screen; the position is remembered. A tap opens the chat. */
@Composable
fun ChatFab(cfg: Cfg, hist: History, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    BoxWithConstraints(modifier) {
        val density = LocalDensity.current
        val sz = with(density) { 52.dp.toPx() }
        val margin = with(density) { 14.dp.toPx() }
        val maxX = (constraints.maxWidth - sz).coerceAtLeast(0f)
        val maxY = (constraints.maxHeight - sz).coerceAtLeast(0f)
        var ox by remember(maxX) { mutableFloatStateOf(cfg.get("chatFabFx").toFloatOrNull()?.let { it * maxX } ?: (maxX - margin).coerceAtLeast(0f)) }
        var oy by remember(maxY) { mutableFloatStateOf(cfg.get("chatFabFy").toFloatOrNull()?.let { it * maxY } ?: (maxY - margin).coerceAtLeast(0f)) }
        Box(
            Modifier
                .offset { IntOffset(ox.roundToInt(), oy.roundToInt()) }
                .size(52.dp).shadow(6.dp, CircleShape).clip(CircleShape).background(MaterialTheme.colorScheme.primary)
                .pointerInput(Unit) { detectTapGestures { open = true } }
                .pointerInput(maxX, maxY) {
                    detectDragGestures(
                        onDragEnd = {
                            if (maxX > 0) cfg.set("chatFabFx", (ox / maxX).toString())
                            if (maxY > 0) cfg.set("chatFabFy", (oy / maxY).toString())
                        }
                    ) { change, drag ->
                        change.consume()
                        ox = (ox + drag.x).coerceIn(0f, maxX)
                        oy = (oy + drag.y).coerceIn(0f, maxY)
                    }
                },
            contentAlignment = Alignment.Center
        ) { Text("💬", fontSize = 22.sp) }
    }
    if (open) Dialog(onDismissRequest = { open = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            ChatScreen(cfg, hist) { open = false }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(cfg: Cfg, hist: History, onClose: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    val msgs = ChatBot.msgs
    val ctx = androidx.compose.ui.platform.LocalContext.current.applicationContext
    var talking by remember { mutableStateOf(false) }
    var voiceOn by remember { mutableStateOf(cfg.get("chatVoice", "1") != "0") }
    LaunchedEffect(Unit) { Voice.init(ctx) }
    DisposableEffect(Unit) { onDispose { Voice.stop(); Listen.stop() } }
    fun startMic() {
        if (!Listen.available(ctx)) { Toast.makeText(ctx, L.t("chat_mic_unavailable"), Toast.LENGTH_LONG).show(); return }
        Listen.start(ctx,
            onPartial = { input = it },
            onFinal = { txt ->
                input = ""
                if (txt.isNotBlank() && !ChatBot.busy && ChatBot.pending.isEmpty()) ChatBot.send(ctx, cfg, hist, txt) else input = txt
            },
            onError = { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() })
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startMic() else Toast.makeText(ctx, L.t("chat_mic_denied"), Toast.LENGTH_LONG).show()
    }
    LaunchedEffect(msgs.size) {
        val m = msgs.lastOrNull()
        if (m != null && !m.fromUser && !m.error) {
            if (voiceOn) Voice.speak(m.text)          // the mouth follows the voice (Voice.speaking)
            else {
                talking = true
                kotlinx.coroutines.delay((900L + m.text.length * 30L).coerceAtMost(6000L))
            }
        }
        talking = false
    }
    var mood by remember { mutableStateOf(SunMood.Normal) }
    LaunchedEffect(msgs.size) {
        val m = msgs.lastOrNull()
        mood = when {
            m != null && m.error -> SunMood.Worried
            m != null && !m.fromUser && m.text.startsWith("✅") -> SunMood.Happy
            else -> SunMood.Normal
        }
        if (mood != SunMood.Normal) { kotlinx.coroutines.delay(4500); mood = SunMood.Normal }
    }
    LaunchedEffect(msgs.size, ChatBot.busy, ChatBot.pending.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size) }
    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primary).padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("💬 " + L.t("chat_name"), Modifier.weight(1f).padding(start = 8.dp), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            TextButton({
                voiceOn = !voiceOn; cfg.set("chatVoice", if (voiceOn) "1" else "0")
                if (!voiceOn) Voice.stop()
            }) { Text(if (voiceOn) "🔊" else "🔇", fontSize = 18.sp) }
            TextButton({ Voice.stop(); ChatBot.clear() }) { Text(L.t("chat_clear"), color = Color.White) }
            TextButton(onClose) { Text("✕", color = Color.White, fontSize = 18.sp) }
        }
        val lastReply = msgs.lastOrNull { !it.fromUser && !it.error }
        val bubble = when {
            ChatBot.busy -> L.t("chat_thinking")
            ChatBot.pending.isNotEmpty() -> L.t("chat_confirm_q")
            (talking || Voice.speaking) && lastReply != null -> lastReply.text.let { if (it.length > 110) it.take(110).trimEnd() + "…" else it }
            msgs.isEmpty() -> L.t("chat_greeting")
            else -> L.t("chat_idle")
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            SunMascot(
                thinking = ChatBot.busy, talking = talking || Voice.speaking, boxSize = 104.dp,
                mood = if (ChatBot.pending.isNotEmpty()) SunMood.Curious else mood
            )
            Spacer(Modifier.width(6.dp))
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(L.t("chat_name"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Text(bubble, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (msgs.isEmpty()) item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(L.t("chat_hint"), color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f), fontSize = 14.sp)
                    if (cfg.get("anthropicKey").isBlank()) Text(LocalBot.help(), color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                }
            }
            items(msgs.toList()) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                    val bg = when {
                        m.error -> MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                        m.fromUser -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.surface
                    }
                    Text(
                        m.text, Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(16.dp)).background(bg).padding(horizontal = 14.dp, vertical = 10.dp),
                        color = if (m.fromUser && !m.error) Color.White else MaterialTheme.colorScheme.onSurface, fontSize = 15.sp
                    )
                }
            }
            if (ChatBot.pending.isNotEmpty()) item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(L.t("chat_confirm_q"), fontWeight = FontWeight.SemiBold)
                    ChatBot.pending.forEach { Text("• " + ChatBot.describe(it)) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ ChatBot.resolve(ctx, cfg, hist, true) }, enabled = !ChatBot.busy) { Text(L.t("chat_confirm")) }
                        OutlinedButton({ ChatBot.resolve(ctx, cfg, hist, false) }, enabled = !ChatBot.busy) { Text(L.t("chat_cancel")) }
                    }
                }
            }
            if (ChatBot.busy) item { Text(L.t("chat_thinking"), color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f), fontSize = 13.sp) }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), maxLines = 4,
                placeholder = { Text(L.t("chat_placeholder")) }, shape = RoundedCornerShape(24.dp)
            )
            Spacer(Modifier.width(6.dp))
            FilledTonalButton(onClick = {
                if (Listen.active) Listen.stop()
                else if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startMic()
                else micPerm.launch(Manifest.permission.RECORD_AUDIO)
            }, enabled = !ChatBot.busy && ChatBot.pending.isEmpty(), contentPadding = PaddingValues(horizontal = 12.dp),
                colors = if (Listen.active) ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.error) else ButtonDefaults.filledTonalButtonColors()
            ) { Text(if (Listen.active) "⏹" else "🎤", fontSize = 18.sp) }
            Spacer(Modifier.width(6.dp))
            Button(onClick = { Voice.stop(); Listen.stop(); val t = input; input = ""; ChatBot.send(ctx, cfg, hist, t) }, enabled = !ChatBot.busy && ChatBot.pending.isEmpty() && input.isNotBlank()) { Text(L.t("chat_send")) }
        }
    }
}
