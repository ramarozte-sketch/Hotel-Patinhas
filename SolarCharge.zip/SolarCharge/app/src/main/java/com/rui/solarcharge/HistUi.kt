package com.rui.solarcharge

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow

/** Rounds a value up to a "nice" axis maximum (1, 2, 5 x 10^n). */
fun niceCeil(v: Double): Double {
    if (v <= 0) return 1.0
    val p = 10.0.pow(floor(log10(v)))
    val f = v / p
    return p * when { f <= 1 -> 1.0; f <= 2 -> 2.0; f <= 5 -> 5.0; else -> 10.0 }
}

/** Rounded selector pill (used for period, metric and cumulative toggles). */
@Composable
fun Pill(selected: Boolean, text: String, onClick: () -> Unit) {
    val p = MaterialTheme.colorScheme.primary
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) p else MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        FitText(text, fontSize = 14.sp, minSize = 9.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
    }
}

/** Tinted statistic tile with emoji, caption and value. */
@Composable
fun StatTile(icon: String, label: String, value: String, tint: Color, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(tint.copy(alpha = 0.13f)).padding(14.dp)) {
        Text(icon, fontSize = 20.sp)
        Spacer(Modifier.height(6.dp))
        FitText(value, fontSize = 19.sp, minSize = 11.sp, fontWeight = FontWeight.Bold)
        FitText(label, fontSize = 12.sp, minSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
    }
}

/** Bar chart drawn on a canvas: grid with small axis values, gradient bars, dashed average line, tap to select a bar. */
@Composable
fun HistChart(values: List<Double>, xLabels: List<String>, selected: Int, onSelect: (Int) -> Unit, showAvg: Boolean, modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val onSurf = MaterialTheme.colorScheme.onSurface
    val measurer = rememberTextMeasurer()
    val prog = remember(values) { Animatable(0f) }
    LaunchedEffect(values) { prog.animateTo(1f, tween(650)) }
    val top = niceCeil(maxOf(values.maxOrNull() ?: 0.0, 0.01))
    val avg = values.filter { it > 0 }.let { if (it.isEmpty()) 0.0 else it.average() }
    val tickStyle = TextStyle(fontSize = 9.sp, color = onSurf.copy(alpha = 0.55f))
    val xStyle = TextStyle(fontSize = 8.sp, color = onSurf.copy(alpha = 0.6f))
    val dec = if (top >= 10) 0 else if (top >= 2) 1 else 2
    val curSel by rememberUpdatedState(selected)
    val curPick by rememberUpdatedState(onSelect)
    Canvas(
        modifier.fillMaxWidth().height(210.dp).pointerInput(values) {
            detectTapGestures { off ->
                val left = 34.dp.toPx(); val right = 4.dp.toPx()
                val slot = (size.width - left - right) / values.size
                val i = ((off.x - left) / slot).toInt()
                curPick(if (i in values.indices && i != curSel) i else -1)
            }
        }
    ) {
        val left = 34.dp.toPx(); val right = 4.dp.toPx(); val topPad = 8.dp.toPx(); val bottomPad = 22.dp.toPx()
        val plotW = size.width - left - right
        val plotH = size.height - topPad - bottomPad
        val base = topPad + plotH
        // grid + y axis values
        for (k in 0..2) {
            val y = base - plotH * k / 2f
            drawLine(onSurf.copy(alpha = if (k == 0) 0.22f else 0.08f), Offset(left, y), Offset(size.width - right, y), strokeWidth = 1.dp.toPx())
            val t = measurer.measure(L.n(top * k / 2.0, dec), tickStyle)
            drawText(t, topLeft = Offset(left - 6.dp.toPx() - t.size.width, y - t.size.height / 2f))
        }
        val n = values.size
        val slot = plotW / n
        val barW = (slot * 0.62f).coerceAtMost(26.dp.toPx())
        val corner = CornerRadius(minOf(barW / 2f, 6.dp.toPx()))
        values.forEachIndexed { i, v ->
            val x = left + slot * i + (slot - barW) / 2f
            val h = if (v > 0) maxOf(plotH * (v / top).toFloat() * prog.value, 3.dp.toPx()) else 2.dp.toPx()
            val y = base - h
            val dim = selected >= 0 && i != selected
            val a = if (v > 0) (if (dim) 0.45f else 1f) else 0.18f
            drawRoundRect(
                Brush.verticalGradient(listOf(primary.copy(alpha = a), primary.copy(alpha = a * 0.55f)), startY = y, endY = base),
                Offset(x, y), Size(barW, h), corner
            )
            if (i == selected && v > 0) drawCircle(primary, 3.dp.toPx(), Offset(x + barW / 2f, y - 7.dp.toPx()))
            val lbl = xLabels.getOrElse(i) { "" }
            if (lbl.isNotEmpty()) {
                val t = measurer.measure(lbl, xStyle)
                drawText(t, topLeft = Offset(left + slot * i + (slot - t.size.width) / 2f, base + 5.dp.toPx()))
            }
        }
        if (showAvg && avg > 0) {
            val y = base - plotH * (avg / top).toFloat()
            drawLine(primary.copy(alpha = 0.75f), Offset(left, y), Offset(size.width - right, y), strokeWidth = 1.5.dp.toPx(),
                cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
        }
    }
}
