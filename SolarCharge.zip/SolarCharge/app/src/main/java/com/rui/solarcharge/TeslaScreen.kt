package com.rui.solarcharge

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

private const val MI = 1.609344

/** Runs a Tessie command off the main thread, shows the result as a toast and refreshes the state. */
private fun runCommand(ctx: android.content.Context, cfg: Cfg, cmd: String) {
    Thread {
        val msg = try { Api.get(cfg).command(cmd); try { Api.get(cfg).teslaState() } catch (_: Exception) {}; L.t("tsl_sent") }
                  catch (e: Exception) { L.t("tsl_fail", e.message ?: "") }
        android.os.Handler(android.os.Looper.getMainLooper()).post { android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show() }
    }.start()
}

private fun JSONObject?.num(k: String): Double? =
    if (this == null || !has(k) || isNull(k)) null else optDouble(k).takeIf { !it.isNaN() }

@Composable
private fun TRow(label: String, value: String?, warn: Boolean = false) {
    if (value == null) return
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, color = if (warn) Color(0xFFE5484D) else Color.Unspecified)
    }
}

@Composable
private fun TPanel(id: String, title: String, content: @Composable ColumnScope.() -> Unit) {
    Panel(id = id, title = title, content = content)
}

@Composable
fun TeslaScreen(cfg: Cfg) {
    val ctx = LocalContext.current
    var busy by remember { mutableStateOf(false) }
    fun refresh() {
        if (busy) return
        busy = true
        Thread { try { Api.get(cfg).teslaState() } catch (_: Exception) {} ; busy = false }.start()
    }
    LaunchedEffect(Unit) { if (Live.teslaJson == null && cfg.get("vin").isNotBlank()) refresh() }

    val j = Live.teslaJson
    val cs = j?.optJSONObject("charge_state")
    val cl = j?.optJSONObject("climate_state")
    val vs = j?.optJSONObject("vehicle_state")
    val ds = j?.optJSONObject("drive_state")
    val vc = j?.optJSONObject("vehicle_config")

    fun km(mi: Double?) = mi?.let { L.n(it * MI, 0) + " km" }
    fun deg(v: Double?) = v?.let { L.n(it, 1) + " °C" }
    fun yn(b: Boolean) = if (b) L.t("tsl_yes") else L.t("tsl_no")

    Column(
        Modifier.fillMaxSize().verticalScroll(tabScroll("tesla")).padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(j?.optString("display_name")?.takeIf { it.isNotBlank() } ?: L.t("tsl_title"), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                if (Live.teslaAt.isNotEmpty()) Label(L.t("tsl_updated", Live.teslaAt))
            }
            ArrangeToggle("tesla")
            Button({ refresh() }, enabled = !busy) { Text(L.t("tsl_refresh")) }
        }
        if (j == null) { Label(L.t("tsl_none")); return@Column }

        Blocks("tesla") {
        block("tsl_battery") {
        TPanel("tsl_battery", L.t("tsl_battery")) {
            val lvl = cs.num("battery_level")
            val usable = cs.num("usable_battery_level")
            TRow(L.t("tsl_level"), lvl?.let { "${it.toInt()} %" + if (usable != null && usable.toInt() != it.toInt()) " (${usable.toInt()} %)" else "" })
            TRow(L.t("tsl_range"), km(cs.num("est_battery_range") ?: cs.num("battery_range")))
            TRow(L.t("tsl_limit"), cs.num("charge_limit_soc")?.let { "${it.toInt()} %" })
            val st = cs?.optString("charging_state")?.takeIf { it.isNotBlank() }
            TRow(L.t("tsl_charging"), st?.let { stateName(it) })
            if (st == "Charging") {
                TRow(L.t("tsl_power"), Live.teslaKw.let { L.n(it, 1) + " kW" })
                val a = cs.num("charger_actual_current"); val v = cs.num("charger_voltage")
                TRow(L.t("tsl_current"), a?.let { L.n(it, 0) + " A" + if (v != null && v > 0) " · ${v.toInt()} V" else "" })
                cs.num("minutes_to_full_charge")?.takeIf { it > 0 }?.let { m ->
                    TRow(L.t("tsl_ttf"), "%d h %02d min".format(m.toInt() / 60, m.toInt() % 60))
                    TRow(L.t("tsl_eta"), java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date(System.currentTimeMillis() + (m * 60_000).toLong())))
                }
            }
            TRow(L.t("tsl_energy"), cs.num("charge_energy_added")?.let { L.n(it, 1) + " kWh" })
            val cable = cs?.optString("conn_charge_cable")?.takeIf { it.isNotBlank() }
            TRow(L.t("tsl_cable"), cable?.let { if (it == "<invalid>" || it == "SNA") L.t("tsl_unplugged") else it })
        }
        }
        block("tsl_session") {
        TPanel("tsl_session", L.t("tsl_session")) {
            val live = remember(Live.teslaAt, Live.chargingState) { Sessions(ctx).current() }
            val last = remember(Live.teslaAt, Live.chargingState) { Sessions(ctx).all().firstOrNull() }
            val ss = live ?: last
            if (ss == null) Label(L.t("tsl_session_none")) else {
                val tf = remember { java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.US) }
                Text(L.t(if (live != null) "tsl_session_now" else "tsl_session_last") + " · " + L.t("sess_mode_" + ss.mode), fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
                TRow(L.t("tsl_s_time"), tf.format(java.util.Date(ss.start)) + " → " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date(ss.end)))
                TRow(L.t("tsl_energy"), L.n(ss.kwh, 2) + " kWh")
                val pct = if (ss.kwh > 0) (ss.solarKwh / ss.kwh * 100).toInt().coerceIn(0, 100) else 0
                TRow(L.t("tsl_s_solar"), "$pct %")
                if (ss.b0 >= 0) TRow(L.t("tsl_s_battery"), "${ss.b0} → ${ss.b1} %")
                TRow(L.t("tsl_s_saved"), L.n(ss.saved, 2) + " €")
                TRow(L.t("tsl_s_cost"), L.n(ss.cost, 2) + " €")
            }
        }
        }
        block("tsl_ctrl") {
        TPanel("tsl_ctrl", L.t("tsl_ctrl")) {
            var lim by remember(cs.num("charge_limit_soc")) { mutableFloatStateOf((cs.num("charge_limit_soc") ?: 80.0).toFloat().coerceIn(50f, 100f)) }
            Text(L.t("tsl_limit") + ": " + lim.toInt() + " %", fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Slider(value = lim, onValueChange = { lim = Math.round(it / 5f) * 5f }, valueRange = 50f..100f, steps = 9)
            Button({ runCommand(ctx, cfg, "set_charge_limit?percent=" + lim.toInt()) }, Modifier.fillMaxWidth()) { Text(L.t("tsl_apply")) }
            Label(L.t("tsl_limit_help"))
            Spacer(Modifier.height(8.dp))
            val sentry = vs != null && vs.optBoolean("sentry_mode")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(L.t("tsl_sentry"), Modifier.weight(1f))
                Switch(checked = sentry, onCheckedChange = { on -> runCommand(ctx, cfg, if (on) "enable_sentry" else "disable_sentry") })
            }
        }
        }
        block("tsl_actions") {
        TPanel("tsl_actions", L.t("tsl_actions")) {
            var askHonk by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ runCommand(ctx, cfg, "start_climate") }, Modifier.weight(1f)) { Text("♨️ " + L.t("tsl_a_climate_on"), fontSize = 13.sp, textAlign = TextAlign.Center) }
                OutlinedButton({ runCommand(ctx, cfg, "stop_climate") }, Modifier.weight(1f)) { Text("❄️ " + L.t("tsl_a_climate_off"), fontSize = 13.sp, textAlign = TextAlign.Center) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ runCommand(ctx, cfg, "open_charge_port") }, Modifier.weight(1f)) { Text("🔌 " + L.t("tsl_a_port_open"), fontSize = 13.sp, textAlign = TextAlign.Center) }
                OutlinedButton({ runCommand(ctx, cfg, "close_charge_port") }, Modifier.weight(1f)) { Text("🔒 " + L.t("tsl_a_port_close"), fontSize = 13.sp, textAlign = TextAlign.Center) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ askHonk = true }, Modifier.weight(1f)) { Text("📣 " + L.t("tsl_a_honk"), fontSize = 13.sp, textAlign = TextAlign.Center) }
                OutlinedButton({ runCommand(ctx, cfg, "flash") }, Modifier.weight(1f)) { Text("💡 " + L.t("tsl_a_flash"), fontSize = 13.sp, textAlign = TextAlign.Center) }
            }
            Label(L.t("tsl_actions_help"))
            if (askHonk) AlertDialog(
                onDismissRequest = { askHonk = false },
                title = { Text(L.t("tsl_a_honk")) }, text = { Text(L.t("tsl_a_honk_q")) },
                confirmButton = { TextButton({ askHonk = false; runCommand(ctx, cfg, "honk") }) { Text(L.t("chat_confirm")) } },
                dismissButton = { TextButton({ askHonk = false }) { Text(L.t("chat_cancel")) } }
            )
        }
        }
        block("tsl_stats") {
        TPanel("tsl_stats", L.t("tsl_stats")) {
            val kmT = CarStats.kmToday(); val cons = CarStats.consumption(); val r100 = CarStats.range100()
            TRow(L.t("tsl_km_today"), kmT?.let { L.n(it, 0) + " km" })
            TRow(L.t("tsl_cons"), cons?.let { L.n(it.first, 0) + " Wh/km (" + L.t("tsl_cons_n", it.second) + ")" })
            TRow(L.t("tsl_r100"), r100?.let { L.n(it.first, 0) + " km" })
            if (r100 != null && r100.third >= 7) TRow(L.t("tsl_r100_pct"), L.n(r100.first / r100.second * 100, 1) + " %")
            if (kmT == null && cons == null && r100 == null) Label(L.t("tsl_stats_wait"))
            else Label(L.t("tsl_stats_help"))
        }
        }
        block("tsl_climate") {
        TPanel("tsl_climate", L.t("tsl_climate")) {
            TRow(L.t("tsl_inside"), deg(cl.num("inside_temp")))
            TRow(L.t("tsl_outside"), deg(cl.num("outside_temp")))
            if (cl != null && cl.has("is_climate_on")) TRow(L.t("tsl_climate"), if (cl.optBoolean("is_climate_on")) L.t("tsl_on") else L.t("tsl_off"))
            if (cl != null && cl.has("is_preconditioning")) TRow(L.t("tsl_precond"), if (cl.optBoolean("is_preconditioning")) L.t("tsl_on") else L.t("tsl_off"))
            if (cl != null && cl.has("battery_heater")) TRow(L.t("tsl_batheat"), if (cl.optBoolean("battery_heater")) L.t("tsl_on") else L.t("tsl_off"))
        }
        }
        block("tsl_vehicle") {
        TPanel("tsl_vehicle", L.t("tsl_vehicle")) {
            val model = listOfNotNull(vc?.optString("car_type")?.takeIf { it.isNotBlank() }, vc?.optString("trim_badging")?.takeIf { it.isNotBlank() }).joinToString(" ")
            TRow(L.t("tsl_model"), model.ifBlank { null })
            TRow(L.t("tsl_state"), j.optString("state").takeIf { it.isNotBlank() })
            val ts = ds.num("timestamp") ?: vs.num("timestamp")
            if (ts != null && ts > 1e11) {
                val ago = ((System.currentTimeMillis() - ts.toLong()) / 60_000).toInt().coerceAtLeast(0)
                TRow(L.t("tsl_lastread"), java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date(ts.toLong())) + " (" + L.t("tsl_ago", ago) + ")", ago > 120)
            }
            if (vs != null && vs.has("locked")) TRow(L.t("tsl_locked"), yn(vs.optBoolean("locked")))
            if (vs != null && vs.has("sentry_mode")) TRow(L.t("tsl_sentry"), if (vs.optBoolean("sentry_mode")) L.t("tsl_on") else L.t("tsl_off"))
            TRow(L.t("tsl_odo"), km(vs.num("odometer")))
            TRow(L.t("tsl_sw"), vs?.optString("car_version")?.takeIf { it.isNotBlank() }?.substringBefore(" "))
            if (vs != null && vs.has("df")) {
                val open = listOf("df", "dr", "pf", "pr", "ft", "rt").any { vs.optInt(it, 0) != 0 } ||
                    listOf("fd_window", "fp_window", "rd_window", "rp_window").any { vs.optInt(it, 0) != 0 }
                TRow(L.t("tsl_doors"), if (open) L.t("tsl_open") else L.t("tsl_closed"))
            }
        }
        }
        val tp = listOf("fl", "fr", "rl", "rr").map { vs.num("tpms_pressure_$it") }
        val tireMin = cfg.get("tireMinBar", "2.2").replace(',', '.').toDoubleOrNull() ?: 2.2
        val tireLow = tp.map { it != null && it > 0.5 && it < tireMin }
        block("tsl_tires") {
        if (tp.any { it != null }) TPanel("tsl_tires", L.t("tsl_tires")) {
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) { TRow("FL", tp[0]?.let { L.n(it, 1) }, tireLow[0]); TRow("RL", tp[2]?.let { L.n(it, 1) }, tireLow[2]) }
                Spacer(Modifier.width(24.dp))
                Column(Modifier.weight(1f)) { TRow("FR", tp[1]?.let { L.n(it, 1) }, tireLow[1]); TRow("RR", tp[3]?.let { L.n(it, 1) }, tireLow[3]) }
            }
            if (tireLow.any { it }) Label(L.t("tsl_tire_warn", L.n(tireMin, 1)))
        }
        }
        val lat = ds.num("latitude"); val lon = ds.num("longitude")
        block("tsl_location") {
        if (lat != null && lon != null) TPanel("tsl_location", L.t("tsl_location")) {
            TRow(L.t("tsl_location"), "%.4f, %.4f".format(java.util.Locale.US, lat, lon))
            OutlinedButton({
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            }, Modifier.fillMaxWidth()) { Text(L.t("tsl_open_map")) }
        }
        }

        }
    }
}
