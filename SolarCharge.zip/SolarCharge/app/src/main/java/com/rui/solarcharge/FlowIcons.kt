package com.rui.solarcharge

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp

/** One piece of an icon: SVG path on a 24 x 24 grid, filled or stroked, with opacity and stroke width. */
class P(val d: String, val fill: Boolean, val alpha: Float, val width: Float)

/** Flow-diagram icon sets drawn from SVG paths: line, solid, duo (two tone), bold, soft (outline + tint), neon (glow). "emoji" is the classic set. The same paths serve the app and the widget. */
object FlowIcons {
    val sets = listOf("line", "solid", "duo", "bold", "soft", "neon", "emoji")

    private val data: Map<String, Map<String, List<P>>> = mapOf(
        "line" to mapOf(
            "sun" to listOf(P("M8 12a4 4 0 1 0 8 0a4 4 0 1 0 -8 0Z", false, 1.0f, 1.8f), P("M12 2.5v2", false, 1.0f, 1.8f), P("M12 19.5v2", false, 1.0f, 1.8f), P("M4.9 4.9l1.4 1.4", false, 1.0f, 1.8f), P("M17.7 17.7l1.4 1.4", false, 1.0f, 1.8f), P("M2.5 12h2", false, 1.0f, 1.8f), P("M19.5 12h2", false, 1.0f, 1.8f), P("M4.9 19.1l1.4-1.4", false, 1.0f, 1.8f), P("M17.7 6.3l1.4-1.4", false, 1.0f, 1.8f)),
            "home" to listOf(P("M3.5 11.2 12 3.8l8.5 7.4", false, 1.0f, 1.8f), P("M5.5 9.8V20h13V9.8", false, 1.0f, 1.8f), P("M10 20v-5.2h4V20", false, 1.0f, 1.8f)),
            "car" to listOf(P("M4 16.5H3v-5l2-4.2A2 2 0 0 1 6.8 6h10.4A2 2 0 0 1 19 7.3l2 4.2v5h-1", false, 1.0f, 1.8f), P("M9 16.5h6", false, 1.0f, 1.8f), P("M3 11.5h18", false, 1.0f, 1.8f), P("M4.3 17a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0 -4.4 0Z", false, 1.0f, 1.8f), P("M15.3 17a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0 -4.4 0Z", false, 1.0f, 1.8f)),
            "grid" to listOf(P("M9 22 12 3l3 19", false, 1.0f, 1.8f), P("M5.5 8h13", false, 1.0f, 1.8f), P("M7 13.5h10", false, 1.0f, 1.8f), P("M8 18.5h8", false, 1.0f, 1.8f), P("M9.6 8 14.4 13.5", false, 1.0f, 1.8f), P("M14.4 8 9.6 13.5", false, 1.0f, 1.8f))
        ),
        "solid" to mapOf(
            "sun" to listOf(P("M7 12a5 5 0 1 0 10 0a5 5 0 1 0 -10 0Z", true, 1.0f, 0f), P("M12 2.5v2", false, 1.0f, 1.8f), P("M12 19.5v2", false, 1.0f, 1.8f), P("M4.9 4.9l1.4 1.4", false, 1.0f, 1.8f), P("M17.7 17.7l1.4 1.4", false, 1.0f, 1.8f), P("M2.5 12h2", false, 1.0f, 1.8f), P("M19.5 12h2", false, 1.0f, 1.8f), P("M4.9 19.1l1.4-1.4", false, 1.0f, 1.8f), P("M17.7 6.3l1.4-1.4", false, 1.0f, 1.8f)),
            "home" to listOf(P("M12 3 2.5 11.5H5V20h5.5v-5.5h3V20H19v-8.5h2.5Z", true, 1.0f, 0f)),
            "car" to listOf(P("M5.4 9 6.8 5.9A2 2 0 0 1 8.6 4.8h6.8a2 2 0 0 1 1.8 1.1L18.6 9H20a1.5 1.5 0 0 1 1.5 1.5v5a1 1 0 0 1-1 1h-1.2a2.5 2.5 0 0 1-5 0H9.7a2.5 2.5 0 0 1-5 0H3.5a1 1 0 0 1-1-1v-5A1.5 1.5 0 0 1 4 9Z", true, 1.0f, 0f)),
            "grid" to listOf(P("M13.5 2 5 13.5h5.5L9.5 22 19 9.5h-5.5Z", true, 1.0f, 0f))
        ),
        "duo" to mapOf(
            "sun" to listOf(P("M2 12a10 10 0 1 0 20 0a10 10 0 1 0 -20 0Z", true, 0.28f, 0f), P("M6.6 12a5.4 5.4 0 1 0 10.8 0a5.4 5.4 0 1 0 -10.8 0Z", true, 1.0f, 0f)),
            "home" to listOf(P("M12 2.8 2 11h20Z", true, 0.45f, 0f), P("M5 11h14v9.2H5ZM10.4 20.2v-5h3.2v5Z", true, 1.0f, 0f)),
            "car" to listOf(P("M6.4 6h11.2l3 5.5H3.4Z", true, 0.45f, 0f), P("M3 11.5h18V16a1.2 1.2 0 0 1-1.2 1.2H4.2A1.2 1.2 0 0 1 3 16Z", true, 1.0f, 0f), P("M4.800000000000001 17.4a2.4 2.4 0 1 0 4.8 0a2.4 2.4 0 1 0 -4.8 0Z", true, 1.0f, 0f), P("M14.4 17.4a2.4 2.4 0 1 0 4.8 0a2.4 2.4 0 1 0 -4.8 0Z", true, 1.0f, 0f)),
            "grid" to listOf(P("M2 12a10 10 0 1 0 20 0a10 10 0 1 0 -20 0Z", true, 0.28f, 0f), P("M13.2 3.5 6.8 13h4.4l-.9 7.5L17.2 11h-4.4Z", true, 1.0f, 0f))
        ),
        "bold" to mapOf(
            "sun" to listOf(P("M6.4 12a5.6 5.6 0 1 0 11.2 0a5.6 5.6 0 1 0 -11.2 0Z", true, 1.0f, 0f), P("M12.00 0.40L13.45 4.20L10.55 4.20Z", true, 1.0f, 0f), P("M20.20 3.80L18.54 7.51L16.49 5.46Z", true, 1.0f, 0f), P("M23.60 12.00L19.80 13.45L19.80 10.55Z", true, 1.0f, 0f), P("M20.20 20.20L16.49 18.54L18.54 16.49Z", true, 1.0f, 0f), P("M12.00 23.60L10.55 19.80L13.45 19.80Z", true, 1.0f, 0f), P("M3.80 20.20L5.46 16.49L7.51 18.54Z", true, 1.0f, 0f), P("M0.40 12.00L4.20 10.55L4.20 13.45Z", true, 1.0f, 0f), P("M3.80 3.80L7.51 5.46L5.46 7.51Z", true, 1.0f, 0f)),
            "home" to listOf(P("M12 2.2 1.5 11.6H4.6V21.2h6v-6h2.8v6h6V11.6h3.1Z", true, 1.0f, 0f)),
            "car" to listOf(P("M4.2 10.3 5.9 5.4A2.4 2.4 0 0 1 8.2 3.8h7.6a2.4 2.4 0 0 1 2.3 1.6l1.7 4.9H21.5v3.6h-1V19a1.2 1.2 0 0 1-1.2 1.2H17A1.2 1.2 0 0 1 15.8 19v-1.4H8.2V19A1.2 1.2 0 0 1 7 20.2H4.7A1.2 1.2 0 0 1 3.5 19v-5.1h-1V10.3ZM7.7 6.4 6.8 9.3h10.4l-.9-2.9ZM6.6 11.6a1.3 1.3 0 1 0 0 2.6a1.3 1.3 0 1 0 0-2.6ZM17.4 11.6a1.3 1.3 0 1 0 0 2.6a1.3 1.3 0 1 0 0-2.6Z", true, 1.0f, 0f)),
            "grid" to listOf(P("M12 1.8 15.6 22h-2.3l-.6-3.4h-1.4l-.6 3.4H8.4Z", true, 1.0f, 0f), P("M3.5 6.6h17V8.6h-17Z", true, 1.0f, 0f), P("M5.5 11.6h13v2h-13Z", true, 1.0f, 0f))
        ),
        "soft" to mapOf(
            "sun" to listOf(P("M8 12a4 4 0 1 0 8 0a4 4 0 1 0 -8 0Z", true, 0.35f, 0f), P("M8 12a4 4 0 1 0 8 0a4 4 0 1 0 -8 0Z", false, 1.0f, 1.8f), P("M12 2.5v2", false, 1.0f, 1.8f), P("M12 19.5v2", false, 1.0f, 1.8f), P("M4.9 4.9l1.4 1.4", false, 1.0f, 1.8f), P("M17.7 17.7l1.4 1.4", false, 1.0f, 1.8f), P("M2.5 12h2", false, 1.0f, 1.8f), P("M19.5 12h2", false, 1.0f, 1.8f), P("M4.9 19.1l1.4-1.4", false, 1.0f, 1.8f), P("M17.7 6.3l1.4-1.4", false, 1.0f, 1.8f)),
            "home" to listOf(P("M5.5 9.8 12 4.2l6.5 5.6V20h-13Z", true, 0.3f, 0f), P("M3.5 11.2 12 3.8l8.5 7.4", false, 1.0f, 1.8f), P("M5.5 9.8V20h13V9.8", false, 1.0f, 1.8f), P("M10 20v-5.2h4V20", false, 1.0f, 1.8f)),
            "car" to listOf(P("M3 16.5v-5l2-4.2A2 2 0 0 1 6.8 6h10.4A2 2 0 0 1 19 7.3l2 4.2v5Z", true, 0.3f, 0f), P("M4 16.5H3v-5l2-4.2A2 2 0 0 1 6.8 6h10.4A2 2 0 0 1 19 7.3l2 4.2v5h-1", false, 1.0f, 1.8f), P("M9 16.5h6", false, 1.0f, 1.8f), P("M3 11.5h18", false, 1.0f, 1.8f), P("M4.3 17a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0 -4.4 0Z", false, 1.0f, 1.8f), P("M15.3 17a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0 -4.4 0Z", false, 1.0f, 1.8f)),
            "grid" to listOf(P("M9 22 12 3l3 19Z", true, 0.3f, 0f), P("M9 22 12 3l3 19", false, 1.0f, 1.8f), P("M5.5 8h13", false, 1.0f, 1.8f), P("M7 13.5h10", false, 1.0f, 1.8f), P("M8 18.5h8", false, 1.0f, 1.8f), P("M9.6 8 14.4 13.5", false, 1.0f, 1.8f), P("M14.4 8 9.6 13.5", false, 1.0f, 1.8f))
        ),
        "neon" to mapOf(
            "sun" to listOf(P("M8 12a4 4 0 1 0 8 0a4 4 0 1 0 -8 0Z", false, 0.22f, 4.4f), P("M12 2.5v2", false, 0.22f, 4.4f), P("M12 19.5v2", false, 0.22f, 4.4f), P("M4.9 4.9l1.4 1.4", false, 0.22f, 4.4f), P("M17.7 17.7l1.4 1.4", false, 0.22f, 4.4f), P("M2.5 12h2", false, 0.22f, 4.4f), P("M19.5 12h2", false, 0.22f, 4.4f), P("M4.9 19.1l1.4-1.4", false, 0.22f, 4.4f), P("M17.7 6.3l1.4-1.4", false, 0.22f, 4.4f), P("M8 12a4 4 0 1 0 8 0a4 4 0 1 0 -8 0Z", false, 1.0f, 1.8f), P("M12 2.5v2", false, 1.0f, 1.8f), P("M12 19.5v2", false, 1.0f, 1.8f), P("M4.9 4.9l1.4 1.4", false, 1.0f, 1.8f), P("M17.7 17.7l1.4 1.4", false, 1.0f, 1.8f), P("M2.5 12h2", false, 1.0f, 1.8f), P("M19.5 12h2", false, 1.0f, 1.8f), P("M4.9 19.1l1.4-1.4", false, 1.0f, 1.8f), P("M17.7 6.3l1.4-1.4", false, 1.0f, 1.8f)),
            "home" to listOf(P("M3.5 11.2 12 3.8l8.5 7.4", false, 0.22f, 4.4f), P("M5.5 9.8V20h13V9.8", false, 0.22f, 4.4f), P("M10 20v-5.2h4V20", false, 0.22f, 4.4f), P("M3.5 11.2 12 3.8l8.5 7.4", false, 1.0f, 1.8f), P("M5.5 9.8V20h13V9.8", false, 1.0f, 1.8f), P("M10 20v-5.2h4V20", false, 1.0f, 1.8f)),
            "car" to listOf(P("M4 16.5H3v-5l2-4.2A2 2 0 0 1 6.8 6h10.4A2 2 0 0 1 19 7.3l2 4.2v5h-1", false, 0.22f, 4.4f), P("M9 16.5h6", false, 0.22f, 4.4f), P("M3 11.5h18", false, 0.22f, 4.4f), P("M4.3 17a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0 -4.4 0Z", false, 0.22f, 4.4f), P("M15.3 17a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0 -4.4 0Z", false, 0.22f, 4.4f), P("M4 16.5H3v-5l2-4.2A2 2 0 0 1 6.8 6h10.4A2 2 0 0 1 19 7.3l2 4.2v5h-1", false, 1.0f, 1.8f), P("M9 16.5h6", false, 1.0f, 1.8f), P("M3 11.5h18", false, 1.0f, 1.8f), P("M4.3 17a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0 -4.4 0Z", false, 1.0f, 1.8f), P("M15.3 17a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0 -4.4 0Z", false, 1.0f, 1.8f)),
            "grid" to listOf(P("M9 22 12 3l3 19", false, 0.22f, 4.4f), P("M5.5 8h13", false, 0.22f, 4.4f), P("M7 13.5h10", false, 0.22f, 4.4f), P("M8 18.5h8", false, 0.22f, 4.4f), P("M9.6 8 14.4 13.5", false, 0.22f, 4.4f), P("M14.4 8 9.6 13.5", false, 0.22f, 4.4f), P("M9 22 12 3l3 19", false, 1.0f, 1.8f), P("M5.5 8h13", false, 1.0f, 1.8f), P("M7 13.5h10", false, 1.0f, 1.8f), P("M8 18.5h8", false, 1.0f, 1.8f), P("M9.6 8 14.4 13.5", false, 1.0f, 1.8f), P("M14.4 8 9.6 13.5", false, 1.0f, 1.8f))
        )
    )

    fun parts(kind: String, set: String): List<P> =
        (data[set] ?: data["line"]!!)[kind] ?: (TabIconData.data[set] ?: TabIconData.data["line"]!!)[kind].orEmpty()

    fun kindOf(emoji: String) = when {
        emoji.startsWith("☀") -> "sun"
        emoji.startsWith("🏠") -> "home"
        emoji.startsWith("🚗") -> "car"
        else -> "grid"
    }

    /** Colour of each icon (the car follows the theme colour). */
    fun color(kind: String, theme: Color, grid: Color): Color = when (kind) {
        "sun" -> Color(0xFFFFB300)
        "home" -> Color(0xFF4FC3F7)
        "car" -> theme
        "chart" -> Color(0xFF4F8CFF)
        "gear" -> Color(0xFF9AA7BD)
        "heart" -> Color(0xFFFF5A7A)
        "info" -> Color(0xFF4FC3F7)
        else -> grid
    }

    /** Draws an icon on an android.graphics.Canvas (widget bitmap). */
    fun drawAndroid(cv: android.graphics.Canvas, kind: String, set: String, cx: Float, cy: Float, size: Float, color: Int) {
        cv.save()
        cv.translate(cx - size / 2f, cy - size / 2f)
        cv.scale(size / 24f, size / 24f)
        val baseA = (color ushr 24) and 0xFF
        parts(kind, set).forEach { part ->
            try {
                val path = androidx.core.graphics.PathParser.createPathFromPathData(part.d)
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                paint.color = (color and 0x00FFFFFF) or ((baseA * part.alpha).toInt().coerceIn(0, 255) shl 24)
                if (part.fill) { paint.style = android.graphics.Paint.Style.FILL; path.fillType = android.graphics.Path.FillType.EVEN_ODD }
                else { paint.style = android.graphics.Paint.Style.STROKE; paint.strokeWidth = part.width; paint.strokeCap = android.graphics.Paint.Cap.ROUND; paint.strokeJoin = android.graphics.Paint.Join.ROUND }
                cv.drawPath(path, paint)
            } catch (_: Exception) {}
        }
        cv.restore()
    }
}

@Composable
fun FlowIcon(kind: String, color: Color, set: String, size: Dp) {
    val paths = remember(kind, set) {
        FlowIcons.parts(kind, set).map { part ->
            part to PathParser().parsePathString(part.d).toPath().also { if (part.fill) it.fillType = PathFillType.EvenOdd }
        }
    }
    Canvas(Modifier.size(size)) {
        val sc = this.size.minDimension / 24f
        scale(sc, sc, Offset.Zero) {
            paths.forEach { (part, p) ->
                val c = color.copy(alpha = color.alpha * part.alpha)
                if (part.fill) drawPath(p, c)
                else drawPath(p, c, style = Stroke(width = part.width, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

/** Light looping motion for a flow icon: sun breathes and turns slightly, house breathes, car sways, grid flickers softly. Only while [active]. */
fun Modifier.iconMotion(kind: String, active: Boolean): Modifier = if (!active) this else composed {
    val t = rememberInfiniteTransition(label = "icon")
    val ms = when (kind) { "sun" -> 3200; "car" -> 1800; "grid" -> 1400; else -> 2800 }
    val v by t.animateFloat(0f, 1f, infiniteRepeatable(tween(ms, easing = androidx.compose.animation.core.FastOutSlowInEasing), RepeatMode.Reverse), label = "v")
    graphicsLayer {
        when (kind) {
            "sun" -> { val k = 1f + 0.08f * v; scaleX = k; scaleY = k; rotationZ = -6f + 12f * v }
            "car" -> { translationX = (-1.5f + 3f * v) * density; rotationZ = -1.5f + 3f * v }
            "grid" -> { alpha = 0.78f + 0.22f * v; val k = 0.96f + 0.08f * v; scaleX = k; scaleY = k }
            else -> { val k = 1f + 0.05f * v; scaleX = k; scaleY = k }
        }
    }
}
