package com.rui.solarcharge

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Derived car statistics kept across restarts: km today, average consumption between charges, range at 100 %. */
object CarStats {
    const val MI_KM = 1.609344
    private var p: SharedPreferences? = null
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun init(ctx: Context) { if (p == null) p = ctx.applicationContext.getSharedPreferences("carstats", Context.MODE_PRIVATE) }

    /** Consumption samples and the 100 % range per day, for the history backup file. */
    @Synchronized
    fun exportJson(ctx: Context): JSONObject {
        init(ctx)
        val sp = p ?: return JSONObject()
        return JSONObject()
            .put("cons", try { JSONArray(sp.getString("cons", "[]")) } catch (_: Exception) { JSONArray() })
            .put("consLog", try { JSONArray(sp.getString("consLog", "[]")) } catch (_: Exception) { JSONArray() })
            .put("r100", try { JSONObject(sp.getString("r100", "{}")) } catch (_: Exception) { JSONObject() })
    }

    /** Merges the samples of a backup file with the existing ones (nothing is lost, nothing is duplicated). */
    @Synchronized
    fun importJson(ctx: Context, o: JSONObject) {
        init(ctx)
        val sp = p ?: return
        val ed = sp.edit()
        // consumption log: [day, Wh/km] pairs, union, newest 200
        val have = HashSet<String>(); val all = ArrayList<JSONArray>()
        fun addAll(a: JSONArray?) { if (a == null) return; for (i in 0 until a.length()) { val e = a.optJSONArray(i) ?: continue; if (have.add(e.optString(0) + "|" + e.optDouble(1))) all.add(e) } }
        addAll(try { JSONArray(sp.getString("consLog", "[]")) } catch (_: Exception) { null })
        addAll(o.optJSONArray("consLog"))
        all.sortBy { it.optString(0) }
        val lg = JSONArray(); all.takeLast(200).forEach { lg.put(it) }
        ed.putString("consLog", lg.toString())
        // recent average: keep the existing one, or take the file's when there is none
        if (sp.getString("cons", "[]") == "[]") o.optJSONArray("cons")?.let { ed.putString("cons", it.toString()) }
        // range at 100 %: per day, existing values win
        val r = try { JSONObject(sp.getString("r100", "{}")) } catch (_: Exception) { JSONObject() }
        o.optJSONObject("r100")?.let { f -> f.keys().forEach { k -> if (!r.has(k)) r.put(k, f.optDouble(k)) } }
        r.keys().asSequence().sorted().toList().dropLast(120).forEach { r.remove(it) }
        ed.putString("r100", r.toString())
        ed.apply()
    }

    /** Called with every fresh Tessie state. */
    @Synchronized
    fun update(j: JSONObject) {
        val sp = p ?: return
        val ed = sp.edit()
        val vs = j.optJSONObject("vehicle_state"); val cs = j.optJSONObject("charge_state")
        val odo = vs?.optDouble("odometer", Double.NaN)?.takeIf { !it.isNaN() && it > 0 }
        val day = dayFmt.format(Date())
        if (odo != null) {
            if (sp.getString("odoDay", "") != day) ed.putString("odoDay", day).putString("odo0", odo.toString())
            ed.putString("odoLast", odo.toString())
        }
        if (cs != null) {
            val charging = cs.optString("charging_state") == "Charging"
            val was = sp.getBoolean("wasCharging", false)
            if (charging) ed.putString("lastEnergy", cs.optDouble("charge_energy_added", 0.0).toString())
            if (was && !charging && odo != null) {
                val energy = sp.getString("lastEnergy", "0")?.toDoubleOrNull() ?: 0.0
                val prev = sp.getString("endOdo", "")?.toDoubleOrNull()
                if (prev != null && energy > 0.5) {
                    val km = (odo - prev) * MI_KM
                    if (km >= 15) {
                        val arr = try { JSONArray(sp.getString("cons", "[]")) } catch (_: Exception) { JSONArray() }
                        arr.put(energy * 1000.0 / km)
                        val lg = try { JSONArray(sp.getString("consLog", "[]")) } catch (_: Exception) { JSONArray() }
                        lg.put(JSONArray().put(day).put(energy * 1000.0 / km))
                        val lt = JSONArray(); for (i in maxOf(0, lg.length() - 200) until lg.length()) lt.put(lg.get(i))
                        ed.putString("consLog", lt.toString())
                        val t = JSONArray(); for (i in maxOf(0, arr.length() - 10) until arr.length()) t.put(arr.get(i))
                        ed.putString("cons", t.toString())
                    }
                }
                ed.putString("endOdo", odo.toString())
            }
            ed.putBoolean("wasCharging", charging)
            // ideal range extrapolated to 100 %: a stable indicator of battery capacity over time
            val lvl = cs.optDouble("battery_level", Double.NaN); val rng = cs.optDouble("battery_range", Double.NaN)
            if (!lvl.isNaN() && !rng.isNaN() && lvl >= 30 && rng > 0) {
                val m = try { JSONObject(sp.getString("r100", "{}")) } catch (_: Exception) { JSONObject() }
                m.put(day, rng * 100.0 / lvl * MI_KM)
                val keys = m.keys().asSequence().sorted().toList()
                keys.dropLast(120).forEach { m.remove(it) }
                ed.putString("r100", m.toString())
            }
        }
        ed.apply()
    }

    /** Kilometres driven today (from the odometer), or null when unknown. */
    @Synchronized
    fun kmToday(): Double? {
        val sp = p ?: return null
        if (sp.getString("odoDay", "") != dayFmt.format(Date())) return null
        val a = sp.getString("odo0", "")?.toDoubleOrNull() ?: return null
        val b = sp.getString("odoLast", "")?.toDoubleOrNull() ?: return null
        return ((b - a) * MI_KM).coerceAtLeast(0.0)
    }

    /** Average consumption in Wh/km (energy added to the car / distance between charges) and the number of samples. */
    @Synchronized
    fun consumption(): Pair<Double, Int>? {
        val sp = p ?: return null
        val arr = try { JSONArray(sp.getString("cons", "[]")) } catch (_: Exception) { return null }
        if (arr.length() == 0) return null
        var s = 0.0; for (i in 0 until arr.length()) s += arr.getDouble(i)
        return s / arr.length() to arr.length()
    }

    /** Latest range at 100 % (km), the best recorded value and the number of days recorded. */
    @Synchronized
    fun range100(): Triple<Double, Double, Int>? {
        val sp = p ?: return null
        val m = try { JSONObject(sp.getString("r100", "{}")) } catch (_: Exception) { return null }
        val keys = m.keys().asSequence().sorted().toList()
        if (keys.isEmpty()) return null
        val vals = keys.map { m.getDouble(it) }
        return Triple(vals.last(), vals.max(), vals.size)
    }

    /** Consumption of each charge interval (date, Wh/km), oldest first. */
    @Synchronized
    fun consLog(): List<Pair<String, Double>> {
        val sp = p ?: return emptyList()
        val a = try { JSONArray(sp.getString("consLog", "[]")) } catch (_: Exception) { return emptyList() }
        return (0 until a.length()).mapNotNull { i -> a.optJSONArray(i)?.let { it.optString(0) to it.optDouble(1) } }
    }

    /** Range at 100 % per day (date, km), oldest first. */
    @Synchronized
    fun range100Log(): List<Pair<String, Double>> {
        val sp = p ?: return emptyList()
        val m = try { JSONObject(sp.getString("r100", "{}")) } catch (_: Exception) { return emptyList() }
        return m.keys().asSequence().sorted().map { it to m.getDouble(it) }.toList()
    }
}
