package com.rui.solarcharge

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId

/** One charging session reported by Tessie (the car's own record, including Superchargers and sessions before the app existed). */
class TCharge(val id: String, val start: Long, val end: Long, val kwh: Double, val used: Double, val b0: Int, val b1: Int,
              val dc: Boolean, val place: String, val cost: Double)

/** Charging sessions from Tessie, kept in SharedPreferences ("tcharges", one JSON per session id). Separate from the daily History so solar/saving figures are not distorted. */
class TeslaCharges(ctx: Context) {
    private val p = ctx.getSharedPreferences("tcharges", Context.MODE_PRIVATE)

    @Synchronized
    fun all(): List<TCharge> = p.all.mapNotNull { (k, v) ->
        if (k.startsWith("_") || v !is String) null else try {
            val o = JSONObject(v)
            TCharge(k, o.optLong("a"), o.optLong("z"), o.optDouble("k"), o.optDouble("u"), o.optInt("b0", -1), o.optInt("b1", -1),
                o.optBoolean("dc"), o.optString("pl"), o.optDouble("c"))
        } catch (_: Exception) { null }
    }.sortedByDescending { it.start }

    @Synchronized
    fun put(list: List<TCharge>): Int {
        val ed = p.edit()
        for (t in list) ed.putString(t.id, JSONObject().put("a", t.start).put("z", t.end).put("k", t.kwh).put("u", t.used)
            .put("b0", t.b0).put("b1", t.b1).put("dc", t.dc).put("pl", t.place).put("c", t.cost).toString())
        ed.apply()
        return list.size
    }

    /** Raw sessions (id included) for the history backup file. */
    @Synchronized
    fun exportArray(): org.json.JSONArray {
        val arr = org.json.JSONArray()
        p.all.forEach { (k, v) -> if (!k.startsWith("_") && v is String) try { arr.put(JSONObject(v).put("id", k)) } catch (_: Exception) {} }
        return arr
    }

    /** Merges sessions from a backup file by id; returns how many were written. */
    @Synchronized
    fun importArray(arr: org.json.JSONArray): Int {
        val ed = p.edit(); var n = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id"); if (id.isBlank() || id.startsWith("_")) continue
            o.remove("id"); ed.putString(id, o.toString()); n++
        }
        ed.apply()
        return n
    }

    var lastSync: Long
        get() = p.getLong("_last", 0L)
        set(v) { p.edit().putLong("_last", v).apply() }

    @Synchronized fun clear() { p.edit().clear().apply() }
}

/** Downloads the charging sessions from Tessie in the background (windows of 6 months) and merges them by id. Safe to repeat. */
object TeslaImport {
    var running by mutableStateOf(false)
    var status by mutableStateOf<Msg?>(null)
    @Volatile private var cancel = false

    fun cancel() { cancel = true }

    /** Quiet daily refresh once a first import exists. */
    fun auto(ctx: Context) {
        val app = ctx.applicationContext
        val st = TeslaCharges(app)
        val c = Cfg(app)
        if (st.lastSync == 0L || System.currentTimeMillis() - st.lastSync < 12 * 3_600_000L) return
        if (c.get("teslaToken").isBlank() || c.get("vin").isBlank()) return
        start(app, java.time.Instant.ofEpochMilli(st.lastSync).atZone(ZoneId.systemDefault()).toLocalDate().minusDays(7))
    }

    fun start(ctx: Context, from: LocalDate) {
        if (running) return
        running = true; cancel = false
        val app = ctx.applicationContext
        Thread {
            var total = 0
            try {
                ApiLog.init(app)
                val c = Cfg(app)
                val store = TeslaCharges(app)
                val api = Api.get(c)
                val zone = ZoneId.systemDefault()
                val today = LocalDate.now()
                var start = from
                var retries = 0
                while (!start.isAfter(today) && !cancel) {
                    val end = minOf(start.plusDays(180), today.plusDays(1))
                    status = Msg("tc_run", listOf(start.toString(), total))
                    try {
                        val list = api.teslaCharges(start.atStartOfDay(zone).toEpochSecond(), end.plusDays(1).atStartOfDay(zone).toEpochSecond())
                        total += store.put(list)
                        start = end.plusDays(1); retries = 0
                    } catch (e: Exception) {
                        if (retries++ < 3) { Thread.sleep(5_000); continue }
                        status = Msg("gi_err", listOf(e.message ?: "")); running = false; return@Thread
                    }
                    Thread.sleep(1_500)
                }
                if (!cancel) store.lastSync = System.currentTimeMillis()
                status = Msg(if (cancel) "tc_cancelled" else "tc_done", listOf(total))
                ApiLog.i("Tessie", "Carregamentos importados: $total")
            } catch (e: Exception) {
                status = Msg("gi_err", listOf(e.message ?: ""))
            } finally { running = false }
        }.start()
    }
}
