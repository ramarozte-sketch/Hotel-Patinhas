package com.rui.solarcharge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the automatic control after the phone reboots (only if it was on and the setting allows it). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        val c = Cfg(ctx)
        if (c.get("autoOn") == "1" && c.get("autoStart", "1") != "0") {
            try { ctx.startForegroundService(Intent(ctx, SolarService::class.java)) } catch (_: Exception) {}
        }
    }
}
