package com.rui.solarcharge

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Pull-to-refresh: re-reads the car, the inverter (the Growatt API itself limits this to about one real call every 5 min) and the forecast. */
fun refreshAll(cfg: Cfg) {
    val t0 = System.currentTimeMillis()
    val api = Api.get(cfg)
    if (cfg.get("teslaToken").isNotBlank() && cfg.get("vin").isNotBlank()) {
        try {
            val st = api.teslaState()
            if (st != null) { Live.chargingState = st.charging; Live.teslaKw = st.powerKw; Live.battery = st.battery }
        } catch (e: Exception) { ApiLog.e("Tessie", "Atualizar: ${e.message}") }
    }
    if (Providers.configured(cfg)) {
        try {
            Live.pvW = api.solarW()
            Live.houseW = api.liveLoadW ?: -1.0
            val at = if (api.dataAt > 0) api.dataAt else api.lastOkAt
            if (at > 0) Live.updated = SimpleDateFormat("HH:mm", Locale.US).format(Date(at))
        } catch (e: Exception) { ApiLog.e("Growatt", "Atualizar: ${e.message}") }
    }
    try { Forecast.refresh(cfg) } catch (_: Exception) {}
    val left = 700 - (System.currentTimeMillis() - t0)
    if (left > 0) Thread.sleep(left)
}
