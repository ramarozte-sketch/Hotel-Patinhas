package com.rui.solarcharge

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.Toast

/** Home-screen widget: solar production, car power and battery. Refreshed by the service on every cycle. */
class SolarWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        L.init(Cfg(ctx))
        ids.forEach { mgr.updateAppWidget(it, build(ctx)) }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_TOGGLE) toggle(ctx)
    }

    companion object {
        const val ACTION_TOGGLE = "com.rui.solarcharge.WIDGET_TOGGLE"

        /** Same behaviour as the automatic-control switch on the dashboard. */
        fun toggle(ctx: Context) {
            val cfg = Cfg(ctx)
            L.init(cfg)
            if (Live.running) {
                val owns = SolarService.ownsCharge
                cfg.set("autoOn", "0")
                ctx.stopService(Intent(ctx, SolarService::class.java))
                if (owns) Thread { try { Api.get(cfg).command("stop_charging") } catch (_: Exception) {} }.start()
            } else if (!startSolar(ctx, cfg)) {
                Toast.makeText(ctx, Live.messageText(), Toast.LENGTH_LONG).show()
            }
            refresh(ctx)
        }

        fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget)
            val on = Live.running
            v.setTextViewText(R.id.w_status, if (on) Live.messageText() else L.t("auto_off"))
            v.setTextViewText(R.id.w_solar, if (on) L.n(Live.pvW / 1000.0, 2) + " kW" else "—")
            v.setTextViewText(R.id.w_solar_l, L.t("node_solar"))
            v.setTextViewText(R.id.w_car, if (on) L.n(Live.teslaKw, 1) + " kW" else "—")
            v.setTextViewText(R.id.w_car_l, L.t("node_car"))
            v.setTextViewText(R.id.w_bat, if (Live.battery >= 0) "${Live.battery} %" else "—")
            v.setTextViewText(R.id.w_bat_l, L.t("nav_tesla"))
            val today = try { History(ctx).today() } catch (_: Exception) { DoubleArray(6) }
            v.setTextViewText(R.id.w_today, L.t("today_charged", L.n(today[0])) + " · " + L.t("today_solar", L.n(today[1])))
            v.setImageViewBitmap(R.id.w_flow, WidgetFlow.render(ctx))
            v.setTextViewText(R.id.w_toggle_l, L.t("auto_title"))
            v.setImageViewResource(R.id.w_toggle, if (on) R.drawable.toggle_on else R.drawable.toggle_off)
            val tg = PendingIntent.getBroadcast(ctx, 1, Intent(ctx, SolarWidget::class.java).setAction(ACTION_TOGGLE), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            v.setOnClickPendingIntent(R.id.w_toggle, tg)
            v.setOnClickPendingIntent(R.id.w_toggle_l, tg)
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            v.setOnClickPendingIntent(R.id.w_root, pi)
            v.setOnClickPendingIntent(R.id.w_flow, pi)
            return v
        }

        fun refresh(ctx: Context) {
            WearBridge.publish(ctx)
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, SolarWidget::class.java))
                if (ids.isEmpty()) return
                val v = build(ctx)
                ids.forEach { mgr.updateAppWidget(it, v) }
            } catch (_: Exception) {}
        }
    }
}
