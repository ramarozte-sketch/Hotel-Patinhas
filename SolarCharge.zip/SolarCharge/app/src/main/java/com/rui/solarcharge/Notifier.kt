package com.rui.solarcharge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/** Event notifications (charge started/stopped, target reached, errors). Separate channel from the ongoing status notification. */
object Notifier {
    private val last = HashMap<Int, Long>()
    private val minGap = mapOf(1014 to 3_600_000L, 1017 to 43_200_000L)   // repeated errors: at most one per hour

    /** Tapping a notification opens the app. */
    fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun init(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alerts", "SolarCharge alerts", NotificationManager.IMPORTANCE_DEFAULT))
    }

    @Synchronized
    fun alert(ctx: Context, c: Cfg, id: Int, titleKey: String, bodyKey: String, vararg args: Any) {
        if (c.get("notify", "1") == "0") return
        val now = System.currentTimeMillis()
        if (now - (last[id] ?: 0L) < (minGap[id] ?: 30_000L)) return
        last[id] = now
        try {
            val n = Notification.Builder(ctx, "alerts")
                .setContentTitle(L.t(titleKey)).setContentText(L.t(bodyKey, *args))
                .setStyle(Notification.BigTextStyle().bigText(L.t(bodyKey, *args)))
                .setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(openApp(ctx)).setAutoCancel(true).build()
            ctx.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (e: Exception) { ApiLog.w("App", "Notificação falhou: ${e.message}") }
    }
}
