package com.rui.solarcharge

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.floor

class SolarService : Service() {
    companion object {
        const val FALLBACK_BASE_W = 400
        /** True while the car is charging because this app started it (the UI uses it to stop that charge when auto control is switched off). */
        @Volatile var ownsCharge = false
        const val ACTION_WAKE = "com.rui.solarcharge.WAKE"
        /** Completed by WakeReceiver when the alarm fires: the loop sleeps on this instead of a timer that stops while the phone sleeps. */
        @Volatile var wakeSignal: CompletableDeferred<Unit>? = null
        private var alarmLock: PowerManager.WakeLock? = null
        /** Keeps the CPU awake for a short time after the alarm, until the loop has resumed and holds its own lock. */
        fun holdAfterAlarm(ctx: android.content.Context) {
            try {
                val pm = ctx.getSystemService(PowerManager::class.java)
                val l = alarmLock ?: pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "solarcharge:alarm").also { it.setReferenceCounted(false); alarmLock = it }
                l.acquire(60_000L)
            } catch (_: Exception) {}
        }
    }
    private var loopLock: PowerManager.WakeLock? = null
    private var lastBusy = true
    private var lastCycleAt = 0L
    private var lastPlanMs = 0L
    private var lastLogged = ""
    /** Holds the CPU awake while the loop works or while there is something to control (otherwise the phone can sleep for hours and no cycle runs). */
    private fun holdWake(on: Boolean) {
        try {
            val l = loopLock ?: getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "solarcharge:loop")
                .also { it.setReferenceCounted(false); loopLock = it }
            if (on) l.acquire(15 * 60_000L) else if (l.isHeld) l.release()
        } catch (_: Exception) {}
    }
    private fun alarmPi() = PendingIntent.getBroadcast(this, 7, Intent(this, WakeReceiver::class.java).setAction(ACTION_WAKE),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    /** Waits for the next cycle. While idle (night) the CPU may sleep, so an alarm wakes it; while busy the wake lock keeps it running and a plain delay is used. */
    private suspend fun waitNext(ms: Long, busy: Boolean) {
        if (busy) { delay(ms); return }
        val sig = CompletableDeferred<Unit>()
        wakeSignal = sig
        try {
            getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + ms, alarmPi())
            withTimeoutOrNull(ms + 180_000L) { sig.await() }
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { delay(ms) }
        finally { wakeSignal = null }
    }   // used only while the inverter does not report house consumption
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private var lastCounterAt = 0L
    private val baseSamples = ArrayDeque<Double>()
    private var lastAmps = -1
    private var charging = false   // car is currently charging
    private var owned = false      // this app started the current session
        set(v) {
            if (field != v) try { getSharedPreferences("svc", MODE_PRIVATE).edit().putBoolean("owned", v).putLong("ownedAt", System.currentTimeMillis()).apply() } catch (_: Exception) {}
            field = v; ownsCharge = v
        }
    private var stateOk = false
    private var lastTick = 0L
    private var aboveSince = 0L    // when surplus first became enough to charge
    private var startTries = 0     // start commands sent that the car has not yet confirmed (state still not "Charging")
    private var belowSince = 0L    // when surplus first became too low
    private var lastAmpChange = 0L
    private var gridMode: String? = null   // "boost" | "guarantee" | "offpeak" while charging from the grid on purpose
    private var targetNotified = false
    private var failures = 0
    private var tessieFails = 0
    private var growattFails = 0
    private var sessions: Sessions? = null
    // house consumption without the car: the inverter's load sample is up to 5 min old, so the car power is taken at the time of the sample (not now)
    private var houseBaseW = -1.0
    private var lastLoadAt = 0L
    private var lastBaseAt = 0L
    private val carLog = ArrayDeque<Pair<Long, Double>>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        ApiLog.init(applicationContext)
        L.init(Cfg(this))
        Notifier.init(this)
        CarStats.init(applicationContext)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sc", "SolarCharge", NotificationManager.IMPORTANCE_LOW))
        val n0 = Notification.Builder(this, "sc").setContentTitle(L.t("notif_active"))
            .setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(Notifier.openApp(this)).build()
        if (android.os.Build.VERSION.SDK_INT >= 34)
            startForeground(1, n0, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n0)
        Live.running = true
        SolarWidget.refresh(this)
        if (job?.isActive != true) {
            ApiLog.i("App", "Serviço iniciado")
            // a session started by the app is still the app's after a restart of the service (otherwise it would never be stopped at the end of the window)
            try {
                val sp = getSharedPreferences("svc", MODE_PRIVATE)
                if (sp.getBoolean("owned", false) && System.currentTimeMillis() - sp.getLong("ownedAt", 0L) < 12 * 3_600_000L) {
                    owned = true; ApiLog.i("App", "Sessão iniciada pela app recuperada após reinício")
                }
            } catch (_: Exception) {}
            job = scope.launch { loop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        ApiLog.i("App", "Serviço parado")
        scope.cancel()
        try { getSystemService(AlarmManager::class.java).cancel(alarmPi()) } catch (_: Exception) {}
        try { if (loopLock?.isHeld == true) loopLock?.release() } catch (_: Exception) {}
        Live.running = false
        Live.boost = false
        ownsCharge = false
        SolarWidget.refresh(this)
        Live.msg("msg_stopped")
    }

    private fun updateNotification() {
        val text = L.t("notif_text", L.n(Live.pvW / 1000.0), L.n(Live.teslaKw), Live.messageText())
        getSystemService(NotificationManager::class.java).notify(1,
            Notification.Builder(this, "sc").setContentTitle("SolarCharge").setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(Notifier.openApp(this)).setOnlyAlertOnce(true).build())
    }

    private suspend fun loop() {
        val c = Cfg(this)
        val hist = History(this)
        sessions = Sessions(this)
        val api = Api.get(c)
        while (scope.isActive) {
            holdWake(true)
            // diagnosis: a cycle that starts much later than planned means Android froze the app (Doze / battery optimisation)
            val t0 = System.currentTimeMillis()
            if (lastCycleAt > 0 && lastPlanMs > 0 && t0 - lastCycleAt > lastPlanMs * 2 + 60_000L) {
                val pm = getSystemService(PowerManager::class.java)
                ApiLog.w("App", "Ciclo atrasado: passaram %d min (previsto %d min) · otimização de bateria %s · Doze %s".format(
                    (t0 - lastCycleAt) / 60_000L, lastPlanMs / 60_000L,
                    if (pm.isIgnoringBatteryOptimizations(packageName)) "desativada (ok)" else "ATIVA — o Android suspende a app; desative-a nas Definições",
                    if (pm.isDeviceIdleMode) "ativo" else "inativo"))
            }
            lastCycleAt = t0
            try { step(c, hist, api) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                Live.msg("msg_error", e.message ?: ""); ApiLog.e("App", "Ciclo falhou: ${e.message}")
                if (++failures >= 3) Notifier.alert(this, c, 1014, "n_title_error", "n_body_error")
            }
            updateNotification()
            SolarWidget.refresh(this)
            val m = Live.messageText()
            if (m != lastLogged) { lastLogged = m; ApiLog.i("App", "Decisão: $m") }
            val d = nextDelayMs(c)
            lastPlanMs = d
            holdWake(lastBusy)
            waitNext(d, lastBusy)
        }
    }

    /** 30 s-type interval by day / while controlling; long interval at night when there is nothing to control. */
    private fun nextDelayMs(c: Cfg): Long {
        val base = c.int("intervalSec", 120).coerceAtLeast(30)
        val night = c.int("nightIntervalSec", 300).coerceAtLeast(60)
        if (night <= base) { lastBusy = true; return base * 1000L }
        val cal = Calendar.getInstance()
        val minNow = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val a = ((c.int("winStartMin", 540) - 15) + 1440) % 1440
        val b = (c.int("winEndMin", 1080) + 15) % 1440
        val busy = inRange(minNow, a, b) || charging || owned || gridMode != null || Live.boost ||
            Live.chargingState == "Charging"
        // at night the OS (Doze) can stretch alarms to 15-30 min; keeping the CPU awake gives the real 5-minute rhythm (switch nightAwake, on by default)
        lastBusy = busy || c.get("nightAwake", "1") != "0"
        return (if (busy) base else night) * 1000L
    }

    /** Alerts (at most every 12 h) when a tyre is below the configured pressure or the car reports a low-pressure warning. */
    private fun checkTires(c: Cfg) {
        val vs = Live.teslaJson?.optJSONObject("vehicle_state") ?: return
        val min = c.get("tireMinBar", "2.2").replace(',', '.').toDoubleOrNull() ?: 2.2
        val names = listOf("fl" to "FL", "fr" to "FR", "rl" to "RL", "rr" to "RR")
        val low = names.mapNotNull { (k, n) ->
            val v = vs.optDouble("tpms_pressure_$k", Double.NaN)
            if (!v.isNaN() && v > 0.5 && v < min) n + " " + L.n(v, 1) else null
        }
        if (low.isNotEmpty()) Notifier.alert(this, c, 1017, "n_title_tire", "n_body_tire", low.joinToString(" · "), L.n(min, 1))
    }

    /** Power margin in W: positive reserves power (more conservative), negative accepts some grid import. */
    private fun bufferW(c: Cfg) = (c.get("bufferW").replace(',', '.').toDoubleOrNull() ?: 0.0).coerceIn(-3000.0, 3000.0)

    private fun hhmm(m: Int) = "%02d:%02d".format(m / 60, m % 60)
    private fun inRange(min: Int, a: Int, b: Int) = if (a <= b) min in a until b else (min >= a || min < b)

    private fun step(c: Cfg, hist: History, api: Api) {
        val now = System.currentTimeMillis()
        stateOk = false
        try {
            // after a start command the cached state can lag: ask the car directly until it confirms "Charging"
            val st = api.teslaState(fresh = startTries in 1..5)
            if (st != null) {
                Live.chargingState = st.charging; Live.teslaKw = st.powerKw; Live.battery = st.battery; carReqAmps = st.reqAmps; carActAmps = st.actAmps
                stateOk = true
            }
        } catch (e: Exception) { ApiLog.e("Tessie", "Falha ao ler estado: ${e.message}") }
        if (stateOk) { carLog.addLast(now to Live.teslaKw); while (carLog.size > 24) carLog.removeFirst() }
        if (stateOk) { tessieFails = 0; checkTires(c) }
        else if (++tessieFails >= 3) Notifier.alert(this, c, 1015, "n_title_tessie", "n_body_tessie")
        if (stateOk) { failures = 0; charging = Live.chargingState == "Charging"; if (charging) startTries = 0 else { owned = false; gridMode = null } }

        val pvW = try { api.solarW().also { growattFails = 0 } } catch (e: Exception) {
            if (++growattFails >= 3) Notifier.alert(this, c, 1016, "n_title_growatt", "n_body_growatt")
            throw e
        }
        Live.pvW = pvW
        val dataTime = if (api.dataAt > 0) api.dataAt else api.lastOkAt
        if (dataTime > 0) Live.updated = SimpleDateFormat("HH:mm", Locale.US).format(Date(dataTime))
        val liveLoad = api.liveLoadW
        Live.houseW = liveLoad ?: -1.0
        if (liveLoad != null && api.loadAt != lastLoadAt) {
            lastLoadAt = api.loadAt
            val near = carLog.filter { it.first >= lastLoadAt - 90_000L && it.first <= lastLoadAt + 60_000L }.map { it.second }
            val steady = near.isEmpty() || (near.max() - near.min()) < 0.4        // the car current was changing around the sample: its power at that moment is uncertain
            // the car reports its power with a delay of up to a minute after a start or a current change: until it settles (75 s; a longer freeze starves the filter while dithering), the car share of the load is unknown
            val settling = lastAmpChange > 0 && now - lastAmpChange < 75_000L
            if ((steady && !settling) || houseBaseW < 0 || now - lastBaseAt > 20 * 60_000L) {
                val carAt = if (near.isNotEmpty()) near.average() else Live.teslaKw
                val sample = maxOf(liveLoad - carAt * 1000, 0.0)
                // 30-second samples are noisy (a kettle for a minute): the median of the last three rejects a single spike
                if (baseSamples.isNotEmpty() && now - lastBaseAt > 120_000L) baseSamples.clear()
                baseSamples.addLast(sample); while (baseSamples.size > 3) baseSamples.removeFirst()
                val med = if (baseSamples.size == 3) baseSamples.sorted()[1] else sample
                houseBaseW = if (houseBaseW < 0) med else 0.5 * houseBaseW + 0.5 * med
                lastBaseAt = now
                ApiLog.i("App", "Consumo da casa sem o carro: amostra ${sample.toInt()} W${if (med != sample) " (mediana ${med.toInt()} W)" else ""} (total ${liveLoad.toInt()} W − carro ${(carAt * 1000).toInt()} W) → base ${houseBaseW.toInt()} W")
            } else ApiLog.i("App", "Amostra de consumo ignorada: a corrente do carro estava a mudar; base mantida em ${houseBaseW.toInt()} W")
        }
        val loadKnown = liveLoad != null && houseBaseW >= 0
        val houseOnlyW = if (loadKnown) houseBaseW else 0.0

        val cal = Calendar.getInstance()
        val minNow = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val offA = c.int("offStartMin", 1320); val offB = c.int("offEndMin", 480)
        val inOff = inRange(minNow, offA, offB)
        val priceN = c.get("priceNormal").replace(',', '.').toDoubleOrNull() ?: 0.20
        val priceO = c.get("priceOff").replace(',', '.').toDoubleOrNull() ?: priceN
        val price = if (inOff) priceO else priceN

        if (lastTick > 0) {
            val dtH = ((now - lastTick) / 3_600_000.0).coerceAtMost(0.2)
            val carKw = Live.teslaKw
            val solarShare = minOf(carKw, maxOf(pvW / 1000.0 - houseOnlyW / 1000.0, 0.0))
            val gridKw = maxOf(carKw - solarShare, 0.0)
            hist.add(carKw * dtH, pvW / 1000.0 * dtH, houseOnlyW / 1000.0 * dtH, gridKw * dtH, solarShare * dtH * priceN, gridKw * dtH * price)
            hist.addHour(cal.get(Calendar.HOUR_OF_DAY), carKw * dtH, pvW / 1000.0 * dtH)
            if (liveLoad != null) {
                val loadKw = liveLoad / 1000.0; val pvKw = pvW / 1000.0
                hist.addFlow(loadKw * dtH, minOf(pvKw, loadKw) * dtH, maxOf(loadKw - pvKw, 0.0) * dtH, maxOf(pvKw - loadKw, 0.0) * dtH)
            }
            if (stateOk) sessions?.tick(charging, Live.battery, carKw * dtH, solarShare * dtH, gridKw * dtH, solarShare * dtH * priceN, gridKw * dtH * price,
                gridMode ?: (if (owned) "solar" else "manual"), now)
        }
        lastTick = now

        Forecast.histProvider = { History(this).all() }
        Forecast.refresh(c)

        // exact solar total of the day from the inverter's counter (daytime only, so the midnight reset never leaks into the next day)
        val mNow = Calendar.getInstance().let { it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE) }
        if (c.get("localHost").isNotBlank() && mNow in 480..1410 && now - lastCounterAt > 300_000L) {
            lastCounterAt = now
            try { LocalInverter.solarToday(c)?.let { hist.raiseSolarToday(it) } } catch (_: Exception) {}
        }

        val volts = c.int("volts", 230) * c.int("phases", 1)
        val minA = c.int("minAmps", 5)
        val maxA = c.int("maxAmps", 16)
        val manage = c.get("manageManual", "1") != "0"
        val targetPct = c.int("targetPct", 100).coerceIn(10, 100)

        // 1) not plugged in
        if (stateOk && Live.chargingState == "Disconnected") {
            idle(); gridMode = null; targetNotified = false
            Live.msg("msg_unplugged")
            return
        }
        // 2) target reached
        if (stateOk && targetPct < 100 && Live.battery >= targetPct) {
            if (charging && (owned || manage)) { api.command("stop_charging"); charging = false }
            idle(); gridMode = null; Live.boost = false
            Live.msg("msg_target", targetPct)
            if (!targetNotified) { targetNotified = true; Notifier.alert(this, c, 1012, "n_title_target", "n_body_target", targetPct) }
            return
        }
        if (Live.battery in 0 until (targetPct - 3).coerceAtLeast(0)) targetNotified = false

        // 3) "Charge now"
        if (Live.boost) { gridCharge(c, api, maxA, "msg_boost", "boost", now); return }

        // 4) manual charge left alone
        if (charging && !owned && !manage) { idle(); Live.msg("msg_manual"); return }

        // 5) departure guarantee
        if (c.get("departEnabled") == "1" && stateOk && Live.battery in 0 until targetPct) {
            val dep = c.int("departMin", 480)
            val capKwh = (c.get("capKwh").replace(',', '.').toDoubleOrNull() ?: 60.0).coerceAtLeast(10.0)
            val needKwh = (targetPct - Live.battery) / 100.0 * capKwh
            val kw = maxA * volts / 1000.0 * 0.92
            val needMin = (needKwh / kw * 60).toInt()
            var left = dep - minNow
            if (left < 0) left += 1440
            if (left <= needMin + 15) {
                gridCharge(c, api, maxA, "msg_guarantee", "guarantee", now, targetPct, hhmm(dep))
                return
            }
        }

        // 6) off-peak grid charging
        if (c.get("offpeakCharge") == "1" && inOff && (targetPct < 100 || Live.battery < 100)) {
            // smart plan: if tomorrow's sun is expected to cover the need, wait; otherwise charge only the shortfall tonight
            var offGoal = targetPct
            var waitForSun = false
            var sunKwh = -1.0
            if (c.get("planSmart", "1") != "0" && Forecast.ready && stateOk && Live.battery >= 0) {
                val kwp = Forecast.kwpOf(c)
                val w0 = c.int("winStartMin", 540); val w1 = c.int("winEndMin", 1080)
                val dayOffset = if (minNow >= w1 || minNow >= 12 * 60) 1 else 0
                val carKwMax = maxA * volts / 1000.0
                val kwh = Forecast.solarKwhForCar(kwp, w0, w1, dayOffset, carKwMax, houseOnlyW.coerceIn(200.0, 3000.0) / 1000.0)
                if (kwh != null) {
                    sunKwh = kwh
                    val capKwh = (c.get("capKwh").replace(',', '.').toDoubleOrNull() ?: 60.0).coerceAtLeast(10.0)
                    val solarPct = kwh * 0.8 / capKwh * 100.0          // 20 % safety margin on the forecast
                    offGoal = (targetPct - solarPct).toInt().coerceIn(0, targetPct)
                    waitForSun = Live.battery >= offGoal
                }
            }
            if (waitForSun) {
                if (charging && owned) { api.command("stop_charging"); charging = false }
                idle(); gridMode = null
                Live.msg("msg_plan_wait", L.n(sunKwh, 1))
                return
            }
            gridCharge(c, api, maxA, "msg_offpeak", "offpeak", now)
            return
        }
        if (gridMode != null) {
            // grid mode ended (guarantee window passed / left off-peak): hand back to the solar logic
            if (charging && owned) { api.command("stop_charging"); charging = false }
            gridMode = null; idle()
        }

        // 7a) "Minimum + solar" mode: inside the solar window it always charges, at least at minA (the difference comes from the grid)
        if (c.get("mode", "solar") == "minpv" && inRange(minNow, c.int("winStartMin", 540), c.int("winEndMin", 1080))) {
            val fresh = api.solarKnown && now - dataTime <= 20 * 60_000L
            val baseW = if (loadKnown) houseOnlyW.coerceIn(100.0, 15000.0).toInt() else FALLBACK_BASE_W
            val tgtMp = if (fresh) floor((pvW - baseW - bufferW(c)) / volts).toInt().coerceIn(minA, maxA) else minA
            aboveSince = 0; belowSince = 0
            var justStarted = false
            if (!charging) {
                api.command("set_charging_amps?amps=$tgtMp"); lastAmps = tgtMp; lastAmpChange = now
                api.command("start_charging"); charging = true; owned = true; startTries++; justStarted = true
                Notifier.alert(this, c, 1010, "n_title_start", "n_body_solar", tgtMp)
            } else if (tgtMp != lastAmps && (tgtMp < lastAmps || now - lastAmpChange > 60_000L)) {
                api.command("set_charging_amps?amps=$tgtMp"); lastAmps = tgtMp; lastAmpChange = now
            }
            Live.amps = lastAmps
            if (justStarted) startMsg() else Live.msg("msg_minpv", Live.amps)
            return
        }

        // 7) solar logic
        if (!api.solarKnown) { Live.msg("msg_collecting"); return }

        val a = c.int("winStartMin", 540); val b = c.int("winEndMin", 1080)
        if (!inRange(minNow, a, b)) {
            if ((owned || manage) && charging) {
                // with "manage manual charges" on, the window is authoritative: a charge started by hand outside it is stopped too
                if (!owned) ApiLog.i("App", "Carregamento iniciado fora da app e fora do horário: a parar")
                api.command("stop_charging"); charging = false
                Notifier.alert(this, c, 1011, "n_title_stop", "n_body_stop_window")
            }
            idle()
            Live.msg("msg_outside", hhmm(a), hhmm(b))
            return
        }
        if (now - dataTime > 20 * 60_000L) {
            if (charging) {
                api.command("stop_charging"); charging = false
                Notifier.alert(this, c, 1011, "n_title_stop", "n_body_stale")
            }
            idle(); Live.msg("msg_stale")
            return
        }

        val realBase = if (loadKnown) houseOnlyW.coerceIn(100.0, 15000.0).toInt() else null
        val base = realBase ?: FALLBACK_BASE_W
        val buffer = bufferW(c)
        val surplus = pvW - base - buffer
        // the car can end up on another current than the one this app believes it set (a command that did not stick, a change from the car or the Tesla app): re-align
        val seenA = if (carActAmps > 0) carActAmps else carReqAmps
        if (charging && lastAmps > 0 && seenA > 0 && seenA != lastAmps && now - lastAmpChange > 60_000L && now - lastResync > 180_000L) {
            ApiLog.w("App", "O carro está a $seenA A mas a app julgava $lastAmps A; a realinhar")
            lastAmps = seenA; lastResync = now
        }
        val exactA = surplus / volts
        var tgt = floor(exactA).toInt().coerceAtMost(maxA)
        // export optimiser: a fraction of an amp would be exported; accumulate it and add 1 A now and then, so on average nothing is exported
        if (c.get("optExport", "1") != "0" && charging && tgt >= minA && tgt < maxA) {
            ditherAcc += (exactA - tgt).coerceIn(0.0, 1.0)
            if (ditherAcc >= 1.0) { tgt += 1; ditherAcc -= 1.0 }
            ditherAcc = ditherAcc.coerceIn(0.0, 1.5)
        } else ditherAcc = 0.0
        // while charging, a small shortfall at the minimum current (up to half an amp, ~115 W of grid) does not stop the charge: stopping and restarting costs more than it saves
        if (c.get("optExport", "1") != "0" && charging && tgt < minA && exactA >= minA - 0.5) tgt = minA
        // hysteresis: do not drop 1 A for a surplus that is only a hair under the current step (avoids 7→6→7 flapping around an integer)
        if (c.get("optExport", "1") != "0" && charging && lastAmps > minA && tgt == lastAmps - 1 && exactA >= lastAmps - 0.15) tgt = lastAmps

        val useFc = c.get("useForecast", "1") != "0" && Forecast.ready
        val worsening = useFc && Live.fcTrend == "down"
        val improving = useFc && Live.fcTrend == "up"
        // the configured delays are exact; the forecast only doubles them when "fcStretch" is switched on
        val stretch = c.get("fcStretch") == "1"
        val startDelay = c.int("startDelaySec", 90) * 1000L * (if (stretch && worsening) 2 else 1)
        val stopDelay = c.int("stopDelaySec", 300) * 1000L * (if (stretch && improving) 2 else 1)
        val startNeed = if (worsening) minA + 1 else minA
        // the confirmation timer of a start is not reset by a dip of up to half an amp (the house load is noisy); it only decides whether the wait goes on
        if (c.get("optExport", "1") != "0" && !charging && aboveSince != 0L && tgt < startNeed && exactA >= startNeed - 0.5) tgt = startNeed
        ApiLog.i("App", "Solar %d W − base %d W (%s)%s = excedente %d W → alvo %d A (mín. %d A)%s"
            .format(pvW.toInt(), base, if (realBase != null) "real" else "estimado", if (buffer != 0.0) " − margem ${buffer.toInt()} W" else "", surplus.toInt(), tgt, minA,
                if (worsening) " · tempo a piorar" else if (improving) " · tempo a melhorar" else ""))

        if (tgt >= (if (charging) minA else startNeed)) {
            belowSince = 0
            var justStarted = false
            if (aboveSince == 0L) aboveSince = now
            if (!charging) {
                val wait = startDelay - (now - aboveSince)
                if (wait > 0) { Live.amps = 0; Live.msg("msg_confirm", (wait / 1000).toInt()); return }
                api.command("set_charging_amps?amps=$tgt"); lastAmps = tgt; lastAmpChange = now
                api.command("start_charging"); charging = true; owned = true; startTries++; justStarted = true
                Notifier.alert(this, c, 1010, "n_title_start", "n_body_solar", tgt)
            } else if (tgt != lastAmps) {
                // going down is immediate; going up waits one cycle (30 s with the optimiser, 60 s without) so the car follows the sun faster
                // Tessie ignores (but still answers "true" in ~0.3 s) a current command that follows another within ~30 s: keep at least 45 s between changes
                val gapOk = c.get("optExport", "1") == "0" || now - lastAmpChange > 45_000L
                if (gapOk && (tgt < lastAmps || now - lastAmpChange > (if (c.get("optExport", "1") != "0") 25_000L else 60_000L))) {
                    api.command("set_charging_amps?amps=$tgt"); lastAmps = tgt; lastAmpChange = now
                }
            }
            Live.amps = lastAmps
            if (justStarted) startMsg() else Live.msg("msg_charging", Live.amps)
        } else {
            aboveSince = 0
            if (!charging) {
                idle()
                if (worsening && tgt >= minA) Live.msg("msg_weather") else Live.msg("msg_low", surplus.toInt().coerceAtLeast(0))
                return
            }
            if (belowSince == 0L) belowSince = now
            val wait = stopDelay - (now - belowSince)
            if (wait > 0) {
                if (lastAmps != minA) { api.command("set_charging_amps?amps=$minA"); lastAmps = minA; lastAmpChange = now }
                Live.amps = lastAmps
                Live.msg("msg_waiting", (wait / 1000).toInt())
            } else {
                api.command("stop_charging"); charging = false
                Notifier.alert(this, c, 1011, "n_title_stop", "n_body_stop_low")
                idle(); Live.msg("msg_nosurplus")
            }
        }
    }

    /** Charge deliberately from the grid at maxA (boost, departure guarantee, off-peak). */
    private fun gridCharge(c: Cfg, api: Api, maxA: Int, msgKey: String, mode: String, now: Long, vararg extra: Any) {
        aboveSince = 0; belowSince = 0
        if (lastAmps != maxA) { api.command("set_charging_amps?amps=$maxA"); lastAmps = maxA; lastAmpChange = now }
        var justStarted = false
        if (!charging) { api.command("start_charging"); charging = true; owned = true; startTries++; justStarted = true }
        Live.amps = lastAmps
        if (gridMode != mode) {
            gridMode = mode
            Notifier.alert(this, c, 1010, "n_title_start", "n_body_grid", maxA)
            if (mode == "guarantee") Notifier.alert(this, c, 1013, "n_title_guarantee", "n_body_guarantee", *extra)
        }
        val args = if (mode == "guarantee") arrayOf<Any>(extra[0], extra[1], maxA) else arrayOf<Any>(maxA)
        if (justStarted) startMsg() else Live.msg(msgKey, *args)
    }

    /** After a start command the car may still report "Stopped" (waking up, cable, schedule): say so instead of claiming it is charging. */
    private fun startMsg() {
        if (startTries >= 3) { Live.msg("msg_nostart", Live.amps, startTries); ApiLog.w("App", "O carro não confirmou o arranque após $startTries comandos") }
        else Live.msg("msg_starting", Live.amps)
    }

    private var ditherAcc = 0.0
    /** Current the car says it was asked for (charge_current_request); -1 when unknown. */
    private var carReqAmps = -1
    private var carActAmps = -1
    private var lastResync = 0L

    private fun idle() { startTries = 0; lastAmps = -1; Live.amps = 0; aboveSince = 0; belowSince = 0; owned = if (charging) owned else false }
}
