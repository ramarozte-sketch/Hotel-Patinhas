package com.rui.solarcharge

import org.json.JSONObject
import java.text.Normalizer

/** Offline assistant: understands simple questions and commands (pt / en / fr) with no Claude key and no internet. Actions still need confirmation. */
object LocalBot {
    class Reply(val text: String, val calls: List<PendingCall> = emptyList())

    private fun norm(s: String) = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    private fun t(pt: String, en: String, fr: String) = when (L.lang) { "en" -> en; "fr" -> fr; else -> pt }
    private fun has(s: String, vararg k: String) = k.any { s.contains(it) }
    private fun f(v: Double, d: Int = 2) = L.n(v, d)
    private fun call(name: String, vararg kv: Pair<String, Any>) =
        PendingCall("local-" + System.nanoTime(), name, JSONObject().apply { kv.forEach { put(it.first, it.second) } })

    private val helpPt = "Modo local (sem chave Claude). Pergunte por: produção solar, bateria, consumo da casa, hoje / semana / mês, poupança, previsão, estado. " +
        "Comandos: iniciar / parar carregamento, \"define 10 amperes\", \"limite 80\", \"objetivo 90\", \"carregar já\", \"liga/desliga controlo automático\", \"liga/desliga sentinela\"."
    private val helpEn = "Local mode (no Claude key). Ask about: solar production, battery, house consumption, today / week / month, savings, forecast, status. " +
        "Commands: start / stop charging, \"set 10 amps\", \"limit 80\", \"target 90\", \"charge now\", \"turn on/off automatic control\", \"turn on/off sentry\"."
    private val helpFr = "Mode local (sans clé Claude). Demandez : production solaire, batterie, consommation, aujourd'hui / semaine / mois, économies, prévision, état. " +
        "Commandes : démarrer / arrêter la charge, \"régler 10 ampères\", \"limite 80\", \"objectif 90\", \"charger maintenant\", \"activer/désactiver le contrôle automatique\", \"activer/désactiver sentinelle\"."

    fun help() = t(helpPt, helpEn, helpFr)

    private fun sum(hist: History, days: Int): DoubleArray {
        val s = DoubleArray(6)
        hist.all().toSortedMap().entries.toList().takeLast(days).forEach { e -> for (i in 0..5) s[i] += e.value[i] }
        return s
    }

    private fun period(label: String, a: DoubleArray) = t(
        "$label: carro ${f(a[0], 1)} kWh, produção ${f(a[1], 1)} kWh, casa ${f(a[2], 1)} kWh, poupado ${f(a[4])} €.",
        "$label: car ${f(a[0], 1)} kWh, production ${f(a[1], 1)} kWh, home ${f(a[2], 1)} kWh, saved ${f(a[4])} €.",
        "$label : voiture ${f(a[0], 1)} kWh, production ${f(a[1], 1)} kWh, maison ${f(a[2], 1)} kWh, économisé ${f(a[4])} €.")

    fun answer(c: Cfg, hist: History, text: String): Reply {
        val s = " " + norm(text) + " "
        val n = Regex("(\\d{1,3})").find(s)?.value?.toIntOrNull()
        val offV = has(s, "desliga", "desativa", "desactiva", "turn off", "disable", "switch off", "desactiv", "eteins", "eteindre", "arrete")
        val onV = !offV

        if (has(s, " ajuda", "help", " aide", "o que sabes", "what can", "que sais")) return Reply(help())

        // ---- actions ----
        if (has(s, "sentinela", "sentry", "sentinelle")) return Reply(t("Vou ${if (onV) "ligar" else "desligar"} o modo sentinela.", "I'll turn sentry mode ${if (onV) "on" else "off"}.", "Je vais ${if (onV) "activer" else "désactiver"} la sentinelle."), listOf(call("set_sentry", "on" to onV)))
        if (has(s, "carregar ja", "carrega ja", "carrega agora", "boost", "forcar", "charge now", "charger maintenant"))
            return Reply(t("Vou ${if (onV) "ligar" else "desligar"} o carregar já.", "I'll turn charge-now ${if (onV) "on" else "off"}.", "Je vais ${if (onV) "activer" else "désactiver"} la charge immédiate."), listOf(call("set_boost", "on" to onV)))
        if (has(s, "automatic") && has(s, "controlo", "control", "controle", "liga", "desliga", "turn", "active", "desactiv"))
            return Reply(t("Vou ${if (onV) "ligar" else "desligar"} o controlo automático.", "I'll turn automatic control ${if (onV) "on" else "off"}.", "Je vais ${if (onV) "activer" else "désactiver"} le contrôle automatique."), listOf(call("set_auto_control", "on" to onV)))
        if (n != null && has(s, "amper", "amps", " a ", " a.")) {
            val a = n.coerceIn(5, 32)
            return Reply(t("Vou definir ${a} A.", "I'll set $a A.", "Je vais régler $a A."), listOf(call("set_charging_amps", "amps" to a)))
        }
        if (n != null && has(s, "limite", "limit")) {
            val p = n.coerceIn(50, 100)
            return Reply(t("Vou definir o limite de carga para $p %.", "I'll set the charge limit to $p %.", "Je vais régler la limite de charge à $p %."), listOf(call("set_charge_limit", "percent" to p)))
        }
        if (n != null && has(s, "objetivo", "alvo", "target", "objectif", "cible")) {
            val p = n.coerceIn(10, 100)
            return Reply(t("Vou definir o objetivo da app para $p %.", "I'll set the app target to $p %.", "Je vais régler l'objectif de l'app à $p %."), listOf(call("set_target_pct", "percent" to p)))
        }
        val charge = has(s, "carreg", "charg")
        if ((charge && has(s, "parar", "para ", "pare", "stop", "interromp", "arret", "cessa")) || s.trim() in setOf("para", "parar", "stop"))
            return Reply(t("Vou parar o carregamento.", "I'll stop charging.", "Je vais arrêter la charge."), listOf(call("stop_charging")))
        if (charge && has(s, "inici", "comec", "start", "liga ", "ativa", "demarr", "commenc", "lance") || has(s, "carrega o carro", "carrega o tesla"))
            return Reply(t("Vou iniciar o carregamento.", "I'll start charging.", "Je vais démarrer la charge."), listOf(call("start_charging")))

        // ---- questions ----
        val out = ArrayList<String>()
        val all = has(s, "estado", "como esta", "resumo", "status", "etat", "resume", "summary")
        if (all || has(s, "solar", " sol ", "producao", "paineis", "panels", "production", "panneaux", "pv", "produz")) {
            out.add(t("Produção solar: ${f(Live.pvW / 1000.0)} kW" + (if (Live.updated.isNotEmpty()) " (às ${Live.updated})." else "."),
                "Solar production: ${f(Live.pvW / 1000.0)} kW" + (if (Live.updated.isNotEmpty()) " (at ${Live.updated})." else "."),
                "Production solaire : ${f(Live.pvW / 1000.0)} kW" + (if (Live.updated.isNotEmpty()) " (à ${Live.updated})." else ".")))
        }
        if (all || has(s, "bateria", "battery", "batterie", "autonomia", "nivel", "tesla", "carro", " car ", "voiture")) {
            val b = if (Live.battery >= 0) "${Live.battery} %" else "—"
            out.add(t("Tesla: bateria $b, estado ${Live.chargingState}, ${f(Live.teslaKw, 1)} kW (${Live.amps} A).",
                "Tesla: battery $b, state ${Live.chargingState}, ${f(Live.teslaKw, 1)} kW (${Live.amps} A).",
                "Tesla : batterie $b, état ${Live.chargingState}, ${f(Live.teslaKw, 1)} kW (${Live.amps} A)."))
        }
        if (all || has(s, "consumo", "casa", "house", "maison", "consumption", "consomm")) {
            out.add(if (Live.houseW >= 0) t("Consumo total da casa (com o carro): ${f(Live.houseW / 1000.0)} kW.", "Total house consumption (with the car): ${f(Live.houseW / 1000.0)} kW.", "Consommation totale (avec la voiture) : ${f(Live.houseW / 1000.0)} kW.")
                else t("O consumo da casa não está disponível com esta leitura.", "House consumption is not available with this reading.", "La consommation n'est pas disponible avec cette lecture."))
        }
        val td = hist.today()
        if (has(s, "hoje", "today", "aujourd", "poup", "sav", "econom", "custo", "cost", "cout") || all) {
            out.add(t("Hoje: carro ${f(td[0])} kWh, produção ${f(td[1])} kWh, casa ${f(td[2])} kWh, poupado ${f(td[4])} €, custo da rede ${f(td[5])} €.",
                "Today: car ${f(td[0])} kWh, production ${f(td[1])} kWh, home ${f(td[2])} kWh, saved ${f(td[4])} €, grid cost ${f(td[5])} €.",
                "Aujourd'hui : voiture ${f(td[0])} kWh, production ${f(td[1])} kWh, maison ${f(td[2])} kWh, économisé ${f(td[4])} €, coût réseau ${f(td[5])} €."))
        }
        if (has(s, "semana", "week", "semaine")) out.add(period(t("Últimos 7 dias", "Last 7 days", "7 derniers jours"), sum(hist, 7)))
        if (has(s, " mes ", "month", " mois ")) out.add(period(t("Últimos 30 dias", "Last 30 days", "30 derniers jours"), sum(hist, 30)))
        if (has(s, "previsao", "tempo", "nuvens", "clouds", "meteo", "forecast", "amanha", "prevision") || all) {
            val o = when (Live.fcOutlook) { "good" -> t("bom", "good", "bonne"); "mixed" -> t("misto", "mixed", "mitigée"); "poor" -> t("fraco", "poor", "faible"); "night" -> t("noite", "night", "nuit"); else -> "" }
            if (o.isNotEmpty()) out.add(t("Previsão solar: $o" + (if (Live.fcCloud >= 0) ", nuvens ${Live.fcCloud} %." else "."),
                "Solar outlook: $o" + (if (Live.fcCloud >= 0) ", clouds ${Live.fcCloud} %." else "."),
                "Prévision solaire : $o" + (if (Live.fcCloud >= 0) ", nuages ${Live.fcCloud} %." else ".")))
        }
        if (all) out.add(Live.messageText())
        if (out.isEmpty()) return Reply(t("Não percebi. ", "I didn't get that. ", "Je n'ai pas compris. ") + help())
        return Reply(out.joinToString("\n"))
    }
}
