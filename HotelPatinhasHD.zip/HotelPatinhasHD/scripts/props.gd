# Hotel Patinhas HD · mobília e objetos (desenhados em lote: cada função acrescenta peças a um Batch)
class_name Props
extends RefCounted

const WOOD := "#8a5a36"
const WOOD_L := "#c79a6b"
const METAL := "#4a4f57"
const CHROME := "#c9cfd6"

static func wood(c := WOOD) -> Material:
	return Mats.textured(c, "planks", 1.2, 0.55, 0.5)

static func xf(origin: Vector3, yaw: float) -> Transform3D:
	return Transform3D(Basis(Vector3.UP, yaw), origin)

# caixa num referencial local (origem + rotação)
static func lbox(B: Batch, T: Transform3D, size: Vector3, pos: Vector3, mat: Material) -> void:
	B.box_xf(size, T * Transform3D(Basis(), pos), mat)

static func lcyl(B: Batch, T: Transform3D, rt: float, rb: float, h: float, pos: Vector3, mat: Material, seg := 16) -> void:
	B.cyl_xf(rt, rb, h, mat, T * Transform3D(Basis(), pos), seg)

static func lball(B: Batch, T: Transform3D, r: float, pos: Vector3, mat: Material, sy := 1.0) -> void:
	B.add(Batch.sphere_mesh(r, r * 2.0 * sy, 12), T * Transform3D(Basis(), pos), mat)

# ---------- quartos ----------
static func pet_bed(B: Batch, pos: Vector3, yaw: float, col: String, big := false) -> void:
	var T := xf(pos, yaw)
	var s := 1.5 if big else 1.0
	lbox(B, T, Vector3(1.5, 0.22, 1.1) * Vector3(s, 1, s), Vector3(0, 0.11, 0), wood())
	lbox(B, T, Vector3(1.38, 0.16, 0.98) * Vector3(s, 1, s), Vector3(0, 0.3, 0), Mats.cloth(col))
	lbox(B, T, Vector3(1.5 * s, 0.4, 0.12), Vector3(0, 0.3, -0.5 * s), wood())
	B.ell(0.32 * s, 0.09, 0.2 * s, Mats.cloth("#f4f1ea"), T * Vector3(-0.35 * s, 0.42, -0.25 * s))

static func bowl(B: Batch, pos: Vector3, col: String) -> void:
	B.cyl(0.24, 0.2, 0.1, Mats.glossy(col, 0.3), pos + Vector3(0, 0.05, 0), 20)
	B.cyl(0.2, 0.2, 0.02, Mats.base("#2a2d33", 0.6), pos + Vector3(0, 0.095, 0), 20)

static func tub(B: Batch, pos: Vector3, yaw: float) -> void:
	var T := xf(pos, yaw)
	var white := Mats.glossy("#f7f7f4", 0.15, 0.0, true)
	lbox(B, T, Vector3(1.5, 0.5, 0.95), Vector3(0, 0.25, 0), white)
	for sx in [-0.62, 0.62]:
		for sz in [-0.36, 0.36]:
			lball(B, T, 0.07, Vector3(sx, 0.04, sz), Mats.glossy("#d4a017", 0.3, 0.8))
	lcyl(B, T, 0.035, 0.035, 0.5, Vector3(0.68, 0.7, 0), Mats.glossy(CHROME, 0.15, 0.9))
	lbox(B, T, Vector3(0.18, 0.04, 0.05), Vector3(0.62, 0.93, 0), Mats.glossy(CHROME, 0.15, 0.9))

static func rug(B: Batch, pos: Vector3, yaw: float, col: String, w := 1.8, d := 1.3) -> void:
	B.box(w, 0.02, d, Mats.cloth(col), pos + Vector3(0, 0.055, 0), yaw)
	B.box(w * 0.82, 0.021, d * 0.76, Mats.cloth(Color(col).lightened(0.25).to_html()), pos + Vector3(0, 0.058, 0), yaw)

static func plant(B: Batch, pos: Vector3, s := 1.0) -> void:
	B.cyl(0.24 * s, 0.18 * s, 0.42 * s, Mats.rough_surface("#c26a3c", 0.5, 0.8), pos + Vector3(0, 0.21 * s, 0))
	var leaf := Mats.rough_surface("#3f8f4a", 0.4, 0.75, 0.8, 9)
	B.ell(0.32 * s, 0.42 * s, 0.32 * s, leaf, pos + Vector3(0, 0.72 * s, 0))
	B.ell(0.22 * s, 0.3 * s, 0.22 * s, Mats.rough_surface("#4f9e52", 0.4, 0.75, 0.8, 9), pos + Vector3(0.12 * s, 0.98 * s, -0.05 * s))

static func lamp_post(B: Batch, pos: Vector3) -> void:
	var m := Mats.glossy("#2e3238", 0.45, 0.6)
	B.cyl(0.05, 0.08, 2.6, m, pos + Vector3(0, 1.3, 0), 10)
	B.cyl(0.13, 0.13, 0.12, m, pos + Vector3(0, 0.06, 0), 10)
	B.cyl(0.22, 0.1, 0.16, m, pos + Vector3(0, 2.72, 0), 12)

static func bench(B: Batch, pos: Vector3, yaw: float) -> void:
	var T := xf(pos, yaw)
	var w := wood("#a8743f")
	for k in 3:
		lbox(B, T, Vector3(1.5, 0.05, 0.12), Vector3(0, 0.45, -0.15 + k * 0.15), w)
	for k in 2:
		lbox(B, T, Vector3(1.5, 0.12, 0.04), Vector3(0, 0.62 + k * 0.17, -0.25), w)
	var m := Mats.glossy("#33373d", 0.5, 0.6)
	for sx in [-0.65, 0.65]:
		lbox(B, T, Vector3(0.05, 0.45, 0.45), Vector3(sx, 0.225, 0), m)
		lbox(B, T, Vector3(0.05, 0.5, 0.05), Vector3(sx, 0.65, -0.27), m)

static func chair(B: Batch, pos: Vector3, yaw: float, col: String) -> void:
	var T := xf(pos, yaw)
	lbox(B, T, Vector3(0.55, 0.12, 0.55), Vector3(0, 0.46, 0), Mats.cloth(col))
	lbox(B, T, Vector3(0.55, 0.55, 0.1), Vector3(0, 0.8, -0.24), Mats.cloth(col))
	var m := Mats.glossy(CHROME, 0.2, 0.9)
	for sx in [-0.24, 0.24]:
		for sz in [-0.22, 0.22]:
			lcyl(B, T, 0.02, 0.02, 0.42, Vector3(sx, 0.21, sz), m, 8)

static func sofa(B: Batch, pos: Vector3, yaw: float, col: String) -> void:
	var T := xf(pos, yaw)
	var c := Mats.cloth(col)
	var d := Mats.cloth(Color(col).darkened(0.15).to_html())
	lbox(B, T, Vector3(2.2, 0.4, 0.9), Vector3(0, 0.25, 0), d)
	for k in 3:
		lbox(B, T, Vector3(0.68, 0.16, 0.75), Vector3(-0.7 + k * 0.7, 0.53, 0.05), c)
	lbox(B, T, Vector3(2.2, 0.6, 0.22), Vector3(0, 0.75, -0.36), d)
	for sx in [-1.12, 1.12]:
		lbox(B, T, Vector3(0.2, 0.62, 0.9), Vector3(sx, 0.42, 0), d)

static func tv(B: Batch, pos: Vector3, yaw: float) -> void:
	var T := xf(pos, yaw)
	lbox(B, T, Vector3(1.6, 0.5, 0.45), Vector3(0, 0.25, 0), wood("#5a4030"))
	lbox(B, T, Vector3(1.3, 0.78, 0.05), Vector3(0, 0.98, 0), Mats.glossy("#15171c", 0.1))
	lbox(B, T, Vector3(1.22, 0.7, 0.01), Vector3(0, 0.98, 0.03), Mats.emissive("#3a6fa8", 0.6))

static func table_round(B: Batch, pos: Vector3, r := 0.5) -> void:
	B.cyl(r, r, 0.05, wood(WOOD_L), pos + Vector3(0, 0.72, 0), 24)
	B.cyl(0.05, 0.05, 0.7, Mats.glossy(METAL, 0.4, 0.7), pos + Vector3(0, 0.35, 0), 10)
	B.cyl(0.28, 0.3, 0.04, Mats.glossy(METAL, 0.4, 0.7), pos + Vector3(0, 0.02, 0), 16)

static func toy_ball(B: Batch, pos: Vector3, col: String, r := 0.13) -> void:
	B.ball(r, Mats.glossy(col, 0.35), pos + Vector3(0, r, 0))

static func painting(B: Batch, pos: Vector3, yaw: float, col: String) -> void:
	var T := xf(pos, yaw)
	lbox(B, T, Vector3(0.7, 0.5, 0.04), Vector3.ZERO, Mats.glossy("#d4a017", 0.4, 0.6))
	lbox(B, T, Vector3(0.6, 0.4, 0.045), Vector3.ZERO, Mats.base(col, 0.9))

static func tree(B: Batch, pos: Vector3, s := 1.0, k := 0) -> void:
	var bark := Mats.rough_surface("#6e4a2e", 0.6, 0.95, 1.0, 41)
	B.cyl(0.13 * s, 0.24 * s, 2.4 * s, bark, pos + Vector3(0, 1.2 * s, 0), 10)
	# ramos
	for j in 3:
		var a := j * 2.1 + k
		var d := Vector3(cos(a), 0, sin(a))
		B.cyl_xf(0.05 * s, 0.08 * s, 1.1 * s, bark, Transform3D(Basis(d.cross(Vector3.UP).normalized(), -0.7), pos + Vector3(0, 2.1 * s, 0) + d * 0.3 * s), 6)
	var greens := ["#4f8a3a", "#5c9a44", "#6aa64c", "#467f35"]
	var parts := [[0.0, 2.9, 0.0, 1.3], [0.7, 2.55, 0.4, 1.0], [-0.65, 2.6, -0.35, 1.05], [0.1, 3.6, -0.1, 0.95], [-0.3, 2.35, 0.7, 0.85], [0.5, 3.2, -0.6, 0.8]]
	var rng := RandomNumberGenerator.new()
	rng.seed = k * 97 + 3
	for j in parts.size():
		var p: Array = parts[j]
		var c := pos + Vector3(p[0] * s, p[1] * s, p[2] * s)
		var r: float = p[3] * s
		# miolo escuro (dá volume) e cachos de folhas por fora
		B.ell(r * 0.72, r * 0.62, r * 0.72, Mats.rough_surface("#2f5a26", 0.5, 0.9, 1.0, 51), c, 0.0, 8)
		var lm := Mats.leaves(greens[(j + k) % 4])
		for q in (7 if Mats.quality == "ultra" else 4):
			var b := Basis(Vector3.UP, rng.randf() * TAU) * Basis(Vector3.RIGHT, rng.randf_range(-0.9, 0.9))
			B.add(_quad(r * 2.3), Transform3D(b, c + Vector3(rng.randf_range(-0.2, 0.2), rng.randf_range(-0.1, 0.2), rng.randf_range(-0.2, 0.2)) * r), lm)

static var _quads := {}
static func _quad(size: float) -> QuadMesh:
	var key := snappedf(size, 0.05)
	if not _quads.has(key):
		var q := QuadMesh.new()
		q.size = Vector2(key, key)
		_quads[key] = q
	return _quads[key]

static func pine(B: Batch, pos: Vector3, s := 1.0) -> void:
	B.cyl(0.12 * s, 0.18 * s, 1.2 * s, Mats.rough_surface("#5e3f28", 0.6, 0.95, 1.0, 41), pos + Vector3(0, 0.6 * s, 0), 8)
	var g := Mats.rough_surface("#2f6b3a", 0.5, 0.85, 1.2, 52)
	for k in 3:
		B.cyl(0.0, (1.3 - k * 0.3) * s, 1.4 * s, g, pos + Vector3(0, (1.6 + k * 0.75) * s, 0), 10)

static func flower_bed(B: Batch, a: Vector3, b: Vector3, n: int) -> void:
	var cols := ["#e0508a", "#f2c230", "#ffffff", "#8a5cd6", "#ff7a35"]
	for k in n:
		var p := a.lerp(b, (k + 0.5) / n)
		B.ball(0.09, Mats.base(cols[k % 5], 0.7), p + Vector3(0, 0.22, 0), 1.0, 8)
		B.ell(0.16, 0.12, 0.16, Mats.rough_surface("#4b8e42", 0.4, 0.85, 0.8, 9), p + Vector3(0, 0.1, 0), 0.0, 8)

static func pumpkin(B: Batch, pos: Vector3, s := 1.0) -> void:
	B.ell(0.32 * s, 0.24 * s, 0.32 * s, Mats.glossy("#e8761f", 0.5), pos + Vector3(0, 0.24 * s, 0))
	B.cyl(0.03 * s, 0.04 * s, 0.14 * s, Mats.base("#4f7a2a"), pos + Vector3(0, 0.52 * s, 0), 6)

static func xmas_tree(B: Batch, pos: Vector3, s := 1.0) -> void:
	var g := Mats.rough_surface("#2c6e3a", 0.4, 0.9, 1.2, 52)
	B.cyl(0.1 * s, 0.12 * s, 0.5 * s, Mats.base("#5e3f28"), pos + Vector3(0, 0.25 * s, 0), 8)
	for k in 4:
		B.cyl(0.0, (1.0 - k * 0.2) * s, 0.9 * s, g, pos + Vector3(0, (0.8 + k * 0.5) * s, 0), 12)
	var cols := ["#e8443a", "#f2c230", "#3a95d8", "#ffffff"]
	for k in 16:
		var a := k * 2.4
		var h := 0.6 + (k % 8) * 0.25
		var r := (1.0 - (h - 0.6) / 2.4) * 0.85
		B.ball(0.06 * s, Mats.emissive(cols[k % 4], 1.5), pos + Vector3(cos(a) * r * s, h * s, sin(a) * r * s), 1.0, 8)
	B.ball(0.14 * s, Mats.emissive("#ffd23a", 3.0), pos + Vector3(0, 2.75 * s, 0), 1.0, 8)

static func umbrella(B: Batch, pos: Vector3, col: String) -> void:
	B.cyl(0.03, 0.03, 2.2, Mats.base("#f4f1ea"), pos + Vector3(0, 1.1, 0), 8)
	B.cyl(0.0, 1.2, 0.4, Mats.cloth(col), pos + Vector3(0, 2.2, 0), 16)
	B.box(0.6, 0.1, 1.6, Mats.cloth("#ffffff"), pos + Vector3(0.9, 0.3, 0.4), 0.3)
