# Hotel Patinhas HD · junta muitas peças paradas num só desenho por material (muito mais leve para o telemóvel)
class_name Batch
extends RefCounted

static var prim := {}
var surf := {} # material -> SurfaceTool
var count := 0

static func box_mesh(s: Vector3) -> BoxMesh:
	var k := "b%.3f_%.3f_%.3f" % [s.x, s.y, s.z]
	if not prim.has(k):
		var m := BoxMesh.new()
		m.size = s
		prim[k] = m
	return prim[k]

static func cyl_mesh(rt: float, rb: float, h: float, seg := 16) -> CylinderMesh:
	var k := "c%.3f_%.3f_%.3f_%d" % [rt, rb, h, seg]
	if not prim.has(k):
		var m := CylinderMesh.new()
		m.top_radius = rt
		m.bottom_radius = rb
		m.height = h
		m.radial_segments = seg
		m.rings = 1
		prim[k] = m
	return prim[k]

static func sphere_mesh(r: float, h: float, seg := 16) -> SphereMesh:
	var k := "s%.3f_%.3f_%d" % [r, h, seg]
	if not prim.has(k):
		var m := SphereMesh.new()
		m.radius = r
		m.height = h
		m.radial_segments = seg
		m.rings = max(4, seg / 2)
		prim[k] = m
	return prim[k]

static func torus_mesh(ri: float, ro: float) -> TorusMesh:
	var k := "t%.3f_%.3f" % [ri, ro]
	if not prim.has(k):
		var m := TorusMesh.new()
		m.inner_radius = ri
		m.outer_radius = ro
		m.rings = 20
		m.ring_segments = 10
		prim[k] = m
	return prim[k]

static func capsule_mesh(r: float, h: float) -> CapsuleMesh:
	var k := "k%.3f_%.3f" % [r, h]
	if not prim.has(k):
		var m := CapsuleMesh.new()
		m.radius = r
		m.height = max(h, r * 2.0)
		m.radial_segments = 14
		m.rings = 6
		prim[k] = m
	return prim[k]

func add(mesh: Mesh, xf: Transform3D, mat: Material) -> void:
	var st: SurfaceTool = surf.get(mat)
	if st == null:
		st = SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		surf[mat] = st
	for s in mesh.get_surface_count():
		st.append_from(mesh, s, xf)
	count += 1

func box(w: float, h: float, d: float, mat: Material, pos: Vector3, ry := 0.0) -> void:
	add(box_mesh(Vector3(w, h, d)), Transform3D(Basis(Vector3.UP, ry), pos), mat)

func box_xf(size: Vector3, xf: Transform3D, mat: Material) -> void:
	add(box_mesh(size), xf, mat)

func cyl(rt: float, rb: float, h: float, mat: Material, pos: Vector3, seg := 16) -> void:
	add(cyl_mesh(rt, rb, h, seg), Transform3D(Basis(), pos), mat)

func cyl_xf(rt: float, rb: float, h: float, mat: Material, xf: Transform3D, seg := 16) -> void:
	add(cyl_mesh(rt, rb, h, seg), xf, mat)

func ball(r: float, mat: Material, pos: Vector3, sy := 1.0, seg := 14) -> void:
	add(sphere_mesh(r, r * 2.0 * sy, seg), Transform3D(Basis(), pos), mat)

func ell(rx: float, ry: float, rz: float, mat: Material, pos: Vector3, ryaw := 0.0, seg := 14) -> void:
	var r: float = max(rx, rz)
	var b := Basis(Vector3.UP, ryaw).scaled(Vector3(rx / r, 1, rz / r))
	add(sphere_mesh(r, ry * 2.0, seg), Transform3D(b, pos), mat)

# segmento de parede/caixa entre dois pontos (no chão)
func seg_box(a: Vector3, b: Vector3, h: float, t: float, mat: Material, y0 := 0.0, extra := 0.0) -> void:
	var d := b - a
	d.y = 0
	var L := d.length()
	if L < 0.01:
		return
	var ang := atan2(d.x, d.z)
	var c := (a + b) * 0.5
	c.y = y0 + h * 0.5
	box(t, h, L + extra, mat, c, ang)

func commit(parent: Node3D, shadows := true, name := "Batch") -> Array:
	var out := []
	for mat in surf:
		var st: SurfaceTool = surf[mat]
		var mesh := st.commit()
		var mi := MeshInstance3D.new()
		mi.name = name
		mi.mesh = mesh
		mi.material_override = mat
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if shadows else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(mi)
		out.append(mi)
	surf.clear()
	return out

# ---------- formas próprias ----------
# anel/sector no chão (xz), ângulos em graus
static func sector_mesh(c: Vector3, r1: float, r2: float, a1: float, a2: float, y: float) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var n: int = max(2, int(ceil(abs(a2 - a1) / 6.0)))
	for k in n:
		var p := deg_to_rad(a1 + (a2 - a1) * k / n)
		var q := deg_to_rad(a1 + (a2 - a1) * (k + 1) / n)
		var A := c + Vector3(cos(p) * r1, y, sin(p) * r1)
		var B := c + Vector3(cos(p) * r2, y, sin(p) * r2)
		var C2 := c + Vector3(cos(q) * r2, y, sin(q) * r2)
		var Dd := c + Vector3(cos(q) * r1, y, sin(q) * r1)
		for v in [A, B, C2, A, C2, Dd]:
			st.set_normal(Vector3.UP)
			st.set_uv(Vector2(v.x, v.z))
			st.add_vertex(v)
	st.generate_tangents()
	return st.commit()

static func disc_mesh(c: Vector3, r: float, y: float) -> ArrayMesh:
	return sector_mesh(c, 0.0, r, 0, 360, y)

# faixa curva com altura (balcão, muro redondo)
static func band_mesh(c: Vector3, r1: float, r2: float, a1: float, a2: float, y0: float, h: float) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var n: int = max(2, int(ceil(abs(a2 - a1) / 6.0)))
	var y1 := y0 + h
	var quad := func(a: Vector3, b: Vector3, cc: Vector3, d: Vector3, nrm: Vector3):
		for v in [a, cc, b, a, d, cc]:
			st.set_normal(nrm)
			st.set_uv(Vector2(v.x + v.z, v.y))
			st.add_vertex(v)
	for k in n:
		var p := deg_to_rad(a1 + (a2 - a1) * k / n)
		var q := deg_to_rad(a1 + (a2 - a1) * (k + 1) / n)
		var dp := Vector3(cos(p), 0, sin(p))
		var dq := Vector3(cos(q), 0, sin(q))
		var dm := (dp + dq).normalized()
		# topo
		quad.call(c + dp * r1 + Vector3(0, y1, 0), c + dq * r1 + Vector3(0, y1, 0), c + dq * r2 + Vector3(0, y1, 0), c + dp * r2 + Vector3(0, y1, 0), Vector3.UP)
		# fora
		quad.call(c + dp * r2 + Vector3(0, y0, 0), c + dp * r2 + Vector3(0, y1, 0), c + dq * r2 + Vector3(0, y1, 0), c + dq * r2 + Vector3(0, y0, 0), dm)
		# dentro
		quad.call(c + dq * r1 + Vector3(0, y0, 0), c + dq * r1 + Vector3(0, y1, 0), c + dp * r1 + Vector3(0, y1, 0), c + dp * r1 + Vector3(0, y0, 0), -dm)
	# pontas
	for a in [a1, a2]:
		var d := Vector3(cos(deg_to_rad(a)), 0, sin(deg_to_rad(a)))
		var nrm := Vector3(-d.z, 0, d.x) * (-1.0 if a == a1 else 1.0)
		quad.call(c + d * r1 + Vector3(0, y0, 0), c + d * r2 + Vector3(0, y0, 0), c + d * r2 + Vector3(0, y1, 0), c + d * r1 + Vector3(0, y1, 0), nrm)
	st.generate_tangents()
	return st.commit()

# telhado cónico em anel (de r_in a r_out), com beirado em ey e cume em ty
static func ring_roof_mesh(c: Vector3, r_in: float, r_out: float, ey: float, ty: float, a1 := 0.0, a2 := 360.0) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var n: int = max(4, int(ceil(abs(a2 - a1) / 5.0)))
	for k in n:
		var p := deg_to_rad(a1 + (a2 - a1) * k / n)
		var q := deg_to_rad(a1 + (a2 - a1) * (k + 1) / n)
		var dp := Vector3(cos(p), 0, sin(p))
		var dq := Vector3(cos(q), 0, sin(q))
		var A := c + dp * r_out + Vector3(0, ey, 0)
		var B := c + dq * r_out + Vector3(0, ey, 0)
		var C2 := c + dq * r_in + Vector3(0, ty, 0)
		var Dd := c + dp * r_in + Vector3(0, ty, 0)
		var nrm := (B - A).cross(Dd - A).normalized()
		if nrm.y < 0:
			nrm = -nrm
		for v in [A, Dd, C2, A, C2, B]:
			st.set_normal(nrm)
			st.set_uv(Vector2((a1 + (a2 - a1) * k / n) / 8.0, v.distance_to(c)))
			st.add_vertex(v)
	st.generate_tangents()
	return st.commit()
