# Hotel Patinhas HD · pessoas 3D (jogador, donos, equipa e peões) com rosto, cabelo, roupa e animação de andar
class_name HumanModel
extends Node3D

var hips: Node3D
var torso: Node3D
var head: Node3D
var arms: Array = []
var legs: Array = []
var eyes: Array = []
var phase := 0.0
var t := 0.0
var moving := false
var speed := 0.0
var pose := ""
var name_label: Label3D
var _batches := {}

const SKINS := ["#f6d3b3", "#e8b68e", "#c98e62", "#9b6440", "#6b4128"]
const HAIRS := ["#2a1d15", "#5a3a22", "#a8743f", "#d9b56a", "#8a8a8a", "#b0442a", "#1b1b1f"]
const SHIRTS := ["#e8443a", "#3a95d8", "#2fae6b", "#f2c230", "#8a5cd6", "#ff7a35", "#33373d", "#f4f4f4", "#e0508a", "#4fb3a6"]
const PANTS := ["#2f4a7a", "#3b3b44", "#5f7f3b", "#a8343f", "#d9cfb8", "#7a5a3a", "#22252b"]

static func random_look(rng: RandomNumberGenerator) -> Dictionary:
	return {"skin": SKINS[rng.randi() % SKINS.size()], "hair": HAIRS[rng.randi() % HAIRS.size()], "style": rng.randi() % 5,
		"shirt": SHIRTS[rng.randi() % SHIRTS.size()], "pants": PANTS[rng.randi() % PANTS.size()], "shoes": ["#2a211c", "#f4f4f4", "#5a3a22", "#22252b"][rng.randi() % 4],
		"female": rng.randf() < 0.5, "hat": "", "h": rng.randf_range(0.94, 1.06), "glasses": rng.randf() < 0.18, "beard": rng.randf() < 0.15}

func _b(n: Node3D) -> Batch:
	if not _batches.has(n):
		_batches[n] = Batch.new()
	return _batches[n]

func _ell(n: Node3D, r: Vector3, pos: Vector3, mat: Material, rot := Vector3.ZERO, seg := 14) -> void:
	var m: float = max(r.x, r.z)
	var bs := Basis.from_euler(rot) * Basis().scaled(Vector3(r.x / m, 1, r.z / m))
	_b(n).add(Batch.sphere_mesh(m, r.y * 2.0, seg), Transform3D(bs, pos), mat)

func _cap(n: Node3D, r: float, h: float, pos: Vector3, mat: Material, rot := Vector3.ZERO) -> void:
	_b(n).add(Batch.capsule_mesh(r, h), Transform3D(Basis.from_euler(rot), pos), mat)

func _box(n: Node3D, s: Vector3, pos: Vector3, mat: Material, rot := Vector3.ZERO) -> void:
	_b(n).add(Batch.box_mesh(s), Transform3D(Basis.from_euler(rot), pos), mat)

func _piv(parent: Node3D, pos: Vector3) -> Node3D:
	var p := Node3D.new()
	p.position = pos
	parent.add_child(p)
	return p

func setup(look: Dictionary) -> void:
	var skin := Mats.skin(look.get("skin", "#e8b68e"))
	var shirt := Mats.cloth(look.get("shirt", "#3a95d8"))
	var pants := Mats.cloth(look.get("pants", "#2f4a7a"))
	var shoes := Mats.glossy(look.get("shoes", "#2a211c"), 0.45)
	var hair := Mats.fur(Color(look.get("hair", "#2a1d15")))
	var fem: bool = look.get("female", false)
	var hk: float = look.get("h", 1.0)
	scale = Vector3(hk, hk, hk)
	hips = _piv(self, Vector3(0, 0.92, 0))
	torso = _piv(hips, Vector3(0, 0.02, 0))
	# tronco: anca, barriga, peito largo com ombros arredondados
	_ell(hips, Vector3(0.17 if fem else 0.165, 0.13, 0.115), Vector3(0, 0.0, 0), pants)
	_ell(torso, Vector3(0.155 if fem else 0.16, 0.16, 0.11), Vector3(0, 0.14, 0.0), shirt)
	_ell(torso, Vector3(0.19 if fem else 0.205, 0.2, 0.125), Vector3(0, 0.33, 0.0), shirt)
	for s2 in [-1.0, 1.0]:
		_ell(torso, Vector3(0.062, 0.058, 0.07), Vector3(s2 * (0.17 if fem else 0.185), 0.455, 0.0), shirt)
	if fem:
		_ell(torso, Vector3(0.15, 0.07, 0.07), Vector3(0, 0.34, 0.075), shirt)
	_box(torso, Vector3(0.12, 0.03, 0.02), Vector3(0, 0.5, 0.1), Mats.cloth(Color(look.get("shirt", "#3a95d8")).darkened(0.15).to_html()))
	if look.get("apron", "") != "":
		_box(torso, Vector3(0.3, 0.46, 0.02), Vector3(0, 0.18, 0.125), Mats.cloth(look.apron))
	if look.get("coat", false):
		_ell(torso, Vector3(0.215, 0.4, 0.135), Vector3(0, 0.16, 0), Mats.cloth("#f7f7f4"))
		_box(torso, Vector3(0.012, 0.5, 0.01), Vector3(0, 0.16, 0.136), Mats.cloth("#dcdcd8"))
	_cap(torso, 0.05, 0.13, Vector3(0, 0.55, 0.0), skin)
	# cabeça
	head = _piv(torso, Vector3(0, 0.62, 0))
	_ell(head, Vector3(0.095, 0.118, 0.105), Vector3(0, 0.1, 0), skin)
	_ell(head, Vector3(0.08, 0.06, 0.085), Vector3(0, 0.035, 0.012), skin)
	# rosto
	for s in [-1.0, 1.0]:
		var e := _piv(head, Vector3(s * 0.036, 0.115, 0.088))
		_ell(e, Vector3(0.017, 0.012, 0.008), Vector3.ZERO, Mats.glossy("#f7f5f0", 0.2))
		_ell(e, Vector3(0.009, 0.009, 0.006), Vector3(0, 0, 0.006), Mats.glossy("#3a2a1e" if s > 0 else "#3a2a1e", 0.1))
		_ell(e, Vector3(0.003, 0.003, 0.002), Vector3(s * 0.002, 0.003, 0.011), Mats.emissive("#ffffff", 0.5), Vector3.ZERO, 6)
		eyes.append(e)
		_box(head, Vector3(0.03, 0.006, 0.01), Vector3(s * 0.036, 0.142, 0.094), Mats.base(look.get("hair", "#2a1d15")), Vector3(0, 0, -s * 0.12))
		_ell(head, Vector3(0.012, 0.025, 0.018), Vector3(s * 0.094, 0.1, 0.0), skin)
	_ell(head, Vector3(0.015, 0.026, 0.022), Vector3(0, 0.085, 0.106), skin)
	_ell(head, Vector3(0.012, 0.006, 0.01), Vector3(-0.009, 0.064, 0.112), Mats.skin(Color(look.get("skin", "#e8b68e")).darkened(0.25).to_html()))
	_ell(head, Vector3(0.012, 0.006, 0.01), Vector3(0.009, 0.064, 0.112), Mats.skin(Color(look.get("skin", "#e8b68e")).darkened(0.25).to_html()))
	_ell(head, Vector3(0.026, 0.008, 0.012), Vector3(0, 0.045, 0.098), Mats.glossy("#b0505a" if fem else "#8f4a44", 0.45))
	for s3 in [-1.0, 1.0]:
		_ell(head, Vector3(0.022, 0.015, 0.012), Vector3(s3 * 0.055, 0.07, 0.085), Mats.skin(Color(look.get("skin", "#e8b68e")).lerp(Color("#e88a80"), 0.25).to_html()))
	if look.get("glasses", false):
		var gm := Mats.glossy("#22252b", 0.2, 0.6)
		for s in [-1.0, 1.0]:
			_b(head).add(Batch.torus_mesh(0.016, 0.021), Transform3D(Basis.from_euler(Vector3(PI / 2, 0, 0)), Vector3(s * 0.037, 0.115, 0.1)), gm)
		_box(head, Vector3(0.025, 0.004, 0.004), Vector3(0, 0.118, 0.103), gm)
	if look.get("beard", false) and not fem:
		_ell(head, Vector3(0.07, 0.045, 0.06), Vector3(0, 0.03, 0.055), hair)
	# cabelo
	var style: int = look.get("style", 0)
	_ell(head, Vector3(0.1, 0.075, 0.108), Vector3(0, 0.155, -0.008), hair)
	if fem:
		match style % 3:
			0:
				_ell(head, Vector3(0.104, 0.14, 0.06), Vector3(0, 0.06, -0.06), hair)
			1:
				_ell(head, Vector3(0.05, 0.05, 0.05), Vector3(0, 0.2, -0.08), hair)
			2:
				_ell(head, Vector3(0.03, 0.12, 0.03), Vector3(0, 0.03, -0.11), hair, Vector3(0.3, 0, 0))
	else:
		if style % 3 == 1:
			_ell(head, Vector3(0.104, 0.06, 0.11), Vector3(0, 0.17, 0.0), hair)
	# chapéu
	match look.get("hat", ""):
		"chef":
			_b(head).add(Batch.cyl_mesh(0.085, 0.09, 0.1), Transform3D(Basis(), Vector3(0, 0.23, 0)), Mats.cloth("#ffffff"))
			_ell(head, Vector3(0.12, 0.07, 0.12), Vector3(0, 0.3, 0), Mats.cloth("#ffffff"))
		"gorro":
			_ell(head, Vector3(0.107, 0.08, 0.112), Vector3(0, 0.17, 0), Mats.cloth(look.get("hatc", "#2f6fae")))
			_ell(head, Vector3(0.035, 0.035, 0.035), Vector3(0, 0.25, 0), Mats.cloth("#ffffff"))
		"bone":
			_ell(head, Vector3(0.105, 0.06, 0.11), Vector3(0, 0.18, 0), Mats.cloth(look.get("hatc", "#f2c230")))
			_box(head, Vector3(0.1, 0.012, 0.09), Vector3(0, 0.16, 0.12), Mats.cloth(look.get("hatc", "#f2c230")))
		"vet":
			_ell(head, Vector3(0.105, 0.05, 0.11), Vector3(0, 0.185, 0), Mats.cloth("#4fb3a6"))
		"cartola":
			_b(head).add(Batch.cyl_mesh(0.075, 0.075, 0.16), Transform3D(Basis(), Vector3(0, 0.28, 0)), Mats.glossy("#222228", 0.4))
			_b(head).add(Batch.cyl_mesh(0.13, 0.13, 0.012), Transform3D(Basis(), Vector3(0, 0.2, 0)), Mats.glossy("#222228", 0.4))
		"rece":
			_box(head, Vector3(0.012, 0.06, 0.012), Vector3(0.1, 0.1, 0.03), Mats.glossy("#22252b", 0.3))
	# braços (ombro, cotovelo e mão com polegar)
	for s in [-1.0, 1.0]:
		var sh := _piv(torso, Vector3(s * (0.2 if fem else 0.215), 0.45, 0))
		_cap(sh, 0.058 if not fem else 0.05, 0.3, Vector3(0, -0.13, 0), shirt)
		var el := _piv(sh, Vector3(0, -0.27, 0))
		var arm_mat: Material = skin if look.get("short", true) else shirt
		_cap(el, 0.047 if not fem else 0.042, 0.27, Vector3(0, -0.12, 0), arm_mat)
		_ell(el, Vector3(0.042, 0.06, 0.024), Vector3(0, -0.29, 0.008), skin)
		_ell(el, Vector3(0.014, 0.03, 0.014), Vector3(-s * 0.035, -0.27, 0.02), skin, Vector3(0, 0, s * 0.5))
		arms.append({"sh": sh, "el": el, "s": s})
	# pernas
	for s in [-1.0, 1.0]:
		var hp := _piv(hips, Vector3(s * 0.088, -0.04, 0))
		_cap(hp, 0.075 if not fem else 0.07, 0.46, Vector3(0, -0.2, 0), pants)
		var kn := _piv(hp, Vector3(0, -0.42, 0))
		_cap(kn, 0.058, 0.44, Vector3(0, -0.2, 0), pants)
		_ell(kn, Vector3(0.055, 0.045, 0.12), Vector3(0, -0.43, 0.04), shoes)
		_box(kn, Vector3(0.1, 0.02, 0.2), Vector3(0, -0.465, 0.04), Mats.base("#f2f0ea" if look.get("shoes", "") != "#f4f4f4" else "#d8d6d0", 0.8))
		legs.append({"hp": hp, "kn": kn, "s": s})
	for n in _batches:
		_batches[n].commit(n, true, "P")
	_batches.clear()
	for gi in find_children("*", "GeometryInstance3D", true, false):
		gi.visibility_range_end = 80.0

func set_label(text: String) -> void:
	if name_label == null:
		name_label = Label3D.new()
		name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		name_label.font_size = 36
		name_label.pixel_size = 0.004
		name_label.outline_size = 12
		name_label.position = Vector3(0, 2.05, 0)
		name_label.visibility_range_end = 16.0
		add_child(name_label)
	name_label.text = text

func animate(dt: float, mv: bool, spd: float, p := "") -> void:
	t += dt
	moving = mv
	pose = p
	var g := 0.0
	if moving:
		phase += dt * 7.5 * clamp(spd / 1.4, 0.6, 1.8)
		g = 1.0
	var s := sin(phase)
	hips.position.y = 0.92 + (abs(cos(phase)) * 0.03 - 0.015) * g
	if pose == "sit":
		hips.position.y = 0.5
	torso.rotation.y = s * 0.08 * g
	torso.rotation.x = 0.06 * g
	for L in legs:
		var sw: float = s * L.s * 0.55 * g
		var hp: Node3D = L.hp
		var kn: Node3D = L.kn
		if pose == "sit":
			hp.rotation.x = -1.45
			kn.rotation.x = 1.45
		else:
			hp.rotation.x = sw
			kn.rotation.x = max(0.0, sin(phase + (0.0 if L.s > 0 else PI) - 0.6)) * 0.8 * g
	for A in arms:
		var sh: Node3D = A.sh
		var el: Node3D = A.el
		if pose == "work":
			sh.rotation.x = -0.9 + sin(t * 6.0 + A.s) * 0.15
			el.rotation.x = -0.6
		elif pose == "lead" and A.s > 0:
			sh.rotation.x = -0.45
			el.rotation.x = -0.3
		else:
			sh.rotation.x = -s * A.s * 0.5 * g + sin(t * 1.3) * 0.02
			el.rotation.x = -0.25 * g - 0.08
		sh.rotation.z = A.s * 0.08
	var blink := 0.15 if fmod(t + get_instance_id() % 7, 4.1) < 0.12 else 1.0
	for e in eyes:
		e.scale.y = blink
	head.rotation.y = sin(t * 0.5 + get_instance_id()) * 0.25 * (1.0 - g)

# mão direita (para a trela)
func hand_pos() -> Vector3:
	for A in arms:
		if A.s > 0:
			return A.el.global_transform * Vector3(0, -0.27, 0.02)
	return global_position + Vector3(0, 1.0, 0)
