# Hotel Patinhas HD · pessoas 3D em estilo fofinho: cabeça grande e redonda, olhos brilhantes,
# bochechas rosadas, corpo roliço, mãos e sapatos arredondados, com animação de andar
class_name HumanModel
extends Node3D

const HIP_Y := 0.6

var hips: Node3D
var torso: Node3D
var head: Node3D
var arms: Array = []
var legs: Array = []
var eyes: Array = []
var phase := 0.0
var t := 0.0
var moving := false
var speed := 0.0
var pose := ""
var name_label: Label3D
var _batches := {}

const SKINS := ["#f9dcc4", "#f0c3a0", "#d9a07a", "#a8714c", "#77492e"]
const HAIRS := ["#2a1d15", "#5a3a22", "#a8743f", "#e2bf6e", "#9a9a9a", "#c0502e", "#1b1b1f"]
const SHIRTS := ["#ef5a4f", "#4aa3e0", "#3dbb7a", "#f6c945", "#9a6ee0", "#ff8a45", "#3f444c", "#f6f6f2", "#ec6a9c", "#5cc2b4"]
const PANTS := ["#3a5a8f", "#454550", "#6a8a45", "#b8454f", "#e0d6bf", "#86654a", "#2a2d34"]

static func random_look(rng: RandomNumberGenerator) -> Dictionary:
	return {"skin": SKINS[rng.randi() % SKINS.size()], "hair": HAIRS[rng.randi() % HAIRS.size()], "style": rng.randi() % 5,
		"shirt": SHIRTS[rng.randi() % SHIRTS.size()], "pants": PANTS[rng.randi() % PANTS.size()], "shoes": ["#3a2a20", "#f6f6f2", "#6a4630", "#2a2d34", "#ef5a4f"][rng.randi() % 5],
		"female": rng.randf() < 0.5, "hat": "", "h": rng.randf_range(0.94, 1.06), "glasses": rng.randf() < 0.15, "beard": rng.randf() < 0.12}

func _b(n: Node3D) -> Batch:
	if not _batches.has(n):
		_batches[n] = Batch.new()
	return _batches[n]

func _ell(n: Node3D, r: Vector3, pos: Vector3, mat: Material, rot := Vector3.ZERO, seg := 16) -> void:
	var m: float = max(r.x, r.z)
	var bs := Basis.from_euler(rot) * Basis().scaled(Vector3(r.x / m, 1, r.z / m))
	_b(n).add(Batch.sphere_mesh(m, r.y * 2.0, seg), Transform3D(bs, pos), mat)

# peça pequena colorida por vértice (não acrescenta desenhos)
func _dot(n: Node3D, r: Vector3, pos: Vector3, col: Color, rot := Vector3.ZERO, seg := 10) -> void:
	var m: float = max(r.x, r.z)
	var bs := Basis.from_euler(rot) * Basis().scaled(Vector3(r.x / m, 1, r.z / m))
	_b(n).add_c(Batch.sphere_mesh(m, r.y * 2.0, seg), Transform3D(bs, pos), col)

func _cap(n: Node3D, r: float, h: float, pos: Vector3, mat: Material, rot := Vector3.ZERO) -> void:
	_b(n).add(Batch.capsule_mesh(r, h), Transform3D(Basis.from_euler(rot), pos), mat)

func _piv(parent: Node3D, pos: Vector3) -> Node3D:
	var p := Node3D.new()
	p.position = pos
	parent.add_child(p)
	return p

func setup(look: Dictionary) -> void:
	var skin_c := Color(look.get("skin", "#f0c3a0"))
	var hair_c := Color(look.get("hair", "#2a1d15"))
	var shirt_c := Color(look.get("shirt", "#4aa3e0"))
	var skin := Mats.skin(skin_c)
	var shirt := Mats.cloth(shirt_c)
	var pants := Mats.cloth(look.get("pants", "#3a5a8f"))
	var shoes := Mats.glossy(look.get("shoes", "#3a2a20"), 0.4)
	var hair := Mats.fur(hair_c)
	var fem: bool = look.get("female", false)
	var hk: float = look.get("h", 1.0)
	var ultra := Mats.quality == "ultra"
	scale = Vector3(hk, hk, hk)
	hips = _piv(self, Vector3(0, HIP_Y, 0))
	torso = _piv(hips, Vector3(0, 0.03, 0))
	# ---- corpo roliço ----
	_ell(hips, Vector3(0.165, 0.12, 0.13), Vector3(0, 0.0, 0), pants)
	_ell(torso, Vector3(0.175, 0.19, 0.145), Vector3(0, 0.15, 0.0), shirt)
	_ell(torso, Vector3(0.16, 0.13, 0.125), Vector3(0, 0.3, -0.005), shirt)
	for s2 in [-1.0, 1.0]:
		_ell(torso, Vector3(0.07, 0.065, 0.07), Vector3(s2 * 0.15, 0.36, 0.0), shirt)
	# gola redonda
	_b(torso).add_c(Batch.torus_mesh(0.045, 0.075), Transform3D(Basis().scaled(Vector3(1.2, 0.7, 1.05)), Vector3(0, 0.415, 0.0)), shirt_c.darkened(0.15))
	if look.get("apron", "") != "":
		_ell(torso, Vector3(0.15, 0.2, 0.03), Vector3(0, 0.12, 0.135), Mats.cloth(look.apron))
		_dot(torso, Vector3(0.05, 0.035, 0.012), Vector3(0, 0.07, 0.165), Color(look.apron).darkened(0.12))
	if look.get("coat", false):
		var cm := Mats.cloth("#f8f8f5")
		_ell(torso, Vector3(0.19, 0.24, 0.16), Vector3(0, 0.13, 0), cm)
		_ell(hips, Vector3(0.18, 0.12, 0.145), Vector3(0, -0.04, 0), cm)
		for k in 3:
			_dot(torso, Vector3(0.011, 0.011, 0.006), Vector3(0.0, 0.3 - k * 0.09, 0.158 - k * 0.002), Color("#c9cfd6"), Vector3.ZERO, 6)
		_dot(torso, Vector3(0.03, 0.022, 0.006), Vector3(-0.09, 0.26, 0.135), Color("#4aa3e0"), Vector3(0, -0.5, 0), 6)
	elif look.get("apron", "") == "":
		# botões na camisola
		for k in 2:
			_dot(torso, Vector3(0.012, 0.012, 0.006), Vector3(0, 0.33 - k * 0.08, 0.135 - k * 0.0), Color("#f6f3ec"), Vector3.ZERO, 6)
	# cinto
	_b(hips).add_c(Batch.cyl_mesh(0.162, 0.162, 0.035), Transform3D(Basis().scaled(Vector3(1, 1, 0.8)), Vector3(0, 0.07, 0)), Color(look.get("pants", "#3a5a8f")).darkened(0.35))
	_b(hips).add_c(Batch.box_mesh(Vector3(0.045, 0.032, 0.012)), Transform3D(Basis(), Vector3(0, 0.07, 0.13)), Color("#e3c56a"))
	# pescoço curto
	_cap(torso, 0.055, 0.1, Vector3(0, 0.43, 0.0), skin)
	# ---- cabeça grande e redonda ----
	head = _piv(torso, Vector3(0, 0.43, 0))
	var HR := 0.19
	_ell(head, Vector3(HR * 1.04, HR, HR * 0.98), Vector3(0, HR, 0), skin)
	_ell(head, Vector3(HR * 0.82, HR * 0.6, HR * 0.8), Vector3(0, HR * 0.66, 0.02), skin)  # bochechas cheias
	# orelhas
	for s in [-1.0, 1.0]:
		_ell(head, Vector3(0.028, 0.042, 0.03), Vector3(s * HR * 1.02, HR * 0.95, -0.005), skin, Vector3.ZERO, 10)
		_dot(head, Vector3(0.012, 0.025, 0.012), Vector3(s * HR * 1.05, HR * 0.95, 0.008), skin_c.darkened(0.12), Vector3.ZERO, 8)
	# olhos grandes e brilhantes
	for s in [-1.0, 1.0]:
		var e := _piv(head, Vector3(s * 0.068, HR * 0.8, HR * 0.9))
		_ell(e, Vector3(0.031, 0.04, 0.016), Vector3.ZERO, Mats.glossy("#2a1c14", 0.08, 0.0, true), Vector3(0, s * 0.3, 0), 14)
		_dot(e, Vector3(0.02, 0.026, 0.008), Vector3(0, -0.006, 0.006), Color("#5a3a26") if look.get("eyes", "") == "" else Color(look.eyes), Vector3(0, s * 0.3, 0), 10)
		_ell(e, Vector3(0.011, 0.011, 0.005), Vector3(s * 0.008, 0.014, 0.013), Mats.emissive("#ffffff", 0.6), Vector3.ZERO, 8)
		_ell(e, Vector3(0.005, 0.005, 0.004), Vector3(-s * 0.009, -0.013, 0.014), Mats.emissive("#ffffff", 0.5), Vector3.ZERO, 6)
		eyes.append(e)
		# sobrancelhas pequenas e arredondadas
		_dot(head, Vector3(0.026, 0.007, 0.008), Vector3(s * 0.068, HR * 1.05, HR * 0.9), hair_c.darkened(0.1), Vector3(0, 0, s * 0.18), 8)
		if fem:
			# pestanas
			_dot(head, Vector3(0.012, 0.005, 0.006), Vector3(s * 0.098, HR * 0.98, HR * 0.84), Color("#1b1410"), Vector3(0, 0, -s * 0.7), 6)
		# bochechas rosadas
		_dot(head, Vector3(0.033, 0.02, 0.01), Vector3(s * 0.112, HR * 0.55, HR * 0.86), skin_c.lerp(Color("#ff8a8a"), 0.5), Vector3(0, s * 0.45, 0), 10)
	# nariz pequenino
	_dot(head, Vector3(0.017, 0.013, 0.012), Vector3(0, HR * 0.62, HR * 0.99), skin_c.darkened(0.08), Vector3.ZERO, 8)
	# sorriso (um arco de pontinhos)
	var mouth_c := skin_c.lerp(Color("#8a3a3a"), 0.75)
	for k in 13:
		var x := -0.03 + k * 0.005
		var y := HR * 0.38 - 0.012 * (1.0 - pow(x / 0.03, 2))
		var z := sqrt(max(0.0, pow(HR * 0.97, 2) - x * x - pow(y - HR * 0.6, 2) * 0.5)) - 0.004
		_dot(head, Vector3(0.006, 0.0048, 0.005), Vector3(x, y, min(z, HR * 0.93)), mouth_c, Vector3.ZERO, 6)
	if look.get("glasses", false):
		var gm := Mats.glossy("#2a2d33", 0.2, 0.6)
		for s in [-1.0, 1.0]:
			_b(head).add(Batch.torus_mesh(0.03, 0.037), Transform3D(Basis.from_euler(Vector3(PI / 2, 0, 0)), Vector3(s * 0.068, HR * 0.8, HR * 0.97)), gm)
		_b(head).add_c(Batch.box_mesh(Vector3(0.03, 0.006, 0.006)), Transform3D(Basis(), Vector3(0, HR * 0.83, HR * 1.0)), Color("#2a2d33"))
	if look.get("beard", false) and not fem:
		_ell(head, Vector3(0.12, 0.07, 0.08), Vector3(0, HR * 0.3, HR * 0.55), hair)
		_ell(head, Vector3(0.04, 0.012, 0.012), Vector3(0, HR * 0.47, HR * 0.95), hair)
	# ---- cabelo ----
	var style: int = look.get("style", 0)
	var hat: String = look.get("hat", "")
	_ell(head, Vector3(HR * 1.1, HR * 0.75, HR * 1.07), Vector3(0, HR * 1.55, -0.02), hair)
	if hat == "":
		# franja
		for k in 4:
			var fx := -0.09 + k * 0.06
			_ell(head, Vector3(0.05, 0.03, 0.035), Vector3(fx, HR * 1.4, HR * 0.8), hair, Vector3(0.4, 0, -fx * 2.0), 10)
	if fem:
		match style % 3:
			0:  # cabelo comprido
				_ell(head, Vector3(HR * 1.08, HR * 0.95, HR * 0.6), Vector3(0, HR * 0.75, -HR * 0.55), hair)
				for s in [-1.0, 1.0]:
					_ell(head, Vector3(0.045, 0.12, 0.05), Vector3(s * HR * 1.0, HR * 0.6, HR * 0.1), hair, Vector3(0, 0, s * 0.1), 12)
			1:  # carrapito
				if hat == "":
					_ell(head, Vector3(0.075, 0.07, 0.075), Vector3(0, HR * 2.15, -0.04), hair)
			2:  # duas marias-chiquinhas
				for s in [-1.0, 1.0]:
					_ell(head, Vector3(0.06, 0.1, 0.06), Vector3(s * HR * 1.2, HR * 1.05, -0.04), hair, Vector3(0, 0, s * 0.35), 12)
					_dot(head, Vector3(0.022, 0.022, 0.022), Vector3(s * HR * 1.08, HR * 1.3, -0.03), shirt_c.lightened(0.2), Vector3.ZERO, 8)
	else:
		match style % 3:
			1:  # topete
				if hat == "":
					for k in 3:
						_ell(head, Vector3(0.05, 0.05, 0.05), Vector3(-0.05 + k * 0.05, HR * 1.95, 0.05 - k * 0.03), hair, Vector3(0.3, 0, 0), 10)
			2:  # risca ao lado
				if hat == "":
					_ell(head, Vector3(HR * 0.7, HR * 0.3, HR * 0.6), Vector3(HR * 0.35, HR * 1.75, HR * 0.25), hair, Vector3(0, 0, -0.3))
	if ultra and hat == "":
		var r := RandomNumberGenerator.new()
		r.seed = hash(str(look))
		for k in 16:
			var u := r.randf() * TAU
			var v := r.randf_range(0.1, 1.15)
			var dir := Vector3(sin(v) * cos(u), cos(v), sin(v) * sin(u))
			if dir.z > 0.45 and dir.y < 0.8:
				dir.z = -dir.z
			var p := Vector3(0, HR * 1.55, -0.02) + Vector3(dir.x * HR * 1.08, dir.y * HR * 0.73, dir.z * HR * 1.05)
			_ell(head, Vector3(0.05, 0.035, 0.05) * r.randf_range(0.8, 1.2), p, hair, Vector3(r.randf_range(-0.4, 0.4), u, 0), 10)
	# ---- chapéus ----
	match hat:
		"chef":
			_b(head).add(Batch.cyl_mesh(HR * 0.95, HR * 0.98, 0.12), Transform3D(Basis(), Vector3(0, HR * 1.85, 0)), Mats.cloth("#ffffff"))
			_ell(head, Vector3(HR * 1.15, 0.1, HR * 1.15), Vector3(0, HR * 2.35, 0), Mats.cloth("#ffffff"))
		"gorro":
			_ell(head, Vector3(HR * 1.12, HR * 0.8, HR * 1.1), Vector3(0, HR * 1.48, -0.01), Mats.cloth(look.get("hatc", "#2f6fae")))
			_ell(head, Vector3(0.05, 0.05, 0.05), Vector3(0, HR * 2.3, -0.01), Mats.cloth("#ffffff"))
		"bone":
			_ell(head, Vector3(HR * 1.1, HR * 0.65, HR * 1.08), Vector3(0, HR * 1.55, -0.01), Mats.cloth(look.get("hatc", "#f2c230")))
			_ell(head, Vector3(HR * 0.8, 0.012, HR * 0.6), Vector3(0, HR * 1.42, HR * 0.95), Mats.cloth(look.get("hatc", "#f2c230")))
		"vet":
			_ell(head, Vector3(HR * 1.1, HR * 0.55, HR * 1.08), Vector3(0, HR * 1.6, -0.01), Mats.cloth("#5cc2b4"))
		"cartola":
			_b(head).add(Batch.cyl_mesh(HR * 0.7, HR * 0.7, 0.2), Transform3D(Basis(), Vector3(0, HR * 2.35, 0)), Mats.glossy("#222228", 0.4))
			_b(head).add(Batch.cyl_mesh(HR * 1.25, HR * 1.25, 0.016), Transform3D(Basis(), Vector3(0, HR * 1.85, 0)), Mats.glossy("#222228", 0.4))
		"rece":
			_b(head).add_c(Batch.torus_mesh(HR * 1.02, HR * 1.1), Transform3D(Basis.from_euler(Vector3(0, 0, PI / 2)), Vector3(0, HR * 1.1, 0)), Color("#2a2d33"))
			_dot(head, Vector3(0.025, 0.035, 0.03), Vector3(HR * 1.08, HR * 0.95, 0), Color("#2a2d33"))
			_dot(head, Vector3(0.008, 0.008, 0.05), Vector3(HR * 0.95, HR * 0.55, HR * 0.6), Color("#2a2d33"), Vector3(0, -0.6, 0), 6)
	# ---- braços curtos com mãos redondas ----
	var arm_mat: Material = skin if look.get("short", true) and not look.get("coat", false) else (Mats.cloth("#f8f8f5") if look.get("coat", false) else shirt)
	for s in [-1.0, 1.0]:
		var sh := _piv(torso, Vector3(s * 0.19, 0.36, 0))
		_ell(sh, Vector3(0.06, 0.06, 0.06), Vector3(0, -0.01, 0), arm_mat if look.get("coat", false) else shirt)
		_cap(sh, 0.052, 0.2, Vector3(0, -0.09, 0), arm_mat if look.get("coat", false) else shirt)
		var el := _piv(sh, Vector3(0, -0.19, 0))
		_cap(el, 0.047, 0.18, Vector3(0, -0.07, 0), arm_mat)
		_ell(el, Vector3(0.05, 0.048, 0.045), Vector3(0, -0.19, 0.005), skin, Vector3.ZERO, 14)
		_ell(el, Vector3(0.018, 0.026, 0.018), Vector3(-s * 0.04, -0.175, 0.025), skin, Vector3(0, 0, s * 0.6), 8)
		if ultra and s < 0:
			_b(el).add_c(Batch.torus_mesh(0.042, 0.052), Transform3D(Basis(), Vector3(0, -0.14, 0.0)), Color("#2a2d33"))
			_b(el).add_c(Batch.cyl_mesh(0.018, 0.018, 0.008), Transform3D(Basis.from_euler(Vector3(PI / 2, 0, 0)), Vector3(0, -0.14, 0.052)), Color("#e8ecf0"))
		arms.append({"sh": sh, "el": el, "s": s})
	# ---- pernas e sapatos redondos ----
	for s in [-1.0, 1.0]:
		var hp := _piv(hips, Vector3(s * 0.085, -0.04, 0))
		_cap(hp, 0.075, 0.3, Vector3(0, -0.13, 0), pants)
		var kn := _piv(hp, Vector3(0, -0.27, 0))
		_cap(kn, 0.068, 0.26, Vector3(0, -0.1, 0), pants)
		_ell(kn, Vector3(0.075, 0.062, 0.115), Vector3(0, -0.255, 0.035), shoes)
		_b(kn).add_c(Batch.box_mesh(Vector3(0.13, 0.025, 0.21)), Transform3D(Basis(), Vector3(0, -0.3, 0.035)), Color("#f4f1ea") if look.get("shoes", "") != "#f6f6f2" else Color("#d8d4cc"))
		if ultra:
			for k in 2:
				_b(kn).add_c(Batch.box_mesh(Vector3(0.05, 0.007, 0.01)), Transform3D(Basis(), Vector3(0, -0.2 - k * 0.006, 0.07 + k * 0.025)), Color("#f6f3ec"))
		legs.append({"hp": hp, "kn": kn, "s": s})
	for n in _batches:
		_batches[n].commit(n, true, "P")
	_batches.clear()
	for gi in find_children("*", "GeometryInstance3D", true, false):
		gi.visibility_range_end = 80.0

func set_label(text: String) -> void:
	if name_label == null:
		name_label = Label3D.new()
		name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		name_label.font_size = 36
		name_label.pixel_size = 0.004
		name_label.outline_size = 12
		name_label.position = Vector3(0, 1.78, 0)
		name_label.visibility_range_end = 16.0
		add_child(name_label)
	name_label.text = text

func animate(dt: float, mv: bool, spd: float, p := "") -> void:
	t += dt
	moving = mv
	pose = p
	var g := 0.0
	if moving:
		phase += dt * 8.5 * clamp(spd / 1.4, 0.6, 1.8)
		g = 1.0
	var s := sin(phase)
	# passinhos saltitantes
	hips.position.y = HIP_Y + (abs(cos(phase)) * 0.035 - 0.012) * g
	if pose == "sit":
		hips.position.y = 0.36
	torso.rotation.y = s * 0.06 * g
	torso.rotation.z = s * 0.05 * g
	torso.rotation.x = 0.04 * g
	for L in legs:
		var sw: float = s * L.s * 0.6 * g
		var hp: Node3D = L.hp
		var kn: Node3D = L.kn
		if pose == "sit":
			hp.rotation.x = -1.45
			kn.rotation.x = 1.45
		else:
			hp.rotation.x = sw
			kn.rotation.x = max(0.0, sin(phase + (0.0 if L.s > 0 else PI) - 0.6)) * 0.7 * g
	for A in arms:
		var sh: Node3D = A.sh
		var el: Node3D = A.el
		if pose == "work":
			sh.rotation.x = -0.9 + sin(t * 6.0 + A.s) * 0.15
			el.rotation.x = -0.6
		elif pose == "lead" and A.s > 0:
			sh.rotation.x = -0.5
			el.rotation.x = -0.3
		else:
			sh.rotation.x = -s * A.s * 0.6 * g + sin(t * 1.3) * 0.02
			el.rotation.x = -0.2 * g - 0.08
		sh.rotation.z = A.s * (0.12 + 0.04 * sin(t * 1.1))
	var blink := 0.12 if fmod(t + get_instance_id() % 7, 4.1) < 0.12 else 1.0
	for e in eyes:
		e.scale.y = blink
	# cabeça inclina de vez em quando (dá um ar simpático)
	head.rotation.y = sin(t * 0.5 + get_instance_id()) * 0.25 * (1.0 - g)
	head.rotation.z = sin(t * 0.7 + get_instance_id() * 0.3) * 0.08 * (1.0 - g) + s * 0.04 * g

# mão direita (para a trela)
func hand_pos() -> Vector3:
	for A in arms:
		if A.s > 0:
			return A.el.global_transform * Vector3(0, -0.19, 0.02)
	return global_position + Vector3(0, 0.8, 0)
