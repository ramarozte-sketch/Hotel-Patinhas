# Hotel Patinhas HD · dados partilhados, regras e traduções (autoload "D")
extends Node

const Gen = preload("res://scripts/data_gen.gd")
const SPECIES = Gen.SPECIES
const SPECIES_ORDER = Gen.SPECIES_ORDER
const COATS = Gen.COATS
const PETS = Gen.PETS
const OWNERS = Gen.OWNERS
const STAFF_NAMES = Gen.STAFF_NAMES
const HOTEL_NAMES = Gen.HOTEL_NAMES
const ROLES = Gen.ROLES
const TRAITS = Gen.TRAITS
const TRAIT_IDS = Gen.TRAIT_IDS
const LVL_XP = Gen.LVL_XP
const PRODUCTS = Gen.PRODUCTS
const FRANCH = Gen.FRANCH
const MISSION_POOL = Gen.MISSION_POOL
const ACH = Gen.ACH
const REQS = Gen.REQS
const REQ_IDS = Gen.REQ_IDS
const DAILY = Gen.DAILY
const MINE_SP = Gen.MINE_SP
const COLLARS = Gen.COLLARS
const SEASON_INFO = Gen.SEASON_INFO
const UPS = Gen.UPS
const NEEDS = ["fome", "sede", "banho", "diver"]
const PAY_EVERY := 240.0
const NRING := 16
const NROOMS := 26
const VERSION := "1.0"
const PAYPAL := "https://www.paypal.com/paypalme/ruivascoamaro"

var lang := "pt"
var I18N := {}
var UP_BY_ID := {}

func _init() -> void:
	for k in Gen.I18N_BASE:
		I18N[k] = Gen.I18N_BASE[k]
	for k in EXTRA:
		I18N[k] = EXTRA[k]
	for u in UPS:
		UP_BY_ID[u.id] = u
	var l := OS.get_locale_language()
	lang = l if l in ["en", "fr"] else "pt"

# ===================== traduções =====================
func T(s: String) -> String:
	if lang == "pt" or s == "":
		return s
	var row = I18N.get(s)
	if row == null:
		return s
	return row[0] if lang == "en" else row[1]

# {chave} -> valor; um valor [texto, params] é traduzido
func F(s: String, p: Dictionary = {}) -> String:
	var out := T(s)
	for k in p:
		var v = p[k]
		var txt := ""
		if v is Array:
			txt = F(str(v[0]), v[1] if v.size() > 1 else {})
		elif v is float and v == floor(v):
			txt = str(int(v))
		else:
			txt = str(v)
		out = out.replace("{" + str(k) + "}", txt)
	return out

func fmt(n: float) -> String:
	var v := int(round(n))
	var s := str(abs(v))
	var out := ""
	var c := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		c += 1
		if c % 3 == 0 and i > 0:
			out = " " + out
	return ("−€" if v < 0 else "€") + out

func mmss(t: float) -> String:
	var s := int(max(0.0, t))
	return "%d:%02d" % [s / 60, s % 60]

# ===================== regras =====================
func stars(rep: float) -> int:
	return min(5, 1 + int(floor(rep / 20.0)))

func happy(g: Dictionary) -> float:
	var h: float = (g.fome + g.sede + g.banho + g.diver) / 4.0
	if min(min(g.fome, g.sede), min(g.banho, g.diver)) < 15:
		h -= 12
	h -= min(24.0, g.get("mess", 0) * 6.0)
	if g.get("sick", false):
		h -= 20
	if g.get("leak", false):
		h -= 8
	return clamp(h, 0.0, 100.0)

func max_rooms(up: Dictionary) -> int:
	var n := 8
	if up.get("pav_e", 0) > 0:
		n += 4
		if up.get("pav_w", 0) > 0:
			n += 4
	return n

func season_now() -> String:
	var d := Time.get_date_dict_from_system()
	var m: int = d.month
	var day: int = d.day
	if m == 10 or (m == 11 and day <= 2):
		return "halloween"
	if m == 12 or (m == 1 and day <= 6):
		return "natal"
	if (m == 6 and day >= 15) or m == 7 or m == 8 or (m == 9 and day <= 15):
		return "verao"
	return ""

func room_no(i: int) -> String:
	if i < 8:
		return str(101 + i)
	if i < 12:
		return str(201 + i - 8)
	if i < 16:
		return str(301 + i - 12)
	if i < 22:
		return "C" + str(i - 15)
	return "A" + str(i - 21)

func room_kind(i: int) -> String:
	if i >= 22:
		return "avi"
	if i >= 16:
		return "barn"
	return ""

func place_of(sp: String) -> String:
	return SPECIES[sp].get("place", "")

func is_rare(sp: String, coat: int) -> bool:
	var L: Array = COATS[sp]
	return L.size() > 2 and coat == L.size() - 1

func up_cost(id: String, level: int) -> int:
	var u: Dictionary = UP_BY_ID[id]
	var c: Array = u.costs
	return int(c[min(level, c.size() - 1)])

func up_max(id: String, up: Dictionary) -> int:
	if id == "rooms":
		return max_rooms(up)
	return int(UP_BY_ID[id].max)

func speed_of(sp: String) -> float:
	return float(SPECIES[sp].get("speed", 10)) * 0.2

func sp_name(sp: String) -> String:
	return T(SPECIES[sp].n)

# ===================== textos novos desta versão =====================
const EXTRA = {
	"Cores": ["Colours", "Couleurs"],
	"Colorido": ["Colourful", "Coloré"],
	"Natural": ["Natural", "Naturel"],
	"Realista": ["Realistic", "Réaliste"],
	"Cores vivas e alegres, a pensar nas crianças": ["Bright, cheerful colours for children", "Couleurs vives et joyeuses pour les enfants"],
	"O aspeto normal do jogo": ["The game's normal look", "L'aspect normal du jeu"],
	"Cores sóbrias e naturais, a pensar nos adultos": ["Subdued, natural colours for adults", "Couleurs sobres et naturelles pour les adultes"],
	"A carregar": ["Loading", "Chargement"],
	"A pintar o céu": ["Painting the sky", "On peint le ciel"],
	"A preparar o terreno": ["Preparing the ground", "On prépare le terrain"],
	"A construir o hotel": ["Building the hotel", "On construit l'hôtel"],
	"A plantar o jardim": ["Planting the garden", "On plante le jardin"],
	"A arrumar os quartos": ["Tidying the rooms", "On range les chambres"],
	"A abrir a rua": ["Opening the street", "On ouvre la rue"],
	"A plantar a relva": ["Growing the grass", "On fait pousser l'herbe"],
	"A acrescentar pormenores": ["Adding details", "On ajoute des détails"],
	"A chamar os hóspedes": ["Calling the guests", "On appelle les clients"],
	"A preparar a receção": ["Opening the reception", "On ouvre la réception"],
	"A preparar os gráficos": ["Preparing the graphics", "On prépare les graphismes"],
	"Dica: dá banho, comida e mimos para os hóspedes ficarem felizes.": ["Tip: baths, food and cuddles keep the guests happy.", "Astuce : bains, nourriture et câlins rendent les clients heureux."],
	"Dica: leva os cães ao parque pela trela.": ["Tip: take the dogs to the park on the leash.", "Astuce : emmène les chiens au parc en laisse."],
	"Dica: contrata ajudantes quando o hotel crescer.": ["Tip: hire helpers when the hotel grows.", "Astuce : engage des aides quand l'hôtel grandit."],
	"Dica: em Opções podes escolher a qualidade dos gráficos.": ["Tip: you can choose the graphics quality in Options.", "Astuce : tu peux choisir la qualité graphique dans les Options."],
	"Continuar": ["Continue", "Continuer"],
	"Continuar a jogar": ["Keep playing", "Continuer à jouer"],
	"Novo jogo": ["New game", "Nouvelle partie"],
	"Jogo em pausa": ["Game paused", "Jeu en pause"],
	"O hotel de animais mais fofo do mundo": ["The cutest pet hotel in the world", "L'hôtel pour animaux le plus mignon du monde"],
	"Missões e conquistas": ["Missions and achievements", "Missions et succès"],
	"Personagem": ["Character", "Personnage"],
	"Opções": ["Options", "Options"],
	"Apoiar o jogo": ["Support the game", "Soutenir le jeu"],
	"Modo foto": ["Photo mode", "Mode photo"],
	"Menu principal": ["Main menu", "Menu principal"],
	"Voltar": ["Back", "Retour"],
	"Gráficos": ["Graphics", "Graphismes"],
	"Ultra": ["Ultra", "Ultra"],
	"Alta": ["High", "Élevée"],
	"Média": ["Medium", "Moyenne"],
	"Leve": ["Light", "Légère"],
	"Sombras suaves, relva densa, reflexos e brilho": ["Soft shadows, dense grass, reflections and glow", "Ombres douces, herbe dense, reflets et lueur"],
	"Equilíbrio entre beleza e fluidez": ["Balance between looks and smoothness", "Équilibre entre beauté et fluidité"],
	"Sem sombras nem relva, para telemóveis mais fracos": ["No shadows or grass, for weaker phones", "Sans ombres ni herbe, pour les téléphones moins puissants"],
	"Tudo no máximo, para telemóveis topo de gama": ["Everything maxed out, for flagship phones", "Tout au maximum, pour les téléphones haut de gamme"],
	"Música": ["Music", "Musique"],
	"Efeitos e animais": ["Effects and animals", "Effets et animaux"],
	"Vibração": ["Vibration", "Vibration"],
	"Ligada": ["On", "Activée"],
	"Desligada": ["Off", "Désactivée"],
	"Hora do dia": ["Time of day", "Heure de la journée"],
	"Automática": ["Automatic", "Automatique"],
	"Sempre de dia": ["Always day", "Toujours le jour"],
	"Sempre de noite": ["Always night", "Toujours la nuit"],
	"Meteorologia": ["Weather", "Météo"],
	"Variável": ["Changing", "Variable"],
	"Sempre sol": ["Always sunny", "Toujours du soleil"],
	"Câmara": ["Camera", "Caméra"],
	"Vista de cima": ["Top view", "Vue de dessus"],
	"Terceira pessoa": ["Third person", "Troisième personne"],
	"Primeira pessoa": ["First person", "Première personne"],
	"Faixa": ["Track", "Piste"],
	"Sem música": ["No music", "Sans musique"],
	"Passeio no parque": ["Stroll in the park", "Balade au parc"],
	"Tarde no Algarve": ["Afternoon in the Algarve", "Après-midi en Algarve"],
	"Noite calma": ["Calm night", "Nuit calme"],
	"Nome do hotel": ["Hotel name", "Nom de l'hôtel"],
	"O teu nome": ["Your name", "Ton nom"],
	"Pele": ["Skin", "Peau"],
	"Cabelo": ["Hair", "Cheveux"],
	"Camisola": ["Shirt", "Haut"],
	"Calças": ["Trousers", "Pantalon"],
	"Começar a trabalhar": ["Start working", "Commencer à travailler"],
	"Mapa": ["Map", "Carte"],
	"Toca num sítio para ires lá": ["Tap a place to go there", "Touche un endroit pour y aller"],
	"Receção": ["Reception", "Réception"],
	"Átrio": ["Atrium", "Atrium"],
	"Parque": ["Park", "Parc"],
	"Rua": ["Street", "Rue"],
	"Celeiro": ["Barn", "Grange"],
	"Aviário": ["Aviary", "Volière"],
	"Pavilhão Nascente": ["East Wing", "Pavillon Est"],
	"Pavilhão Poente": ["West Wing", "Pavillon Ouest"],
	"Pavilhão redondo com mais 4 quartos, ligado à receção por uma galeria coberta.": ["A round wing with 4 more rooms, linked to reception by a covered gallery.", "Un pavillon rond avec 4 chambres de plus, relié à la réception par une galerie couverte."],
	"Mais 4 quartos no pavilhão do lado poente. Precisa do Pavilhão Nascente cheio.": ["4 more rooms in the west wing. Needs a full East Wing.", "4 chambres de plus dans le pavillon ouest. Le Pavillon Est doit être plein."],
	"Consultório ao lado da galeria nascente. As consultas ficam perto e a metade do preço.": ["A clinic next to the east gallery. Vet visits are close and half price.", "Un cabinet à côté de la galerie est. Consultations proches et à moitié prix."],
	"Edifício com 4 viveiros com rede, atrás do Pavilhão Nascente. Os papagaios só ficam lá.": ["A building with 4 netted aviaries, behind the East Wing. Parrots only stay there.", "Un bâtiment de 4 volières grillagées, derrière le Pavillon Est. Les perroquets ne logent que là."],
	"Celeiro com 6 celas, atrás do Pavilhão Poente. Cavalos e unicórnios só ficam lá.": ["A barn with 6 stalls, behind the West Wing. Horses and unicorns only stay there.", "Une grange de 6 boxes, derrière le Pavillon Ouest. Chevaux et licornes ne logent que là."],
	"Lago gelado ao lado do hotel. Recebe tartarugas e pinguins.": ["A frozen lake next to the hotel. Welcomes turtles and penguins.", "Un lac gelé à côté de l'hôtel. Accueille tortues et pingouins."],
	"Decorar o quarto": ["Decorate the room", "Décorer la chambre"],
	"Chão": ["Floor", "Sol"],
	"Tapete": ["Rug", "Tapis"],
	"Cama": ["Bed", "Lit"],
	"Está a chover: o parque tem lama e os animais voltam sujos.": ["It's raining: the park is muddy and pets come back dirty.", "Il pleut : le parc est boueux et les animaux reviennent sales."],
	"Já parou de chover.": ["The rain has stopped.", "La pluie s'est arrêtée."],
	"Toca no ecrã para voltar": ["Tap the screen to go back", "Touche l'écran pour revenir"],
	"Fotografia guardada em {p}": ["Photo saved in {p}", "Photo enregistrée dans {p}"],
	"Tirar fotografia": ["Take photo", "Prendre une photo"],
	"Fechar": ["Close", "Fermer"],
	"Dinheiro": ["Money", "Argent"],
	"Hóspedes servidos": ["Guests served", "Clients accueillis"],
	"Apagar o progresso e começar de novo?": ["Erase your progress and start over?", "Effacer ta progression et recommencer ?"],
	"Sim, começar de novo": ["Yes, start over", "Oui, recommencer"],
	"Cancelar": ["Cancel", "Annuler"],
	"Idioma": ["Language", "Langue"],
	"O idioma muda já.": ["The language changes right away.", "La langue change tout de suite."],
	"Quartos": ["Rooms", "Chambres"],
	"Fome": ["Hunger", "Faim"],
	"Sede": ["Thirst", "Soif"],
	"Higiene": ["Hygiene", "Hygiène"],
	"Diversão": ["Fun", "Amusement"],
	"Vai à receção e aceita um hóspede.": ["Go to reception and accept a guest.", "Va à la réception et accepte un client."],
	"Constrói uma ala para teres mais quartos.": ["Build a wing to get more rooms.", "Construis une aile pour avoir plus de chambres."],
	"Precisas de {n} quartos.": ["You need {n} rooms.", "Il te faut {n} chambres."],
	"Precisas de: {n}": ["You need: {n}", "Il te faut : {n}"],
	"Construir por {c}": ["Build for {c}", "Construire pour {c}"],
	"Constrói primeiro o quarto {r}.": ["Build room {r} first.", "Construis d'abord la chambre {r}."],
	"{n} quarto(s) livre(s)": ["{n} free room(s)", "{n} chambre(s) libre(s)"],
	"Ninguém à espera. Os próximos donos já vêm a caminho.": ["Nobody waiting. The next owners are on their way.", "Personne n'attend. Les prochains maîtres arrivent."],
	"À espera para voltar: {l}. Aproxima-te para os levares pela trela.": ["Waiting to go back: {l}. Get close to take them on the lead.", "En attente du retour : {l}. Approche-toi pour les prendre en laisse."],
	"à espera no veterinário": ["waiting at the vet", "attend chez le vétérinaire"],
	"Recompensa diária": ["Daily reward", "Récompense quotidienne"],
	"Apoia o desenvolvimento": ["Support development", "Soutiens le développement"],
	"❤️ Gostas do Hotel Patinhas?": ["❤️ Enjoying Hotel Patinhas?", "❤️ Tu aimes Hotel Patinhas ?"],
	"O jogo é gratuito e feito por Rui Amaro. Se te diverte e queres ajudar a mantê-lo e a melhorá-lo, podes deixar um donativo voluntário.": ["The game is free and made by Rui Amaro. If you enjoy it and would like to help keep it going and improve it, you can leave a voluntary donation.", "Le jeu est gratuit et créé par Rui Amaro. S'il t'amuse et que tu veux aider à le maintenir et l'améliorer, tu peux faire un don volontaire."],
	"Escolhe um valor": ["Choose an amount", "Choisis un montant"],
	"Outro valor (€)": ["Other amount (€)", "Autre montant (€)"],
	"Escreve um valor válido": ["Enter a valid amount", "Saisis un montant valide"],
	"Doar {v} € com PayPal": ["Donate €{v} with PayPal", "Donner {v} € avec PayPal"],
	"Abre o PayPal no navegador. O pagamento é feito diretamente no PayPal; o jogo nunca vê nem guarda dados de pagamento.": ["Opens PayPal in the browser. Payment is made directly on PayPal; the game never sees or stores payment details.", "Ouvre PayPal dans le navigateur. Le paiement se fait directement sur PayPal ; le jeu ne voit ni ne stocke aucune donnée de paiement."],
	"A abrir o PayPal… Obrigado! 💙": ["Opening PayPal… Thank you! 💙", "Ouverture de PayPal… Merci ! 💙"],
	"Versão {v}": ["Version {v}", "Version {v}"],
	"Pedido": ["Request", "Demande"],
	"Os cavalos e unicórnios precisam do celeiro.": ["Horses and unicorns need the barn.", "Chevaux et licornes ont besoin de la grange."],
	"Ninguém à espera.": ["Nobody waiting.", "Personne n'attend."],
	"Gravado": ["Saved", "Enregistré"],
	"Uma noite no hotel": ["A night at the hotel", "Une nuit à l'hôtel"],
	"Animais": ["Pets", "Animaux"],
	"Equipa": ["Team", "Équipe"],
	"Vai buscar": ["Pick up", "Va chercher"],
	"Arrasta para olhar à volta": ["Drag to look around", "Glisse pour regarder autour"],
	"Rodar": ["Rotate", "Tourner"],
	"Aproximar": ["Zoom in", "Zoomer"],
	"Afastar": ["Zoom out", "Dézoomer"],
	"Melhorias e ajudantes": ["Upgrades and helpers", "Améliorations et assistants"],
	"A abrir o hotel…": ["Opening the hotel…", "Ouverture de l'hôtel…"],
	"Recolher": ["Collect", "Récupérer"],
	"Estiveste fora {m} min": ["You were away for {m} min", "Tu étais absent {m} min"],
	"Pelagens": ["Coats", "Pelages"],
	"Lago gelado": ["Frozen lake", "Lac gelé"],
	"Gabinete veterinário": ["Vet clinic", "Cabinet vétérinaire"],
	"Sala do pessoal": ["Staff room", "Salle du personnel"],
	"Parque de acrobacias": ["Agility park", "Parc d'agilité"],
	"Veterinário do bairro": ["Neighbourhood vet", "Vétérinaire du quartier"],
}

const HELP := {
	"pt": "🕹️ Usa o joystick para andar. Vai à [b]receção[/b] e aceita os donos que chegam com os animais.\n\n🚪 Os quartos estão à volta do átrio com a fonte. Entra num quarto e usa os botões [b]Ração[/b], [b]Água[/b], [b]Banho[/b], [b]Brincar[/b], [b]Mimos[/b] e [b]Limpar[/b].\n\n🌳 [b]Parque[/b]: o animal segue-te pela trela até ao parque de acrobacias, nas traseiras. Faz o percurso e fica à espera: aproxima-te e leva-o de volta ao quarto.\n\n💶 Quando o dono volta, paga conforme o animal esteve feliz. Gasta o dinheiro em [b]🛠️ Melhorias[/b]: quartos, pavilhões, celeiro, aviário, lago, piscina, gabinete veterinário e ajudantes.\n\n🐴 Cavalos e unicórnios só ficam no [b]celeiro[/b]; papagaios só no [b]aviário[/b].\n\n🤒 Um animal com fome ou num quarto sujo pode adoecer: leva-o ao veterinário com 🩺.\n\n🎯 Há missões diárias, conquistas, álbum de pelagens raras, franquias, concursos, visitas surpresa, clientes habituais e o prémio do mês.\n\n🎥 O botão da câmara troca entre vista de cima, terceira e primeira pessoa. Faz zoom com dois dedos e roda o mundo arrastando um dedo.\n\n🗺️ No mapa tocas num sítio para ires lá num instante.\n\n💾 O jogo guarda sozinho no telemóvel.",
	"en": "🕹️ Use the joystick to walk. Go to [b]reception[/b] and accept the owners arriving with their pets.\n\n🚪 Rooms are around the atrium with the fountain. Walk into a room and use [b]Food[/b], [b]Water[/b], [b]Bath[/b], [b]Play[/b], [b]Cuddles[/b] and [b]Clean[/b].\n\n🌳 [b]Park[/b]: the pet follows you on the lead to the agility park out back. It runs the course and waits: get close and take it back to its room.\n\n💶 When the owner returns, they pay according to how happy the pet was. Spend money in [b]🛠️ Upgrades[/b]: rooms, wings, barn, aviary, lake, pool, vet clinic and helpers.\n\n🐴 Horses and unicorns only stay in the [b]barn[/b]; parrots only in the [b]aviary[/b].\n\n🤒 A hungry pet or a dirty room can make a pet sick: take it to the vet with 🩺.\n\n🎯 Daily missions, achievements, rare-coat album, franchises, contests, surprise visitors, regulars and the monthly award.\n\n🎥 The camera button switches between top, third-person and first-person views. Pinch to zoom and drag to rotate.\n\n🗺️ On the map, tap a place to go there instantly.\n\n💾 The game saves by itself on your phone.",
	"fr": "🕹️ Utilise le joystick pour marcher. Va à la [b]réception[/b] et accepte les maîtres qui arrivent avec leurs animaux.\n\n🚪 Les chambres entourent l'atrium et sa fontaine. Entre dans une chambre et utilise [b]Croquettes[/b], [b]Eau[/b], [b]Bain[/b], [b]Jouer[/b], [b]Câlins[/b] et [b]Nettoyer[/b].\n\n🌳 [b]Parc[/b] : l'animal te suit en laisse jusqu'au parc d'agilité, à l'arrière. Il fait le parcours et attend : approche-toi et ramène-le dans sa chambre.\n\n💶 Quand le maître revient, il paie selon le bonheur de l'animal. Dépense l'argent dans [b]🛠️ Améliorations[/b] : chambres, pavillons, grange, volière, lac, piscine, cabinet vétérinaire et aides.\n\n🐴 Chevaux et licornes logent seulement dans la [b]grange[/b] ; les perroquets seulement dans la [b]volière[/b].\n\n🤒 Un animal affamé ou une chambre sale peut le rendre malade : emmène-le chez le vétérinaire avec 🩺.\n\n🎯 Missions quotidiennes, succès, album des pelages rares, franchises, concours, visites surprises, habitués et prix du mois.\n\n🎥 Le bouton caméra passe de la vue du dessus à la troisième puis à la première personne. Pince pour zoomer et glisse pour tourner.\n\n🗺️ Sur la carte, touche un endroit pour y aller tout de suite.\n\n💾 Le jeu s'enregistre tout seul sur ton téléphone.",
}
