# Hotel Patinhas HD · o jogo: liga o mundo, a simulação, o jogador, a câmara, a interface e a gravação
extends Node3D

const SAVE_PATH := "user://hotel.json"
const SET_PATH := "user://settings.json"

var settings := {"lang": "", "quality": "alta", "colors": "natural", "track": "parque", "mv": 0.55, "fv": 0.8, "time": "auto", "weather": "var", "vib": true, "cam": "top"}
var envn: Env
var world: World
var sim: Sim
var ui: UI
var audio: Audio
var player: HumanModel
var cam: Camera3D
var cam_mode := "top"
var cam_yaw := 0.0
var cam_pitch := deg_to_rad(52.0)
var fp_pitch := 0.0
var cam_dist := 15.0
var cam_focus := Vector3.ZERO
var started := false
var paused_ui := false
var save_t := 0.0
var arrow: Node3D
var touches := {}
var pinch_d := 0.0
var drag_moved := 0.0
var test_mode := ""
var test_t := 0.0
var fps_acc := 0.0
var fps_n := 0
var hour_override := -1.0
var loader: Loader
var loaded := false

func _ready() -> void:
	_load_settings()
	if OS.get_environment("HP_Q") != "":
		settings.quality = OS.get_environment("HP_Q")
	if settings.lang != "":
		D.lang = settings.lang
	Mats.quality = settings.quality
	if OS.get_environment("HP_COLORS") != "":
		settings.colors = OS.get_environment("HP_COLORS")
	Mats.palette = settings.colors if settings.colors in ["colorido", "natural", "real"] else "natural"
	Batch.hi = 1.35 if settings.quality == "ultra" else 1.0
	Batch.lods = settings.quality == "ultra" and OS.get_environment("HP_NOLOD") == ""
	_apply_quality()
	var args0 := OS.get_cmdline_user_args()
	var show_loader := not ("--zoo" in args0) and OS.get_environment("HP_PANEL") == ""
	if show_loader:
		loader = Loader.new()
		add_child(loader)
		loader.set_progress(0.04, D.T("A carregar"))
		await get_tree().process_frame
		await get_tree().process_frame
	audio = Audio.new()
	add_child(audio)
	audio.set_volumes(settings.mv, settings.fv)
	audio.set_track(settings.track)
	envn = Env.new()
	add_child(envn)
	await _step(0.1, D.T("A pintar o céu"))
	envn.build(settings.quality)
	world = World.new()
	add_child(world)
	if loader:
		world.progress = func(f, txt): loader.set_progress(f, txt)
	await world.build()
	await _step(0.76, D.T("A chamar os hóspedes"))
	player = HumanModel.new()
	add_child(player)
	cam = Camera3D.new()
	cam.fov = 52.0
	cam.far = 400.0
	add_child(cam)
	var save := _load_save()
	sim = Sim.new()
	add_child(sim)
	sim.sound.connect(func(n, p):
		audio.play(n, p)
		if settings.vib and n in ["coin", "fanfare", "sick"]:
			Input.vibrate_handheld(35 if n == "coin" else 80)
	)
	var look: Dictionary = save.get("char", {}).get("look", {}) if save.has("char") else {}
	_make_player(look)
	player.position = Vector3(0, 0, 13.5)
	sim.setup(world, save, player)
	world.movers.append(player)
	await _step(0.88, D.T("A preparar a receção"))
	ui = UI.new()
	add_child(ui)
	ui.build(self)
	_make_arrow()
	cam_mode = settings.cam
	_update_hour(0.0)
	loaded = true
	if loader:
		# deixa o telemóvel preparar os gráficos por trás do ecrã de carregamento
		await _step(0.95, D.T("A preparar os gráficos"))
		for k in 4:
			await get_tree().process_frame
		loader.finish()
	var args := OS.get_cmdline_user_args()
	if OS.get_environment("HP_PANEL") != "":
		start_game(false)
		sim.S.money = 5000
		_panel_shots(OS.get_environment("HP_PANEL").split(","))
		return
	if "--zoo" in args:
		_zoo()
		return
	if "--test" in args:
		test_mode = "test"
	elif "--shot" in args:
		test_mode = "shot"
	if test_mode != "":
		if OS.get_environment("HP_SAVE") != "":
			var occ := 0
			for g in sim.S.rooms:
				if g != null:
					occ += 1
			print("LOADED money=%d served=%d rooms=%d occupied=%d staff=%d" % [sim.S.money, sim.S.served, sim.S.up.rooms, occ, sim.S.staff.size()])
		if OS.get_environment("HP_RICH") != "":
			sim.S.money = 60000
			sim.S.rep = 88
		if OS.get_environment("HP_SCALE") != "":
			Engine.time_scale = float(OS.get_environment("HP_SCALE"))
		start_game(false)
		return
	ui.open("menu")
	if sim.S.char.get("name", "") == "" and int(sim.S.served) == 0:
		ui.open("char")

func _step(f: float, txt: String) -> void:
	if loader:
		loader.set_progress(f, txt)
		await get_tree().process_frame
		await get_tree().process_frame

func _make_player(look: Dictionary) -> void:
	if look.is_empty():
		look = {"skin": "#e8b68e", "hair": "#5a3a22", "style": 1, "shirt": "#ff7a35", "pants": "#2f4a7a", "shoes": "#f4f4f4", "female": false, "hat": "", "h": 1.0}
	var pos := Vector3(0, 0, 13.5)
	var yaw := PI
	if player:
		pos = player.position
		yaw = player.rotation.y
		world.movers.erase(player)
		player.queue_free()
	player = HumanModel.new()
	add_child(player)
	look = look.duplicate()
	look.h = 1.0
	player.setup(look)
	player.position = pos
	player.rotation.y = yaw
	if sim:
		sim.player = player
		world.movers.append(player)
	player.visible = cam_mode != "first"

func rebuild_player() -> void:
	_make_player(sim.S.char.look)

func _apply_quality() -> void:
	var vp := get_viewport()
	match settings.quality:
		"ultra":
			vp.scaling_3d_scale = 1.0
			vp.msaa_3d = Viewport.MSAA_4X
		"alta":
			vp.scaling_3d_scale = 0.9
			vp.msaa_3d = Viewport.MSAA_2X
		"media":
			vp.scaling_3d_scale = 0.8
			vp.msaa_3d = Viewport.MSAA_DISABLED
		_:
			vp.scaling_3d_scale = 0.65
			vp.msaa_3d = Viewport.MSAA_DISABLED
	Engine.max_fps = 60

# ===================== gravação =====================
func _load_settings() -> void:
	if FileAccess.file_exists(SET_PATH):
		var j = JSON.parse_string(FileAccess.get_file_as_string(SET_PATH))
		if typeof(j) == TYPE_DICTIONARY:
			for k in j:
				settings[k] = j[k]

func _save_settings() -> void:
	var f := FileAccess.open(SET_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(settings))

func _load_save() -> Dictionary:
	if FileAccess.file_exists(SAVE_PATH):
		var j = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
		if typeof(j) == TYPE_DICTIONARY:
			return j
	return Sim.fresh()

func save_game() -> void:
	if sim == null or (test_mode == "test" and OS.get_environment("HP_SAVE") == ""):
		return
	var f := FileAccess.open(SAVE_PATH + ".tmp", FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(sim.snapshot()))
	f.close()
	DirAccess.rename_absolute(ProjectSettings.globalize_path(SAVE_PATH + ".tmp"), ProjectSettings.globalize_path(SAVE_PATH))

func _notification(what: int) -> void:
	if not loaded:
		return
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if started:
			save_game()
		_save_settings()
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if ui.is_open():
			ui.close()
		else:
			ui.open("menu")

func set_setting(k: String, v, rerender := true) -> void:
	settings[k] = v
	match k:
		"lang":
			D.lang = v
			world.set_sign("🐾 " + sim.hotel_name())
		"quality", "colors":
			_save_settings()
			save_game()
			get_tree().reload_current_scene()
			return
		"track":
			audio.set_track(v)
		"mv", "fv":
			audio.set_volumes(settings.mv, settings.fv)
		"time", "weather":
			pass
	_save_settings()

# ===================== jogo =====================
func start_game(_newg: bool) -> void:
	if not started:
		started = true
		var back = sim.welcome_back()
		if back != null and test_mode == "":
			ui.show_back(back)
	set_paused_ui(false)

func new_game() -> void:
	var look: Dictionary = sim.S.char.get("look", {})
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		var s := Sim.fresh()
		s.char.look = look
		f.store_string(JSON.stringify(s))
		f.close()
	get_tree().reload_current_scene()

func to_title() -> void:
	save_game()
	get_tree().reload_current_scene()

func set_paused_ui(on: bool) -> void:
	paused_ui = on

func travel(pos: Vector3) -> void:
	player.position = Vector3(pos.x, 0, pos.z)
	sim.player_trail.clear()
	for id in sim.pets:
		var e = sim.pets[id]
		if e.leash != null and e.leash.kind == "player":
			e.pos = player.position + Vector3(0.6, 0, 0.6)
	if sim.mine != null:
		sim.mine.pos = player.position + Vector3(0.8, 0, 0.8)

# ===================== câmara =====================
func cycle_camera() -> void:
	var order := ["top", "third", "first"]
	set_camera(order[(order.find(cam_mode) + 1) % 3])

func set_camera(m: String) -> void:
	cam_mode = m
	settings.cam = m
	player.visible = m != "first"
	if m == "first":
		cam_yaw = player.rotation.y + PI
		fp_pitch = 0.0
	_save_settings()

func zoom(f: float) -> void:
	cam_dist = clamp(cam_dist * f, 5.0, 84.0)

func rotate_cam(a: float) -> void:
	cam_yaw += a

func _update_camera(dt: float) -> void:
	var p := player.position
	cam_focus = cam_focus.lerp(p, min(1.0, dt * 6.0))
	match cam_mode:
		"top":
			var off := Vector3(sin(cam_yaw), 0, cos(cam_yaw)) * cos(cam_pitch) * cam_dist + Vector3(0, sin(cam_pitch) * cam_dist, 0)
			cam.position = cam_focus + off
			cam.look_at(cam_focus + Vector3(0, 0.8, 0), Vector3.UP)
		"third":
			var d: float = clamp(cam_dist * 0.32, 3.2, 9.0)
			var off2 := Vector3(sin(cam_yaw), 0, cos(cam_yaw)) * d + Vector3(0, d * 0.42 + 0.6, 0)
			cam.position = cam.position.lerp(cam_focus + off2, min(1.0, dt * 8.0))
			cam.look_at(cam_focus + Vector3(0, 1.3, 0), Vector3.UP)
		"first":
			cam.position = p + Vector3(0, 1.62, 0) + Vector3(sin(cam_yaw), 0, cos(cam_yaw)) * -0.05
			cam.rotation = Vector3(fp_pitch, cam_yaw + PI, 0)

func _unhandled_input(ev: InputEvent) -> void:
	if not loaded:
		return
	if ui.is_open() or ui.photo_mode and not (ev is InputEventScreenDrag or ev is InputEventMouseMotion):
		pass
	if ev is InputEventScreenTouch:
		if ev.pressed:
			touches[ev.index] = ev.position
		else:
			touches.erase(ev.index)
		pinch_d = 0.0
		if touches.size() == 2:
			var ps: Array = touches.values()
			pinch_d = ps[0].distance_to(ps[1])
	elif ev is InputEventScreenDrag:
		touches[ev.index] = ev.position
		if touches.size() >= 2:
			var ps2: Array = touches.values()
			var d: float = ps2[0].distance_to(ps2[1])
			if pinch_d > 0:
				cam_dist = clamp(cam_dist * pinch_d / max(d, 1.0), 5.0, 84.0)
			pinch_d = d
		else:
			_drag(ev.relative)
	elif ev is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and not DisplayServer.is_touchscreen_available():
		_drag(ev.relative)
	elif ev is InputEventMouseButton and ev.pressed:
		if ev.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom(0.9)
		elif ev.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom(1.1)
	elif ev is InputEventKey and ev.pressed and ev.keycode == KEY_ESCAPE:
		if ui.is_open():
			ui.close()
		else:
			ui.open("menu")

func _drag(rel: Vector2) -> void:
	var k := 0.006
	cam_yaw -= rel.x * k
	if cam_mode == "first":
		fp_pitch = clamp(fp_pitch - rel.y * k, -1.2, 1.2)
	elif cam_mode == "top":
		cam_pitch = clamp(cam_pitch + rel.y * k * 0.6, deg_to_rad(28), deg_to_rad(80))

# ===================== seta-guia =====================
func _make_arrow() -> void:
	arrow = Node3D.new()
	add_child(arrow)
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.32
	cm.bottom_radius = 0.0
	cm.height = 0.6
	mi.mesh = cm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color("#ffd23a")
	m.emission_enabled = true
	m.emission = Color("#ffb000")
	m.emission_energy_multiplier = 1.4
	mi.material_override = m
	mi.position = Vector3(0, 2.4, 0)
	arrow.add_child(mi)
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.55
	tm.outer_radius = 0.7
	ring.mesh = tm
	ring.material_override = m
	ring.position = Vector3(0, 0.05, 0)
	ring.scale = Vector3(1, 0.2, 1)
	arrow.add_child(ring)
	arrow.visible = false

# ===================== ciclo =====================
func _update_hour(dt: float) -> void:
	var h := 12.0
	match settings.time:
		"dia":
			h = 11.0
		"noite":
			h = 22.5
		_:
			var t := Time.get_time_dict_from_system()
			h = t.hour + t.minute / 60.0 + t.second / 3600.0
	if hour_override >= 0:
		h = hour_override
	envn.set_hour(h)
	sim.day_hour = h
	world.set_night(envn.night)

func context() -> String:
	var p := player.position
	if Vector2(p.x - World.DESK.x, p.z - (World.DESK.z + 2.6)).length() < 2.0:
		return "desk"
	var i := world.room_at(p)
	if i >= 0:
		return "room%d" % i
	for k in D.NROOMS:
		if k < world.room_nodes.size() and world.room_nodes[k] != null and p.distance_to(world.room_point(k, "out")) < 0.9:
			return "room%d" % k
	if sim.in_park(p):
		return "park"
	return ""

var hour_t := 0.0
func _process(dt: float) -> void:
	if not loaded:
		return
	dt = min(dt, 0.1 * Engine.time_scale)
	# jogador
	var mv := Vector2.ZERO
	if not paused_ui and started:
		mv = ui.joy_vec
		var kv := Vector2(Input.get_axis("ui_left", "ui_right"), Input.get_axis("ui_up", "ui_down"))
		if Input.is_key_pressed(KEY_A):
			kv.x -= 1
		if Input.is_key_pressed(KEY_D):
			kv.x += 1
		if Input.is_key_pressed(KEY_W):
			kv.y -= 1
		if Input.is_key_pressed(KEY_S):
			kv.y += 1
		if kv.length() > 0.1:
			mv = kv.normalized()
	var moving := mv.length() > 0.12
	var speed: float = 3.4 * min(1.0, mv.length() * 1.2)
	if moving:
		var fwd := Vector3(-sin(cam_yaw), 0, -cos(cam_yaw))
		var right := Vector3(cos(cam_yaw), 0, -sin(cam_yaw))
		var d: Vector3 = (right * mv.x - fwd * mv.y).normalized() * speed * dt
		player.position = world.slide(player.position, d, 0.3)
		player.position.y = 0
		player.rotation.y = lerp_angle(player.rotation.y, atan2(d.x, d.z), min(1.0, dt * 12.0))
		if cam_mode == "third" and touches.size() == 0:
			cam_yaw = lerp_angle(cam_yaw, player.rotation.y + PI, dt * 1.5)
	var led = sim.leading_pet("player")
	player.animate(dt, moving, speed, "lead" if led != null else "")
	# mundo
	if started and test_mode != "shot":
		sim.update(dt)
		world.town.update(dt, player.position)
	world.update_doors(dt)
	_update_camera(dt)
	world.update_roofs(dt, cam_dist if cam_mode == "top" else 0.0, player.position, cam_mode != "top")
	envn.update(dt, cam.global_position, player.position, world.lamps)
	envn.set_rain(sim.raining)
	audio.focus = player.position
	hour_t -= dt
	if hour_t <= 0:
		hour_t = 2.0
		_update_hour(dt)
		sim.weather_tick(settings.weather == "var")
	# seta
	var at = sim.arrow_target()
	arrow.visible = at != null
	if at != null:
		arrow.position = Vector3(at.x, sin(Time.get_ticks_msec() / 300.0) * 0.15, at.z)
		arrow.rotation.y += dt * 2.0
	# interface
	if started:
		ui.update_ctx(context() if not ui.photo_mode else "")
	ui.tick(dt)
	save_t += dt
	if save_t > 20.0 and started:
		save_t = 0.0
		save_game()
	if test_mode == "test":
		_test_tick(dt)
		_shots()

# ===================== teste automático (só no computador) =====================
var bot_t := 0.0
var bot_target = null
var bot_mode := "idle"
var bot_room := -1
var bot_path: Array = []
var bot_path_to = null
var real_t0 := 0
var frames_n := 0
func _test_tick(dt: float) -> void:
	test_t += dt
	frames_n += 1
	bot_t -= dt
	if bot_target != null:
		var d: Vector3 = bot_target - player.position
		d.y = 0
		if d.length() < 0.4:
			bot_target = null
		else:
			if bot_path.is_empty() or bot_path_to != bot_target:
				bot_path = world.find_path(player.position, bot_target)
				bot_path_to = bot_target
			if not bot_path.is_empty() and player.position.distance_to(bot_path[0]) < 0.3:
				bot_path.remove_at(0)
			var path := bot_path
			if not path.is_empty():
				var nx: Vector3 = path[0]
				var dd := nx - player.position
				dd.y = 0
				if dd.length() > 0.01:
					player.position = world.slide(player.position, dd.normalized() * min(dd.length(), 3.4 * dt), 0.3)
					player.rotation.y = atan2(dd.x, dd.z)
	if bot_t > 0:
		return
	bot_t = 0.7
	var S: Dictionary = sim.S
	for q in sim.queue:
		if sim.free_room_for(q.sp) >= 0 and Vector2(player.position.x, player.position.z - 11.0).length() < 2.5:
			sim.accept(int(q.id))
	for id in ["rooms", "rooms", "h_comida", "beds", "ads", "h_banho", "pav_e", "estabulo", "aviario", "clinica", "h_vet", "h_brincar", "h_rece", "lago", "piscina", "luzes", "decor", "pav_w", "suite", "feeder", "fonte"]:
		var u: Dictionary = D.UP_BY_ID[id]
		if sim.can_buy(u)[0]:
			sim.buy(id)
			break
	if bot_target != null:
		return
	if bot_mode == "park":
		var led = sim.leading_pet("player")
		if led != null and led.phase == "go":
			bot_target = Vector3(0, 0, -19)
			return
		for id in sim.pets:
			var e = sim.pets[id]
			if e.trip and e.phase == "wait" and e.escort == null and e.dest != "vet":
				bot_target = e.pos
				return
		if led != null and led.phase == "back":
			bot_target = world.room_point(sim.room_of(led), "center")
			return
		bot_mode = "idle"
	if not sim.queue.is_empty() and rng_bot() < 0.5:
		bot_target = Vector3(0, 0, 11.0)
		return
	var best := -1
	var bv := 60.0
	var bk := ""
	for i in D.NROOMS:
		var g = S.rooms[i]
		if g == null:
			continue
		var e2 = sim.pets.get(int(g.id))
		if e2 != null and e2.trip:
			continue
		for k in ["fome", "sede", "banho", "diver"]:
			if g[k] < bv:
				bv = g[k]
				best = i
				bk = k
		if int(g.get("mess", 0)) > 1:
			best = i
			bk = "limpar"
			bv = 0
	if best >= 0:
		if world.in_room(best, player.position):
			if bk == "diver" and rng_bot() < 0.4:
				sim.care(best, "parque")
				bot_mode = "park"
			else:
				sim.care(best, bk)
				sim.care(best, "mimos")
		else:
			bot_target = world.room_point(best, "center")
	if test_t - last_print >= 30.0:
		last_print = test_t
		print("t=%d €%d ★%d served=%d rooms=%d staff=%d queue=%d pets=%d fps=%.0f" % [test_t, S.money, sim.stars(), S.served, S.up.rooms, S.staff.size(), sim.queue.size(), sim.pets.size(), frames_n * 1000000.0 / max(1, Time.get_ticks_usec() - real_t0)])
		real_t0 = Time.get_ticks_usec()
		frames_n = 0
		var orphan := []
		for id in sim.pets:
			var e = sim.pets[id]
			if sim.guest_of(e) == null:
				var inq := false
				for q in sim.queue:
					if int(q.id) == id:
						inq = true
				if not inq:
					orphan.append("%d:%s:%s:%s" % [id, e.phase, e.path.size(), "L" if e.leash != null else "-"])
		print("  orphans ", orphan, " leavers ", sim.leavers.size())
		if OS.get_environment("HP_COUNT") != "":
			var cnt := {}
			for gi in get_tree().root.find_children("*", "GeometryInstance3D", true, false):
				var nm: String = gi.name.rstrip("0123456789@")
				cnt[nm] = cnt.get(nm, 0) + 1
			print("  nodes ", cnt)
		print("  draws=%d objs=%d prims=%d" % [Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME), Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME), Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)])
		fps_acc = 0
		fps_n = 0
	var limit := float(OS.get_environment("HP_TEST_SECS")) if OS.get_environment("HP_TEST_SECS") != "" else 600.0
	if test_t > limit:
		print("TEST DONE errors-check")
		save_game()
		get_tree().quit()

var shot_i := 0
var free_custom := false
var SHOTS := [[60.0, "top", 15.0, 11.0], [64.0, "third", 15.0, 10.0], [68.0, "first", 15.0, 15.0], [72.0, "top", 40.0, 9.0], [76.0, "top", 12.0, 22.0], [80.0, "third", 12.0, 18.5]]
var FREE_SHOTS := [[Vector3(-20, 9, -12), Vector3(-32, 0, -30), 11.0], [Vector3(20, 8, -14), Vector3(31, 0, -27), 11.0], [Vector3(14, 10, 4), Vector3(27, 0, -3), 11.0], [Vector3(4, 7, -14), Vector3(0, 0, -26), 16.0], [Vector3(-6, 4.5, 2.5), Vector3(-8, 0, -6), 12.0], [Vector3(6, 3.5, 20), Vector3(0, 1, 30), 13.0], [Vector3(0, 70, 55), Vector3(0, 0, -4), 12.0], [Vector3(-3, 3, 6), Vector3(-9, 0.4, -4), 20.5], ["pet", "cao", 11.0], ["pet", "gato", 11.0], ["pet", "cavalo", 11.0], ["pet", "papagaio", 11.0], ["pet", "coelho", 11.0], ["pet", "unicornio", 11.0], ["pet", "pinguim", 11.0], ["pet", "raposa", 11.0], ["human", "", 11.0], ["tree", "", 11.0]]
func _shots() -> void:
	if OS.get_environment("HP_SHOTS") == "free":
		if OS.get_environment("HP_FREE") != "" and not free_custom:
			free_custom = true
			var custom := []
			for spec in OS.get_environment("HP_FREE").split(";"):
				if spec.begins_with("pet:") or spec.begins_with("human") or spec.begins_with("tree"):
					var parts := spec.split(":")
					custom.append([parts[0], parts[1] if parts.size() > 1 else "", 11.0])
				else:
					var v := spec.split_floats(",")
					if v.size() >= 7:
						custom.append([Vector3(v[0], v[1], v[2]), Vector3(v[3], v[4], v[5]), v[6]])
			FREE_SHOTS = custom
		if shot_i >= FREE_SHOTS.size() or test_t < 70.0 + shot_i * 2.0:
			return
		var fs: Array = FREE_SHOTS[shot_i]
		cam_mode = "free"
		ui.visible = false
		if typeof(fs[0]) == TYPE_STRING:
			var tgt = null
			var hh := 0.6
			if fs[0] == "pet":
				for id in sim.pets:
					var g = sim.guest_of(sim.pets[id])
					if g != null and (g.sp == fs[1] or D.SPECIES[g.sp].get("base", "") == fs[1]) and not sim.pets[id].trip:
						tgt = sim.pets[id].m
						hh = sim.pets[id].m.height
						break
			elif fs[0] == "human":
				for k in sim.staff_ents:
					tgt = sim.staff_ents[k].m
					hh = 1.7
					break
			elif fs[0] == "tree":
				cam.position = Vector3(-14, 2.5, 22)
				cam.look_at(Vector3(-20, 2.2, 26))
			if tgt != null:
				var fwd: Vector3 = tgt.global_transform.basis.z
				cam.position = tgt.global_position + fwd * (hh * 1.6 + 0.6) + Vector3(0, hh * 0.9 + 0.3, 0) + tgt.global_transform.basis.x * hh * 0.8
				cam.look_at(tgt.global_position + Vector3(0, hh * 0.45, 0))
			elif fs[0] != "tree":
				shot_i += 1
				return
		else:
			cam.position = fs[0]
			cam.look_at(fs[1])
		hour_override = fs[2]
		_update_hour(0)
		world.update_roofs(1.0, 99.0, Vector3(500, 0, 500), false)
		shot_i += 1
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/tmp/hpfree_%d.png" % shot_i)
		var nh := 0
		var geo_cnt := {}
		var npet := 0
		var ngi := 0
		for n in get_tree().root.find_children("*", "Node3D", true, false):
			if n is HumanModel:
				nh += 1
			elif n is PetModel:
				npet += 1
			elif n is GeometryInstance3D and n.is_visible_in_tree():
				ngi += 1
				var path := str(n.get_path()).split("/")
				var key := "/".join(path.slice(2, 7)).rstrip("0123456789")
				var tri := 0
				if n is MeshInstance3D and n.mesh is ArrayMesh:
					for si in n.mesh.get_surface_count():
						var il: int = n.mesh.surface_get_array_index_len(si)
						tri += (il if il > 0 else n.mesh.surface_get_array_len(si)) / 3
				elif n is MultiMeshInstance3D:
					var mmm: MultiMesh = n.multimesh
					tri = mmm.visible_instance_count * mmm.mesh.surface_get_array_len(0) / 3
				geo_cnt[key] = geo_cnt.get(key, 0) + tri
		print("humans=%d pets=%d visible_geo=%d" % [nh, npet, ngi])
		var ltxt := {}
		for l in world.find_children("*", "Label3D", false, false):
			ltxt[l.text] = ltxt.get(l.text, 0) + 1
		print("   LABELS ", ltxt)
		var stn := {}
		for c in world.static_root.get_children():
			stn[c.name.rstrip("0123456789@")] = stn.get(c.name.rstrip("0123456789@"), 0) + 1
		print("   STATIC ", stn)
		var top_keys := geo_cnt.keys()
		top_keys.sort_custom(func(x, y): return geo_cnt[x] > geo_cnt[y])
		for kk in top_keys.slice(0, 25):
			print("   ", kk, " ", geo_cnt[kk])
		print("free shot ", shot_i, "  draws=%d objs=%d prims=%d" % [Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME), Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME), Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)])
		return
	if OS.get_environment("HP_SHOTS") == "" or shot_i >= SHOTS.size():
		return
	var sh: Array = SHOTS[shot_i]
	if test_t >= sh[0] - 1.5 and cam_mode != sh[1]:
		set_camera(sh[1])
		cam_dist = sh[2]
		hour_override = sh[3]
		_update_hour(0)
	if test_t >= sh[0]:
		shot_i += 1
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/tmp/hpshot_%d.png" % shot_i)
		print("shot ", shot_i)

var _brng := RandomNumberGenerator.new()
var last_print := -100.0
func rng_bot() -> float:
	return _brng.randf()


# ===================== montra dos modelos (só para verificar o aspeto) =====================
func _zoo() -> void:
	ui.visible = false
	hour_override = 10.5
	_update_hour(0)
	var x := -9.0
	var all := []
	for sp in D.SPECIES_ORDER:
		var m := PetModel.new()
		add_child(m)
		m.setup(sp, 0)
		all.append(m)
	var xs := 0.0
	for m in all:
		m.position = Vector3(4.0 + xs, 0, 19.0)
		m.rotation.y = 0.5
		xs += max(0.8, m.height * 0.9)
	for k in 3:
		var h := HumanModel.new()
		add_child(h)
		var r := RandomNumberGenerator.new()
		r.seed = k + 3
		var lk := HumanModel.random_look(r)
		lk.hat = ["", "chef", "vet"][k]
		h.setup(lk)
		h.position = Vector3(3.2 - k * 0.0, 0, 20.5 + k * 0.9)
		h.rotation.y = 0.4
	cam_mode = "free"
	for shot in [[Vector3(7, 1.2, 22.0), Vector3(7, 0.3, 19)], [Vector3(11.5, 1.4, 23.0), Vector3(11.5, 0.5, 19)], [Vector3(4.6, 1.5, 23.5), Vector3(3.6, 0.9, 20.5)]]:
		cam.position = shot[0]
		cam.look_at(shot[1])
		for f in 6:
			for m in all:
				m.animate(0.05, f > 2, 1.5, "")
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/tmp/hpzoo_%d.png" % [int(shot[0].x * 10)])
	get_tree().quit()


func _panel_shots(names: Array) -> void:
	hour_override = 11.0
	_update_hour(0)
	for n in names:
		if n == "ctxroom":
			ui.close()
			player.position = world.room_point(0, "center")
		elif n == "ctxdesk":
			ui.close()
			player.position = Vector3(0, 0, 11.2)
		else:
			ui.open(n)
		for f in 30:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/tmp/hppanel_%s.png" % n)
	get_tree().quit()
