# Hotel Patinhas HD · animais 3D com pelo, olhos brilhantes e animação (andar, trotar, comer, dormir, abanar a cauda)
class_name PetModel
extends Node3D

var sp := "cao"
var base := "cao"
var coat := 0
var body: Node3D      # tronco (sobe e desce)
var head: Node3D
var neck: Node3D
var tail: Array = []  # segmentos da cauda
var legs: Array = []  # {hip, knee, side, front}
var wings: Array = []
var ears: Array = []
var eyes: Array = []
var phase := 0.0
var t := 0.0
var height := 0.5
var body_h := 0.4
var act := ""
var moving := false
var speed := 0.0
var happy := false
var lie := 0.0
var look := 0.0
var look_t := 0.0
var kind := "quad"
var _batches := {}
var c_main: Color
var c_dark: Color
var c_light: Color
var size_k := 1.0

func setup(species: String, coat_idx: int, collar := "") -> void:
	sp = species
	var S: Dictionary = D.SPECIES.get(sp, D.SPECIES.cao)
	base = S.get("base", sp)
	coat = coat_idx
	var coats: Array = D.COATS.get(sp, D.COATS.cao)
	var c: Array = coats[clamp(coat_idx, 0, coats.size() - 1)]
	c_main = Color(c[0])
	c_dark = Color(c[1])
	c_light = Color(c[2])
	body = Node3D.new()
	add_child(body)
	match base:
		"cao":
			var k := 1.0
			if sp == "agua":
				k = 0.95
			elif sp == "serra":
				k = 1.3
			_quad({"len": 0.62 * k, "h": 0.5 * k, "br": 0.16 * k, "bw": 0.14 * k, "leg": 0.042 * k, "head": 0.105 * k, "mlen": 0.12 * k, "mr": 0.052 * k, "ears": "flop" if sp != "serra" else "small", "tail": "wag", "fluffy": sp == "serra" or sp == "agua"})
		"gato":
			var k2 := 1.0
			if sp == "persa":
				k2 = 1.1
			elif sp == "lince":
				k2 = 1.65
			_quad({"len": 0.42 * k2, "h": 0.27 * k2, "br": 0.1 * k2, "bw": 0.085 * k2, "leg": 0.026 * k2, "head": 0.072 * k2, "mlen": 0.035 * k2 if sp != "persa" else 0.02 * k2, "mr": 0.034 * k2, "ears": "tuft" if sp == "lince" else "point", "tail": "bob" if sp == "lince" else "long", "fluffy": sp == "persa", "spots": sp == "lince"})
		"raposa":
			_quad({"len": 0.55, "h": 0.36, "br": 0.11, "bw": 0.09, "leg": 0.028, "head": 0.08, "mlen": 0.11, "mr": 0.032, "ears": "big", "tail": "plume", "socks": true})
		"coelho":
			_quad({"len": 0.3, "h": 0.15, "br": 0.11, "bw": 0.095, "leg": 0.03, "head": 0.075, "mlen": 0.03, "mr": 0.04, "ears": "long", "tail": "puff", "hop": true})
		"hamster":
			_hamster()
		"papagaio":
			_parrot()
		"pinguim":
			_penguin()
		"tartaruga":
			_turtle()
		"cavalo", "unicornio":
			_horse(base == "unicornio")
		_:
			_quad({"len": 0.62, "h": 0.5, "br": 0.16, "bw": 0.14, "leg": 0.042, "head": 0.105, "mlen": 0.12, "mr": 0.052, "ears": "flop", "tail": "wag"})
	if collar != "":
		_collar(Color(collar))
	_commit()
	for gi in find_children("*", "GeometryInstance3D", true, false):
		gi.visibility_range_end = 70.0

# ---------- ajudantes de construção ----------
func _b(n: Node3D) -> Batch:
	if not _batches.has(n):
		_batches[n] = Batch.new()
	return _batches[n]

func _commit() -> void:
	for n in _batches:
		_batches[n].commit(n, true, "Part")
	_batches.clear()

func _fur(c: Color) -> Material:
	return Mats.fur(c)

func _ell(n: Node3D, r: Vector3, pos: Vector3, mat: Material, rot := Vector3.ZERO, seg := 16) -> void:
	var m: float = max(r.x, r.z)
	var bs := Basis.from_euler(rot) * Basis().scaled(Vector3(r.x / m, 1, r.z / m))
	_b(n).add(Batch.sphere_mesh(m, r.y * 2.0, seg), Transform3D(bs, pos), mat)

func _cyl(n: Node3D, r1: float, r2: float, h: float, pos: Vector3, mat: Material, rot := Vector3.ZERO, seg := 12) -> void:
	_b(n).add(Batch.cyl_mesh(r1, r2, h, seg), Transform3D(Basis.from_euler(rot), pos), mat)

func _pivot(parent: Node3D, pos: Vector3) -> Node3D:
	var p := Node3D.new()
	p.position = pos
	parent.add_child(p)
	return p

const IRIS := {"gato": "#8fae3a", "raposa": "#c7862a", "cao": "#6b4423", "coelho": "#4a2a1a", "cavalo": "#3a2416", "unicornio": "#5a7fd0"}

func _eye(n: Node3D, pos: Vector3, r: float, side: float) -> void:
	var e := _pivot(n, pos)
	_ell(e, Vector3(r, r, r * 0.8), Vector3.ZERO, Mats.glossy("#1a1410", 0.08, 0.0, true), Vector3.ZERO, 12)
	var hz := 0.62
	if Mats.quality == "ultra" and IRIS.has(base):
		_b(e).add_c(Batch.sphere_mesh(r * 0.78, r * 0.5, 12), Transform3D(Basis().scaled(Vector3(1, 1, 0.32)), Vector3(0, 0, r * 0.6)), Color(IRIS[base]))
		var slit := base == "gato"
		_b(e).add_c(Batch.sphere_mesh(r * 0.42, r * (1.24 if slit else 0.84), 10), Transform3D(Basis().scaled(Vector3(0.43 if slit else 1.0, 1, 0.48)), Vector3(0, 0, r * 0.72)), Color("#050404"))
		hz = 0.86
	_ell(e, Vector3(r * 0.32, r * 0.32, r * 0.2), Vector3(side * r * 0.25, r * 0.35, r * hz), Mats.emissive("#ffffff", 0.6), Vector3.ZERO, 6)
	eyes.append(e)

# ---------- quadrúpedes (cão, gato, raposa, coelho e raças) ----------
func _quad(p: Dictionary) -> void:
	kind = "quad"
	var L: float = p.len
	var H: float = p.h
	var br: float = p.br
	var bw: float = p.bw
	var lr: float = p.leg
	var hr: float = p.head
	var hop: bool = p.get("hop", false)
	var fluffy: bool = p.get("fluffy", false)
	var fm := _fur(c_main)
	var fl := _fur(c_light)
	var fd := _fur(c_dark)
	var leg_len: float = max(H - br * 0.9, 0.06)
	body_h = leg_len + br * 0.75
	height = body_h + br + hr * 1.6
	body.position = Vector3(0, body_h, 0)
	var fz := 1.15 if fluffy else 1.0
	# tronco: peito, barriga e anca
	_ell(body, Vector3(bw * fz, br * fz, L * 0.36), Vector3(0, 0, L * 0.12), fm)
	_ell(body, Vector3(bw * 0.95 * fz, br * 0.92 * fz, L * 0.3), Vector3(0, 0.0, -L * 0.18), fm)
	_ell(body, Vector3(bw * 0.7, br * 0.55, L * 0.38), Vector3(0, -br * 0.38, 0.02), fl)
	if p.get("spots", false):
		var dm := _fur(c_dark)
		for k in 9:
			_ell(body, Vector3(0.02, 0.02, 0.026) * (H / 0.27), Vector3((k % 3 - 1) * bw * 0.8, br * 0.55 + (k % 2) * 0.02, -L * 0.3 + k * L * 0.07), dm)
	# pescoço e cabeça
	neck = _pivot(body, Vector3(0, br * 0.45, L * 0.38))
	_ell(neck, Vector3(bw * 0.62 * fz, br * 0.7, br * 0.7), Vector3(0, br * 0.25, br * 0.15), fm, Vector3(-0.5, 0, 0))
	head = _pivot(neck, Vector3(0, br * 0.7, br * 0.55))
	_ell(head, Vector3(hr * 0.95, hr * 0.88, hr), Vector3(0, 0, 0), fm)
	var ml: float = p.mlen
	var mr: float = p.mr
	if ml > 0.03:
		_ell(head, Vector3(mr * 1.05, mr * 0.9, ml * 0.65 + mr * 0.5), Vector3(0, -hr * 0.3, hr * 0.62 + ml * 0.35), fl)
		_ell(head, Vector3(mr * 0.55, mr * 0.42, mr * 0.45), Vector3(0, -hr * 0.12, hr * 0.62 + ml * 0.82 + mr * 0.2), Mats.glossy("#1b1512", 0.2))
	else:
		_ell(head, Vector3(mr, mr * 0.75, mr * 0.8), Vector3(0, -hr * 0.32, hr * 0.78), fl)
		_ell(head, Vector3(mr * 0.35, mr * 0.25, mr * 0.2), Vector3(0, -hr * 0.18, hr * 0.98), Mats.glossy("#d97a8a", 0.3))
	for s in [-1.0, 1.0]:
		_eye(head, Vector3(s * hr * 0.42, hr * 0.22, hr * 0.78), hr * 0.17, s)
	# orelhas
	var ek: String = p.ears
	for s in [-1.0, 1.0]:
		var e := _pivot(head, Vector3(s * hr * 0.55, hr * 0.62, -hr * 0.05))
		match ek:
			"flop":
				_ell(e, Vector3(hr * 0.16, hr * 0.55, hr * 0.38), Vector3(s * hr * 0.18, -hr * 0.4, 0), fd, Vector3(0, 0, s * 0.35))
			"small":
				_ell(e, Vector3(hr * 0.14, hr * 0.32, hr * 0.3), Vector3(s * hr * 0.12, -hr * 0.12, 0), fd, Vector3(0, 0, s * 0.6))
			"point", "tuft", "big":
				var ehk := 0.75 if ek == "big" else 0.55
				_cyl(e, 0.0, hr * (0.38 if ek == "big" else 0.32), hr * ehk, Vector3(0, hr * ehk * 0.45, 0), fm, Vector3(0, 0, -s * 0.2), 8)
				_cyl(e, 0.0, hr * 0.2, hr * ehk * 0.7, Vector3(0, hr * ehk * 0.38, hr * 0.06), Mats.skin("#d9a0a8") if base != "raposa" else fd, Vector3(0, 0, -s * 0.2), 6)
				if ek == "tuft":
					_cyl(e, 0.0, hr * 0.06, hr * 0.4, Vector3(0, hr * 0.95, 0), Mats.base("#1b1512"), Vector3.ZERO, 5)
			"long":
				_ell(e, Vector3(hr * 0.22, hr * 1.25, hr * 0.12), Vector3(0, hr * 1.05, -hr * 0.05), fm, Vector3(-0.15, 0, -s * 0.12))
				_ell(e, Vector3(hr * 0.13, hr * 1.0, hr * 0.06), Vector3(0, hr * 1.05, 0.0), Mats.skin("#f0b8c4"), Vector3(-0.15, 0, -s * 0.12))
		ears.append(e)
	# pernas (duas partes para dobrar o joelho)
	var feet := [Vector3(-bw * 0.62, 0, L * 0.3), Vector3(bw * 0.62, 0, L * 0.3), Vector3(-bw * 0.6, 0, -L * 0.28), Vector3(bw * 0.6, 0, -L * 0.28)]
	for k in 4:
		var f: Vector3 = feet[k]
		var front := k < 2
		var hip := _pivot(body, Vector3(f.x, -br * 0.25, f.z))
		var up_len := (leg_len - br * 0.25 + body_h - body_h) * (0.55 if not hop else 0.5)
		var total := body_h - br * 0.25
		var upper := total * 0.52
		var lower := total - upper
		var socks: bool = p.get("socks", false)
		var lm := fd if socks else fm
		_ell(hip, Vector3(lr * 1.5, upper * 0.6, lr * 1.6), Vector3(0, -upper * 0.42, 0), fm)
		var knee := _pivot(hip, Vector3(0, -upper, 0))
		_cyl(knee, lr * 0.95, lr * 0.8, lower, Vector3(0, -lower * 0.5, 0), lm)
		_ell(knee, Vector3(lr * 1.15, lr * 0.7, lr * 1.6), Vector3(0, -lower + lr * 0.5, lr * 0.5), fl if not socks else fd)
		legs.append({"hip": hip, "knee": knee, "front": front, "side": -1.0 if k % 2 == 0 else 1.0, "pair": 0 if (k == 0 or k == 3) else 1})
		up_len = up_len
	# cauda
	var tk: String = p.tail
	var tp := _pivot(body, Vector3(0, br * 0.35, -L * 0.46))
	tail.append(tp)
	match tk:
		"wag", "long":
			var segs := 3
			var seg_l := L * (0.13 if tk == "wag" else 0.17)
			var parent := tp
			for k in segs:
				var r0 := lr * (0.9 - k * 0.15) * (1.4 if fluffy else 1.0)
				_ell(parent, Vector3(r0, r0, seg_l * 0.6), Vector3(0, 0, -seg_l * 0.5), fm if k < 2 or tk == "wag" else fd)
				var nx := _pivot(parent, Vector3(0, 0, -seg_l))
				tail.append(nx)
				parent = nx
			tp.rotation.x = 0.6 if tk == "wag" else 0.3
		"plume":
			_ell(tp, Vector3(lr * 2.6, lr * 2.6, L * 0.32), Vector3(0, -0.02, -L * 0.3), fm, Vector3(0.35, 0, 0))
			_ell(tp, Vector3(lr * 1.8, lr * 1.8, L * 0.12), Vector3(0, -0.07, -L * 0.6), _fur(Color("#f6efe6")), Vector3(0.35, 0, 0))
			tp.rotation.x = -0.2
		"bob":
			_ell(tp, Vector3(lr * 1.3, lr * 1.3, L * 0.09), Vector3(0, 0, -L * 0.06), fm)
			_ell(tp, Vector3(lr * 0.9, lr * 0.9, L * 0.04), Vector3(0, 0, -L * 0.14), _fur(Color("#1b1512")))
			tp.rotation.x = 0.7
		"puff":
			_ell(tp, Vector3(br * 0.4, br * 0.4, br * 0.4), Vector3(0, 0.0, -br * 0.15), _fur(Color("#ffffff")))
	if Mats.quality == "ultra":
		_ultra_quad(p, L, br, bw, lr, hr, fz, fm, fl, fd)
	if hop:
		kind = "hop"

func _ultra_quad(p: Dictionary, L: float, br: float, bw: float, lr: float, hr: float, fz: float, fm: Material, fl: Material, fd: Material) -> void:
	var r := RandomNumberGenerator.new()
	r.seed = hash(sp) + coat * 31
	# dedos e unhas
	for lg in legs:
		var kn: Node3D = lg.knee
		var lower: float = -lg.knee.position.y
		var total := body_h - br * 0.25
		var lo2: float = total - lower
		for k in 3:
			var tx := (k - 1) * lr * 0.62
			_ell(kn, Vector3(lr * 0.42, lr * 0.38, lr * 0.5), Vector3(tx, -lo2 + lr * 0.32, lr * 1.75), fl if not p.get("socks", false) else fd, Vector3.ZERO, 8)
			if base == "cao" or base == "raposa":
				_b(kn).add_c(Batch.sphere_mesh(lr * 0.2, lr * 0.2, 6), Transform3D(Basis().scaled(Vector3(0.6, 1, 1)), Vector3(tx, -lo2 + lr * 0.12, lr * 2.2)), Color("#2a2420"))
	# bigodes
	if base in ["gato", "raposa", "coelho"]:
		var wm := Color("#f4f1ea" if base != "raposa" else "#1b1512")
		var org := Vector3(0, -hr * 0.3, hr * (0.92 if p.mlen < 0.06 else 1.1))
		for sd in [-1.0, 1.0]:
			for k in 3:
				var d := Vector3(sd, 0.12 - k * 0.12, -0.15).normalized()
				var wl := hr * 1.15
				var bs := Basis(Quaternion(Vector3.UP, d))
				_b(head).add_c(Batch.cyl_mesh(0.0008, 0.0016, wl, 3), Transform3D(bs, org + Vector3(sd * hr * 0.15, 0, 0) + d * wl * 0.5), wm)
	# tufos de pelo à volta do corpo (dão volume e uma silhueta menos lisa)
	var n := 22 if p.get("fluffy", false) else 14
	for k in n:
		var u := r.randf() * TAU
		var v := r.randf_range(0.15, 1.35)
		var rx: float = bw * fz
		var ry: float = br * fz
		var rz: float = L * 0.4
		var pos := Vector3(rx * sin(v) * cos(u), ry * cos(v), L * 0.0 + rz * sin(v) * sin(u)) * 0.93
		var col: Material = fm if r.randf() < 0.7 else (fl if r.randf() < 0.5 else fd)
		var tsz := bw * r.randf_range(0.28, 0.4)
		_ell(body, Vector3(tsz, tsz * 0.75, tsz * 1.3), pos, col, Vector3(r.randf_range(-0.3, 0.3), u, 0), 8)
	# peito e bochechas mais fofos
	_ell(neck, Vector3(bw * 0.5 * fz, br * 0.42, br * 0.35), Vector3(0, -br * 0.05, br * 0.55), fl, Vector3(-0.3, 0, 0), 10)
	for sd in [-1.0, 1.0]:
		_ell(head, Vector3(hr * 0.32, hr * 0.3, hr * 0.32), Vector3(sd * hr * 0.62, -hr * 0.22, hr * 0.25), fm, Vector3.ZERO, 8)
		# narinas
		if p.mlen > 0.03:
			_b(head).add_c(Batch.sphere_mesh(p.mr * 0.12, p.mr * 0.16, 6), Transform3D(Basis().scaled(Vector3(1, 1, 0.67)), Vector3(sd * p.mr * 0.2, -hr * 0.16, hr * 0.62 + p.mlen * 0.82 + p.mr * 0.52)), Color("#050404"))
	# sobrancelhas (tufos claros)
	for sd in [-1.0, 1.0]:
		_ell(head, Vector3(hr * 0.16, hr * 0.06, hr * 0.08), Vector3(sd * hr * 0.42, hr * 0.44, hr * 0.78), fl, Vector3(0, 0, -sd * 0.25), 6)

# ---------- hamster ----------
func _hamster() -> void:
	kind = "tiny"
	var r := 0.075
	body_h = r * 0.95
	height = r * 2.6
	body.position = Vector3(0, body_h, 0)
	_ell(body, Vector3(r, r * 0.9, r * 1.25), Vector3.ZERO, _fur(c_main))
	_ell(body, Vector3(r * 0.75, r * 0.6, r * 0.9), Vector3(0, -r * 0.3, r * 0.2), _fur(c_light))
	neck = _pivot(body, Vector3(0, r * 0.2, r * 0.9))
	head = _pivot(neck, Vector3.ZERO)
	_ell(head, Vector3(r * 0.72, r * 0.66, r * 0.68), Vector3(0, r * 0.1, r * 0.2), _fur(c_main))
	_ell(head, Vector3(r * 0.5, r * 0.4, r * 0.4), Vector3(0, -r * 0.1, r * 0.55), _fur(c_light))
	_ell(head, Vector3(r * 0.1, r * 0.08, r * 0.06), Vector3(0, r * 0.05, r * 0.86), Mats.glossy("#e0708a", 0.3))
	for s in [-1.0, 1.0]:
		_eye(head, Vector3(s * r * 0.36, r * 0.28, r * 0.68), r * 0.11, s)
		var e := _pivot(head, Vector3(s * r * 0.42, r * 0.62, r * 0.05))
		_ell(e, Vector3(r * 0.2, r * 0.22, r * 0.08), Vector3.ZERO, Mats.skin("#e8a0a8"))
		ears.append(e)
	for k in 4:
		var hip := _pivot(body, Vector3((-1.0 if k % 2 == 0 else 1.0) * r * 0.6, -r * 0.6, r * (0.6 if k < 2 else -0.6)))
		var knee := _pivot(hip, Vector3(0, -r * 0.2, 0))
		_ell(knee, Vector3(r * 0.18, r * 0.12, r * 0.24), Vector3(0, -r * 0.05, r * 0.08), Mats.skin("#f0c0c8"))
		legs.append({"hip": hip, "knee": knee, "front": k < 2, "side": -1.0 if k % 2 == 0 else 1.0, "pair": 0 if (k == 0 or k == 3) else 1})

# ---------- papagaio ----------
func _parrot() -> void:
	kind = "bird"
	var s := 1.0
	body_h = 0.13
	height = 0.42
	body.position = Vector3(0, body_h, 0)
	_ell(body, Vector3(0.075, 0.12, 0.08), Vector3(0, 0.07, 0), Mats.glossy(c_main, 0.55), Vector3(-0.25, 0, 0))
	_ell(body, Vector3(0.055, 0.08, 0.04), Vector3(0, 0.05, 0.045), Mats.glossy(c_light, 0.6), Vector3(-0.25, 0, 0))
	neck = _pivot(body, Vector3(0, 0.17, 0.02))
	head = _pivot(neck, Vector3(0, 0.03, 0.01))
	_ell(head, Vector3(0.06, 0.06, 0.065), Vector3.ZERO, Mats.glossy(c_main, 0.55))
	_ell(head, Vector3(0.03, 0.035, 0.035), Vector3(0, -0.015, 0.06), Mats.glossy("#2a2622", 0.3), Vector3(0.5, 0, 0))
	_ell(head, Vector3(0.035, 0.02, 0.03), Vector3(0, 0.012, 0.055), Mats.skin("#f4efe6"))
	for sd in [-1.0, 1.0]:
		_eye(head, Vector3(sd * 0.04, 0.015, 0.035), 0.011, sd)
		var w := _pivot(body, Vector3(sd * 0.07, 0.13, -0.01))
		_ell(w, Vector3(0.022, 0.1, 0.06), Vector3(sd * 0.01, -0.06, -0.01), Mats.glossy(c_dark, 0.6), Vector3(-0.3, 0, 0))
		wings.append({"n": w, "s": sd})
		var hip := _pivot(body, Vector3(sd * 0.03, -0.03, 0.0))
		var knee := _pivot(hip, Vector3(0, -0.05, 0))
		_cyl(hip, 0.01, 0.01, 0.06, Vector3(0, -0.03, 0), Mats.base("#7a6a5a"))
		_ell(knee, Vector3(0.018, 0.01, 0.03), Vector3(0, -0.04, 0.01), Mats.base("#7a6a5a"))
		legs.append({"hip": hip, "knee": knee, "front": sd < 0, "side": sd, "pair": 0 if sd < 0 else 1})
	var tp := _pivot(body, Vector3(0, -0.02, -0.06))
	_ell(tp, Vector3(0.03, 0.13, 0.012), Vector3(0, -0.1, -0.03), Mats.glossy(c_dark, 0.6), Vector3(0.45, 0, 0))
	if Mats.quality == "ultra":
		for k in [-1.0, 1.0]:
			_ell(tp, Vector3(0.018, 0.12, 0.008), Vector3(k * 0.022, -0.09, -0.03), Mats.glossy(c_main, 0.6), Vector3(0.45, 0, k * 0.2), 8)
		for w in wings:
			var wn: Node3D = w.n
			var ws: float = w.s
			for k in 3:
				_ell(wn, Vector3(0.012, 0.06 - k * 0.008, 0.03), Vector3(ws * 0.018, -0.1 - k * 0.025, -0.03 - k * 0.012), Mats.glossy(c_light if k == 0 else c_dark, 0.6), Vector3(-0.3, 0, 0), 8)
		for k in 3:
			_ell(head, Vector3(0.012, 0.03, 0.012), Vector3(0, 0.055, -0.01 - k * 0.02), Mats.glossy(c_main, 0.55), Vector3(-0.5 - k * 0.3, 0, 0), 8)
	tail.append(tp)
	s = s

# ---------- pinguim ----------
func _penguin() -> void:
	kind = "waddle"
	body_h = 0.06
	height = 0.68
	body.position = Vector3(0, body_h, 0)
	var blk := Mats.glossy(c_main, 0.45)
	_ell(body, Vector3(0.16, 0.27, 0.14), Vector3(0, 0.26, 0), blk)
	_ell(body, Vector3(0.12, 0.22, 0.07), Vector3(0, 0.24, 0.08), Mats.glossy(c_light, 0.5))
	neck = _pivot(body, Vector3(0, 0.48, 0))
	head = _pivot(neck, Vector3(0, 0.04, 0))
	_ell(head, Vector3(0.11, 0.1, 0.1), Vector3.ZERO, blk)
	_ell(head, Vector3(0.025, 0.02, 0.06), Vector3(0, -0.02, 0.11), Mats.glossy(c_dark, 0.4))
	_ell(head, Vector3(0.05, 0.03, 0.04), Vector3(0, -0.06, 0.06), Mats.glossy("#f2c230", 0.4))
	for sd in [-1.0, 1.0]:
		_eye(head, Vector3(sd * 0.055, 0.03, 0.07), 0.014, sd)
		var w := _pivot(body, Vector3(sd * 0.15, 0.4, 0))
		_ell(w, Vector3(0.025, 0.14, 0.06), Vector3(sd * 0.01, -0.12, 0), blk)
		wings.append({"n": w, "s": sd})
		var hip := _pivot(body, Vector3(sd * 0.07, 0.02, 0.02))
		var knee := _pivot(hip, Vector3.ZERO)
		_ell(knee, Vector3(0.045, 0.02, 0.07), Vector3(0, -0.04, 0.04), Mats.glossy(c_dark, 0.5))
		legs.append({"hip": hip, "knee": knee, "front": sd < 0, "side": sd, "pair": 0 if sd < 0 else 1})

# ---------- tartaruga ----------
func _turtle() -> void:
	kind = "turtle"
	body_h = 0.08
	height = 0.3
	body.position = Vector3(0, body_h, 0)
	var shell := Mats.glossy(c_main, 0.4)
	_ell(body, Vector3(0.2, 0.11, 0.25), Vector3(0, 0.04, 0), shell)
	for o in [[-0.08, 0.06], [0.08, -0.04], [0.0, 0.0], [-0.07, -0.1], [0.08, 0.1], [0.0, 0.14], [0.0, -0.15]]:
		_ell(body, Vector3(0.055, 0.03, 0.055), Vector3(o[0], 0.12, o[1]), Mats.glossy(c_dark, 0.45))
	_ell(body, Vector3(0.19, 0.03, 0.23), Vector3(0, -0.03, 0), Mats.base(c_light, 0.7))
	var skin := Mats.rough_surface(c_light, 0.2, 0.8, 1.0, 101)
	neck = _pivot(body, Vector3(0, 0.0, 0.22))
	head = _pivot(neck, Vector3(0, 0.02, 0.06))
	_ell(head, Vector3(0.055, 0.05, 0.07), Vector3.ZERO, skin)
	for sd in [-1.0, 1.0]:
		_eye(head, Vector3(sd * 0.035, 0.02, 0.045), 0.009, sd)
	for k in 4:
		var sd2 := -1.0 if k % 2 == 0 else 1.0
		var hip := _pivot(body, Vector3(sd2 * 0.15, -0.03, 0.13 if k < 2 else -0.13))
		var knee := _pivot(hip, Vector3.ZERO)
		_ell(knee, Vector3(0.045, 0.05, 0.05), Vector3(sd2 * 0.02, -0.04, 0), skin)
		legs.append({"hip": hip, "knee": knee, "front": k < 2, "side": sd2, "pair": 0 if (k == 0 or k == 3) else 1})

# ---------- cavalo e unicórnio ----------
func _horse(uni: bool) -> void:
	kind = "horse"
	var fm := _fur(c_main)
	var fl := _fur(c_light)
	var mane := ["#ff6b8b", "#ffb347", "#fff275", "#7ee081", "#6ec6ff", "#b28dff"]
	body_h = 1.15
	height = 2.15
	body.position = Vector3(0, body_h, 0)
	_ell(body, Vector3(0.3, 0.33, 0.62), Vector3(0, 0, 0.05), fm)
	_ell(body, Vector3(0.29, 0.31, 0.3), Vector3(0, 0.02, -0.42), fm)
	_ell(body, Vector3(0.28, 0.32, 0.28), Vector3(0, 0.0, 0.45), fm)
	neck = _pivot(body, Vector3(0, 0.12, 0.55))
	_ell(neck, Vector3(0.15, 0.4, 0.24), Vector3(0, 0.26, 0.17), fm, Vector3(0.72, 0, 0))
	_ell(neck, Vector3(0.12, 0.2, 0.16), Vector3(0, 0.02, 0.0), fm, Vector3(0.3, 0, 0))
	head = _pivot(neck, Vector3(0, 0.55, 0.42))
	_ell(head, Vector3(0.12, 0.13, 0.3), Vector3(0, 0, 0.12), fm, Vector3(0.6, 0, 0))
	_ell(head, Vector3(0.1, 0.1, 0.12), Vector3(0, -0.17, 0.32), fl, Vector3(0.6, 0, 0))
	for sd in [-1.0, 1.0]:
		_eye(head, Vector3(sd * 0.11, 0.05, 0.08), 0.03, sd)
		_ell(head, Vector3(0.015, 0.012, 0.012), Vector3(sd * 0.04, -0.2, 0.38), Mats.base("#1b1512"))
		var e := _pivot(head, Vector3(sd * 0.07, 0.14, -0.04))
		_cyl(e, 0.0, 0.045, 0.14, Vector3(0, 0.06, 0), fm, Vector3(-0.2, 0, -sd * 0.15), 8)
		ears.append(e)
	# crina
	var mm := Mats.fur(c_dark) if not uni else null
	var nm := 14 if Mats.quality == "ultra" else 7
	for k in nm:
		var kk := k * 7.0 / nm
		var col: Material = mm if not uni else Mats.fur(Color(mane[int(kk) % 6]))
		var sx := (0.025 if k % 2 == 0 else -0.025) if nm > 7 else 0.0
		_ell(neck, Vector3(0.05, 0.12, 0.08), Vector3(sx, 0.6 - kk * 0.075, 0.27 - kk * 0.075) + Vector3(0, 0, -0.06), col, Vector3(0.72, 0, sx * 4.0))
	if Mats.quality == "ultra":
		var fcol: Material = mm if not uni else Mats.fur(Color(mane[0]))
		_ell(head, Vector3(0.05, 0.1, 0.04), Vector3(0, 0.15, 0.02), fcol, Vector3(0.9, 0, 0), 8)
		for sd in [-1.0, 1.0]:
			_ell(head, Vector3(0.012, 0.004, 0.02), Vector3(sd * 0.11, 0.075, 0.09), Mats.base("#1b1512"), Vector3.ZERO, 6)
	if uni:
		var gold := Mats.glossy("#f2c230", 0.2, 0.9)
		_cyl(head, 0.0, 0.03, 0.32, Vector3(0, 0.26, 0.12), gold, Vector3(0.5, 0, 0), 10)
		for k in 4:
			_b(head).add(Batch.torus_mesh(0.024 - k * 0.004, 0.034 - k * 0.005), Transform3D(Basis.from_euler(Vector3(0.5, 0, 0)), Vector3(0, 0.15 + k * 0.065, 0.06 + k * 0.035)), Mats.glossy("#e0a820", 0.3, 0.8))
	# pernas longas
	var feet := [Vector3(-0.17, 0, 0.42), Vector3(0.17, 0, 0.42), Vector3(-0.17, 0, -0.45), Vector3(0.17, 0, -0.45)]
	var hoof := Mats.glossy("#e8c35a" if uni else "#2a211c", 0.35, 0.6 if uni else 0.0)
	for k in 4:
		var f: Vector3 = feet[k]
		var hip := _pivot(body, Vector3(f.x, -0.15, f.z))
		_ell(hip, Vector3(0.09, 0.3, 0.12), Vector3(0, -0.22, 0), fm)
		var knee := _pivot(hip, Vector3(0, -0.5, 0))
		_cyl(knee, 0.045, 0.04, 0.45, Vector3(0, -0.23, 0), fm)
		_cyl(knee, 0.055, 0.06, 0.08, Vector3(0, -0.46, 0), hoof)
		legs.append({"hip": hip, "knee": knee, "front": k < 2, "side": -1.0 if k % 2 == 0 else 1.0, "pair": 0 if (k == 0 or k == 3) else 1})
	var tp := _pivot(body, Vector3(0, 0.22, -0.68))
	var nt := (6 if uni else 3) * (2 if Mats.quality == "ultra" else 1)
	for k in nt:
		var col2: Material = Mats.fur(Color(mane[k % 6])) if uni else Mats.fur(c_dark)
		_ell(tp, Vector3(0.05, 0.36, 0.05), Vector3((k % 3 - 1) * 0.03, -0.32 - (k / 6) * 0.04, -0.08 - (k % 6) * 0.01), col2, Vector3(-0.25 - (k % 2) * 0.12, 0, (k % 3 - 1) * 0.1))
	if Mats.quality == "ultra":
		# pelos nos boletos
		for lg in legs:
			_ell(lg.knee, Vector3(0.06, 0.05, 0.065), Vector3(0, -0.4, -0.01), fl, Vector3.ZERO, 8)
	tail.append(tp)

func _collar(c: Color) -> void:
	if neck == null:
		return
	var r: float = max(0.03, height * 0.12)
	_b(neck).add(Batch.torus_mesh(r * 0.8, r), Transform3D(Basis.from_euler(Vector3(0.9, 0, 0)), Vector3(0, r * 0.6, r * 0.4)), Mats.glossy(c, 0.35))
	_ell(neck, Vector3(r * 0.25, r * 0.25, r * 0.12), Vector3(0, r * 0.1, r * 1.3), Mats.glossy("#f2c230", 0.2, 0.9))

# ---------- animação ----------
func animate(dt: float, mv: bool, spd: float, action: String, is_happy := false) -> void:
	t += dt
	moving = mv
	speed = spd
	act = action
	happy = is_happy
	var sleep := act == "sleep"
	lie = move_toward(lie, 1.0 if sleep else 0.0, dt * 1.8)
	var gait := 0.0
	if moving:
		var freq := 9.0 if kind == "tiny" else (4.6 if kind == "horse" else 7.5)
		if kind == "turtle":
			freq = 3.0
		phase += dt * freq * clamp(spd / 1.6, 0.6, 2.2)
		gait = 1.0
	var s := sin(phase)
	var c := cos(phase)
	# corpo
	var bob := 0.0
	if moving:
		bob = abs(s) * height * 0.025
		if kind == "hop":
			bob = abs(sin(phase * 0.5)) * height * 0.6
	var breathe := 1.0 + sin(t * (1.2 if sleep else 2.4)) * 0.012
	body.position.y = body_h + bob - lie * body_h * (0.55 if kind == "quad" or kind == "hop" or kind == "horse" else 0.2)
	body.scale = Vector3(breathe, breathe, 1.0)
	if kind == "waddle":
		body.rotation.z = sin(phase) * 0.18 * gait
	# pernas
	for L in legs:
		var hip: Node3D = L.hip
		var knee: Node3D = L.knee
		var off := 0.0 if L.pair == 0 else PI
		var sw := sin(phase + off) * gait
		var amp := 0.55 if kind != "horse" else 0.42
		if kind == "hop":
			sw = sin(phase * 0.5) * gait * (1.0 if L.front else -1.2)
		hip.rotation.x = sw * amp
		knee.rotation.x = (max(0.0, -sin(phase + off + 0.6)) * 0.9 * gait) * (1.0 if L.front else -1.0)
		if lie > 0.01 and (kind == "quad" or kind == "horse" or kind == "hop"):
			hip.rotation.x = lerp(hip.rotation.x, (-1.35 if L.front else 1.35), lie)
			knee.rotation.x = lerp(knee.rotation.x, (1.6 if L.front else -1.6), lie)
	# cabeça
	look_t -= dt
	if look_t <= 0:
		look_t = randf_range(1.5, 4.0)
		look = randf_range(-0.6, 0.6) if not moving else 0.0
	if head:
		var pitch := 0.0
		if act == "eat" or act == "drink":
			pitch = 0.75 + sin(t * 8.0) * 0.08
		elif sleep:
			pitch = 0.5
		elif act == "play":
			pitch = sin(t * 6.0) * 0.2 - 0.1
		elif moving:
			pitch = sin(phase * 2.0) * 0.05
		if neck:
			neck.rotation.x = lerp_angle(neck.rotation.x, pitch * 0.6, dt * 6.0)
			neck.rotation.y = lerp_angle(neck.rotation.y, look * 0.5, dt * 2.0)
		head.rotation.x = lerp_angle(head.rotation.x, pitch * 0.5, dt * 6.0)
		head.rotation.y = lerp_angle(head.rotation.y, look * 0.5, dt * 2.0)
	# olhos (piscar e fechados a dormir)
	var blink := 1.0
	if sleep:
		blink = 0.12
	elif fmod(t, 3.7) < 0.12:
		blink = 0.15
	for e in eyes:
		e.scale.y = blink
	# orelhas mexem de vez em quando
	for k in ears.size():
		ears[k].rotation.z = sin(t * 3.0 + k) * 0.05 + (0.25 * sin(t * 15.0) if fmod(t + k, 5.0) < 0.3 else 0.0)
	# cauda
	if not tail.is_empty():
		var rate := 14.0 if (happy or act == "play") else 4.0
		var amp2 := 0.65 if (happy or act == "play") else 0.22
		if sleep:
			amp2 = 0.05
		for k in tail.size():
			tail[k].rotation.y = sin(t * rate - k * 0.6) * amp2 * (0.6 + k * 0.25)
	# asas
	for w in wings:
		var flap := 0.0
		if kind == "bird" and (moving or act == "play"):
			flap = abs(sin(t * 18.0)) * 0.9
		elif kind == "waddle":
			flap = 0.25 + sin(phase) * 0.2 * gait
		w.n.rotation.z = w.s * flap
