# Hotel Patinhas HD · materiais realistas (PBR) com texturas geradas no próprio jogo
class_name Mats
extends RefCounted

static var cache := {}
static var tex_cache := {}
static var quality := "alta"
static var palette := "natural"  # "colorido" (crianças), "natural" ou "real" (adultos)

# ajusta uma cor ao estilo escolhido: mais viva e alegre, ou mais sóbria e realista
static func tone(c: Color, amt := 1.0) -> Color:
	if palette == "natural":
		return c
	var h := c.h
	var sat := c.s
	var v := c.v
	if palette == "colorido":
		if sat > 0.06:
			sat = min(1.0, sat * lerp(1.0, 1.3, amt) + 0.06 * amt)
		v = min(1.0, v * lerp(1.0, 1.06, amt) + 0.02 * amt)
	else:
		sat *= lerp(1.0, 0.74, amt)
		v *= lerp(1.0, 0.84, amt)
		if h > 0.15 and h < 0.45:
			h = lerp(h, 0.2, 0.25 * amt)  # verdes mais oliva, como a vegetação verdadeira
	var o := Color.from_hsv(h, sat, v, c.a)
	if palette == "real":
		o = o.lerp(Color(o.r * 1.03, o.g * 1.0, o.b * 0.94, o.a), amt)
	return o

# ---------- imagens base ----------
static func _noise_img(seed: int, freq: float, size: int, octaves := 4, cellular := false) -> Image:
	var n := FastNoiseLite.new()
	n.seed = seed
	n.frequency = freq
	n.fractal_octaves = octaves
	if cellular:
		n.noise_type = FastNoiseLite.TYPE_CELLULAR
	var img := n.get_seamless_image(size, size, false, false, 0.1, true)
	img.convert(Image.FORMAT_RGB8)
	return img

static func _tex(img: Image) -> ImageTexture:
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)

static func _normal_from(img: Image, strength: float) -> ImageTexture:
	var n := img.duplicate() as Image
	n.clear_mipmaps()
	n.convert(Image.FORMAT_RGBA8)
	n.bump_map_to_normal_map(strength)
	n.generate_mipmaps()
	return ImageTexture.create_from_image(n)

static func noise_tex(seed: int, freq: float, size := 256, contrast := 1.0) -> ImageTexture:
	var key := "n%d_%f_%d_%f" % [seed, freq, size, contrast]
	if tex_cache.has(key):
		return tex_cache[key]
	var img := _noise_img(seed, freq, size)
	if contrast != 1.0:
		# contraste baixo à volta de 0.5 e depois clarear para o máximo ficar em 1 (só escurece um pouco)
		img.adjust_bcs(1.0, contrast, 1.0)
		img.adjust_bcs(1.0 / (0.5 + contrast * 0.5), 1.0, 1.0)
	var t := _tex(img)
	tex_cache[key] = t
	return t

static func noise_normal(seed: int, freq: float, strength := 3.0, size := 256) -> ImageTexture:
	var key := "nn%d_%f_%f" % [seed, freq, strength]
	if tex_cache.has(key):
		return tex_cache[key]
	var t := _normal_from(_noise_img(seed, freq, size), strength)
	tex_cache[key] = t
	return t

# ---------- padrões (desenhados com retângulos: rápido mesmo no telemóvel) ----------
# devolve [albedo (tons de cinzento), normal]
static func pattern(kind: String) -> Array:
	if tex_cache.has("p_" + kind):
		return tex_cache["p_" + kind]
	var S := 256
	var img := Image.create_empty(S, S, false, Image.FORMAT_RGB8)
	var bump := Image.create_empty(S, S, false, Image.FORMAT_RGB8)
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(kind)
	match kind:
		"tiles":
			img.fill(Color(0.6, 0.6, 0.6)); bump.fill(Color(0.2, 0.2, 0.2))
			var n := 4
			var c := S / n
			for y in n:
				for x in n:
					var v := rng.randf_range(0.88, 1.0)
					img.fill_rect(Rect2i(x * c + 3, y * c + 3, c - 6, c - 6), Color(v, v, v))
					bump.fill_rect(Rect2i(x * c + 3, y * c + 3, c - 6, c - 6), Color(0.8, 0.8, 0.8))
		"bigtiles":
			img.fill(Color(0.7, 0.7, 0.7)); bump.fill(Color(0.3, 0.3, 0.3))
			var c2 := S / 2
			for y in 2:
				for x in 2:
					var v2 := rng.randf_range(0.9, 1.0)
					img.fill_rect(Rect2i(x * c2 + 2, y * c2 + 2, c2 - 4, c2 - 4), Color(v2, v2, v2))
					bump.fill_rect(Rect2i(x * c2 + 2, y * c2 + 2, c2 - 4, c2 - 4), Color(0.8, 0.8, 0.8))
		"planks":
			img.fill(Color(0.35, 0.35, 0.35)); bump.fill(Color(0.3, 0.3, 0.3))
			var rows := 8
			var h := S / rows
			for r in rows:
				var off := rng.randi_range(0, S)
				var x0 := -off
				while x0 < S:
					var w := rng.randi_range(110, 200)
					var v3 := rng.randf_range(0.72, 1.0)
					img.fill_rect(Rect2i(max(x0 + 1, 0), r * h + 1, w - 2 + min(x0, 0), h - 2), Color(v3, v3, v3))
					bump.fill_rect(Rect2i(max(x0 + 1, 0), r * h + 1, w - 2 + min(x0, 0), h - 2), Color(0.75, 0.75, 0.75))
					for k in 6:
						var gy := r * h + rng.randi_range(2, h - 3)
						var gv := v3 * rng.randf_range(0.85, 0.97)
						img.fill_rect(Rect2i(max(x0, 0), gy, w + min(x0, 0), 1), Color(gv, gv, gv))
					x0 += w
		"bricks":
			img.fill(Color(0.78, 0.78, 0.76)); bump.fill(Color(0.3, 0.3, 0.3))
			var bh := 32
			for r in S / bh:
				var o := 0 if r % 2 == 0 else 32
				for x in range(-1, S / 64 + 1):
					var v4 := rng.randf_range(0.75, 1.0)
					img.fill_rect(Rect2i(x * 64 + o + 2, r * bh + 2, 60, bh - 4), Color(v4, v4 * 0.97, v4 * 0.95))
					bump.fill_rect(Rect2i(x * 64 + o + 2, r * bh + 2, 60, bh - 4), Color(0.8, 0.8, 0.8))
		"roof":
			img.fill(Color(0.4, 0.4, 0.4)); bump.fill(Color(0.1, 0.1, 0.1))
			var rh := 32
			for r in S / rh:
				var o2 := 0 if r % 2 == 0 else 16
				for x in range(-1, S / 32 + 1):
					var v5 := rng.randf_range(0.8, 1.0)
					img.fill_rect(Rect2i(x * 32 + o2 + 1, r * rh, 30, rh - 3), Color(v5, v5, v5))
					for k in 6:
						var g := float(k) / 6.0
						bump.fill_rect(Rect2i(x * 32 + o2 + 1, r * rh + k * 4, 30, 4), Color(0.9 - g * 0.6, 0.9 - g * 0.6, 0.9 - g * 0.6))
		"pavers":
			img.fill(Color(0.55, 0.55, 0.55)); bump.fill(Color(0.2, 0.2, 0.2))
			for r in 8:
				var o3 := 0 if r % 2 == 0 else 16
				for x in range(-1, 9):
					var v6 := rng.randf_range(0.82, 1.0)
					img.fill_rect(Rect2i(x * 32 + o3 + 2, r * 32 + 2, 28, 28), Color(v6, v6, v6))
					bump.fill_rect(Rect2i(x * 32 + o3 + 2, r * 32 + 2, 28, 28), Color(0.85, 0.85, 0.85))
		"stripes":
			for k in 8:
				var col := Color(0.9, 0.2, 0.18) if k % 2 == 0 else Color(0.97, 0.97, 0.97)
				img.fill_rect(Rect2i(k * 32, 0, 32, S), col)
			bump.fill(Color(0.5, 0.5, 0.5))
		"planks_v":
			img.fill(Color(0.4, 0.4, 0.4)); bump.fill(Color(0.3, 0.3, 0.3))
			for x in 8:
				var v7 := rng.randf_range(0.75, 1.0)
				img.fill_rect(Rect2i(x * 32 + 1, 0, 30, S), Color(v7, v7, v7))
				bump.fill_rect(Rect2i(x * 32 + 1, 0, 30, S), Color(0.8, 0.8, 0.8))
		_:
			img.fill(Color(1, 1, 1)); bump.fill(Color(0.5, 0.5, 0.5))
	var res := [_tex(img), _normal_from(bump, 6.0)]
	tex_cache["p_" + kind] = res
	return res

# ---------- materiais ----------
static func base(col, rough := 0.8, metal := 0.0) -> StandardMaterial3D:
	var c: Color = tone(col if col is Color else Color(col))
	var key := "b%s_%.2f_%.2f" % [c.to_html(), rough, metal]
	if cache.has(key):
		return cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	cache[key] = m
	return m

# material com textura no mundo (triplanar), escala em metros por repetição
static func textured(col, kind: String, meters := 2.0, rough := 0.8, nstr := 1.0, noise := true) -> StandardMaterial3D:
	var c: Color = tone(col if col is Color else Color(col))
	var key := "t%s_%s_%.2f_%.2f_%s" % [c.to_html(), kind, meters, rough, quality]
	if cache.has(key):
		return cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3.ONE / meters
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	if kind != "":
		var p := pattern(kind)
		m.albedo_texture = p[0]
		if quality != "leve":
			m.normal_enabled = true
			m.normal_texture = p[1]
			m.normal_scale = nstr
	if noise and quality != "leve":
		m.detail_enabled = true
		m.detail_blend_mode = BaseMaterial3D.BLEND_MODE_MUL
		m.detail_albedo = noise_tex(7, 0.02, 256, 0.16)
		m.detail_uv_layer = BaseMaterial3D.DETAIL_UV_2
		m.uv2_triplanar = true
		m.uv2_world_triplanar = true
		m.uv2_scale = Vector3.ONE / (meters * 3.7)
	cache[key] = m
	return m

# superfície rugosa sem padrão (reboco, terra, areia, casca)
static func rough_surface(col, meters := 1.5, rough := 0.9, nstr := 0.6, seed := 3) -> StandardMaterial3D:
	var c: Color = tone(col if col is Color else Color(col))
	var key := "r%s_%.2f_%d_%s" % [c.to_html(), meters, seed, quality]
	if cache.has(key):
		return cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3.ONE / meters
	m.albedo_texture = noise_tex(seed, 0.035, 256, 0.45)
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	if quality != "leve":
		m.normal_enabled = true
		m.normal_texture = noise_normal(seed + 1, 0.06, 2.5)
		m.normal_scale = nstr
	cache[key] = m
	return m

# reboco liso (paredes): variação muito suave
static func plaster(col) -> StandardMaterial3D:
	var c: Color = tone(col if col is Color else Color(col))
	var key := "pl%s_%s" % [c.to_html(), quality]
	if cache.has(key):
		return cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.88
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3.ONE / 2.5
	m.albedo_texture = noise_tex(17, 0.02, 256, 0.12)
	if quality != "leve":
		m.normal_enabled = true
		m.normal_texture = noise_normal(18, 0.09, 1.5)
		m.normal_scale = 0.25
	cache[key] = m
	return m

static func glossy(col, rough := 0.25, metal := 0.0, clearcoat := false) -> StandardMaterial3D:
	var c: Color = tone(col if col is Color else Color(col))
	var key := "g%s_%.2f_%.2f_%s" % [c.to_html(), rough, metal, clearcoat]
	if cache.has(key):
		return cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	if clearcoat and quality != "leve":
		m.clearcoat_enabled = true
		m.clearcoat = 0.8
		m.clearcoat_roughness = 0.15
	cache[key] = m
	return m

static func glass() -> StandardMaterial3D:
	if cache.has("glass"):
		return cache["glass"]
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.75, 0.88, 0.95, 0.28)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.roughness = 0.05
	m.metallic = 0.2
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	cache["glass"] = m
	return m

static func emissive(col, energy := 2.0) -> StandardMaterial3D:
	var c: Color = tone(col if col is Color else Color(col))
	var key := "e%s_%.2f" % [c.to_html(), energy]
	if cache.has(key):
		return cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = energy
	cache[key] = m
	return m

# pelo de animal: cor com riscas finas, relevo suave e brilho de contorno (parece macio)
static func fur(col, seed := 11) -> StandardMaterial3D:
	var c: Color = tone(col if col is Color else Color(col))
	var key := "f%s_%s" % [c.to_html(), quality]
	if cache.has(key):
		return cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.92
	m.albedo_texture = fur_tex()
	m.uv1_triplanar = true
	m.uv1_scale = Vector3(2.5, 2.5, 2.5)
	if quality != "leve":
		m.normal_enabled = true
		m.normal_texture = fur_normal()
		m.normal_scale = 0.7
		m.rim_enabled = true
		m.rim = 0.55
		m.rim_tint = 0.75
	cache[key] = m
	return m

static func fur_tex() -> ImageTexture:
	if tex_cache.has("fur"):
		return tex_cache["fur"]
	var n := FastNoiseLite.new()
	n.seed = 21
	n.frequency = 0.09
	n.fractal_octaves = 3
	var img := n.get_seamless_image(128, 128, false, false, 0.1, true)
	img.convert(Image.FORMAT_RGB8)
	# estica na vertical (riscas de pelo)
	img.resize(64, 256, Image.INTERPOLATE_BILINEAR)
	img.resize(128, 128, Image.INTERPOLATE_BILINEAR)
	img.adjust_bcs(1.0, 0.4, 1.0)
	img.adjust_bcs(1.0 / 0.7, 1.0, 1.0)
	var t := _tex(img)
	tex_cache["fur"] = t
	return t

static func fur_normal() -> ImageTexture:
	if tex_cache.has("furn"):
		return tex_cache["furn"]
	var n := FastNoiseLite.new()
	n.seed = 23
	n.frequency = 0.12
	var img := n.get_seamless_image(128, 128, false, false, 0.1, true)
	img.resize(48, 256, Image.INTERPOLATE_BILINEAR)
	img.resize(128, 128, Image.INTERPOLATE_BILINEAR)
	var t := _normal_from(img, 3.0)
	tex_cache["furn"] = t
	return t

static func skin(col) -> StandardMaterial3D:
	var c: Color = tone(col if col is Color else Color(col), 0.45)
	var key := "s%s" % c.to_html()
	if cache.has(key):
		return cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.6
	if quality != "leve":
		m.rim_enabled = true
		m.rim = 0.25
		m.rim_tint = 0.9
	cache[key] = m
	return m

static func cloth(col) -> StandardMaterial3D:
	var c: Color = tone(col if col is Color else Color(col))
	var key := "c%s_%s" % [c.to_html(), quality]
	if cache.has(key):
		return cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.95
	if quality != "leve":
		m.normal_enabled = true
		m.normal_texture = noise_normal(31, 0.25, 1.5, 128)
		m.normal_scale = 0.4
		m.uv1_triplanar = true
		m.uv1_scale = Vector3(6, 6, 6)
	cache[key] = m
	return m

# folhagem: muitas folhas pequenas desenhadas numa textura com transparência (para copas realistas)
static func leaf_tex(seed := 5) -> ImageTexture:
	var key := "leaf%d" % seed
	if tex_cache.has(key):
		return tex_cache[key]
	var S := 256
	var img := Image.create_empty(S, S, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var c := Vector2(S * 0.5, S * 0.5)
	for k in 420:
		# folhas mais densas no centro do cacho
		var a := rng.randf() * TAU
		var r := sqrt(rng.randf()) * S * 0.46
		var p := c + Vector2(cos(a), sin(a)) * r
		var ang := rng.randf() * TAU
		var L := rng.randf_range(7.0, 12.0)
		var W := L * 0.45
		var v := rng.randf_range(0.62, 1.0)
		var col := Color(v * rng.randf_range(0.9, 1.0), v, v * rng.randf_range(0.75, 0.9), 1.0)
		var d := Vector2(cos(ang), sin(ang))
		var n := Vector2(-d.y, d.x)
		for ix in range(int(-L), int(L) + 1):
			for iy in range(int(-W), int(W) + 1):
				var u := float(ix) / L
				var w := float(iy) / W
				if u * u + w * w > 1.0:
					continue
				var q := p + d * ix + n * iy
				var x := int(q.x)
				var y := int(q.y)
				if x >= 0 and y >= 0 and x < S and y < S:
					var shade: float = 1.0 - 0.25 * abs(w)
					img.set_pixel(x, y, Color(col.r * shade, col.g * shade, col.b * shade, 1.0))
	img.generate_mipmaps()
	var t := ImageTexture.create_from_image(img)
	tex_cache[key] = t
	return t

static func leaves(col) -> StandardMaterial3D:
	var c: Color = tone(col if col is Color else Color(col))
	var key := "lv%s_%s" % [c.to_html(), quality]
	if cache.has(key):
		return cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.albedo_texture = leaf_tex()
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	m.alpha_scissor_threshold = 0.45
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.roughness = 0.75
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	if quality != "leve":
		m.backlight_enabled = true
		m.backlight = Color(0.25, 0.35, 0.1)
	cache[key] = m
	return m

static func clear() -> void:
	cache.clear()
