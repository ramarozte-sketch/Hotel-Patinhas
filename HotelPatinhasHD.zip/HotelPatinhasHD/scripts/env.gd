# Hotel Patinhas HD · céu, sol, lua, nevoeiro, chuva e luzes da noite
class_name Env
extends Node3D

var we: WorldEnvironment
var env: Environment
var sun: DirectionalLight3D
var moon: DirectionalLight3D
var sky_mat: ShaderMaterial
var night := 0.0
var hour := 12.0
var rain := 0.0
var rain_on := false
var rain_fx: GPUParticles3D
var light_pool: Array = []
var pool_t := 0.0
var quality := "alta"

func build(q: String) -> void:
	quality = q
	we = WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_mat = ShaderMaterial.new()
	sky_mat.shader = load("res://shaders/sky.gdshader")
	sky_mat.set_shader_parameter("cloud_tex", Mats.noise_tex(201, 0.012, 256, 1.0))
	var stars := FastNoiseLite.new()
	stars.noise_type = FastNoiseLite.TYPE_CELLULAR
	stars.frequency = 0.08
	stars.cellular_return_type = FastNoiseLite.RETURN_CELL_VALUE
	var simg := stars.get_seamless_image(256, 256)
	sky_mat.set_shader_parameter("star_tex", ImageTexture.create_from_image(_star_img()))
	sky.sky_material = sky_mat
	sky.process_mode = Sky.PROCESS_MODE_INCREMENTAL
	sky.radiance_size = Sky.RADIANCE_SIZE_64
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_sky_contribution = 0.85
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	env.tonemap_white = 6.0
	if quality != "leve":
		env.glow_enabled = true
		env.glow_intensity = 0.55
		env.glow_bloom = 0.04
		env.glow_hdr_threshold = 1.1
	env.fog_enabled = quality != "leve"
	env.fog_mode = Environment.FOG_MODE_DEPTH
	env.fog_light_color = Color(0.72, 0.82, 0.92)
	env.fog_depth_begin = 70.0
	env.fog_depth_end = 220.0
	env.fog_density = 0.6
	if quality == "ultra":
		env.ssao_enabled = true
		env.ssao_radius = 0.8
		env.ssao_intensity = 1.6
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.08
	env.adjustment_contrast = 1.04
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.light_color = Color(1.0, 0.95, 0.86)
	sun.light_energy = 1.25
	sun.shadow_enabled = quality != "leve"
	sun.shadow_blur = 1.2
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = 45.0 if quality != "ultra" else 70.0
	if quality == "ultra":
		sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
		sun.directional_shadow_split_1 = 0.08
		sun.directional_shadow_split_2 = 0.22
		sun.directional_shadow_split_3 = 0.5
		RenderingServer.directional_shadow_atlas_set_size(4096, true)
		RenderingServer.directional_soft_shadow_filter_set_quality(RenderingServer.SHADOW_QUALITY_SOFT_HIGH)
	if quality != "ultra":
		sun.directional_shadow_split_1 = 0.25
	sun.shadow_normal_bias = 1.2
	sun.shadow_bias = 0.04
	sun.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_AND_SKY
	add_child(sun)
	moon = DirectionalLight3D.new()
	moon.light_color = Color(0.55, 0.65, 0.95)
	moon.light_energy = 0.0
	moon.shadow_enabled = false
	moon.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_ONLY
	add_child(moon)
	for k in (4 if quality != "leve" else 2):
		var l := OmniLight3D.new()
		l.light_color = Color(1.0, 0.82, 0.55)
		l.omni_range = 9.0
		l.light_energy = 0.0
		l.shadow_enabled = false
		add_child(l)
		light_pool.append(l)
	_make_rain()

func _star_img() -> Image:
	var img := Image.create_empty(256, 256, false, Image.FORMAT_L8)
	img.fill(Color(0, 0, 0))
	var r := RandomNumberGenerator.new()
	r.seed = 5
	for k in 420:
		var x := r.randi() % 256
		var y := r.randi() % 256
		var v := r.randf_range(0.88, 1.0)
		img.set_pixel(x, y, Color(v, v, v))
	return img

func _make_rain() -> void:
	rain_fx = GPUParticles3D.new()
	rain_fx.amount = 1600 if quality != "leve" else 500
	rain_fx.lifetime = 1.1
	rain_fx.emitting = false
	rain_fx.visibility_aabb = AABB(Vector3(-30, -20, -30), Vector3(60, 40, 60))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(22, 1, 22)
	pm.direction = Vector3(0.1, -1, 0)
	pm.spread = 3.0
	pm.initial_velocity_min = 16.0
	pm.initial_velocity_max = 19.0
	pm.gravity = Vector3(0, -9.8, 0)
	rain_fx.process_material = pm
	var dm := QuadMesh.new()
	dm.size = Vector2(0.02, 0.45)
	var mm := StandardMaterial3D.new()
	mm.albedo_color = Color(0.8, 0.85, 0.95, 0.35)
	mm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mm.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	dm.material = mm
	rain_fx.draw_pass_1 = dm
	add_child(rain_fx)

# hora (0..24): posição do sol e da lua, cores, nevoeiro
func set_hour(h: float) -> void:
	hour = h
	var a := (h - 6.0) / 12.0 * PI  # 0 ao nascer, PI ao pôr
	var sun_dir := Vector3(cos(a), sin(a), -0.35).normalized()
	var up: float = sun_dir.y
	night = clamp(1.0 - (up + 0.12) / 0.3, 0.0, 1.0)
	sun.visible = up > -0.05
	if sun.visible:
		sun.look_at_from_position(Vector3.ZERO, -sun_dir, Vector3.UP if abs(sun_dir.y) < 0.99 else Vector3.FORWARD)
	var low: float = 1.0 - clamp(up / 0.35, 0.0, 1.0)
	sun.light_color = Color(1.0, 0.95, 0.86).lerp(Color(1.0, 0.62, 0.38), low * 0.8)
	sun.light_energy = clamp(up * 3.0, 0.0, 1.0) * 1.3 * (1.0 - rain * 0.45)
	var moon_dir := -sun_dir
	moon_dir.y = abs(moon_dir.y) * 0.8 + 0.2
	moon.look_at_from_position(Vector3.ZERO, -moon_dir.normalized(), Vector3.UP)
	moon.light_energy = night * 0.22
	sky_mat.set_shader_parameter("night", night)
	sky_mat.set_shader_parameter("moon_dir", moon_dir.normalized())
	sky_mat.set_shader_parameter("cloudy", 0.25 + rain * 0.7)
	env.ambient_light_energy = lerp(1.0, 0.35, night)
	env.background_energy_multiplier = lerp(1.0, 0.6, night) * (1.0 - rain * 0.3)
	env.fog_light_color = Color(0.72, 0.82, 0.92).lerp(Color(0.08, 0.1, 0.18), night).lerp(Color(0.55, 0.58, 0.62), rain * 0.6)
	env.tonemap_exposure = lerp(1.0, 1.35, night)

func set_rain(on: bool) -> void:
	rain_on = on

func update(dt: float, cam_pos: Vector3, focus: Vector3, lamps: Array) -> void:
	rain = move_toward(rain, 1.0 if rain_on else 0.0, dt * 0.2)
	rain_fx.emitting = rain > 0.3
	rain_fx.global_position = Vector3(cam_pos.x, cam_pos.y + 12.0, cam_pos.z)
	pool_t -= dt
	if pool_t <= 0.0:
		pool_t = 0.4
		var sorted := lamps.duplicate()
		sorted.sort_custom(func(a, b): return a.distance_squared_to(focus) < b.distance_squared_to(focus))
		for k in light_pool.size():
			var l: OmniLight3D = light_pool[k]
			if k < sorted.size() and night > 0.05:
				l.global_position = sorted[k]
				l.light_energy = night * 1.6
				l.visible = true
			else:
				l.light_energy = 0.0
				l.visible = false
