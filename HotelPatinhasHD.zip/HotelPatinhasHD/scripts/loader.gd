# Hotel Patinhas HD · ecrã de carregamento: pegada a saltar, barra de progresso e o que está a ser preparado
class_name Loader
extends CanvasLayer

var bg: ColorRect
var paw: TextureRect
var shadow: Panel
var title: Label
var status: Label
var bar: ProgressBar
var t := 0.0
var shown := 0.0
var target := 0.0
var fading := false
var fade := 1.0
var dots := 0.0
var msg := ""
var tips: Array = []
var tip_lbl: Label
var tip_t := 0.0
var tip_i := 0
var _shot := false

func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(root)
	bg = ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.62, 0.84, 0.93)
	root.add_child(bg)
	var grad := TextureRect.new()
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 0.0))
	g.set_color(1, Color(0.36, 0.66, 0.42, 0.55))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill_from = Vector2(0, 0.45)
	gt.fill_to = Vector2(0, 1)
	grad.texture = gt
	grad.stretch_mode = TextureRect.STRETCH_SCALE
	grad.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	grad.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(grad)
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 14)
	box.custom_minimum_size = Vector2(440, 0)
	box.position = Vector2(-220, -200)
	root.add_child(box)
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(440, 190)
	box.add_child(holder)
	shadow = Panel.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0, 0, 0, 0.18)
	sb.set_corner_radius_all(40)
	shadow.add_theme_stylebox_override("panel", sb)
	shadow.size = Vector2(110, 18)
	holder.add_child(shadow)
	paw = TextureRect.new()
	paw.texture = load("res://icon.svg")
	paw.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	paw.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	paw.size = Vector2(130, 130)
	paw.pivot_offset = Vector2(65, 65)
	holder.add_child(paw)
	title = _lbl("Hotel Patinhas HD", 40, Color.WHITE)
	title.add_theme_color_override("font_outline_color", Color("#ff7a35"))
	title.add_theme_constant_override("outline_size", 14)
	box.add_child(title)
	bar = ProgressBar.new()
	bar.custom_minimum_size = Vector2(440, 26)
	bar.show_percentage = false
	bar.max_value = 1.0
	var bgs := StyleBoxFlat.new()
	bgs.bg_color = Color(1, 1, 1, 0.55)
	bgs.set_corner_radius_all(13)
	var fgs := StyleBoxFlat.new()
	fgs.bg_color = Color("#ff7a35")
	fgs.set_corner_radius_all(13)
	bar.add_theme_stylebox_override("background", bgs)
	bar.add_theme_stylebox_override("fill", fgs)
	box.add_child(bar)
	status = _lbl("", 22, Color("#20343f"))
	box.add_child(status)
	tip_lbl = _lbl("", 18, Color(0.13, 0.2, 0.25, 0.8))
	tip_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip_lbl.custom_minimum_size = Vector2(440, 0)
	box.add_child(tip_lbl)
	tips = [D.T("Dica: dá banho, comida e mimos para os hóspedes ficarem felizes."), D.T("Dica: leva os cães ao parque pela trela."), D.T("Dica: contrata ajudantes quando o hotel crescer."), D.T("Dica: em Opções podes escolher a qualidade dos gráficos.")]
	tip_i = randi() % tips.size()
	tip_lbl.text = tips[tip_i]
	get_viewport().size_changed.connect(_layout)
	_layout()

func _lbl(text: String, size: int, col: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	return l

func _layout() -> void:
	var box: Control = title.get_parent()
	var vs := get_viewport().get_visible_rect().size
	box.position = Vector2(vs.x * 0.5 - 220, vs.y * 0.5 - 200)

# f: 0..1, texto do que está a ser preparado
func set_progress(f: float, text: String) -> void:
	target = max(target, f)
	msg = text

func finish() -> void:
	target = 1.0
	fading = true

func _process(dt: float) -> void:
	dt = min(dt, 0.1)
	t += dt
	shown = move_toward(shown, target, dt * 1.6 + (target - shown) * dt * 4.0)
	bar.value = shown
	dots += dt * 2.5
	status.text = msg + ".".repeat(int(dots) % 4)
	# a pegada salta e roda um pouco
	var hop: float = abs(sin(t * 4.2))
	paw.position = Vector2(155, 10 + (1.0 - hop) * 42.0)
	paw.rotation = sin(t * 2.1) * 0.18
	var sq := 1.0 + (1.0 - hop) * 0.0
	paw.scale = Vector2(1.0 + (1.0 - hop) * 0.06, 1.0 - (1.0 - hop) * 0.06) * sq
	shadow.position = Vector2(220 - 55 * (0.7 + hop * 0.3), 168)
	shadow.size = Vector2(110 * (0.7 + (1.0 - hop) * 0.3), 18)
	if OS.get_environment("HP_LOADSHOT") != "" and shown > 0.4 and not _shot:
		_shot = true
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png("/tmp/hp_loading.png")
	tip_t += dt
	if tip_t > 3.5:
		tip_t = 0.0
		tip_i = (tip_i + 1) % tips.size()
		tip_lbl.text = tips[tip_i]
	if fading and shown > 0.99:
		fade -= dt * 2.5
		for c in get_children():
			(c as CanvasItem).modulate.a = max(fade, 0.0)
		if fade <= 0.0:
			queue_free()
