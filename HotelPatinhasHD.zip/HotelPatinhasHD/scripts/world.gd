# Hotel Patinhas HD · o mundo: hotel redondo com átrio, quartos em leque, pavilhões, galerias, parque,
# celeiro, aviário, gabinete veterinário, rua e cidade. Também guarda as colisões e a grelha de caminhos.
class_name World
extends Node3D

const C := Vector3(0, 0, -3)
const RI := 6.0
const RO := 12.5
const HW := 15.0
const PHI := [135.0, 45.0, 165.0, 15.0, 195.0, -15.0, 225.0, -45.0]
const LOB := Vector3(0, 0, 9)
const LR := 5.0
const DESK := Vector3(0, 0, 8.4)
const PAV := {
	"E": {"c": Vector3(27, 0, -3), "door": 180.0, "phis": [135.0, -135.0, 45.0, -45.0], "up": "pav_e", "sx": 1.0, "first": 8},
	"W": {"c": Vector3(-27, 0, -3), "door": 0.0, "phis": [45.0, -45.0, 135.0, -135.0], "up": "pav_w", "sx": -1.0, "first": 12},
}
const BARN := {"x": -32.0, "z": -30.0, "cols": [-5.4, 0.0, 5.4], "first": 16}
const AVI := {"x": 31.0, "z": -27.0, "cols": [-2.7, 2.7], "first": 22}
const DEPTH := 6.4
const RHW := 2.7
const EXT_H := 1.75
const INT_H := 1.35
const PEN_FLOORS := ["#f2d9b0", "#cfe6b6", "#c6e0f0", "#f0cfd9", "#ddd3f0", "#f3e3a8", "#cbe8dd", "#f2d3bb"]
const RUGS := ["#d9826b", "#6fae7f", "#5f97c9", "#d97a9c", "#9a83d6", "#d9b43e", "#58b39b", "#d98f5a"]
const BEDS := ["#8a7a6a", "#5f87b8", "#c2566c", "#4f9a73", "#8a5cd6", "#d4a017"]
const GIN := Vector3(0, 0, -18.4)
const PARK_WAIT := Vector3(0, 0, -17.6)
const CLINIC := {"x1": 6.9, "x2": 12.4, "z1": 8.3, "z2": 12.7, "door": Vector3(9.8, 0, 12.7), "table": Vector3(10.1, 0, 10.15), "stand": Vector3(10.1, 0, 9.15), "wait": Vector3(8.3, 0, 11.2)}
const TOWN_VET := {"table": Vector3(-21.6, 0, 19.0), "walk": Vector3(-16.6, 0, 19.0), "door": Vector3(-17.6, 0, 19.0)}
const ROAD_Z := 30.0
const SIDEWALK_Z := 24.4
const POOL := Vector3(11.5, 0, -32)
const LAKE := Vector3(23.5, 0, 20.5)
# grelha de caminhos
const GX0 := -64.0
const GZ0 := -48.0
const CELL := 0.4
const NX := 320
const NZ := 232

var rooms: Array = []      # definições dos 26 quartos
var room_nodes: Array = [] # nós de cada quarto (mobília, portas, placas)
var segs: Array = []       # colisões: [ax, az, bx, bz, r, on]
var seg_hash := {}
var astar := AStarGrid2D.new()
var nav_dirty := true
var lamps: Array = []      # posições de luzes noturnas
var glow_mats: Array = []  # materiais que brilham de noite
var roofs: Array = []      # {node, c, r}
var built := {}
var link_doors := {}
var movers: Array = []     # coisas que abrem portas (jogador, animais, pessoas)
var hotel_sign: Label3D
var hotel_sign_back: Label3D
var fountain_water: MeshInstance3D
var water_mat: ShaderMaterial
var park_gates := {}
var rain_mud := false
var static_root: Node3D
var dyn_root: Node3D
var grass_mm: MultiMeshInstance3D

func _ready() -> void:
	pass

# ===================== geometria base =====================
static func Pc(c: Vector3, a: float, R: float) -> Vector3:
	var r := deg_to_rad(a)
	return Vector3(c.x + R * cos(r), 0, c.z + R * sin(r))

static func ang_at(c: Vector3, p: Vector3) -> float:
	return rad_to_deg(atan2(p.z - c.z, p.x - c.x))

static func ang_diff(a: float, b: float) -> float:
	var d := fmod(a - b, 360.0)
	if d > 180:
		d -= 360
	if d < -180:
		d += 360
	return d

func _make_rooms() -> void:
	rooms.clear()
	var add_ring := func(c: Vector3, phi: float, hall: String):
		var r := deg_to_rad(phi)
		var f := Vector3(cos(r), 0, sin(r))
		var l := Vector3(sin(r), 0, -cos(r))
		rooms.append({"i": rooms.size(), "kind": "", "ring": true, "c": c, "phi": phi, "f": f, "l": l, "door": c + f * RI, "hall": hall})
	for p in PHI:
		add_ring.call(C, p, "main")
	for k in ["E", "W"]:
		for p in PAV[k].phis:
			add_ring.call(PAV[k].c, p, k)
	for pair in [[BARN, "barn"], [AVI, "avi"]]:
		var B: Dictionary = pair[0]
		for side in [-1.0, 1.0]:
			for dx in B.cols:
				var f := Vector3(0, 0, side)
				var door := Vector3(B.x + dx, 0, B.z + side * 1.6)
				rooms.append({"i": rooms.size(), "kind": pair[1], "ring": false, "c": door, "phi": 90.0 * side, "f": f, "l": Vector3(f.z, 0, -f.x), "door": door, "hall": pair[1]})

func W(i: int, u: float, v: float) -> Vector3:
	var R: Dictionary = rooms[i]
	if R.ring:
		return R.c + R.f * (RI + u) + R.l * v
	return R.door + R.f * u + R.l * v

func room_point(i: int, what: String) -> Vector3:
	match what:
		"door": return W(i, 0, 0)
		"out": return W(i, -0.9, 0)
		"in": return W(i, 1.0, 0)
		"center": return W(i, 3.6, 0)
		"bed": return W(i, 5.5, -1.9) if rooms[i].ring else W(i, 5.2, -1.3)
		"tub": return W(i, 5.25, 1.75) if rooms[i].ring else W(i, 5.0, 1.4)
		"food": return W(i, 2.4, -1.45)
		"water": return W(i, 2.4, 1.45)
		"hfood": return W(i, 1.5, -0.95)
		"hwater": return W(i, 1.5, 0.95)
		"htub": return W(i, 4.05, 1.75) if rooms[i].ring else W(i, 3.9, 1.2)
		"hplay": return W(i, 3.0, -0.5)
	return W(i, 3.6, 0)

func in_room(i: int, p: Vector3) -> bool:
	var R: Dictionary = rooms[i]
	if R.ring:
		var d := Vector2(p.x - R.c.x, p.z - R.c.z).length()
		return d > RI + 0.15 and d < RO - 0.2 and abs(ang_diff(ang_at(R.c, p), R.phi)) < HW - 0.8
	var q: Vector3 = p - R.door
	var u: float = q.dot(R.f)
	var v: float = q.dot(R.l)
	return u > 0.2 and u < DEPTH - 0.2 and abs(v) < RHW - 0.2

func room_at(p: Vector3) -> int:
	for i in rooms.size():
		if in_room(i, p):
			return i
	return -1

func random_in_room(i: int, rng: RandomNumberGenerator) -> Vector3:
	if rooms[i].ring:
		var u := rng.randf_range(1.6, 5.6)
		var R := RI + u
		var hw := R * sin(deg_to_rad(HW - 4.0)) - 0.4
		return W(i, u, rng.randf_range(-hw, hw))
	return W(i, rng.randf_range(1.4, 5.4), rng.randf_range(-1.8, 1.8))

# ===================== colisões =====================
func add_seg(a: Vector3, b: Vector3, r: float) -> int:
	var id := segs.size()
	segs.append([a.x, a.z, b.x, b.z, r, true])
	var x0 := int(floor((min(a.x, b.x) - r) / 3.0))
	var x1 := int(floor((max(a.x, b.x) + r) / 3.0))
	var z0 := int(floor((min(a.z, b.z) - r) / 3.0))
	var z1 := int(floor((max(a.z, b.z) + r) / 3.0))
	for x in range(x0, x1 + 1):
		for z in range(z0, z1 + 1):
			var k := Vector2i(x, z)
			if not seg_hash.has(k):
				seg_hash[k] = []
			seg_hash[k].append(id)
	nav_dirty = true
	return id

func set_seg(id: int, on: bool) -> void:
	if id >= 0 and segs[id][5] != on:
		segs[id][5] = on
		nav_dirty = true

static func seg_dist(px: float, pz: float, s: Array) -> float:
	var dx: float = s[2] - s[0]
	var dz: float = s[3] - s[1]
	var L := dx * dx + dz * dz
	var t := 0.0
	if L > 0:
		t = clamp(((px - s[0]) * dx + (pz - s[1]) * dz) / L, 0.0, 1.0)
	var qx: float = s[0] + dx * t - px
	var qz: float = s[1] + dz * t - pz
	return sqrt(qx * qx + qz * qz)

func blocked(x: float, z: float, r: float) -> bool:
	var k := Vector2i(int(floor(x / 3.0)), int(floor(z / 3.0)))
	var lst = seg_hash.get(k)
	if lst == null:
		return false
	for id in lst:
		var s: Array = segs[id]
		if s[5] and seg_dist(x, z, s) < s[4] + r:
			return true
	return false

# move com deslize pelas paredes
func slide(p: Vector3, d: Vector3, r: float) -> Vector3:
	var n := p + d
	for it in 3:
		var k := Vector2i(int(floor(n.x / 3.0)), int(floor(n.z / 3.0)))
		var pushed := false
		for dx in [-1, 0, 1]:
			for dz in [-1, 0, 1]:
				var lst = seg_hash.get(k + Vector2i(dx, dz))
				if lst == null:
					continue
				for id in lst:
					var s: Array = segs[id]
					if not s[5]:
						continue
					var dist := seg_dist(n.x, n.z, s)
					var lim: float = s[4] + r
					if dist < lim:
						var sx: float = s[2] - s[0]
						var sz: float = s[3] - s[1]
						var L := sx * sx + sz * sz
						var t := 0.0
						if L > 0:
							t = clamp(((n.x - s[0]) * sx + (n.z - s[1]) * sz) / L, 0.0, 1.0)
						var q := Vector3(s[0] + sx * t, n.y, s[1] + sz * t)
						var away := n - q
						away.y = 0
						if away.length() < 0.0001:
							away = -d
							away.y = 0
						n += away.normalized() * (lim - dist + 0.001)
						pushed = true
		if not pushed:
			break
	return n

# ===================== grelha de caminhos =====================
func rebuild_nav() -> void:
	astar.region = Rect2i(0, 0, NX, NZ)
	astar.cell_size = Vector2(CELL, CELL)
	astar.offset = Vector2(GX0 + CELL * 0.5, GZ0 + CELL * 0.5)
	astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	astar.default_compute_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	astar.default_estimate_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	astar.update()
	var agent := 0.28
	for s in segs:
		if not s[5]:
			continue
		var r: float = s[4] + agent
		var cx0 := int(floor((min(s[0], s[2]) - r - GX0) / CELL))
		var cx1 := int(floor((max(s[0], s[2]) + r - GX0) / CELL))
		var cz0 := int(floor((min(s[1], s[3]) - r - GZ0) / CELL))
		var cz1 := int(floor((max(s[1], s[3]) + r - GZ0) / CELL))
		for cx in range(max(cx0, 0), min(cx1, NX - 1) + 1):
			for cz in range(max(cz0, 0), min(cz1, NZ - 1) + 1):
				var px := GX0 + (cx + 0.5) * CELL
				var pz := GZ0 + (cz + 0.5) * CELL
				if seg_dist(px, pz, s) < r:
					astar.set_point_solid(Vector2i(cx, cz), true)
	nav_dirty = false

func cell_of(p: Vector3) -> Vector2i:
	return Vector2i(clamp(int(floor((p.x - GX0) / CELL)), 0, NX - 1), clamp(int(floor((p.z - GZ0) / CELL)), 0, NZ - 1))

func free_cell(c: Vector2i) -> Vector2i:
	if not astar.is_point_solid(c):
		return c
	for r in range(1, 10):
		for dx in range(-r, r + 1):
			for dz in [-r, r]:
				var q := c + Vector2i(dx, dz)
				if astar.is_in_boundsv(q) and not astar.is_point_solid(q):
					return q
				var q2 := c + Vector2i(dz, dx)
				if astar.is_in_boundsv(q2) and not astar.is_point_solid(q2):
					return q2
	return c

func line_free(a: Vector3, b: Vector3) -> bool:
	var d := b - a
	d.y = 0
	var L := d.length()
	var n := int(ceil(L / 0.2))
	for k in range(1, n):
		var p := a + d * (float(k) / n)
		if astar.is_point_solid(cell_of(p)):
			return false
	return true

func find_path(a: Vector3, b: Vector3) -> Array:
	if nav_dirty:
		rebuild_nav()
	var ca := free_cell(cell_of(a))
	var cb := free_cell(cell_of(b))
	var ids := astar.get_id_path(ca, cb, true)
	var pts: Array = []
	for id in ids:
		pts.append(Vector3(GX0 + (id.x + 0.5) * CELL, 0, GZ0 + (id.y + 0.5) * CELL))
	if pts.is_empty():
		return [Vector3(b.x, 0, b.z)]
	pts[pts.size() - 1] = Vector3(b.x, 0, b.z) if not astar.is_point_solid(cell_of(b)) else pts[pts.size() - 1]
	# alisar: salta pontos que se vêem diretamente
	var out: Array = []
	var cur := Vector3(a.x, 0, a.z)
	var i := 0
	while i < pts.size():
		var j := pts.size() - 1
		while j > i and not line_free(cur, pts[j]):
			j -= 1
		out.append(pts[j])
		cur = pts[j]
		i = j + 1
	return out

# ===================== construção =====================
var B: Batch

func wall(a: Vector3, b: Vector3, ext: bool, r_override := -1.0) -> int:
	var h := EXT_H if ext else INT_H
	var t := 0.28 if ext else 0.2
	var plaster := Mats.plaster("#f7f2e8" if ext else "#f1ece2")
	B.seg_box(a, b, h, t, plaster, 0.0, 0.04)
	B.seg_box(a, b, 0.14, t + 0.05, Mats.base("#9c8a70" if ext else "#b89f7e", 0.6))
	B.seg_box(a, b, 0.06, t + 0.08, Mats.base("#ffffff", 0.5), h, 0.06)
	_ao(a, b, t)
	return add_seg(a, b, t * 0.5 if r_override < 0 else r_override)

func wall_arc(c: Vector3, R: float, a1: float, a2: float, ext: bool) -> void:
	var n: int = max(1, int(ceil(abs(a2 - a1) / 7.5)))
	for k in n:
		wall(Pc(c, a1 + (a2 - a1) * k / n, R), Pc(c, a1 + (a2 - a1) * (k + 1) / n, R), ext)

var ao_st: SurfaceTool
func _ao(a: Vector3, b: Vector3, t: float) -> void:
	if Mats.quality == "leve":
		return
	if ao_st == null:
		ao_st = SurfaceTool.new()
		ao_st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var d := b - a
	d.y = 0
	var L := d.length()
	if L < 0.01:
		return
	var nrm := Vector3(-d.z, 0, d.x) / L
	for sgn in [-1.0, 1.0]:
		var i0: Vector3 = nrm * (t * 0.5 * sgn)
		var o0: Vector3 = nrm * ((t * 0.5 + 0.55) * sgn)
		var P := [a + i0, b + i0, b + o0, a + i0, b + o0, a + o0]
		var UV := [0.0, 0.0, 1.0, 0.0, 1.0, 1.0]
		for k in 6:
			ao_st.set_uv(Vector2(0, UV[k]))
			ao_st.set_normal(Vector3.UP)
			ao_st.add_vertex(P[k] + Vector3(0, 0.06, 0))

func _flush_ao(parent: Node3D) -> void:
	if ao_st == null:
		return
	var mesh := ao_st.commit()
	ao_st = null
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var g := Gradient.new()
	g.set_color(0, Color(0, 0, 0, 0.38))
	g.set_color(1, Color(0, 0, 0, 0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	gt.width = 4
	gt.height = 64
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_texture = gt
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.render_priority = -1
	mi.material_override = m
	parent.add_child(mi)

func floor_sector(c: Vector3, r1: float, r2: float, a1: float, a2: float, y: float, mat: Material) -> void:
	B.add(Batch.sector_mesh(c, r1, r2, a1, a2, y), Transform3D(), mat)

func floor_rect(x1: float, x2: float, z1: float, z2: float, y: float, mat: Material) -> void:
	B.box(abs(x2 - x1), 0.02, abs(z2 - z1), mat, Vector3((x1 + x2) * 0.5, y - 0.01, (z1 + z2) * 0.5))

func label(text: String, pos: Vector3, size := 64, bg := Color(0, 0, 0, 0), col := Color.WHITE, parent: Node = null) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.position = pos
	l.font_size = size
	l.pixel_size = 0.0042
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.modulate = col
	l.outline_size = 14
	l.outline_modulate = Color(0.1, 0.12, 0.15, 0.85) if bg.a == 0 else bg
	l.double_sided = true
	l.no_depth_test = false
	l.fixed_size = false
	(parent if parent else self).add_child(l)
	return l

func lamp(pos: Vector3, parent: Node3D, bb: Batch) -> void:
	Props.lamp_post(bb, pos)
	var bulb := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.16
	sm.height = 0.3
	bulb.mesh = sm
	bulb.material_override = _glow_mat("#fff1c4")
	bulb.position = pos + Vector3(0, 2.62, 0)
	bulb.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(bulb)
	lamps.append(pos + Vector3(0, 2.5, 0))

func set_sign(text: String) -> void:
	hotel_sign.text = text
	hotel_sign_back.text = text

func _glow_mat(col: String) -> StandardMaterial3D:
	for m in glow_mats:
		if m.albedo_color == Color(col):
			return m
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(col)
	m.emission_enabled = true
	m.emission = Color(col)
	m.emission_energy_multiplier = 0.2
	glow_mats.append(m)
	return m

func set_night(f: float) -> void:
	for m in glow_mats:
		m.emission_energy_multiplier = 0.15 + f * 3.5

# ===================== mundo inteiro =====================
func build() -> void:
	_make_rooms()
	static_root = Node3D.new()
	static_root.name = "Static"
	add_child(static_root)
	dyn_root = Node3D.new()
	dyn_root.name = "Dynamic"
	add_child(dyn_root)
	B = Batch.new()
	_build_ground()
	_build_main()
	_build_garden()
	_build_front()
	_build_trees()
	B.commit(static_root, true, "Hotel")
	_flush_ao(static_root)
	for i in 8:
		_room_shell(i)
	_build_roofs_main()
	_build_town()
	_build_grass()

func _build_ground() -> void:
	var g := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(420, 420)
	pm.subdivide_width = 0
	g.mesh = pm
	var m := ShaderMaterial.new()
	m.shader = load("res://shaders/ground.gdshader")
	m.set_shader_parameter("noise_tex", Mats.noise_tex(12, 0.01, 256, 1.0))
	m.set_shader_parameter("detail_tex", Mats.noise_tex(13, 0.05, 256, 1.0))
	m.set_shader_parameter("normal_tex", Mats.noise_normal(14, 0.08, 4.0))
	g.material_override = m
	g.position = Vector3(0, 0, -10)
	g.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	static_root.add_child(g)

func _build_main() -> void:
	var hall := Mats.textured("#eadfca", "bigtiles", 1.1, 0.35, 0.6)
	var stone := Mats.textured("#cfc6b6", "pavers", 1.6, 0.85, 1.0)
	var woodf := Mats.textured("#b98b5e", "planks", 2.4, 0.45, 0.6)
	floor_sector(C, 0, RO + 0.2, 0, 360, 0.015, Mats.rough_surface("#e9e0cf", 2.0, 0.9))
	B.add(Batch.disc_mesh(LOB, LR + 0.05, 0.04), Transform3D(), hall)
	B.add(Batch.disc_mesh(C, RI, 0.035), Transform3D(), woodf)
	floor_sector(C, RI, RO, 60, 120, 0.03, hall)
	floor_sector(C, RI, RO, 240, 300, 0.03, stone)
	for a in [120.0, 150.0, 180.0, 210.0, 240.0, 60.0, 30.0, 0.0, -30.0, -60.0]:
		wall(Pc(C, a, RI), Pc(C, a, RO), false)
	for p in PHI:
		wall_arc(C, RO, p - HW, p + HW, true)
	wall_arc(C, RO, 240, 263, true)
	wall_arc(C, RO, 277, 300, true)
	for pr in [[-20.0, 52.0], [72.0, 76.0], [104.0, 108.0], [128.0, 200.0]]:
		wall_arc(LOB, LR, pr[0], pr[1], true)
	# portas das galerias (fechadas até haver pavilhão)
	for k in ["E", "W"]:
		var a: float = 62.0 if k == "E" else 118.0
		var p1 := Pc(LOB, a - 10, LR)
		var p2 := Pc(LOB, a + 10, LR)
		link_doors[k] = {"seg": add_seg(p1, p2, 0.14), "a": a}
	wall(Pc(C, 120, RO), Pc(LOB, 200, LR), true)
	wall(Pc(C, 60, RO), Pc(LOB, -20, LR), true)
	# entrada com arco
	var tc := Mats.glossy("#7fb8a7", 0.5)
	var e1 := Pc(LOB, 76, LR)
	var e2 := Pc(LOB, 104, LR)
	B.box(0.5, 3.0, 0.5, tc, e1 + Vector3(0, 1.5, 0))
	B.box(0.5, 3.0, 0.5, tc, e2 + Vector3(0, 1.5, 0))
	B.box(3.3, 0.5, 0.6, tc, Vector3(0, 3.1, (e1.z + e2.z) * 0.5))
	hotel_sign = label("🐾 Casota Patinhas", Vector3(0, 3.75, 14.2), 96)
	hotel_sign.billboard = BaseMaterial3D.BILLBOARD_DISABLED
	hotel_sign.pixel_size = 0.0045
	hotel_sign.modulate = Color("#ffffff")
	hotel_sign.outline_modulate = Color("#ff7a35")
	hotel_sign.outline_size = 36
	hotel_sign.double_sided = false
	hotel_sign_back = hotel_sign.duplicate() as Label3D
	hotel_sign_back.rotation.y = PI
	add_child(hotel_sign_back)
	for a in [40.0, 140.0]:
		var p := Pc(LOB, a, LR + 0.16)
		B.box(1.6, 0.7, 0.05, Mats.glass(), p + Vector3(0, 0.95, 0), atan2(p.x - LOB.x, p.z - LOB.z))
	# balcão curvo
	var desk_wood := Mats.textured("#9a6a44", "planks", 1.0, 0.5, 0.6)
	B.add(Batch.band_mesh(DESK, 1.6, 2.05, 0, 180, 0, 1.0), Transform3D(), desk_wood)
	B.add(Batch.band_mesh(DESK, 1.52, 2.15, 0, 180, 1.0, 0.08), Transform3D(), Mats.textured("#e8dcc8", "", 1.0, 0.25, 0.3))
	for k in 6:
		var a1 := k * 30.0
		add_seg(Pc(DESK, a1, 1.83), Pc(DESK, a1 + 30, 1.83), 0.26)
	B.box(0.55, 0.34, 0.04, Mats.glossy("#16181d", 0.15), Vector3(0.7, 1.33, 8.4 + 1.2), 0.0)
	B.box(0.08, 0.22, 0.08, Mats.glossy("#16181d", 0.3), Vector3(0.7, 1.15, 9.6))
	B.box(0.5, 0.3, 0.01, Mats.emissive("#5aa0e0", 0.6), Vector3(0.7, 1.33, 9.62))
	B.cyl(0.11, 0.13, 0.07, Mats.glossy("#d9b13a", 0.2, 0.9), Vector3(-0.7, 1.12, 10.0), 16)
	B.ball(0.08, Mats.glossy("#d9b13a", 0.2, 0.9), Vector3(-0.7, 1.18, 10.0))
	label("🛎️", Vector3(-0.7, 1.5, 10.0), 28)
	# tapete da entrada
	B.box(3.2, 0.02, 1.5, Mats.cloth("#c2566c"), Vector3(0, 0.055, 12.3))
	# cadeiras de espera e plantas
	for k in 3:
		var a2: float = [150.0, 165.0, 15.0][k]
		var p := Pc(LOB, a2, 3.9)
		Props.chair(B, p, atan2(LOB.x - p.x, LOB.z - p.z), "#2f8f83")
	Props.plant(B, Pc(LOB, 30, 4.2))
	Props.plant(B, Pc(LOB, 120, 4.3))
	# candeeiro de teto da receção
	lamps.append(Vector3(0, 2.8, LOB.z + 1))
	# átrio com fonte
	var stoneW := Mats.rough_surface("#d8d2c4", 0.8, 0.7, 0.6, 7)
	B.cyl(1.35, 1.45, 0.45, stoneW, C + Vector3(0, 0.22, 0), 32)
	B.cyl(0.18, 0.26, 1.1, stoneW, C + Vector3(0, 0.6, 0), 16)
	B.cyl(0.55, 0.3, 0.14, stoneW, C + Vector3(0, 1.15, 0), 24)
	add_seg(C, C, 1.45)
	fountain_water = _water_disc(C + Vector3(0, 0.43, 0), 1.2, static_root)
	_water_disc(C + Vector3(0, 1.23, 0), 0.48, static_root)
	for a in [20.0, 160.0, 200.0, 340.0]:
		var p := Pc(C, a, 3.4)
		Props.bench(B, p, atan2(p.x - C.x, p.z - C.z) + PI)
		add_seg(p, p, 0.45)
	lamps.append(C + Vector3(0, 3.0, 0))
	# sala do pessoal (sector das traseiras)
	var p1 := Pc(C, 249, 11.4)
	Props.sofa(B, p1, atan2(C.x - p1.x, C.z - p1.z), "#6b8fb3")
	add_seg(p1, p1, 0.9)
	var p2 := Pc(C, 249, 7.6)
	Props.tv(B, p2, atan2(p1.x - p2.x, p1.z - p2.z))
	add_seg(p2, p2, 0.6)
	var p3 := Pc(C, 290, 11.5)
	B.box(0.9, 1.0, 0.6, Mats.glossy("#e8e2d4", 0.3), p3 + Vector3(0, 0.5, 0), atan2(C.x - p3.x, C.z - p3.z))
	B.box(0.4, 0.5, 0.35, Mats.glossy("#2a2d33", 0.3, 0.5), p3 + Vector3(0, 1.25, 0), atan2(C.x - p3.x, C.z - p3.z))
	add_seg(p3, p3, 0.55)
	Props.table_round(B, Pc(C, 288, 8.6), 0.55)
	add_seg(Pc(C, 288, 8.6), Pc(C, 288, 8.6), 0.6)
	for a in [282.0, 294.0]:
		var pc := Pc(C, a, 8.6)
		Props.chair(B, pc, atan2(Pc(C, 288, 8.6).x - pc.x, Pc(C, 288, 8.6).z - pc.z), "#d9826b")
	Props.plant(B, Pc(C, 243, 11.8))
	Props.plant(B, Pc(C, 297, 11.8))
	label("☕ " + D.T("Sala do pessoal"), Pc(C, 270, 9.0) + Vector3(0, 2.4, 0), 44)
	# porta do jardim
	var gd := Mats.glossy("#43a35a", 0.5)
	var g1 := Pc(C, 263, RO)
	var g2 := Pc(C, 277, RO)
	B.box(0.35, 2.3, 0.35, gd, g1 + Vector3(0, 1.15, 0))
	B.box(0.35, 2.3, 0.35, gd, g2 + Vector3(0, 1.15, 0))
	B.box(3.3, 0.3, 0.4, gd, Vector3(0, 2.35, (g1.z + g2.z) * 0.5))
	label("🌳 " + D.T("Parque de acrobacias"), Vector3(0, 3.2, -15.8), 56)

func _water_disc(pos: Vector3, r: float, parent: Node3D) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r
	cm.height = 0.02
	cm.radial_segments = 32
	mi.mesh = cm
	mi.material_override = get_water_mat()
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi

func get_water_mat() -> ShaderMaterial:
	if water_mat == null:
		water_mat = ShaderMaterial.new()
		water_mat.shader = load("res://shaders/water.gdshader")
		water_mat.set_shader_parameter("normal_tex", Mats.noise_normal(61, 0.05, 3.0))
	return water_mat

# ---------- parque de acrobacias ----------
func fence(a: Vector3, b: Vector3, bb: Batch) -> int:
	var white := Mats.base("#f6f1e6", 0.7)
	bb.seg_box(a, b, 0.08, 0.06, white, 0.35)
	bb.seg_box(a, b, 0.08, 0.06, white, 0.75)
	var L := a.distance_to(b)
	var n: int = max(1, int(ceil(L / 0.5)))
	for k in n + 1:
		var p := a.lerp(b, float(k) / n)
		bb.box(0.08, 0.95, 0.04, white, p + Vector3(0, 0.47, 0), atan2(b.x - a.x, b.z - a.z))
	return add_seg(a, b, 0.08)

const COURSE := [
	[Vector3(0, 0, -19.0), 0.0], [Vector3(-6, 0, -19.6), 0.0], [Vector3(-8.6, 0, -20.6), 0.0], [Vector3(-10.4, 0, -22.2), 0.55],
	[Vector3(-11, 0, -23.4), 0.0], [Vector3(-11, 0, -28.6), 0.0], [Vector3(-9.2, 0, -30.4), 0.0],
	[Vector3(-7.5, 0, -31.6), 0.0], [Vector3(-6.1, 0, -30.4), 0.0], [Vector3(-4.7, 0, -31.6), 0.0], [Vector3(-3.3, 0, -30.4), 0.0], [Vector3(-1.9, 0, -31.6), 0.0], [Vector3(-0.5, 0, -30.4), 0.0],
	[Vector3(2.6, 0, -29.5), 0.0], [Vector3(5.3, 0, -29.5), 1.35], [Vector3(8.0, 0, -29.5), 0.0],
	[Vector3(10, 0, -26.8), 0.0], [Vector3(10, 0, -23.2), 1.1], [Vector3(8.4, 0, -20.4), 0.0], [Vector3(6, 0, -18.8), 0.55], [Vector3(3, 0, -17.8), 0.0],
]

func _build_garden() -> void:
	var gw := -30.0
	var ge := -27.0
	var pts := [[Pc(C, 215, RO), Vector3(-16, 0, -14)], [Vector3(-16, 0, -14), Vector3(-16, 0, gw + 1.1)], [Vector3(-16, 0, gw - 1.1), Vector3(-16, 0, -35.5)],
		[Vector3(-16, 0, -35.5), Vector3(16, 0, -35.5)], [Vector3(16, 0, -35.5), Vector3(16, 0, ge - 1.1)], [Vector3(16, 0, ge + 1.1), Vector3(16, 0, -14)], [Vector3(16, 0, -14), Pc(C, 325, RO)]]
	for pr in pts:
		fence(pr[0], pr[1], B)
	park_gates["W"] = {"seg": add_seg(Vector3(-16, 0, gw - 1.1), Vector3(-16, 0, gw + 1.1), 0.1), "pos": Vector3(-16, 0, gw)}
	park_gates["E"] = {"seg": add_seg(Vector3(16, 0, ge - 1.1), Vector3(16, 0, ge + 1.1), 0.1), "pos": Vector3(16, 0, ge)}
	B.box(2.2, 0.02, 3.2, Mats.textured("#cfc6b6", "pavers", 1.4, 0.85), Vector3(0, 0.02, -17.4))
	# areia
	var sand := Mats.rough_surface("#e3cf9c", 1.2, 0.95, 0.8, 71)
	B.add(Batch.disc_mesh(Vector3.ZERO, 1.0, 0.0), Transform3D(Basis().scaled(Vector3(12.4, 1, 8.4)), Vector3(0, 0.018, -25.2)), sand)
	var white := Mats.base("#ffffff", 0.5)
	var red := Mats.glossy("#e8443a", 0.4)
	# barreira
	var hp := Vector3(-10.4, 0, -22.2)
	var hy := atan2(-1.8, -1.6)
	for sx in [-0.95, 0.95]:
		var o := Basis(Vector3.UP, hy) * Vector3(sx, 0, 0)
		B.cyl(0.05, 0.05, 1.1, white, hp + o + Vector3(0, 0.55, 0), 8)
	B.box(1.9, 0.08, 0.08, red, hp + Vector3(0, 0.62, 0), hy + PI / 2)
	B.box(1.9, 0.08, 0.08, white, hp + Vector3(0, 0.35, 0), hy + PI / 2)
	# túnel
	var tun := MeshInstance3D.new()
	var tm := CylinderMesh.new()
	tm.top_radius = 0.78
	tm.bottom_radius = 0.78
	tm.height = 4.6
	tm.cap_top = false
	tm.cap_bottom = false
	tm.radial_segments = 24
	B.add(tm, Transform3D(Basis(Vector3.RIGHT, PI / 2), Vector3(-11, 0.55, -26)), _double(Mats.glossy("#e0508a", 0.5)))
	for z in [-2.3, -0.8, 0.8, 2.3]:
		B.add(Batch.torus_mesh(0.72, 0.86), Transform3D(Basis(Vector3.RIGHT, PI / 2), Vector3(-11, 0.55, -26 + z)), Mats.glossy("#f2c230", 0.4))
	add_seg(Vector3(-11.8, 0, -28.3), Vector3(-11.8, 0, -23.7), 0.05)
	add_seg(Vector3(-10.2, 0, -28.3), Vector3(-10.2, 0, -23.7), 0.05)
	# slalom
	for k in 6:
		var x := -7.5 + k * 1.4
		B.cyl(0.045, 0.045, 1.15, Mats.glossy("#3a95d8" if k % 2 else "#ffffff", 0.4), Vector3(x, 0.575, -31), 8)
		B.box(0.25, 0.03, 0.25, Mats.base("#33373d"), Vector3(x, 0.015, -31))
	# rampa (A)
	var ra := atan(1.4 / 2.15)
	var pl := sqrt(2.15 * 2.15 + 1.4 * 1.4)
	var blue := Mats.glossy("#3a95d8", 0.5)
	B.box_xf(Vector3(1.1, 0.08, pl), Transform3D(Basis(Vector3.UP, PI / 2) * Basis(Vector3.RIGHT, -ra), Vector3(5.3 - 1.075, 0.7, -29.5)), blue)
	B.box_xf(Vector3(1.1, 0.08, pl), Transform3D(Basis(Vector3.UP, PI / 2) * Basis(Vector3.RIGHT, ra), Vector3(5.3 + 1.075, 0.7, -29.5)), blue)
	# pneu
	for sx in [-1.05, 1.05]:
		B.cyl(0.07, 0.07, 2.2, white, Vector3(10 + sx, 1.1, -24), 8)
	B.box(2.2, 0.1, 0.1, white, Vector3(10, 2.2, -24))
	B.add(Batch.torus_mesh(0.42, 0.62), Transform3D(Basis(Vector3.RIGHT, PI / 2), Vector3(10, 1.15, -24)), Mats.base("#1f1f23", 0.9))
	# pódio
	B.cyl(0.8, 0.85, 0.5, Mats.glossy("#ff7a35", 0.5), Vector3(6, 0.25, -18.8), 24)
	B.cyl(0.82, 0.82, 0.06, Mats.glossy("#f2c230", 0.4), Vector3(6, 0.53, -18.8), 24)
	label("⭐", Vector3(6, 2.0, -18.8), 64)
	for p in [Vector3(-13.5, 0, -25), Vector3(13.5, 0, -24)]:
		Props.bench(B, p, PI / 2 if p.x < 0 else -PI / 2)
		add_seg(p, p, 0.5)
	Props.flower_bed(B, Vector3(-14.6, 0, -16), Vector3(-14.6, 0, -34.5), 18)
	Props.flower_bed(B, Vector3(14.6, 0, -16), Vector3(14.6, 0, -34.5), 18)
	B.cyl(0.3, 0.35, 0.6, Mats.glossy("#9ad0ea", 0.4), Vector3(-3.5, 0.3, -17.6), 16)
	add_seg(Vector3(-3.5, 0, -17.6), Vector3(-3.5, 0, -17.6), 0.4)
	for p in [Vector3(-13, 0, -20.5), Vector3(13, 0, -20.5), Vector3(-13, 0, -29.5), Vector3(0, 0, -34.5)]:
		lamp(p, static_root, B)
		add_seg(p, p, 0.12)

func _double(m: StandardMaterial3D) -> StandardMaterial3D:
	var d := m.duplicate() as StandardMaterial3D
	d.cull_mode = BaseMaterial3D.CULL_DISABLED
	return d

# ---------- frente do hotel ----------
func _build_front() -> void:
	var pav := Mats.textured("#d8d0c0", "pavers", 1.3, 0.85, 1.0)
	B.box(3.0, 0.03, 10.0, pav, Vector3(0, 0.025, 19.2))
	Props.flower_bed(B, Vector3(-2.2, 0, 15), Vector3(-2.2, 0, 23.5), 12)
	Props.flower_bed(B, Vector3(2.2, 0, 15), Vector3(2.2, 0, 23.5), 12)
	for x in [-2.6, 2.6]:
		for z in [16.8, 22.6]:
			lamp(Vector3(x, 0, z), static_root, B)
			add_seg(Vector3(x, 0, z), Vector3(x, 0, z), 0.12)
	# veterinário do bairro
	var vb := Mats.rough_surface("#f6f3ec", 1.2, 0.85)
	var vx := -21.6
	var vz := 19.0
	B.box(7.0, 0.04, 6.0, Mats.textured("#e3f0f0", "tiles", 1.2, 0.3), Vector3(vx, 0.03, vz))
	wall(Vector3(vx - 3.5, 0, vz - 3), Vector3(vx + 3.5, 0, vz - 3), true)
	wall(Vector3(vx - 3.5, 0, vz + 3), Vector3(vx + 3.5, 0, vz + 3), true)
	wall(Vector3(vx - 3.5, 0, vz - 3), Vector3(vx - 3.5, 0, vz + 3), true)
	wall(Vector3(vx + 3.5, 0, vz - 3), Vector3(vx + 3.5, 0, vz - 1.0), true)
	wall(Vector3(vx + 3.5, 0, vz + 1.0), Vector3(vx + 3.5, 0, vz + 3), true)
	B.box(1.2, 0.85, 0.7, Mats.glossy("#c9cfd6", 0.3, 0.6), Vector3(vx, 0.42, vz))
	B.box(1.3, 0.06, 0.8, Mats.glossy("#e8eef2", 0.2), Vector3(vx, 0.88, vz))
	add_seg(Vector3(vx - 0.6, 0, vz), Vector3(vx + 0.6, 0, vz), 0.4)
	B.box(0.5, 1.8, 2.0, Mats.glossy("#ffffff", 0.3), Vector3(vx - 3.1, 0.9, vz), 0)
	B.box(2.8, 0.03, 1.4, pav, Vector3(vx + 4.9, 0.025, vz))
	B.box(6.0, 0.03, 1.4, pav, Vector3((vx + 6.3 - 1.5) * 0.5 - 6.0, 0.024, vz))
	label("🩺 " + D.T("Veterinário do bairro"), Vector3(vx, 3.0, vz), 52)
	vb = vb

func _build_trees() -> void:
	var pts := [[-18, 15], [18, 15], [-20, 26], [20, 26], [-21, -22], [21, -24], [-6, -41], [7, -41], [-19, -34], [19, -33], [-13.5, -33], [-14, -17.2], [14, -17.2], [-43, -3], [43, -3], [-30, 14], [30, 12], [-30, -20], [30, -20], [-46, 20], [46, 20], [-46, -30], [46, -30], [-40, -46], [40, -46], [0, -44], [-52, 0], [52, 4], [-8, 26], [9, 26]]
	for k in pts.size():
		var p := Vector3(pts[k][0], 0, pts[k][1])
		if k % 4 == 3:
			Props.pine(B, p, 1.1 + (k % 3) * 0.15)
		else:
			Props.tree(B, p, 0.95 + ((k * 37) % 5) / 10.0, k)
		add_seg(p, p, 0.3)

# ---------- quartos ----------
func _room_shell(i: int) -> void:
	if room_nodes.size() > i and room_nodes[i] != null:
		return
	while room_nodes.size() <= i:
		room_nodes.append(null)
	var R: Dictionary = rooms[i]
	var node := Node3D.new()
	node.name = "Room%d" % i
	(dyn_root if R.kind == "" else built.get(R.kind + "_node", dyn_root)).add_child(node)
	var rn := {"node": node, "furn": null, "leaves": [], "open": 0.0, "gate": -1, "gate_mesh": null, "sign": null, "lock": null, "levels": {}, "tub_water": null}
	var bb := Batch.new()
	if R.ring:
		var da := rad_to_deg(asin(0.98 / RI))
		var pen_floor := Mats.textured(PEN_FLOORS[i % 8], "tiles", 1.0, 0.4, 0.5)
		var oldB := B
		B = bb
		floor_sector(R.c, RI, RO, R.phi - HW, R.phi + HW, 0.04, pen_floor)
		if R.hall == "main":
			wall_arc(R.c, RI, R.phi - HW, R.phi - da, false)
			wall_arc(R.c, RI, R.phi + da, R.phi + HW, false)
		else:
			wall_arc(R.c, RI, R.phi - HW, R.phi - da, false)
			wall_arc(R.c, RI, R.phi + da, R.phi + HW, false)
		B = oldB
	else:
		var oldB2 := B
		B = bb
		var fl := Mats.rough_surface("#d9c89a" if R.kind == "barn" else "#cfc8b8", 1.0, 0.95, 0.8, 81)
		var c := W(i, DEPTH * 0.5, 0)
		B.box(RHW * 2.0, 0.03, DEPTH, fl, c + Vector3(0, 0.03, 0), atan2(R.f.x, R.f.z))
		B = oldB2
	# portas: duplas de madeira nos quartos, meias-portas de estábulo no celeiro e de rede no aviário
	var T := Transform3D(Basis(Vector3.UP, atan2(R.l.x, R.l.z) + PI / 2), R.door)
	var fh := 2.3 if R.kind == "" else (1.45 if R.kind == "barn" else 2.4)
	var fr := Mats.glossy("#f4efe6", 0.5) if R.kind == "" else (Props.wood("#7a5a3a") if R.kind == "barn" else Mats.glossy("#5f87b8", 0.4, 0.5))
	Props.lbox(bb, T, Vector3(0.14, fh, 0.3), Vector3(-1.05, fh * 0.5, 0), fr)
	Props.lbox(bb, T, Vector3(0.14, fh, 0.3), Vector3(1.05, fh * 0.5, 0), fr)
	if R.kind != "barn":
		Props.lbox(bb, T, Vector3(2.24, 0.16, 0.32), Vector3(0, fh + 0.02, 0), fr)
	bb.commit(node, true, "Shell")
	for s in [-1.0, 1.0]:
		var hinge := Node3D.new()
		hinge.transform = T * Transform3D(Basis(), Vector3(s * 0.97, 0, 0))
		node.add_child(hinge)
		var lb := Batch.new()
		var lx: float = -s * 0.475
		if R.kind == "":
			var wood := Mats.textured("#8a5a36", "planks_v", 1.0, 0.45, 0.5)
			lb.box(0.93, 2.1, 0.05, wood, Vector3(lx, 1.07, 0))
			lb.box(0.6, 0.6, 0.06, Mats.glass(), Vector3(lx, 1.55, 0))
			lb.box(0.04, 0.2, 0.09, Mats.glossy("#c9cfd6", 0.15, 0.9), Vector3(-s * 0.85, 1.0, 0))
		elif R.kind == "barn":
			var w2 := Mats.textured("#a8402f", "planks_v", 0.8, 0.7, 0.6)
			lb.box(0.93, 1.15, 0.06, w2, Vector3(lx, 0.65, 0))
			lb.box(0.9, 0.08, 0.08, Mats.base("#f4f1ec", 0.6), Vector3(lx, 0.65, 0.0), 0.0)
			lb.box_xf(Vector3(1.2, 0.08, 0.07), Transform3D(Basis(Vector3.FORWARD, 0.9 * s), Vector3(lx, 0.65, 0.01)), Mats.base("#f4f1ec", 0.6))
		else:
			lb.box(0.9, 2.2, 0.03, Mats.glass(), Vector3(lx, 1.15, 0))
			lb.box(0.93, 0.06, 0.06, Mats.glossy("#5f87b8", 0.4, 0.5), Vector3(lx, 2.24, 0))
			lb.box(0.06, 2.2, 0.06, Mats.glossy("#5f87b8", 0.4, 0.5), Vector3(lx - s * 0.44, 1.15, 0))
		lb.commit(hinge, true, "Leaf")
		rn.leaves.append({"h": hinge, "s": s})
	# barreira (quarto por construir)
	var gm := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.95, 0.9, 0.18)
	gm.mesh = bm
	var sm := StandardMaterial3D.new()
	sm.albedo_texture = Mats.pattern("stripes")[0]
	sm.roughness = 0.5
	gm.material_override = sm
	gm.transform = T * Transform3D(Basis(), Vector3(0, 0.45, 0))
	node.add_child(gm)
	rn.gate_mesh = gm
	rn.gate = add_seg(R.door + R.l * 1.0, R.door - R.l * 1.0, 0.1)
	rn.sign = label(D.room_no(i), R.door + Vector3(0, 2.75, 0), 40, Color(0, 0, 0, 0), Color.WHITE, node)
	rn.sign.visibility_range_end = 30.0
	rn.lock = label("🔒", W(i, 3.6, 0) + Vector3(0, 1.3, 0), 80, Color(0, 0, 0, 0), Color.WHITE, node)
	room_nodes[i] = rn

# mobília conforme o tipo de quarto e a decoração escolhida
func furnish(i: int, open: bool, decor: Dictionary) -> void:
	var rn: Dictionary = room_nodes[i]
	if rn.furn != null:
		rn.furn.queue_free()
		rn.furn = null
	rn.levels = {}
	set_seg(rn.gate, not open)
	rn.gate_mesh.visible = not open
	rn.lock.visible = not open
	if not open:
		return
	var R: Dictionary = rooms[i]
	var fn := Node3D.new()
	rn.node.add_child(fn)
	rn.furn = fn
	var bb := Batch.new()
	var fl: String = decor.get("floor", PEN_FLOORS[i % 8])
	var rugc: String = decor.get("rug", RUGS[i % 8])
	var bedc: String = decor.get("bed", BEDS[i % BEDS.size()])
	var face := atan2(-R.f.x, -R.f.z)
	if R.kind == "":
		if decor.has("floor"):
			var oldB := B
			B = bb
			floor_sector(R.c, RI + 0.02, RO - 0.05, R.phi - HW + 0.3, R.phi + HW - 0.3, 0.045, Mats.textured(fl, "tiles", 1.0, 0.4, 0.5))
			B = oldB
		Props.rug(bb, W(i, 3.6, 0), face, rugc)
		Props.pet_bed(bb, room_point(i, "bed"), face, bedc)
		Props.tub(bb, room_point(i, "tub"), face + PI / 2)
		Props.plant(bb, W(i, 5.9, 0.6), 0.8)
		Props.painting(bb, W(i, 6.3, 0) + Vector3(0, 1.25, 0), face, RUGS[(i + 3) % 8])
		Props.toy_ball(bb, W(i, 3.4, -0.7), "#e8443a")
		add_room_cols(i, ["bed", "tub"])
	elif R.kind == "barn":
		var straw := Mats.rough_surface("#e2c66e", 0.6, 0.95, 1.2, 83)
		bb.ell(1.3, 0.35, 1.0, straw, room_point(i, "bed"))
		bb.box(1.6, 0.6, 0.5, Props.wood("#7a5a3a"), W(i, 2.4, -1.6) + Vector3(0, 0.3, 0), atan2(R.l.x, R.l.z))
		bb.box(1.6, 0.6, 0.5, Mats.rough_surface("#9aa3ab", 0.6, 0.6), W(i, 2.4, 1.6) + Vector3(0, 0.3, 0), atan2(R.l.x, R.l.z))
		bb.box(2.0, 0.04, 1.6, Mats.textured("#b9c1c6", "tiles", 0.6, 0.3), room_point(i, "tub") + Vector3(0, 0.05, 0))
		bb.ball(0.2, Mats.base("#f4efe6", 0.9), W(i, 6.1, 0) + Vector3(0, 1.0, 0))
	else:
		var br := Mats.rough_surface("#7a5a3a", 0.5, 0.9, 1.0, 41)
		bb.cyl(0.08, 0.1, 1.8, br, room_point(i, "bed") + Vector3(0, 0.9, 0), 8)
		bb.cyl(0.03, 0.03, 1.4, br, room_point(i, "bed") + Vector3(0, 1.5, 0), 6)
		bb.box(1.4, 0.05, 0.05, br, room_point(i, "bed") + Vector3(0, 1.5, 0), atan2(R.l.x, R.l.z))
		bb.ell(0.35, 0.18, 0.35, Mats.rough_surface("#a8875a", 0.4, 0.95, 1.2, 83), room_point(i, "bed") + Vector3(0.0, 1.9, 0))
		bb.cyl(0.7, 0.75, 0.2, Mats.rough_surface("#a9a59c", 0.5, 0.8), room_point(i, "tub") + Vector3(0, 0.1, 0), 20)
		bb.ell(0.6, 0.6, 0.6, Mats.rough_surface("#4f9e52", 0.5, 0.85, 1.0, 9), W(i, 5.8, 1.6) + Vector3(0, 0.6, 0))
	bb.commit(fn, true, "Furn")
	# comedouro e bebedouro (com o nível visível)
	var bowlh := 0.0 if R.kind != "avi" else 0.0
	var fb := Batch.new()
	Props.bowl(fb, room_point(i, "food") + Vector3(0, bowlh, 0), "#c9692f")
	Props.bowl(fb, room_point(i, "water") + Vector3(0, bowlh, 0), "#3a95d8")
	fb.commit(fn, true, "Bowls")
	rn.levels["food"] = _level_disc(fn, room_point(i, "food") + Vector3(0, 0.1, 0), Mats.rough_surface("#a8682f", 0.1, 0.9, 1.0, 91))
	rn.levels["water"] = _level_disc(fn, room_point(i, "water") + Vector3(0, 0.1, 0), get_water_mat())
	var tw := _water_disc(room_point(i, "tub") + Vector3(0, 0.46 if R.kind == "" else 0.08, 0), 0.5, fn)
	tw.scale = Vector3(1.3, 1, 0.75)
	tw.rotation.y = face + PI / 2
	tw.visible = false
	rn.tub_water = tw

func _level_disc(parent: Node3D, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.19
	cm.bottom_radius = 0.19
	cm.height = 0.02
	cm.radial_segments = 18
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi

var furn_cols := {}
func add_room_cols(i: int, which: Array) -> void:
	if furn_cols.has(i):
		return
	var ids := []
	if "bed" in which:
		var b := room_point(i, "bed")
		ids.append(add_seg(b, b, 0.55))
	if "tub" in which:
		var t := room_point(i, "tub")
		ids.append(add_seg(t, t, 0.5))
	furn_cols[i] = ids

func set_level(i: int, food: float, water: float) -> void:
	if i >= room_nodes.size() or room_nodes[i] == null:
		return
	var lv: Dictionary = room_nodes[i].levels
	if lv.has("food"):
		lv.food.visible = food > 4
		lv.water.visible = water > 4
		lv.food.position.y = room_point(i, "food").y + 0.04 + 0.05 * food / 100.0
		lv.water.position.y = room_point(i, "water").y + 0.04 + 0.05 * water / 100.0

func set_bath(i: int, on: bool) -> void:
	if i < room_nodes.size() and room_nodes[i] != null and room_nodes[i].tub_water != null:
		room_nodes[i].tub_water.visible = on

# ===================== portas que abrem sozinhas =====================
func update_doors(dt: float) -> void:
	for rn in room_nodes:
		if rn == null:
			continue
		var door: Vector3 = rn.leaves[0].h.global_position if not rn.leaves.is_empty() else Vector3.ZERO
		var near := false
		for m in movers:
			if is_instance_valid(m) and m.visible:
				var p: Vector3 = m.global_position
				if abs(p.x - door.x) < 2.2 and abs(p.z - door.z) < 2.2:
					near = true
					break
		var target := 1.0 if near and not rn.gate_mesh.visible else 0.0
		if abs(rn.open - target) > 0.001:
			rn.open = move_toward(rn.open, target, dt * 3.0)
			var e := ease(rn.open, -2.0)
			for lf in rn.leaves:
				lf.h.rotation.y = lf.h.get_parent().rotation.y * 0.0 + _leaf_base(lf) + lf.s * e * 1.45

func _leaf_base(lf: Dictionary) -> float:
	if not lf.has("base"):
		lf["base"] = lf.h.rotation.y
	return lf.base

# ===================== telhados =====================
func _roof_mat() -> StandardMaterial3D:
	var m := Mats.textured("#b5532f", "roof", 1.4, 0.75, 1.2).duplicate() as StandardMaterial3D
	m.uv1_triplanar = true
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m

func add_roof(mesh: Mesh, c: Vector3, r: float, parent: Node3D, xf := Transform3D()) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.transform = xf
	mi.material_override = _roof_mat()
	parent.add_child(mi)
	roofs.append({"node": mi, "c": c, "r": r, "f": 1.0})

func _build_roofs_main() -> void:
	add_roof(Batch.ring_roof_mesh(C, RI - 0.2, RO + 0.7, EXT_H + 0.05, EXT_H + 2.6), C, RO + 1, static_root)
	add_roof(Batch.ring_roof_mesh(LOB, 0.3, LR + 0.7, EXT_H + 0.05, EXT_H + 2.4, -30, 210), LOB, LR + 1, static_root)

# esconde os telhados quando a câmara se aproxima ou o jogador está debaixo
func update_roofs(dt: float, cam_dist: float, player: Vector3, inside_view: bool) -> void:
	for r in roofs:
		var show := cam_dist > 17.0 and not inside_view
		var d := Vector2(player.x - r.c.x, player.z - r.c.z).length()
		if d < r.r and cam_dist < 30.0:
			show = false
		var t := 1.0 if show else 0.0
		r.f = move_toward(r.f, t, dt * 2.5)
		var mi: MeshInstance3D = r.node
		mi.visible = r.f > 0.01
		mi.transparency = 1.0 - r.f
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if r.f > 0.99 else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

# ===================== partes que se compram =====================
func refresh(up: Dictionary, season: String) -> void:
	if up.get("pav_e", 0) > 0:
		_build_pavilion("E")
	if up.get("pav_w", 0) > 0:
		_build_pavilion("W")
	if up.get("clinica", 0) > 0:
		_build_clinic()
	if up.get("estabulo", 0) > 0:
		_build_barn()
	if up.get("aviario", 0) > 0:
		_build_aviary()
	if up.get("piscina", 0) > 0:
		_build_pool()
	if up.get("lago", 0) > 0:
		_build_lake()
	if up.get("luzes", 0) > 0:
		_build_party_lights()
	_build_decor(int(up.get("decor", 0)))
	_build_season(season)
	if up.get("suite", 0) > 0 and not built.has("suite"):
		built["suite"] = true
		label("👑 " + D.T("Suite real"), Vector3(-32, 4.6, -21.0), 64, Color(0, 0, 0, 0), Color("#ffd23a"))

func _build_pavilion(k: String) -> void:
	if built.has("pav_" + k):
		return
	built["pav_" + k] = true
	var P: Dictionary = PAV[k]
	var node := Node3D.new()
	node.name = "Pav" + k
	dyn_root.add_child(node)
	var bb := Batch.new()
	var oldB := B
	B = bb
	var c: Vector3 = P.c
	var hall := Mats.textured("#eadfca", "bigtiles", 1.1, 0.35, 0.6)
	floor_sector(c, 0, RO + 0.2, 0, 360, 0.015, Mats.rough_surface("#e9e0cf", 2.0, 0.9))
	B.add(Batch.disc_mesh(c, RI, 0.035), Transform3D(), Mats.textured("#b98b5e", "planks", 2.4, 0.45, 0.6))
	var door: float = P.door
	floor_sector(c, RI, RO + 0.3, door - 14, door + 14, 0.03, hall)
	# paredes: arco exterior com a porta, paredes entre quartos e sectores fechados
	wall_arc(c, RO, door + 9, door + 360 - 9, true)
	var room_edges := []
	for p in P.phis:
		room_edges.append(p - HW)
		room_edges.append(p + HW)
	for a in room_edges:
		wall(Pc(c, a, RI), Pc(c, a, RO), false)
	wall(Pc(c, door - 14, RI), Pc(c, door - 14, RO), false)
	wall(Pc(c, door + 14, RI), Pc(c, door + 14, RO), false)
	# sectores sem quarto: fechados por dentro, com canteiros
	var used := [[door - 14, door + 14]]
	for p in P.phis:
		used.append([p - HW, p + HW])
	for s in 72:
		var a := s * 5.0 + 2.5
		var free := true
		for u in used:
			if abs(ang_diff(a, (u[0] + u[1]) * 0.5)) < (u[1] - u[0]) * 0.5:
				free = false
		if free:
			wall(Pc(c, a - 2.5, RI), Pc(c, a + 2.5, RI), false)
			if s % 3 == 0:
				Props.plant(B, Pc(c, a, 9.5), 1.1)
	# bancos e fonte pequena no centro
	B.cyl(0.9, 1.0, 0.4, Mats.rough_surface("#d8d2c4", 0.8, 0.7), c + Vector3(0, 0.2, 0), 24)
	add_seg(c, c, 1.0)
	_water_disc(c + Vector3(0, 0.41, 0), 0.8, node)
	lamps.append(c + Vector3(0, 3.0, 0))
	B = oldB
	# galeria coberta desde a receção
	var sx: float = P.sx
	var X := func(v: float) -> float: return sx * v
	var ga := [Pc(LOB, 52.0 if sx > 0 else 128.0, LR), Vector3(X.call(12.8), 0, 12.7)]
	var walls := []
	if k == "E":
		walls = [[Pc(LOB, 52, LR), Vector3(CLINIC.door.x - 0.8, 0, 12.7)], [Vector3(CLINIC.door.x + 0.8, 0, 12.7), Vector3(12.8, 0, 12.7)]]
	else:
		walls = [ga]
	walls.append([Pc(LOB, 72.0 if sx > 0 else 108.0, LR), Vector3(X.call(2.7), 0, 15.1)])
	walls.append([Vector3(X.call(2.7), 0, 15.1), Vector3(X.call(15.2), 0, 15.1)])
	walls.append([Vector3(X.call(12.8), 0, 12.7), Vector3(X.call(12.8), 0, -1.8)])
	walls.append([Vector3(X.call(15.2), 0, 15.1), Vector3(X.call(15.2), 0, -0.4)])
	B = bb
	for w in walls:
		wall(w[0], w[1], true)
		var L: float = w[0].distance_to(w[1])
		if L > 2.5:
			B.seg_box(w[0], w[1], 0.35, 0.06, Mats.glass(), 1.25)
	var gfl := Mats.textured("#eadfca", "bigtiles", 1.1, 0.35, 0.6)
	floor_rect(X.call(1.6), X.call(15.2), 12.7, 15.1, 0.03, gfl)
	floor_rect(X.call(12.8), X.call(15.2), -3.0, 12.7, 0.03, gfl)
	floor_rect(X.call(12.8), X.call(15.6), -4.6, -1.4, 0.032, gfl)
	B.box(abs(X.call(14.4) - X.call(3.2)), 0.01, 0.9, Mats.cloth("#7fb8a7"), Vector3((X.call(3.2) + X.call(14.4)) * 0.5, 0.045, 13.9))
	B.box(0.9, 0.01, 15.6, Mats.cloth("#7fb8a7"), Vector3(X.call(14.0), 0.045, 5.6))
	Props.plant(B, Vector3(X.call(12.2), 0, 14.6))
	Props.bench(B, Vector3(X.call(13.2), 0, 4.5), PI / 2 if sx > 0 else -PI / 2)
	add_seg(Vector3(X.call(13.2), 0, 4.5), Vector3(X.call(13.2), 0, 4.5), 0.4)
	_ao_flush_into(node)
	B = oldB
	bb.commit(node, true, "Pav")
	# telhados
	add_roof(Batch.ring_roof_mesh(c, RI - 0.2, RO + 0.7, EXT_H + 0.05, EXT_H + 2.6), c, RO + 1, node)
	var gr := Batch.new()
	gr.box(abs(X.call(15.6) - X.call(2.2)), 0.12, 3.2, _roof_mat(), Vector3((X.call(2.2) + X.call(15.6)) * 0.5, EXT_H + 0.25, 13.9))
	gr.box(3.2, 0.12, 16.4, _roof_mat(), Vector3(X.call(14.0), EXT_H + 0.25, 5.4))
	var grn := Node3D.new()
	node.add_child(grn)
	var mis := gr.commit(grn, true, "GalRoof")
	for mi in mis:
		roofs.append({"node": mi, "c": Vector3(X.call(11), 0, 9), "r": 6.0, "f": 1.0})
	label("🏛️ " + D.T("Pavilhão Nascente" if k == "E" else "Pavilhão Poente"), c + Vector3(0, 5.2, 0), 70, Color(0, 0, 0, 0), Color.WHITE, node)
	# porta de vidro na receção passa a estar aberta
	set_seg(link_doors[k].seg, false)
	for idx in range(P.first, P.first + 4):
		_room_shell(idx)

func _ao_flush_into(node: Node3D) -> void:
	_flush_ao(node)

func _build_clinic() -> void:
	if built.has("clinic") or not built.has("pav_E"):
		return
	built["clinic"] = true
	var node := Node3D.new()
	dyn_root.add_child(node)
	var bb := Batch.new()
	var oldB := B
	B = bb
	floor_rect(CLINIC.x1, CLINIC.x2, CLINIC.z1, CLINIC.z2, 0.035, Mats.textured("#e3f0f0", "tiles", 0.8, 0.25, 0.4))
	wall(Vector3(CLINIC.x1, 0, CLINIC.z1), Vector3(CLINIC.x2, 0, CLINIC.z1), true)
	wall(Vector3(CLINIC.x1, 0, CLINIC.z1), Vector3(CLINIC.x1, 0, CLINIC.z2), true)
	wall(Vector3(CLINIC.x2, 0, CLINIC.z1), Vector3(CLINIC.x2, 0, CLINIC.z2), true)
	var t: Vector3 = CLINIC.table
	B.box(1.3, 0.85, 0.7, Mats.glossy("#c9cfd6", 0.3, 0.7), t + Vector3(0, 0.42, 0))
	B.box(1.4, 0.06, 0.8, Mats.glossy("#e8eef2", 0.2), t + Vector3(0, 0.88, 0))
	add_seg(t + Vector3(-0.6, 0, 0), t + Vector3(0.6, 0, 0), 0.4)
	B.box(0.5, 1.9, 1.6, Mats.glossy("#ffffff", 0.3), Vector3(CLINIC.x2 - 0.4, 0.95, 10.5))
	add_seg(Vector3(CLINIC.x2 - 0.4, 0, 9.8), Vector3(CLINIC.x2 - 0.4, 0, 11.2), 0.3)
	B.box(0.9, 0.9, 0.5, Mats.glossy("#e8e2d4", 0.3), Vector3(7.6, 0.45, 8.7))
	B.cyl(0.4, 0.3, 0.05, Mats.emissive("#fff7dc", 1.5), Vector3(10.1, 2.2, 10.1), 20)
	_ao_flush_into(node)
	B = oldB
	bb.commit(node, true, "Clinic")
	label("🩺 " + D.T("Gabinete veterinário"), Vector3(9.6, 3.0, 10.5), 52, Color(0, 0, 0, 0), Color.WHITE, node)

func _build_barn() -> void:
	if built.has("barn"):
		return
	built["barn"] = true
	var node := Node3D.new()
	node.name = "Barn"
	dyn_root.add_child(node)
	built["barn_node"] = node
	var bb := Batch.new()
	var oldB := B
	B = bb
	var x0 := -40.3
	var x1 := -23.7
	var z0 := -38.2
	var z1 := -21.8
	var red := Mats.textured("#a8402f", "planks_v", 1.6, 0.8, 0.7)
	var redw := func(a: Vector3, b: Vector3):
		B.seg_box(a, b, 2.4, 0.3, red, 0.0, 0.05)
		B.seg_box(a, b, 0.12, 0.34, Mats.base("#f4f1ec", 0.6), 2.4, 0.08)
		_ao(a, b, 0.3)
		add_seg(a, b, 0.15)
	floor_rect(x0, x1, z0, z1, 0.02, Mats.rough_surface("#a9a59c", 1.5, 0.95))
	redw.call(Vector3(x0, 0, z0), Vector3(x1, 0, z0))
	redw.call(Vector3(x0, 0, z1), Vector3(x1, 0, z1))
	redw.call(Vector3(x0, 0, z0), Vector3(x0, 0, z1))
	redw.call(Vector3(x1, 0, z0), Vector3(x1, 0, -31.7))
	redw.call(Vector3(x1, 0, -28.3), Vector3(x1, 0, z1))
	var part := Props.wood("#8a6a4a")
	for side in [-1.0, 1.0]:
		var zf: float = -30.0 + side * 1.6
		var zb: float = zf + side * DEPTH
		for xm in [-34.7, -29.3]:
			B.seg_box(Vector3(xm, 0, zf), Vector3(xm, 0, zb), 1.4, 0.12, part)
			add_seg(Vector3(xm, 0, zf), Vector3(xm, 0, zb), 0.08)
		for cx in [-37.4, -32.0, -26.6]:
			for e in [[cx - 2.7, cx - 0.9], [cx + 0.9, cx + 2.7]]:
				B.seg_box(Vector3(e[0], 0, zf), Vector3(e[1], 0, zf), 1.2, 0.12, part)
				add_seg(Vector3(e[0], 0, zf), Vector3(e[1], 0, zf), 0.08)
	B.box(1.6, 0.02, 3.2, Mats.rough_surface("#a9a59c", 1.5, 0.95), Vector3(-23.0, 0.02, -30))
	B.box(7.0, 0.02, 2.0, Mats.textured("#cfc6b6", "pavers", 1.4, 0.85), Vector3(-19.5, 0.02, -30))
	B.ell(0.8, 0.6, 0.8, Mats.rough_surface("#e2c66e", 0.6, 0.95, 1.2, 83), Vector3(-39.2, 0.5, -30.6))
	_ao_flush_into(node)
	B = oldB
	bb.commit(node, true, "Barn")
	# telhado de duas águas
	var rb := Batch.new()
	var rm := _roof_mat()
	var half := (z1 - z0) * 0.5 + 0.6
	var ang := deg_to_rad(28)
	var w := half / cos(ang)
	for s in [-1.0, 1.0]:
		rb.box_xf(Vector3(x1 - x0 + 1.2, 0.14, w), Transform3D(Basis(Vector3.RIGHT, s * ang), Vector3((x0 + x1) * 0.5, 2.45 + half * tan(ang) * 0.5, -30 + s * half * 0.5)), rm)
	var rn := Node3D.new()
	node.add_child(rn)
	for mi in rb.commit(rn, true, "BarnRoof"):
		roofs.append({"node": mi, "c": Vector3(-32, 0, -30), "r": 10.0, "f": 1.0})
	label("🐴 " + D.T("Celeiro"), Vector3(-23.2, 3.4, -30), 64, Color(0, 0, 0, 0), Color.WHITE, node)
	set_seg(park_gates.W.seg, false)
	for i in range(16, 22):
		_room_shell(i)

func _build_aviary() -> void:
	if built.has("avi"):
		return
	built["avi"] = true
	var node := Node3D.new()
	node.name = "Aviary"
	dyn_root.add_child(node)
	built["avi_node"] = node
	var bb := Batch.new()
	var oldB := B
	B = bb
	var x0 := 25.4
	var x1 := 36.6
	var z0 := -35.2
	var z1 := -18.8
	var low := Mats.rough_surface("#f4f1ec", 1.0, 0.85)
	var net := StandardMaterial3D.new()
	net.albedo_color = Color(0.85, 0.88, 0.9, 0.22)
	net.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	net.cull_mode = BaseMaterial3D.CULL_DISABLED
	net.roughness = 0.6
	var nw := func(a: Vector3, b: Vector3):
		B.seg_box(a, b, 0.6, 0.25, low)
		B.seg_box(a, b, 2.2, 0.03, net, 0.6)
		B.seg_box(a, b, 0.06, 0.08, Mats.glossy("#5f87b8", 0.4, 0.5), 2.8)
		add_seg(a, b, 0.13)
	floor_rect(x0, x1, z0, z1, 0.02, Mats.rough_surface("#d9cdb0", 1.2, 0.95))
	nw.call(Vector3(x0, 0, z0), Vector3(x1, 0, z0))
	nw.call(Vector3(x0, 0, z1), Vector3(x1, 0, z1))
	nw.call(Vector3(x1, 0, z0), Vector3(x1, 0, z1))
	nw.call(Vector3(x0, 0, z0), Vector3(x0, 0, -28.7))
	nw.call(Vector3(x0, 0, -25.3), Vector3(x0, 0, z1))
	for side in [-1.0, 1.0]:
		var zf: float = -27.0 + side * 1.6
		var zb: float = zf + side * DEPTH
		nw.call(Vector3(31, 0, zf), Vector3(31, 0, zb))
		for cx in [28.3, 33.7]:
			for e in [[cx - 2.7, cx - 0.9], [cx + 0.9, cx + 2.7]]:
				nw.call(Vector3(e[0], 0, zf), Vector3(e[1], 0, zf))
	B.box(9.0, 0.02, 2.0, Mats.textured("#cfc6b6", "pavers", 1.4, 0.85), Vector3(20.6, 0.02, -27))
	_ao_flush_into(node)
	B = oldB
	bb.commit(node, true, "Aviary")
	label("🦜 " + D.T("Aviário"), Vector3(25.0, 3.4, -27), 64, Color(0, 0, 0, 0), Color.WHITE, node)
	set_seg(park_gates.E.seg, false)
	for i in range(22, 26):
		_room_shell(i)

func _build_pool() -> void:
	if built.has("pool"):
		return
	built["pool"] = true
	var node := Node3D.new()
	dyn_root.add_child(node)
	var bb := Batch.new()
	var edge := Mats.rough_surface("#f4f1ea", 0.8, 0.6)
	bb.box(6.4, 0.3, 0.3, edge, POOL + Vector3(0, 0.15, -1.75))
	bb.box(6.4, 0.3, 0.3, edge, POOL + Vector3(0, 0.15, 1.75))
	bb.box(0.3, 0.3, 3.8, edge, POOL + Vector3(-3.2, 0.15, 0))
	bb.box(0.3, 0.3, 3.8, edge, POOL + Vector3(3.2, 0.15, 0))
	bb.box(6.1, 0.02, 3.2, Mats.textured("#3aa0d8", "tiles", 0.5, 0.2), POOL + Vector3(0, 0.02, 0))
	bb.add(Batch.torus_mesh(0.2, 0.35), Transform3D(Basis(), POOL + Vector3(-1.5, 0.16, 0.5)), Mats.glossy("#e8443a", 0.4))
	bb.commit(node, true, "Pool")
	var w := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(6.1, 0.02, 3.2)
	w.mesh = bm
	w.material_override = get_water_mat()
	w.position = POOL + Vector3(0, 0.14, 0)
	node.add_child(w)
	label("🏊", POOL + Vector3(0, 1.6, 0), 64, Color(0, 0, 0, 0), Color.WHITE, node)

func _build_lake() -> void:
	if built.has("lake"):
		return
	built["lake"] = true
	var node := Node3D.new()
	dyn_root.add_child(node)
	var bb := Batch.new()
	var ice := Mats.glossy("#cfeaf8", 0.12, 0.0, true)
	bb.add(Batch.disc_mesh(Vector3.ZERO, 1.0, 0.0), Transform3D(Basis().scaled(Vector3(5.0, 1, 3.4)), LAKE + Vector3(0, 0.04, 0)), ice)
	var snow := Mats.rough_surface("#f6fbff", 0.6, 0.9, 0.6)
	bb.ell(1.4, 0.5, 1.2, snow, LAKE + Vector3(3.6, 0.1, 2.2))
	bb.ell(0.9, 0.4, 0.8, snow, LAKE + Vector3(-4.1, 0.1, -1.6))
	bb.ell(0.7, 0.35, 0.7, snow, LAKE + Vector3(-2.2, 0.1, 2.9))
	bb.commit(node, true, "Lake")
	add_seg(LAKE + Vector3(-4, 0, 0), LAKE + Vector3(4, 0, 0), 2.0)
	label("🐧 " + D.T("Lago gelado"), LAKE + Vector3(0, 2.4, 0), 56, Color(0, 0, 0, 0), Color.WHITE, node)

func _build_party_lights() -> void:
	if built.has("luzes"):
		return
	built["luzes"] = true
	var node := Node3D.new()
	dyn_root.add_child(node)
	var cols := ["#ff5a5a", "#ffd23a", "#5ad2ff", "#7cff7c", "#ff7ae0"]
	var mats := []
	for c in cols:
		mats.append(_glow_mat(c))
	var bb := Batch.new()
	var lines := [[Vector3(-2.6, 2.5, 16.8), Vector3(-2.6, 2.5, 22.6)], [Vector3(2.6, 2.5, 16.8), Vector3(2.6, 2.5, 22.6)], [Vector3(-13, 2.5, -20.5), Vector3(13, 2.5, -20.5)], [Vector3(-13, 2.5, -29.5), Vector3(0, 2.5, -34.5)]]
	var k := 0
	for ln in lines:
		var a: Vector3 = ln[0]
		var b: Vector3 = ln[1]
		var n := int(a.distance_to(b) / 0.6)
		for j in n + 1:
			var t: float = float(j) / max(1, n)
			var p := a.lerp(b, t) - Vector3(0, sin(t * PI) * 0.4, 0)
			bb.ball(0.06, mats[k % mats.size()], p, 1.0, 6)
			k += 1
	bb.commit(node, false, "Lights")

var decor_node: Node3D
var decor_level := -1
func _build_decor(level: int) -> void:
	if level == decor_level:
		return
	decor_level = level
	if decor_node:
		decor_node.queue_free()
	decor_node = Node3D.new()
	dyn_root.add_child(decor_node)
	var bb := Batch.new()
	var spots := [Pc(LOB, 172, 4.3), Pc(LOB, 8, 4.3), Pc(C, 90, 4.6), Pc(C, 270, 4.8), Vector3(-4.5, 0, 15.2), Vector3(4.5, 0, 15.2), Pc(C, 60, 5.0), Pc(C, 120, 5.0), Pc(C, 0, 4.6), Pc(C, 180, 4.6)]
	for k in min(level * 2, spots.size()):
		Props.plant(bb, spots[k], 1.15)
	if bb.count > 0:
		bb.commit(decor_node, true, "Decor")

var season_node: Node3D
var season_now := "?"
func _build_season(s: String) -> void:
	if s == season_now:
		return
	season_now = s
	if season_node:
		season_node.queue_free()
	season_node = Node3D.new()
	dyn_root.add_child(season_node)
	var bb := Batch.new()
	if s == "halloween":
		for p in [Vector3(-1.8, 0, 14.6), Vector3(1.8, 0, 14.6), Vector3(-2.2, 0, 21), Vector3(2.2, 0, 19), Pc(C, 100, 5.0), Pc(C, 80, 5.0)]:
			Props.pumpkin(bb, p, 1.2)
	elif s == "natal":
		Props.xmas_tree(bb, Pc(LOB, 150, 3.4), 1.0)
		Props.xmas_tree(bb, Vector3(4.5, 0, 18), 1.5)
	elif s == "verao":
		Props.umbrella(bb, Vector3(-6, 0, 19), "#e8443a")
		Props.umbrella(bb, Vector3(6, 0, 19.5), "#3a95d8")
	if bb.count > 0:
		bb.commit(season_node, true, "Season")

# ===================== cidade =====================
var town: Node3D
func _build_town() -> void:
	town = preload("res://scripts/town.gd").new()
	town.name = "Town"
	add_child(town)
	town.build(self)

# ===================== relva =====================
func lawn_free(x: float, z: float) -> bool:
	if Vector2(x - C.x, z - C.z).length() < RO + 1.2:
		return false
	if Vector2(x - LOB.x, z - LOB.z).length() < LR + 1.0:
		return false
	for k in ["E", "W"]:
		if Vector2(x - PAV[k].c.x, z - PAV[k].c.z).length() < RO + 1.2:
			return false
	if abs(x) < 1.9 and z > 13 and z < 25:
		return false
	if z > 23.0:
		return false
	if z > 12.2 and z < 15.6 and abs(x) < 16:
		return false
	if abs(abs(x) - 14) < 1.7 and z > -5 and z < 15.6:
		return false
	if z < -13.5 and z > -36 and abs(x) < 16.5:
		return pow(x / 12.6, 2) + pow((z + 25.2) / 8.6, 2) > 1.0 and abs(x) > 1.5
	if x < -22 and x > -41.5 and z < -20.5 and z > -39.5:
		return false
	if x > 24.5 and x < 37.5 and z < -17.5 and z > -36.5:
		return false
	if x < -16 and x > -25.5 and z > 15 and z < 23:
		return false
	if Vector2(x - LAKE.x, z - LAKE.z).length() < 5.6:
		return false
	return true

func _build_grass() -> void:
	if Mats.quality == "leve":
		return
	var n := 26000 if Mats.quality == "ultra" else (16000 if Mats.quality == "alta" else 7000)
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	var blade := _blade_mesh()
	mm.mesh = blade
	mm.instance_count = n
	var rng := RandomNumberGenerator.new()
	rng.seed = 99
	var k := 0
	var tries := 0
	while k < n and tries < n * 6:
		tries += 1
		var x := rng.randf_range(-58, 58)
		var z := rng.randf_range(-46, 24)
		if not lawn_free(x, z):
			continue
		var s := rng.randf_range(0.6, 1.25)
		var b := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s, s * rng.randf_range(0.7, 1.4), s))
		mm.set_instance_transform(k, Transform3D(b, Vector3(x, 0, z)))
		var g := rng.randf_range(0.75, 1.1)
		mm.set_instance_color(k, Color(0.36 * g, 0.62 * g, 0.26 * g))
		k += 1
	mm.visible_instance_count = k
	grass_mm = MultiMeshInstance3D.new()
	grass_mm.multimesh = mm
	var sm := ShaderMaterial.new()
	sm.shader = load("res://shaders/grass.gdshader")
	grass_mm.material_override = sm
	grass_mm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(grass_mm)

func _blade_mesh() -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	# tufo de 5 folhas finas
	for j in 5:
		var a := j * TAU / 5.0 + 0.3
		var d := Vector3(cos(a), 0, sin(a))
		var side := Vector3(-d.z, 0, d.x) * 0.025
		var lean := d * 0.07
		var h := 0.3 + 0.05 * (j % 3)
		var p0 := -side + d * 0.02
		var p1 := side + d * 0.02
		var p2 := lean + Vector3(0, h, 0) + d * 0.02
		var nrm := (p1 - p0).cross(p2 - p0).normalized()
		if nrm.y < 0:
			nrm = -nrm
		for v in [[p0, 0.0], [p2, 1.0], [p1, 0.0]]:
			st.set_normal((nrm + Vector3.UP).normalized())
			st.set_uv(Vector2(0, v[1]))
			st.add_vertex(v[0])
	return st.commit()
