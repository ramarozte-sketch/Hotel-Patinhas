# Hotel Patinhas HD · a rua em frente ao hotel: avenida, passeios, casas, lojas, carros e pessoas a passear
extends Node3D

var world
var cars: Array = []
var peds: Array = []
var rng := RandomNumberGenerator.new()
const LANE_E := 28.0
const LANE_W := 32.0

func build(w) -> void:
	world = w
	rng.seed = 7
	var B := Batch.new()
	var asphalt := Mats.rough_surface("#3a3d42", 2.0, 0.92, 0.8, 121)
	var pav := Mats.textured("#cfc8bb", "pavers", 1.1, 0.85, 1.0)
	var curb := Mats.rough_surface("#bdb8ae", 1.0, 0.8)
	B.box(200, 0.02, 9.0, asphalt, Vector3(0, 0.02, 30))
	B.box(200, 0.12, 2.2, pav, Vector3(0, 0.06, 24.4))
	B.box(200, 0.12, 2.2, pav, Vector3(0, 0.06, 35.6))
	B.box(200, 0.14, 0.18, curb, Vector3(0, 0.07, 25.45))
	B.box(200, 0.14, 0.18, curb, Vector3(0, 0.07, 34.55))
	var white := Mats.base("#f4f2ea", 0.6)
	for k in range(-24, 25):
		if abs(k) <= 1:
			continue
		B.box(2.4, 0.01, 0.15, white, Vector3(k * 4.0, 0.035, 30))
	B.box(200, 0.01, 0.1, white, Vector3(0, 0.034, 26.0))
	B.box(200, 0.01, 0.1, white, Vector3(0, 0.034, 34.0))
	for k in 8:
		B.box(3.0, 0.012, 0.55, white, Vector3(0, 0.036, 26.4 + k * 1.05 + 0.2))
	# candeeiros da rua
	for x in range(-84, 85, 16):
		if abs(x) < 6:
			continue
		world.lamp(Vector3(x, 0.1, 25.2), self, B)
		world.lamp(Vector3(x + 8, 0.1, 34.8), self, B)
	# casas e lojas do outro lado
	var shops := [["☕ Café", "#8a5a36"], ["🥖 Padaria", "#d98f2a"], ["💐 Florista", "#e0508a"], ["🛒 Mercearia", "#2fae6b"], ["🍦 Gelataria", "#5ab0e0"], ["📚 Livraria", "#8a5cd6"]]
	var si := 0
	var x0 := -86.0
	while x0 < 86.0:
		var w2 := rng.randf_range(8.0, 11.0)
		var cx := x0 + w2 * 0.5
		var shop: bool = si < shops.size() and abs(cx) < 50 and rng.randf() < 0.55
		_house(B, Vector3(cx, 0, 42.0 + rng.randf_range(0, 1.5)), w2 - 1.2, rng.randf_range(7, 9), PI, shop, shops[si] if shop else [])
		if shop:
			si += 1
		x0 += w2 + rng.randf_range(0.5, 2.5)
	# casas do lado do hotel, longe do edifício
	for x in [-44.0, -58.0, -72.0, 46.0, 60.0, 74.0]:
		_house(B, Vector3(x, 0, 17.0), 9.0, 8.0, 0.0, false, [])
	# árvores da rua
	for x in range(-80, 81, 10):
		if abs(x) < 8:
			continue
		Props.tree(B, Vector3(x + 5, 0, 37.6), 0.75, int(x))
	B.commit(self, true, "Town")
	# carros
	var cols := ["#c8102e", "#1f4e9c", "#f2f2f2", "#2b2b2b", "#e8b100", "#5a8a3a", "#8a8f96", "#ff7a35"]
	for k in 7:
		var east := k % 2 == 0
		var car := _car(Color(cols[k % cols.size()]))
		add_child(car)
		var x := -90.0 + k * 28.0
		car.position = Vector3(x, 0, LANE_E if east else LANE_W)
		car.rotation.y = PI / 2 if east else -PI / 2
		cars.append({"n": car, "dir": 1.0 if east else -1.0, "v": rng.randf_range(6.0, 9.0), "cur": 0.0})
	# peões
	for k in 8:
		var h := HumanModel.new()
		add_child(h)
		var look := HumanModel.random_look(rng)
		h.setup(look)
		var side := 36.0 if k % 2 == 0 else 23.8
		h.position = Vector3(rng.randf_range(-80, 80), 0.12, side)
		peds.append({"n": h, "dir": 1.0 if rng.randf() < 0.5 else -1.0, "v": rng.randf_range(1.0, 1.4), "z": side})

func _house(B: Batch, c: Vector3, w: float, d: float, yaw: float, shop: bool, info: Array) -> void:
	var T := Transform3D(Basis(Vector3.UP, yaw), c)
	var cols := ["#f4ead8", "#f6f1e6", "#e9d8c4", "#f2e0b8", "#dfe8ee", "#f0d8d2"]
	var wall := Mats.plaster(cols[rng.randi() % cols.size()])
	var h := 3.2 if not shop else 3.6
	Props.lbox(B, T, Vector3(w, h, d), Vector3(0, h * 0.5, 0), wall)
	Props.lbox(B, T, Vector3(w + 0.1, 0.3, d + 0.1), Vector3(0, 0.15, 0), Mats.rough_surface("#9c8a70", 1.0, 0.8))
	# telhado de duas águas
	var rm := Mats.textured("#b5532f" if rng.randf() < 0.7 else "#6a6f78", "roof", 1.4, 0.75, 1.2)
	var ang := 0.5
	var half := d * 0.5 + 0.5
	for s in [-1.0, 1.0]:
		B.box_xf(Vector3(w + 0.8, 0.15, half / cos(ang)), T * Transform3D(Basis(Vector3.RIGHT, s * ang), Vector3(0, h + half * tan(ang) * 0.5, s * half * 0.5)), rm)
	Props.lbox(B, T, Vector3(w - 0.02, half * tan(ang), 0.1), Vector3(0, h + half * tan(ang) * 0.33, d * 0.5 - 0.05), wall)
	Props.lbox(B, T, Vector3(0.6, 1.4, 0.6), Vector3(w * 0.3, h + 1.3, -d * 0.15), Mats.textured("#a8503a", "bricks", 0.8, 0.85))
	# porta e janelas
	var front := d * 0.5 + 0.03
	Props.lbox(B, T, Vector3(1.1, 2.1, 0.08), Vector3(-w * 0.25 if not shop else 0.0, 1.05, front), Props.wood("#6a4a32"))
	var glass := Mats.glossy("#9cc6dc", 0.06, 0.3)
	var frame := Mats.base("#ffffff", 0.5)
	if shop:
		Props.lbox(B, T, Vector3(w * 0.32, 1.6, 0.06), Vector3(-w * 0.3, 1.3, front), glass)
		Props.lbox(B, T, Vector3(w * 0.32, 1.6, 0.06), Vector3(w * 0.3, 1.3, front), glass)
		var aw := Mats.textured("#ffffff", "stripes", 1.2, 0.8, 0.0, false)
		B.box_xf(Vector3(w * 0.95, 0.06, 1.3), T * Transform3D(Basis(Vector3.RIGHT, 0.35), Vector3(0, 2.6, front + 0.6)), aw)
		var lab := Label3D.new()
		lab.text = D.T(info[0])
		lab.font_size = 70
		lab.pixel_size = 0.006
		lab.outline_size = 16
		lab.outline_modulate = Color(info[1])
		lab.position = T * Vector3(0, 3.15, front + 0.1)
		lab.rotation.y = yaw
		add_child(lab)
	else:
		for wx in [w * 0.15, w * 0.35]:
			Props.lbox(B, T, Vector3(1.1, 1.1, 0.06), Vector3(wx, 1.5, front), glass)
			Props.lbox(B, T, Vector3(1.25, 0.08, 0.1), Vector3(wx, 0.92, front + 0.02), frame)
		Props.lbox(B, T, Vector3(1.1, 1.0, 0.06), Vector3(-w * 0.25, h - 0.3, front), glass)
	world.add_seg(T * Vector3(-w * 0.5, 0, -d * 0.5), T * Vector3(w * 0.5, 0, -d * 0.5), 0.1)
	world.add_seg(T * Vector3(-w * 0.5, 0, d * 0.5), T * Vector3(w * 0.5, 0, d * 0.5), 0.1)
	world.add_seg(T * Vector3(-w * 0.5, 0, -d * 0.5), T * Vector3(-w * 0.5, 0, d * 0.5), 0.1)
	world.add_seg(T * Vector3(w * 0.5, 0, -d * 0.5), T * Vector3(w * 0.5, 0, d * 0.5), 0.1)

func _car(col: Color) -> Node3D:
	var n := Node3D.new()
	var B := Batch.new()
	var paint := Mats.glossy(col, 0.25, 0.35, true)
	var glass := Mats.glossy("#1d2833", 0.05, 0.5)
	var tyre := Mats.base("#1b1b1d", 0.85)
	var rim := Mats.glossy("#c9cfd6", 0.2, 0.9)
	B.box(1.75, 0.55, 4.1, paint, Vector3(0, 0.62, 0))
	B.box(1.6, 0.5, 2.1, paint, Vector3(0, 1.12, -0.25))
	B.box(1.62, 0.42, 1.9, glass, Vector3(0, 1.13, -0.25))
	B.box(1.5, 0.42, 0.05, glass, Vector3(0, 1.1, 0.83))
	for x in [-0.88, 0.88]:
		for z in [-1.3, 1.3]:
			B.cyl_xf(0.34, 0.34, 0.24, tyre, Transform3D(Basis(Vector3.FORWARD, PI / 2), Vector3(x, 0.34, z)), 16)
			B.cyl_xf(0.2, 0.2, 0.25, rim, Transform3D(Basis(Vector3.FORWARD, PI / 2), Vector3(x, 0.34, z)), 12)
	B.box(1.6, 0.12, 0.05, Mats.emissive("#fff4d0", 1.5), Vector3(0, 0.75, 2.06))
	B.box(1.6, 0.12, 0.05, Mats.emissive("#ff2a2a", 1.2), Vector3(0, 0.75, -2.06))
	B.commit(n, true, "Car")
	return n

func update(dt: float, player_pos: Vector3) -> void:
	for c in cars:
		var n: Node3D = c.n
		var ahead: float = n.position.x + c.dir * 5.0
		var stop := false
		# pára se alguém estiver à frente na estrada (jogador ou outro carro)
		if player_pos.z > 25.4 and player_pos.z < 34.6 and abs(player_pos.x - ahead) < 4.5:
			stop = true
		for o in cars:
			if o != c and o.dir == c.dir and (o.n.position.x - n.position.x) * c.dir > 0 and abs(o.n.position.x - n.position.x) < 7.5:
				stop = true
		c.cur = move_toward(c.cur, 0.0 if stop else c.v, dt * (9.0 if stop else 3.0))
		n.position.x += c.dir * c.cur * dt
		if n.position.x > 100:
			n.position.x = -100
		if n.position.x < -100:
			n.position.x = 100
	for p in peds:
		var h: HumanModel = p.n
		h.position.x += p.dir * p.v * dt
		h.rotation.y = PI / 2 if p.dir > 0 else -PI / 2
		if abs(h.position.x) > 88:
			p.dir = -p.dir
		h.animate(dt, true, p.v)
