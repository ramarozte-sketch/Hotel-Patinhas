# Hotel Patinhas HD · o bairro em frente ao hotel: avenida com lojas, travessas, rua de trás com moradias
# algarvias e jardins, praça com igreja, chafariz e parque infantil, aldeia no monte ao longe,
# carros, peões e pessoas a passear o cão
extends Node3D

var world
var cars: Array = []
var peds: Array = []
var birds: Array = []
var rng := RandomNumberGenerator.new()
const LANE_E := 28.0
const LANE_W := 32.0
const BACK_Z := 58.0          # rua de trás
const CROSS_X := [-36.0, 36.0]  # travessas
const PLAZA := Vector3(0, 0, 72.0)

var chunks := {}
func _bb(x: float) -> Batch:
	var k := int(floor((x + 120.0) / 40.0))
	if not chunks.has(k):
		chunks[k] = Batch.new()
	return chunks[k]

func build(w) -> void:
	world = w
	rng.seed = 7
	var B := Batch.new()  # estradas compridas
	var asphalt := Mats.rough_surface("#3a3d42", 2.0, 0.92, 0.8, 121)
	var pav := Mats.textured("#cfc8bb", "pavers", 1.1, 0.85, 1.0)
	var curb := Mats.rough_surface("#bdb8ae", 1.0, 0.8)
	var white := Mats.base("#f4f2ea", 0.6)
	# ---- avenida ----
	B.box(200, 0.02, 9.0, asphalt, Vector3(0, 0.02, 30))
	B.box(200, 0.12, 2.2, pav, Vector3(0, 0.06, 24.4))
	B.box(200, 0.12, 2.2, pav, Vector3(0, 0.06, 35.6))
	B.box(200, 0.14, 0.18, curb, Vector3(0, 0.07, 25.45))
	B.box(200, 0.14, 0.18, curb, Vector3(0, 0.07, 34.55))
	for k in range(-24, 25):
		if abs(k) <= 1:
			continue
		B.box(2.4, 0.01, 0.15, white, Vector3(k * 4.0, 0.035, 30))
	B.box(200, 0.01, 0.1, white, Vector3(0, 0.034, 26.0))
	B.box(200, 0.01, 0.1, white, Vector3(0, 0.034, 34.0))
	for k in 8:
		B.box(3.0, 0.012, 0.55, white, Vector3(0, 0.036, 26.4 + k * 1.05 + 0.2))
	# ---- rua de trás ----
	B.box(200, 0.02, 6.0, asphalt, Vector3(0, 0.02, BACK_Z))
	B.box(200, 0.12, 1.8, pav, Vector3(0, 0.06, BACK_Z - 3.9))
	B.box(200, 0.12, 1.8, pav, Vector3(0, 0.06, BACK_Z + 3.9))
	B.box(200, 0.14, 0.16, curb, Vector3(0, 0.07, BACK_Z - 3.0))
	B.box(200, 0.14, 0.16, curb, Vector3(0, 0.07, BACK_Z + 3.0))
	for k in range(-24, 25):
		B.box(1.8, 0.01, 0.12, white, Vector3(k * 4.0 + 2.0, 0.034, BACK_Z))
	# ---- travessas entre a avenida e a rua de trás ----
	for cx in CROSS_X:
		B.box(6.0, 0.021, BACK_Z - 3.0 - 34.5, asphalt, Vector3(cx, 0.021, (34.5 + BACK_Z - 3.0) * 0.5))
		for sx in [-1.0, 1.0]:
			B.box(1.6, 0.12, BACK_Z - 4.8 - 36.7, pav, Vector3(cx + sx * 3.8, 0.06, (36.7 + BACK_Z - 4.8) * 0.5))
		for k in 6:
			B.box(0.55, 0.012, 2.6, white, Vector3(cx - 2.6 + k * 1.05, 0.036, 38.4))
	B.commit(self, true, "Roads")
	# ---- candeeiros ----
	for x in range(-84, 85, 16):
		if abs(x) < 6:
			continue
		world.lamp(Vector3(x, 0.1, 25.2), self, _bb(x))
		world.lamp(Vector3(x + 8, 0.1, 34.8), self, _bb(x + 8))
	for x in range(-80, 81, 20):
		world.lamp(Vector3(x, 0.1, BACK_Z + 3.3), self, _bb(x))
	# ---- lojas e casas viradas para a avenida (com espaço para as travessas) ----
	var shops := [["☕ Café", "#8a5a36"], ["🥖 Padaria", "#d98f2a"], ["💐 Florista", "#e0508a"], ["🛒 Mercearia", "#2fae6b"], ["🍦 Gelataria", "#5ab0e0"], ["📚 Livraria", "#8a5cd6"]]
	var si := 0
	var x0 := -86.0
	while x0 < 86.0:
		var w2 := rng.randf_range(8.0, 11.0)
		var blocked := false
		for cx in CROSS_X:
			if x0 + w2 > cx - 5.0 and x0 < cx + 5.0:
				blocked = true
				x0 = cx + 5.0
		if blocked:
			continue
		var cx2 := x0 + w2 * 0.5
		var shop: bool = si < shops.size() and abs(cx2) < 50 and rng.randf() < 0.55
		var d := rng.randf_range(7, 8.5)
		_house(_bb(cx2), Vector3(cx2, 0, 38.6 + d * 0.5), w2 - 1.2, d, PI, {"shop": shops[si] if shop else [], "floors": 2 if not shop and rng.randf() < 0.4 else 1, "back": true})
		if shop:
			si += 1
		x0 += w2 + rng.randf_range(0.6, 2.0)
	# ---- moradias da rua de trás (lado sul), com jardim à frente ----
	x0 = -88.0
	while x0 < 88.0:
		var w3 := rng.randf_range(8.5, 11.5)
		var skip := false
		for cx in CROSS_X:
			if x0 + w3 > cx - 4.0 and x0 < cx + 4.0:
				skip = true
				x0 = cx + 4.0
		if x0 + w3 > PLAZA.x - 17.0 and x0 < PLAZA.x + 17.0:
			skip = true
			x0 = PLAZA.x + 17.0
		if skip:
			continue
		var d2 := rng.randf_range(7.0, 8.5)
		var cxh := x0 + w3 * 0.5
		_house(_bb(cxh), Vector3(cxh, 0, BACK_Z + 7.6 + d2 * 0.5), w3 - 2.0, d2, PI, {"garden": true, "floors": 2 if rng.randf() < 0.45 else 1})
		x0 += w3 + rng.randf_range(0.3, 1.2)
	# lado norte da rua de trás: quintais das lojas com sebes, árvores e hortas
	for x in range(-84, 85, 12):
		var bx := float(x) + rng.randf_range(-2, 2)
		var skipn := false
		for cx in CROSS_X:
			if abs(bx - cx) < 6.5:
				skipn = true
		if skipn:
			continue
		var bq := _bb(bx)
		bq.box(9.0, 0.9, 0.5, Mats.rough_surface("#3f7a36", 0.4, 0.9, 1.0, 9), Vector3(bx, 0.45, BACK_Z - 5.2))
		if rng.randf() < 0.6:
			Props.tree(bq, Vector3(bx + rng.randf_range(-3, 3), 0, BACK_Z - 7.5), 0.7 + rng.randf() * 0.2, int(bx))
		world.add_seg(Vector3(bx - 4.5, 0, BACK_Z - 5.2), Vector3(bx + 4.5, 0, BACK_Z - 5.2), 0.25)
	# ---- praça com igreja, chafariz, bancos, quiosque e parque infantil ----
	_build_plaza()
	# ---- casas do lado do hotel, longe do edifício ----
	for x in [-44.0, -58.0, -72.0, 46.0, 60.0, 74.0]:
		_house(_bb(x), Vector3(x, 0, 15.5), 9.0, 8.0, 0.0, {"garden": true, "floors": 1 if int(x) % 2 == 0 else 2})
	# ---- árvores dos passeios ----
	for x in range(-90, 91, 14):
		var tx := float(x) + 7.0
		var near_cross := false
		for cx in CROSS_X:
			if abs(tx - cx) < 5.0:
				near_cross = true
		if abs(tx - PLAZA.x) < 15.0 or near_cross:
			continue
		Props.tree(_bb(tx), Vector3(tx, 0.12, BACK_Z + 3.95), 0.62, int(x) + 3)
		world.add_seg(Vector3(tx, 0, BACK_Z + 3.95), Vector3(tx, 0, BACK_Z + 3.95), 0.25)
	# ---- monte com aldeia e colinas ao longe ----
	_build_horizon()
	# compromete os blocos
	for k in chunks:
		chunks[k].commit(self, true, "Town")
	chunks.clear()
	# ---- carros ----
	var cols := ["#c8102e", "#1f4e9c", "#f2f2f2", "#2b2b2b", "#e8b100", "#5a8a3a", "#8a8f96", "#ff7a35", "#7fc8d8", "#a8343f"]
	for k in 7:
		var east := k % 2 == 0
		var car := _car(Color(cols[k % cols.size()]))
		add_child(car)
		var x := -90.0 + k * 28.0
		car.position = Vector3(x, 0, LANE_E if east else LANE_W)
		car.rotation.y = PI / 2 if east else -PI / 2
		cars.append({"n": car, "dir": 1.0 if east else -1.0, "v": rng.randf_range(6.0, 9.0), "cur": 0.0, "z": LANE_E if east else LANE_W, "half": 4.6})
	for k in 3:
		var east2 := k % 2 == 0
		var car2 := _car(Color(cols[(k + 7) % cols.size()]))
		add_child(car2)
		var lz := BACK_Z - 1.4 if east2 else BACK_Z + 1.4
		car2.position = Vector3(-60.0 + k * 50.0, 0, lz)
		car2.rotation.y = PI / 2 if east2 else -PI / 2
		cars.append({"n": car2, "dir": 1.0 if east2 else -1.0, "v": rng.randf_range(3.5, 5.0), "cur": 0.0, "z": lz, "half": 3.0})
	# carros estacionados junto às moradias
	for k in 5:
		var pc := _car(Color(cols[(k * 3) % cols.size()]))
		add_child(pc)
		pc.position = Vector3(-78.0 + k * 34.0 + rng.randf_range(-3, 3), 0, BACK_Z + 2.0)
		if abs(pc.position.x) < 16.0:
			pc.position.x += 30.0
		pc.rotation.y = -PI / 2
		world.add_seg(pc.position + Vector3(-2.0, 0, 0), pc.position + Vector3(2.0, 0, 0), 0.9)
	# ---- peões ----
	for k in 8:
		var h := HumanModel.new()
		add_child(h)
		h.setup(HumanModel.random_look(rng))
		var side := 36.0 if k % 2 == 0 else 23.8
		h.position = Vector3(rng.randf_range(-80, 80), 0.12, side)
		peds.append({"n": h, "dir": 1.0 if rng.randf() < 0.5 else -1.0, "v": rng.randf_range(1.0, 1.4), "z": side})
	for k in 7:
		var h2 := HumanModel.new()
		add_child(h2)
		h2.setup(HumanModel.random_look(rng))
		var side2 := BACK_Z - 3.9 if k % 2 == 0 else BACK_Z + 3.9
		h2.position = Vector3(rng.randf_range(-80, 80), 0.12, side2)
		var pd := {"n": h2, "dir": 1.0 if rng.randf() < 0.5 else -1.0, "v": rng.randf_range(0.8, 1.2), "z": side2}
		# alguns passeiam o cão
		if k < 3:
			var dog := PetModel.new()
			add_child(dog)
			dog.setup(["cao", "agua", "serra"][k], rng.randi() % 3)
			dog.scale = Vector3.ONE * 0.9
			pd["dog"] = dog
			pd.v = 0.9
			h2.pose = "lead"
		peds.append(pd)
	# ---- pássaros a voar ----
	for k in 6:
		var b := _bird()
		add_child(b)
		birds.append({"n": b, "c": Vector3(rng.randf_range(-40, 40), rng.randf_range(14, 22), rng.randf_range(20, 70)), "r": rng.randf_range(6, 14), "a": rng.randf() * TAU, "s": rng.randf_range(0.25, 0.45) * (1.0 if rng.randf() < 0.5 else -1.0)})

# ---------- moradia / loja ----------
const WALLS := ["#f7f3ea", "#f7f3ea", "#f6f1e6", "#f3e3b8", "#f0d8d2", "#dfe8ee", "#f7f3ea"]
const BARRAS := ["#2f6fae", "#e2b23a", "#c46a3a", "#6a8f5a", "#3a8f9a", "#8a8f96"]
const SHUTTERS := ["#2f6a4a", "#2f5f9a", "#7a4a2a", "#a8343f", "#3a8f9a"]

func _house(B: Batch, c: Vector3, w: float, d: float, yaw: float, opt: Dictionary) -> void:
	var T := Transform3D(Basis(Vector3.UP, yaw), c)
	var shop_info: Array = opt.get("shop", [])
	var shop := not shop_info.is_empty()
	var floors: int = opt.get("floors", 1)
	var wall := Mats.plaster(WALLS[rng.randi() % WALLS.size()])
	var barra_c: String = BARRAS[rng.randi() % BARRAS.size()]
	var barra := Mats.plaster(barra_c)
	var shut := Mats.glossy(SHUTTERS[rng.randi() % SHUTTERS.size()], 0.5)
	var h := (3.4 if not shop else 3.8) + (floors - 1) * 2.8
	Props.lbox(B, T, Vector3(w, h, d), Vector3(0, h * 0.5, 0), wall)
	# barra colorida em baixo e cunhais (como as casas do Algarve)
	Props.lbox(B, T, Vector3(w + 0.06, 0.65, d + 0.06), Vector3(0, 0.325, 0), barra)
	for sx in [-1.0, 1.0]:
		Props.lbox(B, T, Vector3(0.3, h, 0.3), Vector3(sx * (w * 0.5 - 0.12), h * 0.5, d * 0.5 - 0.12), barra)
	Props.lbox(B, T, Vector3(w + 0.12, 0.18, d + 0.12), Vector3(0, h - 0.09, 0), barra)
	# telhado de duas águas
	var rm := Mats.textured("#b5532f" if rng.randf() < 0.8 else "#8a4a32", "roof", 1.4, 0.75, 1.2)
	var ang := 0.48
	var half := d * 0.5 + 0.5
	for s in [-1.0, 1.0]:
		B.box_xf(Vector3(w + 0.8, 0.15, half / cos(ang)), T * Transform3D(Basis(Vector3.RIGHT, s * ang), Vector3(0, h + half * tan(ang) * 0.5, s * half * 0.5)), rm)
	Props.lbox(B, T, Vector3(w - 0.02, half * tan(ang), 0.1), Vector3(0, h + half * tan(ang) * 0.33, d * 0.5 - 0.05), wall)
	Props.lbox(B, T, Vector3(w - 0.02, half * tan(ang), 0.1), Vector3(0, h + half * tan(ang) * 0.33, -d * 0.5 + 0.05), wall)
	# chaminé algarvia (branca, com rendilhado)
	var chx := w * (0.3 if rng.randf() < 0.5 else -0.3)
	var chz := -d * 0.18
	var chy := h + half * tan(ang) * 0.6
	Props.lbox(B, T, Vector3(0.55, 1.3, 0.55), Vector3(chx, chy + 0.25, chz), Mats.plaster("#f7f3ea"))
	Props.lbox(B, T, Vector3(0.75, 0.6, 0.75), Vector3(chx, chy + 1.15, chz), Mats.plaster("#f7f3ea"))
	for k in 3:
		Props.lbox(B, T, Vector3(0.78, 0.06, 0.78), Vector3(chx, chy + 0.92 + k * 0.2, chz), barra)
	Props.lbox(B, T, Vector3(0.5, 0.25, 0.5), Vector3(chx, chy + 1.55, chz), Mats.plaster("#f7f3ea"))
	# fachada: porta, janelas com portadas e parapeito, azulejo junto à porta
	var front := d * 0.5 + 0.03
	var glass := Mats.glossy("#9cc6dc", 0.06, 0.3)
	var frame := Mats.base("#ffffff", 0.5)
	var door_x := -w * 0.25 if not shop else 0.0
	Props.lbox(B, T, Vector3(1.25, 2.3, 0.06), Vector3(door_x, 1.15, front - 0.01), barra)
	Props.lbox(B, T, Vector3(1.05, 2.15, 0.08), Vector3(door_x, 1.08, front), Props.wood("#6a4a32" if rng.randf() < 0.6 else "#2f5f9a"))
	B.box_xf(Vector3(0.06, 0.06, 0.06), T * Transform3D(Basis(), Vector3(door_x + 0.38, 1.05, front + 0.06)), Mats.glossy("#d9b13a", 0.2, 0.9))
	Props.lbox(B, T, Vector3(1.5, 0.12, 0.5), Vector3(door_x, 0.06, front + 0.25), Mats.rough_surface("#bdb8ae", 1.0, 0.8))
	if shop:
		Props.lbox(B, T, Vector3(w * 0.32, 1.7, 0.06), Vector3(-w * 0.3, 1.35, front), glass)
		Props.lbox(B, T, Vector3(w * 0.32, 1.7, 0.06), Vector3(w * 0.3, 1.35, front), glass)
		var aw := Mats.textured(shop_info[1], "stripes", 1.2, 0.8, 0.0, false)
		B.box_xf(Vector3(w * 0.95, 0.06, 1.3), T * Transform3D(Basis(Vector3.RIGHT, 0.35), Vector3(0, 2.75, front + 0.6)), aw)
		# mesas na esplanada
		if shop_info[0].contains("Café") or shop_info[0].contains("Gelataria"):
			for k in 2:
				var tp := T * Vector3(-w * 0.3 + k * w * 0.6, 0, front + 1.2)
				Props.table_round(B, tp + Vector3(0, 0.1, 0), 0.35)
		var lab := Label3D.new()
		lab.text = D.T(shop_info[0])
		lab.font_size = 70
		lab.pixel_size = 0.006
		lab.outline_size = 16
		lab.outline_modulate = Color(shop_info[1])
		lab.position = T * Vector3(0, 3.35, front + 0.1)
		lab.rotation.y = yaw
		add_child(lab)
	else:
		var az := Mats.textured("#3a6fb5", "tiles", 0.3, 0.3, 0.6)
		Props.lbox(B, T, Vector3(0.45, 0.6, 0.03), Vector3(door_x + 0.95, 1.55, front + 0.01), az)
	var wins := [w * 0.12, w * 0.34] if not shop else []
	for fl in floors:
		var wy := 1.55 + fl * 2.8
		var wx_list: Array = wins if fl == 0 else [-w * 0.25, w * 0.12, w * 0.34]
		for wx in wx_list:
			Props.lbox(B, T, Vector3(1.0, 1.15, 0.06), Vector3(wx, wy, front), glass)
			Props.lbox(B, T, Vector3(1.2, 1.32, 0.04), Vector3(wx, wy, front - 0.015), frame)
			Props.lbox(B, T, Vector3(1.3, 0.08, 0.2), Vector3(wx, wy - 0.62, front + 0.07), frame)
			for sd in [-1.0, 1.0]:
				Props.lbox(B, T, Vector3(0.45, 1.2, 0.05), Vector3(wx + sd * 0.78, wy, front + 0.03), shut)
			if rng.randf() < 0.5:
				for k in 3:
					B.ell(0.09, 0.08, 0.09, Mats.base(["#e0508a", "#f2c230", "#e8443a", "#ffffff"][rng.randi() % 4], 0.7), T * Vector3(wx - 0.3 + k * 0.3, wy - 0.5, front + 0.14), 0.0, 8)
		# varanda no primeiro andar
		if fl == 1 and rng.randf() < 0.6:
			Props.lbox(B, T, Vector3(2.4, 0.12, 0.8), Vector3(w * 0.12, wy - 0.8, front + 0.4), frame)
			Props.lbox(B, T, Vector3(2.4, 0.05, 0.05), Vector3(w * 0.12, wy - 0.05, front + 0.78), Mats.glossy("#2a2d33", 0.4, 0.6))
			for k in 9:
				Props.lbox(B, T, Vector3(0.03, 0.7, 0.03), Vector3(w * 0.12 - 1.15 + k * 0.29, wy - 0.4, front + 0.78), Mats.glossy("#2a2d33", 0.4, 0.6))
	# jardim à frente com muro baixo, portão, árvore e vasos
	if opt.get("garden", false):
		var gz := front + 2.6
		var cap := Mats.plaster(barra_c)
		for seg in [[-w * 0.5, door_x - 0.7], [door_x + 0.7, w * 0.5]]:
			var a: float = seg[0]
			var b: float = seg[1]
			Props.lbox(B, T, Vector3(b - a, 0.7, 0.22), Vector3((a + b) * 0.5, 0.35, gz), Mats.plaster("#f7f3ea"))
			Props.lbox(B, T, Vector3(b - a + 0.04, 0.07, 0.28), Vector3((a + b) * 0.5, 0.72, gz), cap)
			world.add_seg(T * Vector3(a, 0, gz), T * Vector3(b, 0, gz), 0.15)
		for sx in [-1.0, 1.0]:
			Props.lbox(B, T, Vector3(0.22, 0.7, 2.6), Vector3(sx * w * 0.5, 0.35, front + 1.3), Mats.plaster("#f7f3ea"))
			world.add_seg(T * Vector3(sx * w * 0.5, 0, front), T * Vector3(sx * w * 0.5, 0, gz), 0.15)
		Props.lbox(B, T, Vector3(1.4, 0.03, 2.5), Vector3(door_x, 0.04, front + 1.3), Mats.textured("#cfc8bb", "pavers", 0.8, 0.85, 1.0))
		Props.lbox(B, T, Vector3(w - 0.4, 0.04, 2.4), Vector3(0, 0.025, front + 1.3), Mats.rough_surface("#5f9a48", 0.5, 0.9, 0.8, 9))
		var gx := w * 0.25
		if rng.randf() < 0.55:
			# laranjeira
			B.cyl_xf(0.07, 0.1, 1.1, Mats.rough_surface("#6e4a2e", 0.6, 0.95, 1.0, 41), T * Transform3D(Basis(), Vector3(gx, 0.55, front + 1.3)), 8)
			B.ell(0.75, 0.65, 0.75, Mats.rough_surface("#3c7a35", 0.35, 0.85, 1.0, 9), T * Vector3(gx, 1.55, front + 1.3), 0.0, 12)
			for k in 7:
				var a2 := k * 0.9
				B.ell(0.07, 0.07, 0.07, Mats.glossy("#f28a1a", 0.4), T * Vector3(gx + cos(a2) * 0.6, 1.45 + sin(k * 1.7) * 0.3, front + 1.3 + sin(a2) * 0.6), 0.0, 8)
		else:
			for k in 3:
				Props.plant(B, T * Vector3(gx - 0.8 + k * 0.8, 0, front + 0.8), 0.7)
		# caixa do correio
		Props.lbox(B, T, Vector3(0.3, 0.35, 0.2), Vector3(door_x + 1.0, 0.95, gz + 0.02), Mats.glossy("#c8102e", 0.4))
	# lojas: traseiras com porta e janela pequena
	if opt.get("back", false):
		Props.lbox(B, T, Vector3(1.0, 2.0, 0.06), Vector3(w * 0.2, 1.0, -d * 0.5 - 0.03), Props.wood("#6a4a32"))
		Props.lbox(B, T, Vector3(0.9, 0.7, 0.06), Vector3(-w * 0.2, 1.9, -d * 0.5 - 0.03), glass)
	world.add_seg(T * Vector3(-w * 0.5, 0, -d * 0.5), T * Vector3(w * 0.5, 0, -d * 0.5), 0.1)
	world.add_seg(T * Vector3(-w * 0.5, 0, d * 0.5), T * Vector3(w * 0.5, 0, d * 0.5), 0.1)
	world.add_seg(T * Vector3(-w * 0.5, 0, -d * 0.5), T * Vector3(-w * 0.5, 0, d * 0.5), 0.1)
	world.add_seg(T * Vector3(w * 0.5, 0, -d * 0.5), T * Vector3(w * 0.5, 0, d * 0.5), 0.1)

# ---------- praça ----------
func _build_plaza() -> void:
	var c := PLAZA
	var B := _bb(c.x)
	var calc := Mats.textured("#ece6da", "pavers", 0.7, 0.85, 0.8)
	B.box(30.0, 0.08, 24.0, calc, c + Vector3(0, 0.04, 0))
	# calçada portuguesa: ondas escuras em volta do chafariz
	for k in 28:
		var a := k * TAU / 28.0
		B.box(0.5, 0.01, 0.9, Mats.base("#3a3d42", 0.8), c + Vector3(cos(a) * 4.6, 0.085, sin(a) * 4.6), -a)
	# chafariz
	var stone := Mats.rough_surface("#d8d2c4", 0.8, 0.7, 0.6, 7)
	B.cyl(2.4, 2.5, 0.55, stone, c + Vector3(0, 0.3, 0), 32)
	B.cyl(0.3, 0.4, 1.5, stone, c + Vector3(0, 0.9, 0), 16)
	B.cyl(1.0, 0.5, 0.2, stone, c + Vector3(0, 1.7, 0), 24)
	B.cyl(0.2, 0.25, 0.6, stone, c + Vector3(0, 2.0, 0), 12)
	world.add_seg(c, c, 2.5)
	world._water_disc(c + Vector3(0, 0.59, 0), 2.25, self)
	world._water_disc(c + Vector3(0, 1.815, 0), 0.92, self)
	# bancos e árvores
	for k in 8:
		var a := k * TAU / 8.0 + 0.4
		var p := c + Vector3(cos(a) * 7.5, 0, sin(a) * 6.0)
		Props.bench(B, p, atan2(c.x - p.x, c.z - p.z))
		world.add_seg(p, p, 0.5)
	for p in [Vector3(-12, 0, -8), Vector3(12, 0, -8), Vector3(-12, 0, 6), Vector3(12, 0, 6), Vector3(-6, 0, -10), Vector3(6, 0, -10)]:
		Props.tree(B, c + p, 0.85, int(p.x * 3 + p.z))
		world.add_seg(c + p, c + p, 0.3)
	for p in [Vector3(-9, 0, 0), Vector3(9, 0, 0)]:
		world.lamp(c + p, self, B)
	# quiosque
	var kq := c + Vector3(-10.5, 0, 9.0)
	B.cyl(1.4, 1.4, 0.15, stone, kq + Vector3(0, 0.08, 0), 8)
	for k in 6:
		var a := k * TAU / 6.0
		B.cyl(0.06, 0.06, 2.4, Mats.glossy("#2f6a4a", 0.4, 0.4), kq + Vector3(cos(a) * 1.2, 1.25, sin(a) * 1.2), 8)
	B.cyl(0.0, 1.8, 0.9, Mats.glossy("#2f6a4a", 0.4, 0.4), kq + Vector3(0, 2.9, 0), 6)
	B.box(1.4, 1.0, 0.8, Mats.textured("#9a6a44", "planks", 1.0, 0.6, 0.6), kq + Vector3(0, 0.6, 0))
	world.add_seg(kq, kq, 1.4)
	# parque infantil: baloiço, escorrega e balancé
	var pg := c + Vector3(10.0, 0, 7.5)
	B.box(7.0, 0.05, 5.0, Mats.rough_surface("#d9634a", 0.6, 0.95, 0.5, 15), pg + Vector3(0, 0.06, 0))
	var mt := Mats.glossy("#3a95d8", 0.35, 0.5)
	for sx in [-1.2, 1.2]:
		B.cyl_xf(0.05, 0.05, 2.4, mt, Transform3D(Basis(Vector3.FORWARD, sx * 0.18), pg + Vector3(-2.0 + sx * 0.8, 1.15, 0)), 8)
	B.box(2.8, 0.08, 0.08, mt, pg + Vector3(-2.0, 2.3, 0))
	for k in 2:
		B.box(0.5, 0.05, 0.25, Mats.glossy("#f2c230", 0.4), pg + Vector3(-2.5 + k * 1.0, 0.55, 0))
	B.box(0.9, 1.4, 0.9, Mats.glossy("#e8443a", 0.4), pg + Vector3(1.3, 0.7, -1.0))
	B.box_xf(Vector3(0.7, 0.06, 2.6), Transform3D(Basis(Vector3.RIGHT, -0.5), pg + Vector3(1.3, 0.75, 0.15)), Mats.glossy("#f2c230", 0.3))
	B.box_xf(Vector3(0.18, 0.12, 2.8), Transform3D(Basis(Vector3.RIGHT, 0.15), pg + Vector3(2.8, 0.4, 0.8)), Mats.glossy("#2fae6b", 0.4))
	world.add_seg(pg + Vector3(-3.4, 0, 0), pg + Vector3(-0.6, 0, 0), 0.3)
	world.add_seg(pg + Vector3(1.3, 0, -1.0), pg + Vector3(1.3, 0, -1.0), 0.6)
	# igreja com torre sineira ao fundo da praça
	var ch := c + Vector3(0, 0, 16.5)
	var T := Transform3D(Basis(Vector3.UP, PI), ch)
	var wall := Mats.plaster("#f7f3ea")
	var yel := Mats.plaster("#e2b23a")
	Props.lbox(B, T, Vector3(9.0, 6.5, 13.0), Vector3(0, 3.25, 0), wall)
	Props.lbox(B, T, Vector3(9.2, 0.7, 13.2), Vector3(0, 0.35, 0), yel)
	for sx in [-1.0, 1.0]:
		Props.lbox(B, T, Vector3(0.45, 6.6, 0.45), Vector3(sx * 4.4, 3.3, 6.35), yel)
	# frontão
	for s in [-1.0, 1.0]:
		B.box_xf(Vector3(5.3, 0.25, 0.4), T * Transform3D(Basis(Vector3.FORWARD, s * 0.45), Vector3(s * 2.25, 7.5, 6.4)), yel)
	Props.lbox(B, T, Vector3(7.4, 1.7, 0.2), Vector3(0, 7.15, 6.42), wall)
	var rm := Mats.textured("#b5532f", "roof", 1.4, 0.75, 1.2)
	for s in [-1.0, 1.0]:
		B.box_xf(Vector3(5.3, 0.15, 13.4), T * Transform3D(Basis(Vector3.FORWARD, s * 0.45), Vector3(s * 2.25, 7.45, 0)), rm)
	Props.lbox(B, T, Vector3(1.9, 3.4, 0.12), Vector3(0, 1.7, 6.52), Props.wood("#5a3a22"))
	Props.lbox(B, T, Vector3(2.3, 3.8, 0.1), Vector3(0, 1.9, 6.5), yel)
	B.cyl_xf(0.6, 0.6, 0.08, Mats.glossy("#7fb8d8", 0.1, 0.3), T * Transform3D(Basis(Vector3.RIGHT, PI / 2), Vector3(0, 5.2, 6.52)), 20)
	for sz in [-3.0, 1.0]:
		for sx in [-1.0, 1.0]:
			Props.lbox(B, T, Vector3(0.1, 1.8, 0.9), Vector3(sx * 4.52, 3.5, sz), Mats.glossy("#7fb8d8", 0.1, 0.3))
	# torre sineira
	var tw := Vector3(3.6, 0, -2.0)
	Props.lbox(B, T, Vector3(2.6, 10.5, 2.6), tw + Vector3(0, 5.25, 0), wall)
	Props.lbox(B, T, Vector3(2.8, 0.25, 2.8), tw + Vector3(0, 8.2, 0), yel)
	Props.lbox(B, T, Vector3(2.8, 0.25, 2.8), tw + Vector3(0, 10.5, 0), yel)
	Props.lbox(B, T, Vector3(1.0, 1.4, 2.7), tw + Vector3(0, 9.3, 0), Mats.base("#2a2a2e", 0.9))
	Props.lbox(B, T, Vector3(2.7, 1.4, 1.0), tw + Vector3(0, 9.3, 0), Mats.base("#2a2a2e", 0.9))
	B.ell(0.4, 0.45, 0.4, Mats.glossy("#c9a03a", 0.25, 0.9), T * (tw + Vector3(0, 9.2, 0)), 0.0, 12)
	B.cyl_xf(0.0, 1.9, 2.2, rm, T * Transform3D(Basis(), tw + Vector3(0, 11.7, 0)), 4)
	B.cyl_xf(0.04, 0.04, 1.2, Mats.glossy("#2a2d33", 0.3, 0.7), T * Transform3D(Basis(), tw + Vector3(0, 13.3, 0)), 6)
	B.box_xf(Vector3(0.6, 0.06, 0.06), T * Transform3D(Basis(), tw + Vector3(0, 13.5, 0)), Mats.glossy("#2a2d33", 0.3, 0.7))
	B.cyl_xf(0.5, 0.5, 0.06, Mats.base("#f7f5f0", 0.5), T * Transform3D(Basis(Vector3.RIGHT, PI / 2), tw + Vector3(0, 7.3, 1.33)), 20)
	for p in [[-4.5, -6.5, 4.5, -6.5], [-4.5, 6.5, 4.5, 6.5], [-4.5, -6.5, -4.5, 6.5], [4.5, -6.5, 4.5, 6.5]]:
		world.add_seg(T * Vector3(p[0], 0, p[1]), T * Vector3(p[2], 0, p[3]), 0.12)
	world.add_seg(T * (tw + Vector3(-1.3, 0, -1.3)), T * (tw + Vector3(1.3, 0, 1.3)), 1.0)
	var lab := Label3D.new()
	lab.text = "⛲ " + D.T("Praça do Bairro")
	lab.font_size = 64
	lab.pixel_size = 0.006
	lab.outline_size = 14
	lab.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lab.position = c + Vector3(0, 3.6, 0)
	add_child(lab)

# ---------- aldeia no monte e colinas ao longe (tudo numa só peça) ----------
func _build_horizon() -> void:
	var B := Batch.new()
	var r := RandomNumberGenerator.new()
	r.seed = 99
	var hill := Color("#7fa65a")
	# colinas em toda a volta, longe
	for k in 22:
		var a := k * TAU / 22.0 + r.randf() * 0.1
		var dist := r.randf_range(150, 175)
		var p := Vector3(cos(a) * dist, -6.0, -10.0 + sin(a) * dist)
		var rx := r.randf_range(30, 50)
		B.ell_c(rx, r.randf_range(14, 26), rx * 0.6, hill * r.randf_range(0.82, 1.05), p, -a, 16)
	# monte com aldeia por trás da praça
	var mc := Vector3(10, -14, 128)
	B.ell_c(70, 26, 34, Color("#86ad5e"), mc, 0.0, 20)
	for k in 70:
		var x := r.randf_range(-48, 60)
		var zz := r.randf_range(-14, 14)
		var t2: float = 1.0 - pow(x - mc.x, 2) / (70.0 * 70.0) - pow(zz, 2) / (34.0 * 34.0)
		if t2 <= 0.05:
			continue
		var y: float = mc.y + 26.0 * sqrt(t2) - 0.4
		var p2 := Vector3(x, y, mc.z + zz)
		var hw := r.randf_range(2.5, 4.0)
		B.box_c(hw, 2.4, hw * 0.8, Color("#f7f3ea") * r.randf_range(0.92, 1.0), p2 + Vector3(0, 1.2, 0), r.randf_range(-0.3, 0.3))
		B.box_c(hw + 0.3, 0.9, hw * 0.8 + 0.3, Color("#b5532f") * r.randf_range(0.85, 1.05), p2 + Vector3(0, 2.75, 0), r.randf_range(-0.3, 0.3))
	for k in 60:
		var x2 := r.randf_range(-60, 75)
		var z2 := r.randf_range(-20, 20)
		var t3: float = 1.0 - pow(x2 - mc.x, 2) / (70.0 * 70.0) - pow(z2, 2) / (34.0 * 34.0)
		if t3 <= 0.02:
			continue
		var y2: float = mc.y + 26.0 * sqrt(t3)
		B.ell_c(1.6, 2.2, 1.6, Color("#4f7a3a") * r.randf_range(0.85, 1.1), Vector3(x2, y2 + 1.6, mc.z + z2), 0.0, 8)
	# moinho de vento no alto
	var mp := Vector3(-8, mc.y + 26.0 - 0.5, mc.z - 4)
	B.cyl_c(1.4, 1.8, 5.0, Color("#f7f3ea"), Transform3D(Basis(), mp + Vector3(0, 2.5, 0)), 12)
	B.cyl_c(0.0, 1.6, 1.4, Color("#5a4636"), Transform3D(Basis(), mp + Vector3(0, 5.7, 0)), 12)
	for k in 4:
		var sb := Basis(Vector3.BACK, k * PI / 2 + 0.4)
		B.add_c(Batch.box_mesh(Vector3(0.6, 3.8, 0.05)), Transform3D(sb, mp + Vector3(0, 5.0, -1.75) + sb * Vector3(0, 1.9, 0)), Color("#e9e2d3"))
	var mis := B.commit(self, false, "Horizon")
	for mi in mis:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

func _bird() -> Node3D:
	var n := Node3D.new()
	var B := Batch.new()
	B.add_c(Batch.box_mesh(Vector3(0.12, 0.08, 0.3)), Transform3D(), Color("#3a3d42"))
	for s in [-1.0, 1.0]:
		var wing := Node3D.new()
		wing.name = "W" + ("L" if s < 0 else "R")
		n.add_child(wing)
		var wb := Batch.new()
		wb.add_c(Batch.box_mesh(Vector3(0.5, 0.02, 0.18)), Transform3D(Basis(), Vector3(s * 0.27, 0, 0)), Color("#3a3d42"))
		wb.commit(wing, false, "Wing")
	B.commit(n, false, "Bird")
	return n

func _car(col: Color) -> Node3D:
	var n := Node3D.new()
	var B := Batch.new()
	var paint := Mats.glossy(col, 0.25, 0.35, true)
	var glass := Mats.glossy("#1d2833", 0.05, 0.5)
	var tyre := Mats.base("#1b1b1d", 0.85)
	var rim := Mats.glossy("#c9cfd6", 0.2, 0.9)
	B.box(1.75, 0.55, 4.1, paint, Vector3(0, 0.62, 0))
	B.box(1.6, 0.5, 2.1, paint, Vector3(0, 1.12, -0.25))
	B.box(1.62, 0.42, 1.9, glass, Vector3(0, 1.13, -0.25))
	B.box(1.5, 0.42, 0.05, glass, Vector3(0, 1.1, 0.83))
	for x in [-0.88, 0.88]:
		for z in [-1.3, 1.3]:
			B.cyl_xf(0.34, 0.34, 0.24, tyre, Transform3D(Basis(Vector3.FORWARD, PI / 2), Vector3(x, 0.34, z)), 16)
			B.cyl_xf(0.2, 0.2, 0.25, rim, Transform3D(Basis(Vector3.FORWARD, PI / 2), Vector3(x, 0.34, z)), 12)
	B.box(1.6, 0.12, 0.05, Mats.emissive("#fff4d0", 1.5), Vector3(0, 0.75, 2.06))
	B.box(1.6, 0.12, 0.05, Mats.emissive("#ff2a2a", 1.2), Vector3(0, 0.75, -2.06))
	B.commit(n, true, "Car")
	return n

func update(dt: float, player_pos: Vector3) -> void:
	for c in cars:
		var n: Node3D = c.n
		var ahead: float = n.position.x + c.dir * 5.0
		var stop := false
		# pára se alguém estiver à frente na estrada (jogador ou outro carro)
		if abs(player_pos.z - c.z) < c.half and abs(player_pos.x - ahead) < 4.5:
			stop = true
		for o in cars:
			if o != c and o.z == c.z and (o.n.position.x - n.position.x) * c.dir > 0 and abs(o.n.position.x - n.position.x) < 7.5:
				stop = true
		c.cur = move_toward(c.cur, 0.0 if stop else c.v, dt * (9.0 if stop else 3.0))
		n.position.x += c.dir * c.cur * dt
		if n.position.x > 100:
			n.position.x = -100
		if n.position.x < -100:
			n.position.x = 100
	for p in peds:
		var h: HumanModel = p.n
		h.position.x += p.dir * p.v * dt
		h.rotation.y = PI / 2 if p.dir > 0 else -PI / 2
		if abs(h.position.x) > 88:
			p.dir = -p.dir
		h.animate(dt, true, p.v, "lead" if p.has("dog") else "")
		if p.has("dog"):
			var dog: PetModel = p.dog
			var target := h.position + Vector3(p.dir * 1.3, -0.12, 0.55 if p.z < BACK_Z else -0.55)
			dog.position = dog.position.lerp(target, min(1.0, dt * 3.0))
			dog.rotation.y = PI / 2 if p.dir > 0 else -PI / 2
			dog.animate(dt, true, p.v, "", true)
	for b in birds:
		b.a += b.s * dt
		var n2: Node3D = b.n
		var c2: Vector3 = b.c
		n2.position = c2 + Vector3(cos(b.a) * b.r, sin(b.a * 2.0) * 0.6, sin(b.a) * b.r)
		n2.rotation.y = -b.a + (PI if b.s > 0 else 0.0)
		var flap := sin(Time.get_ticks_msec() * 0.012 + b.r) * 0.6
		for wch in n2.get_children():
			if wch.name.begins_with("W"):
				wch.rotation.z = flap * (1.0 if wch.name == "WR" else -1.0)
