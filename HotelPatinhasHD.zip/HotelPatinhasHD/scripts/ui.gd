# Hotel Patinhas HD · interface: topo, notificações (canto superior esquerdo), joystick, cartões e painéis
class_name UI
extends CanvasLayer

var G  # main
var sim: Sim
var root: Control
var theme_: Theme
var toast_box: VBoxContainer
var hud_money: Label
var hud_stars: Label
var hud_name: Label
var hud_extra: Label
var ctx_panel: PanelContainer
var ctx_box: VBoxContainer
var ctx_key := ""
var ctx_room := -1
var ctx_bars := {}
var ctx_time: Label
var modal: Control
var modal_panel: PanelContainer
var modal_title: Label
var modal_tabs: HFlowContainer
var modal_body: VBoxContainer
var modal_scroll: ScrollContainer
var current := {}
var joystick: Control
var joy_vec := Vector2.ZERO
var joy_touch := -1
var joy_center := Vector2.ZERO
var top_bar: Control
var right_btns: VBoxContainer
var bottom_btns: Control
var photo_mode := false
var pressing := false
var pending_render := false
var refresh_t := 0.0
var mine_sel := {}
var don_sel := 5.0
var back_data = null

const ORANGE := Color("#ff7a35")
const DARK := Color("#1c2733")
const CREAM := Color("#fff8ee")
const GREEN := Color("#2fae6b")
const RED := Color("#e8443a")
const BLUE := Color("#3a95d8")
const GREY := Color("#b9bec6")
const MUTED := Color("#5a6470")

# ===================== construção =====================
func build(main) -> void:
	G = main
	sim = main.sim
	layer = 10
	theme_ = Theme.new()
	theme_.default_font_size = 22
	var f := SystemFont.new()
	f.font_names = PackedStringArray(["Nunito", "Roboto", "Noto Sans", "sans-serif"])
	f.font_weight = 700
	theme_.default_font = f
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = theme_
	add_child(root)
	_build_hud()
	_build_joystick()
	_build_ctx()
	_build_modal()
	sim.toast_msg.connect(_on_toast)

func sb(col: Color, r := 16, pad := 12, shadow := true) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = col
	s.set_corner_radius_all(r)
	s.content_margin_left = pad
	s.content_margin_right = pad
	s.content_margin_top = pad * 0.75
	s.content_margin_bottom = pad * 0.75
	if shadow:
		s.shadow_color = Color(0.1, 0.15, 0.2, 0.22)
		s.shadow_size = 6
		s.shadow_offset = Vector2(0, 3)
	return s

func lbl(text: String, size := 22, col := DARK, wrap := true) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART if wrap else TextServer.AUTOWRAP_OFF
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

func btn(text: String, cb: Callable, col := ORANGE, enabled := true, size := 22) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", size)
	var c := col if enabled else GREY
	b.add_theme_stylebox_override("normal", sb(c, 14, 14, true))
	b.add_theme_stylebox_override("hover", sb(c.lightened(0.08), 14, 14, true))
	b.add_theme_stylebox_override("pressed", sb(c.darkened(0.12), 14, 14, false))
	b.add_theme_stylebox_override("disabled", sb(GREY, 14, 14, false))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.85))
	b.disabled = not enabled
	b.custom_minimum_size = Vector2(0, 54)
	if enabled:
		b.pressed.connect(func():
			G.audio.play("click")
			cb.call()
		)
	return b

func round_btn(text: String, cb: Callable, size := 64) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(size, size)
	b.add_theme_font_size_override("font_size", int(size * 0.45))
	var s := sb(Color(1, 1, 1, 0.92), size / 2, 4, true)
	b.add_theme_stylebox_override("normal", s)
	b.add_theme_stylebox_override("hover", s)
	b.add_theme_stylebox_override("pressed", sb(Color(0.9, 0.92, 0.95), size / 2, 4, false))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.pressed.connect(func():
		G.audio.play("click")
		cb.call()
	)
	return b

func bar(parent: Control, label: String, v: float, col = null) -> ProgressBar:
	var h := HBoxContainer.new()
	parent.add_child(h)
	var l := lbl(label, 20, DARK, false)
	l.size_flags_horizontal = Control.SIZE_FILL
	l.custom_minimum_size = Vector2(40, 0)
	h.add_child(l)
	var p := ProgressBar.new()
	p.show_percentage = false
	p.custom_minimum_size = Vector2(110, 20)
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	p.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	p.add_theme_stylebox_override("background", sb(Color("#e9e4dc"), 10, 0, false))
	p.value = v
	_bar_col(p, v, col)
	h.add_child(p)
	return p

func _bar_col(p: ProgressBar, v: float, col = null) -> void:
	var c: Color = col if col != null else (RED if v < 25 else (Color("#f2c230") if v < 55 else GREEN))
	var key := c.to_html()
	if p.get_meta("c", "") != key:
		p.set_meta("c", key)
		p.add_theme_stylebox_override("fill", sb(c, 10, 0, false))

# ---------- topo ----------
func _build_hud() -> void:
	top_bar = HBoxContainer.new()
	top_bar.set_anchors_preset(Control.PRESET_CENTER_TOP)
	top_bar.position = Vector2(-10, 10)
	top_bar.grow_horizontal = Control.GROW_DIRECTION_BOTH
	top_bar.add_theme_constant_override("separation", 8)
	top_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(top_bar)
	var chip := func(txt: String) -> Label:
		var pc := PanelContainer.new()
		pc.add_theme_stylebox_override("panel", sb(Color(0.11, 0.15, 0.2, 0.82), 18, 12, false))
		pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var l := lbl(txt, 22, Color.WHITE)
		l.autowrap_mode = TextServer.AUTOWRAP_OFF
		pc.add_child(l)
		top_bar.add_child(pc)
		return l
	hud_money = chip.call("💰 €0")
	hud_stars = chip.call("★☆☆☆☆")
	hud_extra = chip.call("")
	hud_extra.get_parent().visible = false
	hud_name = lbl("", 18, Color.WHITE)
	# botões da direita
	right_btns = VBoxContainer.new()
	right_btns.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	right_btns.position = Vector2(-84, 70)
	right_btns.add_theme_constant_override("separation", 10)
	root.add_child(right_btns)
	right_btns.add_child(round_btn("⏸️", func(): open("menu")))
	right_btns.add_child(round_btn("🎯", func(): open("mis")))
	right_btns.add_child(round_btn("🗺️", func(): open("map")))
	right_btns.add_child(round_btn("🎥", func(): G.cycle_camera()))
	right_btns.add_child(round_btn("📷", func(): set_photo(true)))
	# notificações (canto superior esquerdo)
	toast_box = VBoxContainer.new()
	toast_box.position = Vector2(12, 70)
	toast_box.custom_minimum_size = Vector2(380, 0)
	toast_box.add_theme_constant_override("separation", 6)
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(toast_box)
	# baixo à direita: melhorias, zoom e rodar
	bottom_btns = VBoxContainer.new()
	bottom_btns.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	bottom_btns.position = Vector2(-96, -330)
	bottom_btns.add_theme_constant_override("separation", 10)
	root.add_child(bottom_btns)
	var up := round_btn("🛠️", func(): open("ups"), 84)
	bottom_btns.add_child(up)
	var row := HBoxContainer.new()
	bottom_btns.add_child(row)
	bottom_btns.add_child(round_btn("➕", func(): G.zoom(0.8), 60))
	bottom_btns.add_child(round_btn("➖", func(): G.zoom(1.25), 60))
	var rr := HBoxContainer.new()
	rr.add_theme_constant_override("separation", 8)
	rr.position = Vector2(-150, 0)
	root.add_child(rr)
	rr.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	rr.position = Vector2(-150, -86)
	rr.add_child(round_btn("⟲", func(): G.rotate_cam(-0.4), 60))
	rr.add_child(round_btn("⟳", func(): G.rotate_cam(0.4), 60))

func _on_toast(key: String, params: Dictionary) -> void:
	toast(D.F(key, params))

func toast(text: String) -> void:
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", sb(Color(0.11, 0.15, 0.2, 0.86), 14, 12, false))
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l := lbl(text, 19, Color.WHITE)
	l.custom_minimum_size = Vector2(360, 0)
	pc.add_child(l)
	toast_box.add_child(pc)
	while toast_box.get_child_count() > 5:
		var c := toast_box.get_child(0)
		toast_box.remove_child(c)
		c.queue_free()
	var tw := create_tween()
	tw.tween_interval(5.5)
	tw.tween_property(pc, "modulate:a", 0.0, 0.6)
	tw.tween_callback(pc.queue_free)

func update_hud() -> void:
	var S: Dictionary = sim.S
	hud_money.text = "💰 " + D.fmt(S.money)
	var st := sim.stars()
	hud_stars.text = "★".repeat(st) + "☆".repeat(5 - st)
	var extra := []
	if sim.contest != null:
		extra.append("🏅 " + D.mmss(sim.contest.ends - sim.t))
	if sim.boost > 0:
		extra.append("📣")
	if sim.season != "" and D.SEASON_INFO.has(sim.season):
		extra.append(D.SEASON_INFO[sim.season][0])
	if sim.raining:
		extra.append("🌧️")
	if not sim.queue.is_empty():
		extra.append("🛎️ %d" % sim.queue.size())
	hud_extra.text = "  ".join(extra)
	hud_extra.get_parent().visible = not extra.is_empty()

# ---------- joystick ----------
func _build_joystick() -> void:
	joystick = Control.new()
	joystick.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	joystick.position = Vector2(30, -250)
	joystick.size = Vector2(220, 220)
	joystick.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(joystick)
	joystick.draw.connect(_draw_joy)
	joystick.gui_input.connect(_joy_input)

func _draw_joy() -> void:
	var c := joystick.size * 0.5
	joystick.draw_circle(c, 92, Color(1, 1, 1, 0.22))
	joystick.draw_arc(c, 92, 0, TAU, 48, Color(1, 1, 1, 0.55), 3, true)
	joystick.draw_circle(c + joy_vec * 60, 40, Color(1, 1, 1, 0.85))

func _joy_input(ev: InputEvent) -> void:
	var c := joystick.size * 0.5
	if ev is InputEventScreenTouch:
		if ev.pressed and joy_touch < 0:
			joy_touch = ev.index
			_joy_set(ev.position - c)
		elif not ev.pressed and ev.index == joy_touch:
			joy_touch = -1
			joy_vec = Vector2.ZERO
		joystick.queue_redraw()
	elif ev is InputEventScreenDrag and ev.index == joy_touch:
		_joy_set(ev.position - c)
		joystick.queue_redraw()
	elif ev is InputEventMouseButton and not DisplayServer.is_touchscreen_available():
		if ev.pressed:
			joy_touch = 99
			_joy_set(ev.position - c)
		else:
			joy_touch = -1
			joy_vec = Vector2.ZERO
		joystick.queue_redraw()
	elif ev is InputEventMouseMotion and joy_touch == 99:
		_joy_set(ev.position - c)
		joystick.queue_redraw()

func _joy_set(v: Vector2) -> void:
	joy_vec = v / 60.0
	if joy_vec.length() > 1.0:
		joy_vec = joy_vec.normalized()

# ===================== cartão de contexto (receção / quarto / trela) =====================
func _build_ctx() -> void:
	ctx_panel = PanelContainer.new()
	ctx_panel.add_theme_stylebox_override("panel", sb(Color(1, 1, 1, 0.94), 22, 14, true))
	ctx_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	ctx_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	ctx_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	ctx_panel.visible = false
	root.add_child(ctx_panel)
	ctx_box = VBoxContainer.new()
	ctx_box.add_theme_constant_override("separation", 8)
	ctx_panel.add_child(ctx_box)

func _ctx_width() -> float:
	var vs := root.size
	return min(600.0, vs.x - 330.0) if vs.x > vs.y * 1.2 else min(640.0, vs.x - 30.0)

func _place_ctx() -> void:
	var vs := root.size
	var w := _ctx_width()
	ctx_panel.custom_minimum_size = Vector2(w, 0)
	ctx_panel.size = Vector2(w, ctx_panel.get_combined_minimum_size().y)
	var bottom := 265.0 if vs.y < vs.x * 1.2 and false else (255.0 if vs.y > vs.x * 1.2 else 16.0)
	ctx_panel.position = Vector2((vs.x - w) * 0.5, vs.y - bottom - ctx_panel.get_combined_minimum_size().y)

func clear(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()

func update_ctx(ctx: String) -> void:
	var key := ctx
	var S: Dictionary = sim.S
	var led = sim.leading_pet("player")
	if led != null and (ctx == "" or ctx.begins_with("room")):
		key = "lead:%d:%s:%s" % [led.gid, led.phase, led.dest]
	elif ctx.begins_with("room"):
		var i := int(ctx.substr(4))
		var g = S.rooms[i]
		var e = sim.pets.get(int(g.id)) if g != null else null
		key += ":%s:%s" % [sim.room_open(i), (str(g.id) + ("t" + e.phase if e != null and e.trip else "") + "m%d" % int(g.get("mess", 0)) + ("s" if g.get("sick", false) else "") + ("l" if g.get("leak", false) else "") + ("r%d" % int(g.req.p) if g.get("req") != null else "")) if g != null else "free"]
		if not sim.room_open(i):
			key += ":%d:%d" % [int(S.up.rooms), int(S.money >= D.up_cost("rooms", int(S.up.rooms)))]
	elif ctx == "desk":
		var ids := []
		for q in sim.queue:
			ids.append("%d%s" % [int(q.id), sim.free_room_for(q.sp) >= 0])
		key += ":" + ",".join(ids)
	elif ctx == "park":
		var w := []
		for id in sim.pets:
			var e2 = sim.pets[id]
			if e2.trip and e2.phase == "wait" and e2.escort == null:
				w.append(str(id))
		key += ":" + ",".join(w)
	if key != ctx_key and not pressing:
		ctx_key = key
		_render_ctx(ctx, led)
	_update_ctx_live()
	_place_ctx()

func _render_ctx(ctx: String, led) -> void:
	clear(ctx_box)
	ctx_bars = {}
	ctx_time = null
	ctx_room = -1
	var S: Dictionary = sim.S
	ctx_panel.visible = true
	if led != null and (ctx == "" or ctx.begins_with("room")):
		var lg = sim.guest_of(led)
		var h := HBoxContainer.new()
		ctx_box.add_child(h)
		var where := "a caminho do veterinário" if led.dest == "vet" else "a caminho do parque"
		if led.phase == "back":
			where = "a voltar ao quarto"
		h.add_child(lbl("🦮 %s · %s" % [lg.pet if lg else "", D.T(where)], 21))
		if led.phase == "go":
			var ri := sim.room_of(led)
			h.add_child(btn("✋ " + D.T("Soltar"), func(): sim.care(ri, "parque"), RED))
		return
	if ctx == "desk":
		var top := HBoxContainer.new()
		ctx_box.add_child(top)
		top.add_child(lbl("🛎️ " + D.T("Receção"), 24))
		var fc := D.F("{n} quarto(s) livre(s)", {"n": sim.free_count("")})
		if int(S.up.estabulo) > 0:
			fc += " · 🐴 %d" % sim.free_count("barn")
		if int(S.up.aviario) > 0:
			fc += " · 🦜 %d" % sim.free_count("avi")
		var fl := lbl(fc, 18, MUTED, false)
		fl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		top.add_child(fl)
		if sim.queue.is_empty():
			ctx_box.add_child(lbl(D.T("Ninguém à espera. Os próximos donos já vêm a caminho."), 19, MUTED, true))
			return
		for q in sim.queue:
			var card := VBoxContainer.new()
			ctx_box.add_child(card)
			var sp: Dictionary = D.SPECIES[q.sp]
			var title := "%s %s%s · %s" % [sp.e, "⭐ " if q.has("reg") else "", q.pet, D.T(sp.n)]
			if D.is_rare(q.sp, int(q.coat)):
				title += " ✨"
			card.add_child(lbl(title, 21))
			var est: float = sp.pay * q.stay / 60.0 * (1.0 + 0.15 * int(S.up.decor)) * (0.8 + 0.1 * sim.stars()) * 1.35
			var info := "%s · %s · %s" % [q.owner, D.F("fica {t}", {"t": D.mmss(q.stay)}), D.F("até {m}", {"m": D.fmt(est)})]
			if q.get("vip", "") == "infl":
				info += " · 📸 " + D.T("influenciador")
			elif q.get("vip", "") == "fam":
				info += " · 🌟 " + D.T("famoso")
			card.add_child(lbl(info, 17, MUTED, true))
			if q.get("req") != null:
				var R: Dictionary = D.REQS[q.req.t]
				card.add_child(lbl("📝 " + D.F(R.t, {"n": R.get("n", 0)}), 17, Color("#8a5cd6")))
			var pb := bar(card, "⏳", 100.0 * q.wait / q.waitMax, BLUE)
			ctx_bars["q%d" % int(q.id)] = pb
			var r := HBoxContainer.new()
			r.add_theme_constant_override("separation", 8)
			card.add_child(r)
			var can := sim.free_room_for(q.sp) >= 0
			var qid := int(q.id)
			var b1 := btn("✔ " + D.T("Aceitar"), func(): sim.accept(qid), GREEN, true)
			b1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			r.add_child(b1)
			var b2 := btn("✖ " + D.T("Recusar"), func(): sim.decline(qid), RED)
			b2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			r.add_child(b2)
			if not can:
				var place := D.place_of(q.sp)
				card.add_child(lbl(D.T("O celeiro não tem celas livres." if place == "barn" else ("O aviário não tem viveiros livres." if place == "avi" else "Não há quartos livres. Constrói mais um.")), 16, RED, true))
		return
	if ctx == "park":
		var waiting := []
		for id in sim.pets:
			var e = sim.pets[id]
			if e.trip and e.phase == "wait" and e.escort == null and e.dest != "vet":
				var g = sim.guest_of(e)
				if g:
					waiting.append(g.pet)
		if waiting.is_empty():
			ctx_panel.visible = false
			return
		ctx_box.add_child(lbl("🐾 " + D.F("À espera para voltar: {l}. Aproxima-te para os levares pela trela.", {"l": ", ".join(waiting)}), 19))
		return
	if ctx.begins_with("room"):
		var i := int(ctx.substr(4))
		ctx_room = i
		var g = S.rooms[i]
		var rname := D.F(sim.room_name(i)[0], sim.room_name(i)[1])
		if not sim.room_open(i):
			if i == int(S.up.rooms) and i < D.max_rooms(S.up):
				var cost := D.up_cost("rooms", int(S.up.rooms))
				ctx_box.add_child(lbl("🏗️ " + rname + " · " + D.T("por construir"), 22))
				ctx_box.add_child(btn(D.F("Construir por {c}", {"c": D.fmt(cost)}), func(): sim.buy("rooms"), GREEN, S.money >= cost))
			elif i < D.NRING:
				ctx_box.add_child(lbl("🔒 " + rname, 22))
				ctx_box.add_child(lbl(D.F("Constrói primeiro o quarto {r}.", {"r": D.room_no(int(S.up.rooms))}) if i < D.max_rooms(S.up) else D.T("Constrói uma ala para teres mais quartos."), 18, MUTED, true))
			else:
				ctx_panel.visible = false
			return
		if g == null:
			var h2 := HBoxContainer.new()
			ctx_box.add_child(h2)
			h2.add_child(lbl(rname + " · " + D.T("livre"), 22))
			if D.room_kind(i) == "":
				h2.add_child(btn("🎨", func(): open("decor", i), BLUE))
			ctx_box.add_child(lbl(D.T("Vai à receção e aceita um hóspede."), 18, MUTED, true))
			return
		var e = sim.pets.get(int(g.id))
		var trip: bool = e != null and e.trip
		var sp: Dictionary = D.SPECIES[g.sp]
		var head := HBoxContainer.new()
		ctx_box.add_child(head)
		var title := "%s %s · %s" % [sp.e, g.pet, D.F("de {o}", {"o": g.owner})]
		if trip:
			var st := {"go": "a caminho do veterinário" if e.dest == "vet" else "a caminho do parque", "course": "no parque", "wait": "à espera no veterinário" if e.dest == "vet" else "à espera no parque", "back": "a voltar ao quarto", "treat": "no veterinário", "run": "🏃"}
			title += " · " + D.T(st.get(e.phase, ""))
		head.add_child(lbl(title, 21))
		ctx_time = lbl("", 18, MUTED, false)
		ctx_time.size_flags_horizontal = Control.SIZE_SHRINK_END
		head.add_child(ctx_time)
		if D.room_kind(i) == "":
			var db := btn("🎨", func(): open("decor", i), BLUE, true, 18)
			db.custom_minimum_size = Vector2(48, 44)
			head.add_child(db)
		var info := []
		if g.get("vip", "") == "infl":
			info.append("📸 " + D.T("influenciador"))
		elif g.get("vip", "") == "fam":
			info.append("🌟 " + D.T("famoso"))
		if D.is_rare(g.sp, int(g.coat)):
			info.append("✨ " + D.T("pelagem rara"))
		if g.get("leak", false):
			info.append("💧 " + D.T("fuga de água"))
		if g.has("reg"):
			info.append("⭐ " + D.T("habitual"))
		if g.get("sick", false):
			info.append("🤒 " + D.T("doente"))
		if g.get("req") != null:
			var R2: Dictionary = D.REQS[g.req.t]
			var prog := ""
			if R2.has("n"):
				prog = " (%d/%d)" % [int(g.req.p if g.req.t != "parque" else g.get("parks", 0)), int(R2.n)]
			info.append("📝 " + D.F(R2.t, {"n": R2.get("n", 0)}) + prog)
		if not info.is_empty():
			ctx_box.add_child(lbl(" · ".join(info), 17, Color("#8a5cd6"), true))
		var grid := GridContainer.new()
		grid.columns = 2
		grid.add_theme_constant_override("h_separation", 14)
		grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		ctx_box.add_child(grid)
		for k in ["fome", "sede", "banho", "diver"]:
			var cell := HBoxContainer.new()
			cell.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			grid.add_child(cell)
			ctx_bars[k] = bar(cell, {"fome": "🍖", "sede": "💧", "banho": "🛁", "diver": "🎾"}[k], g[k])
		var acts := HFlowContainer.new()
		acts.add_theme_constant_override("h_separation", 6)
		acts.add_theme_constant_override("v_separation", 6)
		ctx_box.add_child(acts)
		var mine: bool = trip and e.leash != null and e.leash.kind == "player" and e.phase == "go"
		var A := [["fome", "🍖 " + D.T("Ração") + " €1", ORANGE], ["sede", "💧 " + D.T("Água"), BLUE], ["banho", "🛁 " + D.T("Banho"), Color("#4fb3a6")], ["diver", "🎾 " + D.T("Brincar"), Color("#e0508a")], ["mimos", "🤗 " + D.T("Mimos"), Color("#d9608f")]]
		if mine:
			A.append(["parque", "✋ " + D.T("Soltar"), RED])
		elif g.get("sick", false) and not trip:
			A.append(["vet", "🩺 " + D.T("Veterinário") + " " + (D.fmt(sim.vet_fee()) if sim.vet_fee() > 0 else ""), Color("#4fb3a6")])
		else:
			A.append(["parque", "🌳 " + D.T("Parque"), GREEN])
		if g.get("leak", false):
			A.append(["reparar", "🔧 " + D.T("Reparar") + " €20", BLUE])
		else:
			A.append(["limpar", "🧹 " + D.T("Limpar") + (" %d" % int(g.mess) if int(g.get("mess", 0)) > 0 else ""), Color("#8a6a3a")])
		for a in A:
			var act: String = a[0]
			var en := true
			if trip and act != "parque" and act != "reparar":
				en = false
			if act == "parque" and trip and not mine:
				en = false
			if act == "limpar" and int(g.get("mess", 0)) == 0:
				en = false
			var b := btn(a[1], func(): sim.care(i, act), a[2], en, 19)
			b.custom_minimum_size = Vector2(0, 50)
			acts.add_child(b)
		return
	ctx_panel.visible = false

func _update_ctx_live() -> void:
	if ctx_room >= 0:
		var g = sim.S.rooms[ctx_room]
		if g != null:
			for k in ["fome", "sede", "banho", "diver"]:
				if ctx_bars.has(k):
					ctx_bars[k].value = g[k]
					_bar_col(ctx_bars[k], g[k])
			if ctx_time:
				ctx_time.text = "⏱ " + D.mmss(g.left)
	for q in sim.queue:
		var k := "q%d" % int(q.id)
		if ctx_bars.has(k):
			ctx_bars[k].value = 100.0 * q.wait / q.waitMax
			_bar_col(ctx_bars[k], 0, RED if q.wait < 15 else BLUE)

# ===================== painéis =====================
func _build_modal() -> void:
	modal = Control.new()
	modal.set_anchors_preset(Control.PRESET_FULL_RECT)
	modal.visible = false
	root.add_child(modal)
	var dim := ColorRect.new()
	dim.color = Color(0.05, 0.08, 0.12, 0.45)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.gui_input.connect(func(ev):
		if ev is InputEventMouseButton and ev.pressed and current.get("name", "") not in ["menu", "char", "back"]:
			close()
	)
	modal.add_child(dim)
	modal_panel = PanelContainer.new()
	modal_panel.add_theme_stylebox_override("panel", sb(CREAM, 26, 0, true))
	modal.add_child(modal_panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 0)
	modal_panel.add_child(v)
	var head := PanelContainer.new()
	var hs := sb(ORANGE, 26, 16, false)
	hs.corner_radius_bottom_left = 0
	hs.corner_radius_bottom_right = 0
	head.add_theme_stylebox_override("panel", hs)
	v.add_child(head)
	var hh := HBoxContainer.new()
	head.add_child(hh)
	modal_title = lbl("", 26, Color.WHITE)
	hh.add_child(modal_title)
	var cb := round_btn("✖", func(): close(), 52)
	cb.add_theme_color_override("font_color", ORANGE)
	hh.add_child(cb)
	var pad := MarginContainer.new()
	for s in ["left", "right", "top", "bottom"]:
		pad.add_theme_constant_override("margin_" + s, 14)
	pad.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(pad)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 10)
	pad.add_child(inner)
	modal_tabs = HFlowContainer.new()
	modal_tabs.add_theme_constant_override("h_separation", 6)
	modal_tabs.add_theme_constant_override("v_separation", 6)
	inner.add_child(modal_tabs)
	modal_scroll = ScrollContainer.new()
	modal_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	modal_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	inner.add_child(modal_scroll)
	modal_body = VBoxContainer.new()
	modal_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	modal_body.add_theme_constant_override("separation", 10)
	modal_scroll.add_child(modal_body)

func _place_modal() -> void:
	var vs := root.size
	var w: float = min(720.0, vs.x - 24.0)
	var h: float = min(vs.y * 0.86, 1100.0)
	modal_panel.position = Vector2((vs.x - w) * 0.5, (vs.y - h) * 0.5)
	modal_panel.size = Vector2(w, h)
	modal_panel.custom_minimum_size = Vector2(w, h)

func is_open() -> bool:
	return modal.visible

func open(name: String, arg = null) -> void:
	var same: bool = current.get("name", "") == name and current.get("arg") == arg
	current = {"name": name, "arg": arg, "tab": current.get("tab", "") if same else ""}
	modal.visible = true
	G.set_paused_ui(true)
	if name == "mine":
		mine_sel = {}
	render()
	if not same:
		modal_scroll.scroll_vertical = 0

func close() -> void:
	if current.get("name", "") == "back" and back_data != null:
		sim.collect_back()
		back_data = null
	current = {}
	modal.visible = false
	G.set_paused_ui(false)
	if not G.started:
		G.start_game(false)

func render() -> void:
	if current.is_empty():
		return
	var sc := modal_scroll.scroll_vertical
	clear(modal_body)
	clear(modal_tabs)
	modal_tabs.visible = false
	_place_modal()
	var fn: String = "r_" + current.name
	if has_method(fn):
		call(fn, current.get("arg"))
	await get_tree().process_frame
	modal_scroll.scroll_vertical = sc

func tabs(list: Array, default: String) -> String:
	if current.tab == "":
		current.tab = default
	modal_tabs.visible = true
	for t in list:
		var on: bool = current.tab == t[0]
		var id: String = t[0]
		modal_tabs.add_child(btn(t[1], func():
			current.tab = id
			modal_scroll.scroll_vertical = 0
			render()
		, DARK if on else GREY, true, 19))
	return current.tab

func card(col := Color.WHITE) -> VBoxContainer:
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", sb(col, 16, 14, true))
	modal_body.add_child(pc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	pc.add_child(v)
	return v

func row(parent: Control) -> HFlowContainer:
	var r := HFlowContainer.new()
	r.add_theme_constant_override("h_separation", 8)
	r.add_theme_constant_override("v_separation", 8)
	parent.add_child(r)
	return r

# ---------- menu ----------
func r_menu(_a) -> void:
	modal_title.text = "🐾 Hotel Patinhas HD"
	modal_body.add_child(lbl(D.T("Jogo em pausa") if G.started else D.T("O hotel de animais mais fofo do mundo"), 20, MUTED, true))
	var items := [
		["▶️ " + (D.T("Continuar a jogar") if G.started else D.T("Continuar")), func(): close(), GREEN],
	]
	if not G.started:
		items.append(["✨ " + D.T("Novo jogo"), func(): open("confirm"), ORANGE])
	items.append_array([
		["🎯 " + D.T("Missões e conquistas"), func(): open("mis"), BLUE],
		["⭐ " + D.T("Avaliações"), func(): open("reviews"), BLUE],
		["📖 " + D.T("Álbum"), func(): open("album"), BLUE],
		["🏙️ " + D.T("Franquias"), func(): open("fr"), BLUE],
		["🐾 " + D.T("O meu animal"), func(): open("mine"), BLUE],
		["👕 " + D.T("Personagem"), func(): open("char"), BLUE],
		["⚙️ " + D.T("Opções"), func(): open("opts"), DARK],
		["❓ " + D.T("Como jogar"), func(): open("help"), DARK],
		["❤️ " + D.T("Apoiar o jogo"), func(): open("donate"), Color("#d9467a")],
	])
	if G.started:
		items.append(["🏠 " + D.T("Menu principal"), func(): G.to_title(), GREY])
	for it in items:
		var b := btn(it[0], it[1], it[2])
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		modal_body.add_child(b)
	modal_body.add_child(lbl(D.F("Versão {v}", {"v": D.VERSION}), 16, MUTED, true))

func r_confirm(_a) -> void:
	modal_title.text = "✨ " + D.T("Novo jogo")
	modal_body.add_child(lbl(D.T("Apagar o progresso e começar de novo?"), 22))
	modal_body.add_child(btn(D.T("Sim, começar de novo"), func(): G.new_game(), RED))
	modal_body.add_child(btn(D.T("Cancelar"), func(): open("menu"), GREY))

# ---------- melhorias ----------
func up_card(parent: Control, u: Dictionary) -> void:
	var S: Dictionary = sim.S
	var L := int(S.up.get(u.id, 0))
	var c := card()
	var mx := D.up_max(u.id, S.up)
	var lvl := ""
	if u.id == "rooms":
		lvl = " · " + D.F("{n} quartos", {"n": L})
	elif int(u.max) > 1:
		lvl = " · " + D.F("nível {l}", {"l": "%d/%d" % [L, int(u.max)]})
	c.add_child(lbl("%s %s%s" % [u.ic, D.T(u.n), lvl], 22))
	c.add_child(lbl(D.T(u.d), 18, MUTED, true))
	var cb := sim.can_buy(u)
	var why: String = cb[1]
	var r := row(c)
	if why == "max":
		if u.id == "rooms" and L < 16:
			r.add_child(lbl(D.T("Constrói uma ala para teres mais quartos."), 18, BLUE))
		else:
			r.add_child(btn(D.T("Feito ✓") if int(u.max) == 1 else (D.T("Equipa completa") if u.has("role") else D.T("Nível máximo")), func(): pass, GREEN, false))
	elif why == "stars":
		r.add_child(btn(D.F("Precisas de {n} estrelas.", {"n": u.needStars}), func(): pass, GREY, false))
	elif why == "rooms":
		r.add_child(btn(D.F("Precisas de {n} quartos.", {"n": u.needRooms}), func(): pass, GREY, false))
	elif why == "up":
		r.add_child(btn(D.F("Precisas de: {n}", {"n": D.T(D.UP_BY_ID[u.needUp].n)}), func(): pass, GREY, false))
	else:
		var cost := D.up_cost(u.id, L)
		var txt := D.F("Contratar {c}", {"c": D.fmt(cost)}) if u.has("role") else ((D.T("Comprar") if L == 0 else D.T("Melhorar")) + " " + D.fmt(cost))
		var id: String = u.id
		r.add_child(btn(txt, func(): sim.buy(id); render(), GREEN, cb[0]))

func r_ups(_a) -> void:
	modal_title.text = "🛠️ " + D.T("Melhorias")
	var tab := tabs([["hotel", "🏨 " + D.T("Hotel")], ["amp", "🏛️ " + D.T("Ampliações")], ["ajud", "👥 " + D.T("Ajudantes")], ["prod", "🛒 " + D.T("Produtos")]], "hotel")
	var S: Dictionary = sim.S
	if tab == "prod":
		modal_body.add_child(lbl(D.T("Usados automaticamente por ti e pelos ajudantes enquanto houver stock."), 18, MUTED, true))
		for p in D.PRODUCTS:
			var c := card()
			c.add_child(lbl("%s %s · %s" % [p.ic, D.T(p.n), D.F("stock {k}", {"k": int(S.stock.get(p.id, 0))})], 22))
			c.add_child(lbl(D.T(p.d), 18, MUTED, true))
			var id: String = p.id
			row(c).add_child(btn("+%d  %s" % [int(p.pack), D.fmt(p.c)], func(): sim.buy_product(id); render(), GREEN, S.money >= int(p.c)))
		return
	for u in D.UPS:
		if u.grp == tab:
			up_card(modal_body, u)
	if tab == "ajud" and not S.staff.is_empty():
		modal_body.add_child(lbl("👥 " + D.T("A tua equipa"), 24))
		for st in S.staff:
			var R: Dictionary = D.ROLES[st.role]
			var tr: Dictionary = D.TRAITS[st.trait]
			var c2 := card()
			c2.add_child(lbl("%s %s · %s · %s %s" % [R.ic, st.name, D.F("Nível {l}", {"l": int(st.lvl)}), tr.ic, D.T(tr.n)], 21))
			c2.add_child(lbl(D.T(tr.d) + " · " + D.F("Salário: {m} por turno", {"m": D.fmt(sim.staff_salary(st))}), 17, MUTED, true))
			var nxt: int = D.LVL_XP[min(4, int(st.lvl))]
			bar(c2, "⭐", 100.0 if int(st.lvl) >= 5 else 100.0 * int(st.xp) / nxt, Color("#f2c230"))
			bar(c2, "⚡", float(st.en))

# ---------- missões, conquistas, prémio ----------
func r_mis(_a) -> void:
	modal_title.text = "🎯 " + D.T("Missões")
	var S: Dictionary = sim.S
	var tab := tabs([["mis", "🎯 " + D.T("Missões de hoje")], ["ach", "🏆 " + D.T("Conquistas")], ["month", "🥇 " + D.T("Prémio do mês")]], "mis")
	if tab == "mis":
		sim.ensure_missions()
		modal_body.add_child(lbl(D.F("Cada missão vale {m}; as três dão um bónus de {b}.", {"m": D.fmt(sim.mission_reward()), "b": D.fmt(sim.mission_reward() * 2)}), 18, MUTED, true))
		for m in S.mis.list:
			var dd = null
			for x in D.MISSION_POOL:
				if x.id == m.id:
					dd = x
			var c := card(Color("#e6f6ec") if m.done else Color.WHITE)
			c.add_child(lbl(("✅ " if m.done else "🎯 ") + D.F(dd.t, {"n": m.goal}), 21))
			bar(c, "%d/%d" % [int(m.p), int(m.goal)], 100.0 * int(m.p) / int(m.goal), GREEN if m.done else BLUE)
	elif tab == "ach":
		for a in D.ACH:
			var done: bool = S.ach.get(a.id, false)
			var pr := sim.ach_prog(a)
			var c2 := card(Color("#fff4d6") if done else Color.WHITE)
			c2.add_child(lbl("%s %s · %s%s" % [a.ic, D.T(a.n), D.fmt(a.r), "  ✅" if done else ""], 21))
			c2.add_child(lbl(D.T(a.d), 17, MUTED, true))
			if not done:
				bar(c2, "%d/%d" % [min(pr[0], pr[1]), pr[1]], 100.0 * min(pr[0], pr[1]) / pr[1], BLUE)
	else:
		var M = S.month if S.month != null else {"sum": 0, "n": 0}
		var avg: float = float(M.sum) / int(M.n) if int(M.n) > 0 else 0.0
		var c3 := card()
		c3.add_child(lbl("🏆 " + D.T("Melhor Hotel do Algarve"), 24))
		c3.add_child(lbl(D.F("Este mês: média {a}★ em {n} avaliações. Precisas de 4,5★ e 8 avaliações.", {"a": "%.1f" % avg, "n": int(M.n)}), 19, MUTED, true))
		bar(c3, "★ %.1f" % avg, avg * 20.0, Color("#f2c230"))
		c3.add_child(lbl(D.F("Troféus: {n}", {"n": S.trophies.size()}) + "  " + "🏆".repeat(min(12, S.trophies.size())), 21))

# ---------- álbum ----------
func r_album(_a) -> void:
	modal_title.text = "📖 " + D.T("Álbum")
	var S: Dictionary = sim.S
	var a := 0
	var cc := 0
	var dd := 0
	for k in D.SPECIES_ORDER:
		var seen = S.seen.get(k, {})
		if not seen.is_empty():
			a += 1
		dd += D.COATS[k].size()
		cc += seen.size()
	modal_body.add_child(lbl(D.F("Espécies: {a}/{b} · Pelagens: {c}/{d}. Espécie nova €25, pelagem rara ✨ €60, coleção completa €120.", {"a": a, "b": D.SPECIES_ORDER.size(), "c": cc, "d": dd}), 18, MUTED, true))
	for k in D.SPECIES_ORDER:
		var seen = S.seen.get(k, {})
		var c := card()
		var n: int = seen.size()
		var tot: int = D.COATS[k].size()
		c.add_child(lbl("%s %s · %d/%d%s" % [D.SPECIES[k].e if n > 0 else "❔", D.T(D.SPECIES[k].n) if n > 0 else "???", n, tot, ("  " + D.T("Completo") + " ✅") if n == tot else ""], 21))
		var r := row(c)
		for ci in tot:
			var got: bool = seen.has(str(ci))
			var sw := PanelContainer.new()
			var s := sb(Color(D.COATS[k][ci][0]) if got else Color("#e9e4dc"), 22, 0, false)
			if got:
				s.border_color = Color(D.COATS[k][ci][1])
				s.set_border_width_all(4)
			sw.add_theme_stylebox_override("panel", s)
			sw.custom_minimum_size = Vector2(46, 46)
			var l := lbl("✨" if got and D.is_rare(k, ci) else ("" if got else "?"), 20)
			l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			sw.add_child(l)
			r.add_child(sw)

# ---------- franquias ----------
func r_fr(_a) -> void:
	modal_title.text = "🏙️ " + D.T("Franquias")
	var S: Dictionary = sim.S
	modal_body.add_child(lbl(D.F("As franquias rendem sozinhas, mesmo fora do jogo (até 8 horas). Agora: {m} por minuto.", {"m": D.fmt(sim.fr_income())}), 18, MUTED, true))
	for f in D.FRANCH:
		var L := int(S.fr.get(f.id, 0))
		var c := card()
		c.add_child(lbl("%s %s%s" % [f.ic, D.T(f.n), (" · " + D.F("nível {l}", {"l": "%d/5" % L})) if L > 0 else ""], 22))
		c.add_child(lbl(D.T(f.d), 18, MUTED, true))
		c.add_child(lbl(D.F("Rende {m}/min por nível · traz {e} {s}", {"m": D.fmt(f.inc), "e": D.SPECIES[f.sp].e, "s": D.T(D.SPECIES[f.sp].n)}), 18, DARK, true))
		var r := row(c)
		var id: String = f.id
		if L >= 5:
			r.add_child(btn(D.T("Nível máximo"), func(): pass, GREEN, false))
		elif sim.stars() < int(f.stars):
			r.add_child(btn(D.F("Precisas de {n} estrelas.", {"n": f.stars}), func(): pass, GREY, false))
		else:
			var cost: int = int(f.cost) if L == 0 else int(floor(float(f.cost) * 0.5 * L))
			r.add_child(btn((D.T("Comprar") if L == 0 else D.T("Melhorar")) + " " + D.fmt(cost), func(): sim.fr_buy(id); render(), GREEN, S.money >= cost))

# ---------- o meu animal ----------
func r_mine(_a) -> void:
	modal_title.text = "🐾 " + D.T("O meu animal")
	var S: Dictionary = sim.S
	var m = S.mine
	if mine_sel.is_empty():
		mine_sel = {"sp": m.sp, "coat": int(m.coat), "name": m.name, "collar": m.collar} if m != null else {"sp": "cao", "coat": 0, "name": "Patudo", "collar": D.COLLARS[0]}
	modal_body.add_child(lbl(D.T("Muda o teu animal quando quiseres.") if m != null else D.F("Adota um animal teu: segue-te pelo hotel. Custa {m}.", {"m": D.fmt(150)}), 19, DARK, true))
	modal_body.add_child(lbl(D.T("Espécie"), 20))
	var r1 := row(modal_body)
	for k in D.MINE_SP:
		var kk: String = k
		r1.add_child(btn(D.SPECIES[k].e + " " + D.T(D.SPECIES[k].n), func(): mine_sel.sp = kk; mine_sel.coat = 0; render(), DARK if mine_sel.sp == k else GREY, true, 19))
	modal_body.add_child(lbl(D.T("Pelagem"), 20))
	var r2 := row(modal_body)
	var coats: Array = D.COATS[mine_sel.sp]
	for ci in coats.size() - 1:
		var c := ci
		var b := Button.new()
		b.custom_minimum_size = Vector2(54, 54)
		var s := sb(Color(coats[ci][0]), 27, 0, false)
		s.border_color = Color(coats[ci][1]) if mine_sel.coat != ci else DARK
		s.set_border_width_all(4 if mine_sel.coat != ci else 6)
		b.add_theme_stylebox_override("normal", s)
		b.add_theme_stylebox_override("hover", s)
		b.add_theme_stylebox_override("pressed", s)
		b.text = "✔" if mine_sel.coat == ci else ""
		b.pressed.connect(func(): mine_sel.coat = c; render())
		r2.add_child(b)
	modal_body.add_child(lbl(D.T("Coleira"), 20))
	var r3 := row(modal_body)
	for col in D.COLLARS:
		var cc: String = col
		var b2 := Button.new()
		b2.custom_minimum_size = Vector2(50, 50)
		var s2 := sb(Color(col), 25, 0, false)
		if mine_sel.collar == col:
			s2.border_color = DARK
			s2.set_border_width_all(5)
		b2.add_theme_stylebox_override("normal", s2)
		b2.add_theme_stylebox_override("hover", s2)
		b2.add_theme_stylebox_override("pressed", s2)
		b2.pressed.connect(func(): mine_sel.collar = cc; render())
		r3.add_child(b2)
	modal_body.add_child(lbl(D.T("Nome"), 20))
	var le := LineEdit.new()
	le.text = mine_sel.name
	le.max_length = 14
	le.custom_minimum_size = Vector2(0, 54)
	le.text_changed.connect(func(tx): mine_sel.name = tx)
	modal_body.add_child(le)
	modal_body.add_child(btn(("💾 " + D.T("Guardar")) if m != null else ("🐾 " + D.F("Adotar por {m}", {"m": D.fmt(150)})), func(): sim.set_mine(mine_sel); render(), GREEN, m != null or S.money >= 150))

# ---------- avaliações ----------
func r_reviews(_a) -> void:
	modal_title.text = "⭐ " + D.T("Avaliações")
	var S: Dictionary = sim.S
	if S.reviews.is_empty():
		modal_body.add_child(lbl(D.T("Ainda não há avaliações."), 20, MUTED))
		return
	for r in S.reviews:
		var c := card()
		c.add_child(lbl("%s%s  %s · %s %s · %s" % ["★".repeat(int(r.s)), "☆".repeat(5 - int(r.s)), r.o, r.e, r.p, r.r], 20))
		var parts := []
		for tx in r.t:
			parts.append(D.T(tx))
		c.add_child(lbl("“" + " ".join(parts) + "”", 18, MUTED, true))

# ---------- ajuda ----------
func r_help(_a) -> void:
	modal_title.text = "❓ " + D.T("Como jogar")
	var rt := RichTextLabel.new()
	rt.bbcode_enabled = true
	rt.fit_content = true
	rt.text = D.HELP.get(D.lang, D.HELP.pt)
	rt.add_theme_color_override("default_color", DARK)
	rt.add_theme_font_size_override("normal_font_size", 20)
	rt.add_theme_font_size_override("bold_font_size", 20)
	rt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	modal_body.add_child(rt)
	if sim.season != "" and D.SEASON_INFO.has(sim.season):
		var c := card(Color("#fff4d6"))
		c.add_child(lbl(D.SEASON_INFO[sim.season][0] + " " + D.T(D.SEASON_INFO[sim.season][1]), 19))

# ---------- opções ----------
func opt_row(title: String, opts: Array, cur: String, cb: Callable) -> void:
	modal_body.add_child(lbl(title, 20))
	var r := row(modal_body)
	for o in opts:
		var id: String = o[0]
		r.add_child(btn(o[1], func(): cb.call(id); render(), DARK if cur == id else GREY, true, 19))

func r_opts(_a) -> void:
	modal_title.text = "⚙️ " + D.T("Opções")
	var st: Dictionary = G.settings
	opt_row("🌍 " + D.T("Idioma"), [["pt", "🇵🇹 Português"], ["en", "🇬🇧 English"], ["fr", "🇫🇷 Français"]], D.lang, func(id): G.set_setting("lang", id))
	opt_row("✨ " + D.T("Gráficos"), [["ultra", "💎 " + D.T("Ultra")], ["alta", "✨ " + D.T("Alta")], ["media", "🎨 " + D.T("Média")], ["leve", "🔋 " + D.T("Leve")]], st.quality, func(id): G.set_setting("quality", id))
	var qd := {"ultra": "Tudo no máximo, para telemóveis topo de gama", "alta": "Sombras suaves, relva densa, reflexos e brilho", "media": "Equilíbrio entre beleza e fluidez", "leve": "Sem sombras nem relva, para telemóveis mais fracos"}
	modal_body.add_child(lbl(D.T(qd[st.quality]), 17, MUTED, true))
	opt_row("🎵 " + D.T("Faixa"), [["parque", "🎵 " + D.T("Passeio no parque")], ["algarve", "🎵 " + D.T("Tarde no Algarve")], ["noite", "🎵 " + D.T("Noite calma")], ["none", "🔇 " + D.T("Sem música")]], st.track, func(id): G.set_setting("track", id))
	modal_body.add_child(lbl("🎵 " + D.T("Música"), 20))
	var s1 := HSlider.new()
	s1.min_value = 0
	s1.max_value = 100
	s1.value = st.mv * 100
	s1.custom_minimum_size = Vector2(0, 40)
	s1.value_changed.connect(func(v): G.set_setting("mv", v / 100.0, false))
	modal_body.add_child(s1)
	modal_body.add_child(lbl("🔊 " + D.T("Efeitos e animais"), 20))
	var s2 := HSlider.new()
	s2.min_value = 0
	s2.max_value = 100
	s2.value = st.fv * 100
	s2.custom_minimum_size = Vector2(0, 40)
	s2.value_changed.connect(func(v): G.set_setting("fv", v / 100.0, false))
	modal_body.add_child(s2)
	opt_row("🕒 " + D.T("Hora do dia"), [["auto", "🕒 " + D.T("Automática")], ["dia", "☀️ " + D.T("Sempre de dia")], ["noite", "🌙 " + D.T("Sempre de noite")]], st.time, func(id): G.set_setting("time", id))
	opt_row("🌦️ " + D.T("Meteorologia"), [["var", "🌦️ " + D.T("Variável")], ["sol", "☀️ " + D.T("Sempre sol")]], st.weather, func(id): G.set_setting("weather", id))
	opt_row("📳 " + D.T("Vibração"), [["1", "📳 " + D.T("Ligada")], ["0", "🔕 " + D.T("Desligada")]], "1" if st.vib else "0", func(id): G.set_setting("vib", id == "1"))
	opt_row("🎥 " + D.T("Câmara"), [["top", "🛰️ " + D.T("Vista de cima")], ["third", "🧍 " + D.T("Terceira pessoa")], ["first", "👀 " + D.T("Primeira pessoa")]], G.cam_mode, func(id): G.set_camera(id))

# ---------- personagem ----------
func r_char(_a) -> void:
	modal_title.text = "👕 " + D.T("Personagem")
	var ch: Dictionary = sim.S.char
	var look: Dictionary = ch.look
	if look.is_empty():
		look = HumanModel.random_look(RandomNumberGenerator.new())
		look.hat = ""
		ch.look = look
	modal_body.add_child(lbl(D.T("O teu nome"), 20))
	var le := LineEdit.new()
	le.text = ch.get("name", "")
	le.max_length = 16
	le.custom_minimum_size = Vector2(0, 54)
	le.text_changed.connect(func(tx): ch.name = tx)
	modal_body.add_child(le)
	var swatch := func(title: String, key: String, cols: Array):
		modal_body.add_child(lbl(title, 20))
		var r := row(modal_body)
		for c in cols:
			var cc: String = c
			var b := Button.new()
			b.custom_minimum_size = Vector2(50, 50)
			var s := sb(Color(c), 25, 0, false)
			if look.get(key, "") == c:
				s.border_color = DARK
				s.set_border_width_all(5)
			b.add_theme_stylebox_override("normal", s)
			b.add_theme_stylebox_override("hover", s)
			b.add_theme_stylebox_override("pressed", s)
			b.pressed.connect(func():
				look[key] = cc
				G.rebuild_player()
				render()
			)
			r.add_child(b)
	swatch.call(D.T("Pele"), "skin", HumanModel.SKINS)
	swatch.call(D.T("Cabelo"), "hair", HumanModel.HAIRS)
	swatch.call(D.T("Camisola"), "shirt", HumanModel.SHIRTS)
	swatch.call(D.T("Calças"), "pants", HumanModel.PANTS)
	var r2 := row(modal_body)
	r2.add_child(btn("👩", func(): look.female = true; G.rebuild_player(); render(), DARK if look.get("female", false) else GREY))
	r2.add_child(btn("👨", func(): look.female = false; G.rebuild_player(); render(), DARK if not look.get("female", false) else GREY))
	r2.add_child(btn("💇 %d" % (int(look.get("style", 0)) % 3 + 1), func(): look.style = int(look.get("style", 0)) + 1; G.rebuild_player(); render(), BLUE))
	r2.add_child(btn("👓", func(): look.glasses = not look.get("glasses", false); G.rebuild_player(); render(), DARK if look.get("glasses", false) else GREY))
	modal_body.add_child(btn("✔ " + D.T("Começar a trabalhar"), func(): G.rebuild_player(); close(), GREEN))

# ---------- decorar quarto ----------
func r_decor(i) -> void:
	modal_title.text = "🎨 " + D.T("Decorar o quarto") + " " + D.room_no(i)
	var dec: Dictionary = sim.S.decor.get(str(i), {}).duplicate()
	var opts := [["floor", "Chão", World.PEN_FLOORS], ["rug", "Tapete", World.RUGS], ["bed", "Cama", World.BEDS]]
	for o in opts:
		modal_body.add_child(lbl(D.T(o[1]), 20))
		var r := row(modal_body)
		var key: String = o[0]
		for c in o[2]:
			var cc: String = c
			var b := Button.new()
			b.custom_minimum_size = Vector2(52, 52)
			var cur: String = dec.get(key, "")
			var s := sb(Color(c), 26, 0, false)
			if cur == c:
				s.border_color = DARK
				s.set_border_width_all(5)
			b.add_theme_stylebox_override("normal", s)
			b.add_theme_stylebox_override("hover", s)
			b.add_theme_stylebox_override("pressed", s)
			b.pressed.connect(func():
				dec[key] = cc
				sim.set_decor(i, dec)
				render()
			)
			r.add_child(b)

# ---------- mapa ----------
func r_map(_a) -> void:
	modal_title.text = "🗺️ " + D.T("Mapa")
	modal_body.add_child(lbl(D.T("Toca num sítio para ires lá"), 18, MUTED, true))
	var places := [["🛎️ " + D.T("Receção"), Vector3(0, 0, 11.6)], ["⛲ " + D.T("Átrio"), Vector3(0, 0, -0.5)], ["🌳 " + D.T("Parque"), Vector3(0, 0, -19)], ["☕ " + D.T("Sala do pessoal"), World.Pc(World.C, 270, 9)], ["🛣️ " + D.T("Rua"), Vector3(0, 0, 22)], ["🩺 " + D.T("Veterinário do bairro"), World.TOWN_VET.walk]]
	var S: Dictionary = sim.S
	if int(S.up.pav_e) > 0:
		places.append(["🏛️ " + D.T("Pavilhão Nascente"), Vector3(27, 0, -3)])
	if int(S.up.pav_w) > 0:
		places.append(["🏰 " + D.T("Pavilhão Poente"), Vector3(-27, 0, -3)])
	if int(S.up.clinica) > 0:
		places.append(["🩺 " + D.T("Gabinete veterinário"), World.CLINIC.wait])
	if int(S.up.estabulo) > 0:
		places.append(["🐴 " + D.T("Celeiro"), Vector3(-24, 0, -30)])
	if int(S.up.aviario) > 0:
		places.append(["🦜 " + D.T("Aviário"), Vector3(24.5, 0, -27)])
	var r := row(modal_body)
	for p in places:
		var pos: Vector3 = p[1]
		r.add_child(btn(p[0], func(): G.travel(pos); close(), BLUE, true, 19))
	modal_body.add_child(lbl("🚪 " + D.T("Quartos"), 20))
	var r2 := row(modal_body)
	for i in D.NROOMS:
		if not sim.room_open(i):
			continue
		var g = S.rooms[i]
		var ii := i
		var txt: String = D.room_no(i) + (" " + D.SPECIES[g.sp].e if g != null else "")
		r2.add_child(btn(txt, func(): G.travel(sim.world.room_point(ii, "in")); close(), ORANGE if g != null else GREY, true, 18))

# ---------- donativos ----------
func r_donate(_a) -> void:
	modal_title.text = "❤️ " + D.T("Apoiar o jogo")
	modal_body.add_child(lbl(D.T("❤️ Gostas do Hotel Patinhas?"), 24))
	modal_body.add_child(lbl(D.T("O jogo é gratuito e feito por Rui Amaro. Se te diverte e queres ajudar a mantê-lo e a melhorá-lo, podes deixar um donativo voluntário."), 19, MUTED, true))
	modal_body.add_child(lbl(D.T("Escolhe um valor"), 20))
	var r := row(modal_body)
	for v in [2.0, 5.0, 10.0, 20.0, 50.0]:
		var vv: float = v
		r.add_child(btn("%d €" % int(v), func(): don_sel = vv; render(), DARK if don_sel == v else GREY))
	modal_body.add_child(lbl(D.T("Outro valor (€)"), 20))
	var le := LineEdit.new()
	le.placeholder_text = "0,00"
	le.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER_DECIMAL
	le.custom_minimum_size = Vector2(0, 54)
	modal_body.add_child(le)
	var go := btn("💙 " + D.F("Doar {v} € com PayPal", {"v": _don_fmt(don_sel)}), func():
		var v2 := _don_amount(le.text)
		if v2 <= 0:
			return
		var amt := str(int(v2)) if v2 == floor(v2) else "%.2f" % v2
		OS.shell_open(D.PAYPAL + "/" + amt + "EUR")
		toast(D.T("A abrir o PayPal… Obrigado! 💙"))
	, Color("#0070ba"))
	modal_body.add_child(go)
	le.text_changed.connect(func(tx):
		var v3 := _don_amount(tx)
		go.text = "💙 " + (D.F("Doar {v} € com PayPal", {"v": _don_fmt(v3)}) if v3 > 0 else D.T("Escreve um valor válido"))
	)
	modal_body.add_child(lbl(D.T("Abre o PayPal no navegador. O pagamento é feito diretamente no PayPal; o jogo nunca vê nem guarda dados de pagamento."), 17, MUTED, true))

func _don_amount(tx: String) -> float:
	var s := tx.strip_edges().replace(",", ".")
	if s == "":
		return don_sel
	if not s.is_valid_float():
		return -1.0
	var v := s.to_float()
	if v < 1.0 or v > 1000.0:
		return -1.0
	return snapped(v, 0.01)

func _don_fmt(v: float) -> String:
	if v == floor(v):
		return str(int(v))
	var s := "%.2f" % v
	return s if D.lang == "en" else s.replace(".", ",")

# ---------- regresso ----------
func show_back(d: Dictionary) -> void:
	back_data = d
	open("back")

func r_back(_a) -> void:
	modal_title.text = "👋 " + D.T("Bem-vindo de volta!")
	var d = back_data
	if d == null:
		return
	if int(d.daily) > 0:
		var c := card()
		c.add_child(lbl("🎁 " + D.F("Recompensa diária · dia {d} de 7", {"d": d.streak}), 21))
		c.add_child(lbl(D.fmt(d.daily), 28, GREEN))
	if int(d.team) > 0:
		var c2 := card()
		c2.add_child(lbl("👥 " + D.T("A equipa trabalhou enquanto estiveste fora") + " (%d min)" % int(d.mins), 21))
		c2.add_child(lbl(D.fmt(d.team), 28, GREEN))
	if int(d.fr) > 0:
		var c3 := card()
		c3.add_child(lbl("🏙️ " + D.T("Lucros das franquias"), 21))
		c3.add_child(lbl(D.fmt(d.fr), 28, GREEN))
	modal_body.add_child(btn("💰 " + D.F("Recolher {m}", {"m": D.fmt(d.total)}), func(): close(), GREEN))

# ===================== modo foto =====================
func set_photo(on: bool) -> void:
	photo_mode = on
	for n in [top_bar, right_btns, bottom_btns, joystick, toast_box, ctx_panel]:
		n.visible = not on
	for c in root.get_children():
		if c is HBoxContainer and c != top_bar:
			c.visible = not on
	if on:
		toast(D.T("Toca no ecrã para voltar"))
		toast_box.visible = true

func _input(ev: InputEvent) -> void:
	if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
		pressing = ev.pressed
		if not ev.pressed and pending_render:
			pending_render = false
			render.call_deferred()
	if photo_mode and ev is InputEventMouseButton and ev.pressed and not ev.is_echo():
		if ev.position.y > 120:
			set_photo(false)
			get_viewport().set_input_as_handled()

func tick(dt: float) -> void:
	update_hud()
	refresh_t -= dt
	if modal.visible and refresh_t <= 0:
		refresh_t = 1.0
		if current.get("name", "") in ["ups", "mis", "fr", "album", "reviews"]:
			if pressing:
				pending_render = true
			else:
				render()
