# Hotel Patinhas HD · sons gerados no próprio jogo e música calma tocada em tempo real
class_name Audio
extends Node

const RATE := 22050.0
var sfx := {}
var players: Array = []
var music: AudioStreamPlayer
var gen: AudioStreamGeneratorPlayback
var mv := 0.6
var fv := 0.8
var track := "parque"
var focus := Vector3.ZERO
# sequenciador
var seq_t := 0.0
var voices: Array = []
var step := 0
var step_len := 0.3
var next_step := 0.0
var rng := RandomNumberGenerator.new()

const TRACKS := {
	"parque": {"bpm": 104, "root": 60, "prog": [[0, 4, 7], [7, 11, 14], [9, 12, 16], [5, 9, 12]], "scale": [0, 2, 4, 7, 9, 12, 14, 16]},
	"algarve": {"bpm": 92, "root": 57, "prog": [[0, 3, 7], [5, 8, 12], [7, 10, 14], [3, 7, 10]], "scale": [0, 3, 5, 7, 10, 12, 15]},
	"noite": {"bpm": 72, "root": 55, "prog": [[0, 4, 7, 11], [5, 9, 12, 16], [2, 5, 9, 12], [7, 11, 14, 17]], "scale": [0, 2, 4, 7, 9, 11, 12]},
}

func _ready() -> void:
	rng.randomize()
	_make_sfx()
	for k in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	music = AudioStreamPlayer.new()
	var g := AudioStreamGenerator.new()
	g.mix_rate = RATE
	g.buffer_length = 0.5
	music.stream = g
	add_child(music)
	music.play()
	gen = music.get_stream_playback()

func set_volumes(m: float, f: float) -> void:
	mv = m
	fv = f

# ---------- efeitos ----------
func _wav(data: PackedFloat32Array) -> AudioStreamWAV:
	var b := PackedByteArray()
	b.resize(data.size() * 2)
	for i in data.size():
		b.encode_s16(i * 2, int(clamp(data[i], -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = int(RATE)
	w.data = b
	return w

func _tone(notes: Array, wave := "sine", vol := 0.5) -> PackedFloat32Array:
	# notes: [[freq, dur, freq_end]]
	var out := PackedFloat32Array()
	for n in notes:
		var f0: float = n[0]
		var dur: float = n[1]
		var f1: float = n[2] if n.size() > 2 else f0
		var N := int(dur * RATE)
		var ph := 0.0
		for i in N:
			var tt := float(i) / N
			var f: float = lerp(f0, f1, tt)
			ph += f / RATE
			var s := 0.0
			match wave:
				"sine":
					s = sin(ph * TAU)
				"tri":
					s = 1.0 - 4.0 * abs(fmod(ph, 1.0) - 0.5)
				"square":
					s = 0.6 if fmod(ph, 1.0) < 0.5 else -0.6
				"noise":
					s = rng.randf_range(-1, 1)
			var env: float = min(1.0, tt * 30.0) * pow(1.0 - tt, 1.6)
			out.append(s * env * vol)
	return out

func _make_sfx() -> void:
	sfx["click"] = _wav(_tone([[880, 0.05, 660]], "tri", 0.35))
	sfx["coin"] = _wav(_tone([[988, 0.07], [1319, 0.22]], "square", 0.25))
	sfx["ok"] = _wav(_tone([[660, 0.08], [880, 0.14]], "tri", 0.4))
	sfx["bell"] = _wav(_tone([[1568, 0.5, 1560]], "sine", 0.4))
	sfx["fanfare"] = _wav(_tone([[523, 0.12], [659, 0.12], [784, 0.12], [1047, 0.35]], "tri", 0.4))
	sfx["build"] = _wav(_tone([[180, 0.08, 120], [220, 0.08, 140], [300, 0.2, 260]], "square", 0.25))
	sfx["clean"] = _wav(_tone([[3000, 0.25, 1500]], "noise", 0.18))
	sfx["sick"] = _wav(_tone([[400, 0.25, 260]], "tri", 0.3))
	sfx["pet_happy"] = _wav(_tone([[700, 0.08, 1100], [900, 0.1, 1300]], "tri", 0.35))
	sfx["pet_eat"] = _wav(_tone([[220, 0.06, 180], [240, 0.06, 190], [220, 0.06, 170]], "noise", 0.15))
	sfx["pet_drink"] = _wav(_tone([[600, 0.07, 900], [620, 0.07, 950], [610, 0.07, 900]], "sine", 0.25))
	sfx["pet_bath"] = _wav(_tone([[2000, 0.35, 900]], "noise", 0.12))
	sfx["pet_play"] = _wav(_tone([[500, 0.1, 800], [800, 0.12, 600]], "tri", 0.35))
	sfx["pet_sleep"] = _wav(_tone([[200, 0.6, 150]], "sine", 0.15))

func play(name: String, pos = null) -> void:
	if not sfx.has(name) or fv <= 0.01:
		return
	var vol := fv
	if pos != null and typeof(pos) == TYPE_VECTOR3 and pos != Vector3.ZERO:
		var d: float = (pos as Vector3).distance_to(focus)
		vol *= clamp(1.0 - (d - 6.0) / 30.0, 0.0, 1.0)
		if vol < 0.03:
			return
	for p in players:
		if not p.playing:
			p.stream = sfx[name]
			p.volume_db = linear_to_db(vol)
			p.pitch_scale = rng.randf_range(0.94, 1.06) if name.begins_with("pet") else 1.0
			p.play()
			return

# ---------- música ----------
func set_track(t: String) -> void:
	track = t
	voices.clear()
	step = 0

func _midi(n: float) -> float:
	return 440.0 * pow(2.0, (n - 69.0) / 12.0)

func _sched() -> void:
	var T: Dictionary = TRACKS[track]
	step_len = 60.0 / float(T.bpm) / 2.0
	var bar: int = (step / 8) % T.prog.size()
	var chord: Array = T.prog[bar]
	var r: int = T.root
	var pos := step % 8
	if pos == 0:
		for n in chord:
			voices.append({"f": _midi(r + n), "t": 0.0, "dur": step_len * 8.0, "a": 0.035, "w": "pad", "ph": 0.0, "att": 0.3})
		voices.append({"f": _midi(r - 12 + chord[0]), "t": 0.0, "dur": step_len * 3.5, "a": 0.12, "w": "sine", "ph": 0.0, "att": 0.01})
	if pos == 4:
		voices.append({"f": _midi(r - 12 + chord[min(2, chord.size() - 1)]), "t": 0.0, "dur": step_len * 3.5, "a": 0.1, "w": "sine", "ph": 0.0, "att": 0.01})
	# melodia pentatónica, com pausas
	if rng.randf() < (0.55 if track != "noite" else 0.35):
		var sc: Array = T.scale
		var n2: int = sc[rng.randi() % sc.size()]
		voices.append({"f": _midi(r + 12 + n2), "t": 0.0, "dur": step_len * (1.0 if rng.randf() < 0.7 else 2.0), "a": 0.07, "w": "tri", "ph": 0.0, "att": 0.01})
	step += 1

func _process(dt: float) -> void:
	if gen == null:
		return
	var n := gen.get_frames_available()
	if n <= 0:
		return
	if track == "none" or mv <= 0.01:
		var silence := PackedVector2Array()
		silence.resize(n)
		gen.push_buffer(silence)
		voices.clear()
		return
	var buf := PackedVector2Array()
	buf.resize(n)
	var inv := 1.0 / RATE
	for i in n:
		if seq_t >= next_step:
			next_step = seq_t + step_len
			_sched()
		var s := 0.0
		for v in voices:
			var tt: float = v.t
			if tt < v.dur:
				v.ph += v.f * inv
				var p: float = fmod(v.ph, 1.0)
				var w: float
				if v.w == "tri":
					w = 1.0 - 4.0 * abs(p - 0.5)
				elif v.w == "pad":
					w = sin(v.ph * TAU) * 0.7 + sin(v.ph * TAU * 2.0) * 0.2
				else:
					w = sin(v.ph * TAU)
				var env: float = min(1.0, tt / v.att) * clamp((v.dur - tt) / (v.dur * 0.6), 0.0, 1.0)
				s += w * env * v.a
				v.t = tt + inv
		s *= mv
		buf[i] = Vector2(s, s)
		seq_t += inv
	gen.push_buffer(buf)
	if voices.size() > 24:
		var keep := []
		for v in voices:
			if v.t < v.dur:
				keep.append(v)
		voices = keep
