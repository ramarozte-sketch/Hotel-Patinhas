# Hotel Patinhas HD · efeitos sonoros e músicas gravadas (instrumentos modelados, ver music/)
class_name Audio
extends Node

const RATE := 22050.0
var sfx := {}
var players: Array = []
var music: AudioStreamPlayer
var music_b: AudioStreamPlayer
var fade := 1.0
var mv := 0.6
var fv := 0.8
var track := "parque"
var focus := Vector3.ZERO
var rng := RandomNumberGenerator.new()
const TRACKS := ["parque", "algarve", "noite"]

func _ready() -> void:
	rng.randomize()
	_make_sfx()
	for k in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	music = AudioStreamPlayer.new()
	music_b = AudioStreamPlayer.new()
	add_child(music)
	add_child(music_b)

func set_volumes(m: float, f: float) -> void:
	mv = m
	fv = f

# ---------- efeitos ----------
func _wav(data: PackedFloat32Array) -> AudioStreamWAV:
	var b := PackedByteArray()
	b.resize(data.size() * 2)
	for i in data.size():
		b.encode_s16(i * 2, int(clamp(data[i], -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = int(RATE)
	w.data = b
	return w

func _tone(notes: Array, wave := "sine", vol := 0.5) -> PackedFloat32Array:
	# notes: [[freq, dur, freq_end]]
	var out := PackedFloat32Array()
	for n in notes:
		var f0: float = n[0]
		var dur: float = n[1]
		var f1: float = n[2] if n.size() > 2 else f0
		var N := int(dur * RATE)
		var ph := 0.0
		for i in N:
			var tt := float(i) / N
			var f: float = lerp(f0, f1, tt)
			ph += f / RATE
			var s := 0.0
			match wave:
				"sine":
					s = sin(ph * TAU)
				"tri":
					s = 1.0 - 4.0 * abs(fmod(ph, 1.0) - 0.5)
				"square":
					s = 0.6 if fmod(ph, 1.0) < 0.5 else -0.6
				"noise":
					s = rng.randf_range(-1, 1)
			var env: float = min(1.0, tt * 30.0) * pow(1.0 - tt, 1.6)
			out.append(s * env * vol)
	return out

func _make_sfx() -> void:
	sfx["click"] = _wav(_tone([[880, 0.05, 660]], "tri", 0.35))
	sfx["coin"] = _wav(_tone([[988, 0.07], [1319, 0.22]], "square", 0.25))
	sfx["ok"] = _wav(_tone([[660, 0.08], [880, 0.14]], "tri", 0.4))
	sfx["bell"] = _wav(_tone([[1568, 0.5, 1560]], "sine", 0.4))
	sfx["fanfare"] = _wav(_tone([[523, 0.12], [659, 0.12], [784, 0.12], [1047, 0.35]], "tri", 0.4))
	sfx["build"] = _wav(_tone([[180, 0.08, 120], [220, 0.08, 140], [300, 0.2, 260]], "square", 0.25))
	sfx["clean"] = _wav(_tone([[3000, 0.25, 1500]], "noise", 0.18))
	sfx["sick"] = _wav(_tone([[400, 0.25, 260]], "tri", 0.3))
	sfx["pet_happy"] = _wav(_tone([[700, 0.08, 1100], [900, 0.1, 1300]], "tri", 0.35))
	sfx["pet_eat"] = _wav(_tone([[220, 0.06, 180], [240, 0.06, 190], [220, 0.06, 170]], "noise", 0.15))
	sfx["pet_drink"] = _wav(_tone([[600, 0.07, 900], [620, 0.07, 950], [610, 0.07, 900]], "sine", 0.25))
	sfx["pet_bath"] = _wav(_tone([[2000, 0.35, 900]], "noise", 0.12))
	sfx["pet_play"] = _wav(_tone([[500, 0.1, 800], [800, 0.12, 600]], "tri", 0.35))
	sfx["pet_sleep"] = _wav(_tone([[200, 0.6, 150]], "sine", 0.15))
	# sons gravados (mais naturais) substituem os gerados quando existem
	for n in ["bell", "coin", "fanfare", "ok", "click"]:
		var path := "res://sfx/%s.wav" % n
		if ResourceLoader.exists(path):
			sfx[n] = load(path)

func play(name: String, pos = null) -> void:
	if not sfx.has(name) or fv <= 0.01:
		return
	var vol := fv
	if pos != null and typeof(pos) == TYPE_VECTOR3 and pos != Vector3.ZERO:
		var d: float = (pos as Vector3).distance_to(focus)
		vol *= clamp(1.0 - (d - 6.0) / 30.0, 0.0, 1.0)
		if vol < 0.03:
			return
	for p in players:
		if not p.playing:
			p.stream = sfx[name]
			p.volume_db = linear_to_db(vol)
			p.pitch_scale = rng.randf_range(0.94, 1.06) if name.begins_with("pet") else 1.0
			p.play()
			return

# ---------- música ----------
func set_track(t: String) -> void:
	if t == track and music.playing:
		return
	track = t
	# troca suave: a faixa antiga passa para o leitor B e desvanece
	if music.playing:
		music_b.stream = music.stream
		music_b.volume_db = music.volume_db
		music_b.play(music.get_playback_position())
	music.stop()
	fade = 0.0
	if t in TRACKS:
		var path := "res://music/%s.ogg" % t
		if ResourceLoader.exists(path):
			var st = load(path)
			if st is AudioStreamOggVorbis:
				(st as AudioStreamOggVorbis).loop = true
			music.stream = st
			music.play()

func _process(dt: float) -> void:
	fade = min(1.0, fade + dt / 1.5)
	var base := 0.75 * mv
	if music.playing:
		music.volume_db = linear_to_db(max(base * fade, 0.0001))
	if music_b.playing:
		var vb := base * (1.0 - fade)
		if vb <= 0.001:
			music_b.stop()
		else:
			music_b.volume_db = linear_to_db(vb)
