# Hotel Patinhas HD · a simulação do hotel: hóspedes, cuidados, passeios, ajudantes, economia e todas as fases
class_name Sim
extends Node3D

signal toast_msg(key: String, params: Dictionary)
signal changed
signal sound(name: String, pos: Vector3)

var world: World
var S: Dictionary
var rng := RandomNumberGenerator.new()
var queue: Array = []
var pets := {}        # id -> entidade do animal
var owners := {}      # id do hóspede -> pessoa (dono)
var staff_ents := {}  # posição na equipa -> pessoa
var leavers: Array = [] # donos a ir embora com o animal
var mess_nodes := {}
var claims := {}
var player: HumanModel
var player_trail: Array = []
var mine = null
var t := 0.0
var acc := 0.0
var next_arrival := 3.0
var ev_next := 300.0
var mis_next := 420.0
var weather_next := 600.0
var raining := false
var boost := 0.0
var contest = null
var last_ev := ""
var season := ""
var pending_back := 0
var hint = null
var fr_acc := 0.0
var fr_t := 0.0
var level_acc := 0.0
var dirty := true
var pets_root: Node3D
var npc_root: Node3D
var leash_mesh: ImmediateMesh
var leash_mi: MeshInstance3D
var day_hour := 12.0

const NEEDS := ["fome", "sede", "banho", "diver"]
const PET_PATH_SPEED := 2.0
const HUMAN_SPEED := 1.45

# ===================== estado guardado =====================
static func fresh() -> Dictionary:
	var rooms := []
	for i in D.NROOMS:
		rooms.append(null)
	return {
		"v": 1, "money": 60, "rep": 15, "served": 0, "earned": 0, "uid": 1, "rooms": rooms,
		"up": {"rooms": 2, "beds": 0, "feeder": 0, "fonte": 0, "ads": 0, "decor": 0, "aviario": 0, "lago": 0, "estabulo": 0, "suite": 0,
			"h_comida": 0, "h_banho": 0, "h_brincar": 0, "h_rece": 0, "h_vet": 0, "pav_e": 0, "pav_w": 0, "piscina": 0, "luzes": 0, "clinica": 0},
		"staff": [], "cnt": {}, "ach": {}, "mis": null, "reviews": [], "month": null, "trophies": [], "seen": {}, "fr": {}, "stock": {},
		"mine": null, "daily": {"last": "", "streak": 0}, "lastPlay": 0, "regs": [], "payT": 0.0, "decor": {}, "char": {"name": "", "look": {}},
	}

static func fix_save(s: Dictionary) -> Dictionary:
	var F := fresh()
	for k in F:
		if not s.has(k) or (s[k] == null and F[k] != null):
			s[k] = F[k]
	for k in F.up:
		if not s.up.has(k):
			s.up[k] = 0
		s.up[k] = int(s.up[k])
	while s.rooms.size() < D.NROOMS:
		s.rooms.append(null)
	for g in s.rooms:
		if g != null:
			g.coat = int(g.coat)
			g.id = int(g.id)
			g.mess = int(g.get("mess", 0))
	return s

# ===================== arranque =====================
func setup(w: World, save: Dictionary, pl: HumanModel) -> void:
	world = w
	S = fix_save(save)
	player = pl
	rng.randomize()
	pets_root = Node3D.new()
	pets_root.name = "Pets"
	add_child(pets_root)
	npc_root = Node3D.new()
	npc_root.name = "People"
	add_child(npc_root)
	leash_mesh = ImmediateMesh.new()
	leash_mi = MeshInstance3D.new()
	leash_mi.mesh = leash_mesh
	var lm := StandardMaterial3D.new()
	lm.albedo_color = Color("#d8322a")
	lm.roughness = 0.5
	lm.cull_mode = BaseMaterial3D.CULL_DISABLED
	leash_mi.material_override = lm
	leash_mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(leash_mi)
	season = D.season_now()
	refresh_world()
	# animais que já estavam hospedados
	for i in D.NROOMS:
		var g = S.rooms[i]
		if g == null:
			continue
		if not room_open(i) or D.place_of(g.sp) != D.room_kind(i):
			S.rooms[i] = null
			continue
		g.room = i
		g.erase("out")
		var e = spawn_pet(g, world.room_point(i, "center"))
		e.wander = i
		for k in int(g.get("mess", 0)):
			add_mess_part(g, e)
	month_roll()
	ensure_missions()
	sync_staff(false)
	if S.mine != null:
		spawn_mine()

func toast(key: String, p := {}) -> void:
	toast_msg.emit(key, p)

func stars() -> int:
	return D.stars(S.rep)

func hotel_name() -> String:
	return D.T(D.HOTEL_NAMES[stars() - 1]) + " Patinhas"

# ===================== quartos =====================
func room_open(i: int) -> bool:
	if i < D.NRING:
		return i < int(S.up.rooms)
	if i < 22:
		return int(S.up.estabulo) > 0
	return int(S.up.aviario) > 0

func free_room_for(sp: String) -> int:
	var place := D.place_of(sp)
	for i in D.NROOMS:
		if D.room_kind(i) == place and room_open(i) and S.rooms[i] == null and i < world.room_nodes.size() and world.room_nodes[i] != null:
			return i
	return -1

func free_count(kind: String) -> int:
	var n := 0
	for i in D.NROOMS:
		if D.room_kind(i) == kind and room_open(i) and S.rooms[i] == null:
			n += 1
	return n

func refresh_world() -> void:
	world.refresh(S.up, season)
	for i in D.NROOMS:
		if i < world.room_nodes.size() and world.room_nodes[i] != null:
			var open := room_open(i)
			var rn: Dictionary = world.room_nodes[i]
			var dec = S.decor.get(str(i), {})
			var key := "%s_%s" % [open, JSON.stringify(dec)]
			if rn.get("key", "") != key:
				rn["key"] = key
				world.furnish(i, open, dec)
			var locked_wing := (i >= 8 and i < 12 and int(S.up.pav_e) == 0) or (i >= 12 and i < 16 and int(S.up.pav_w) == 0)
			rn.lock.text = "" if open else ("🏗️" if i == int(S.up.rooms) and not locked_wing else "🔒")
	if world.hotel_sign:
		world.set_sign("🐾 " + hotel_name())
	update_levels()
	dirty = true

func update_levels() -> void:
	for i in D.NROOMS:
		var g = S.rooms[i]
		world.set_level(i, g.fome if g else 0.0, g.sede if g else 0.0)

# ===================== entidades =====================
func spawn_pet(g: Dictionary, pos: Vector3) -> Dictionary:
	var m := PetModel.new()
	pets_root.add_child(m)
	m.setup(g.sp, int(g.coat))
	m.position = pos
	var tag := Label3D.new()
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tag.font_size = 38
	tag.pixel_size = 0.004
	tag.outline_size = 12
	tag.position = Vector3(0, m.height + 0.25, 0)
	tag.visibility_range_end = 26.0
	tag.text = g.pet
	m.add_child(tag)
	var spd := D.speed_of(g.sp)
	var e := {"gid": int(g.id), "m": m, "tag": tag, "pos": Vector3(pos.x, 0, pos.z), "yaw": 0.0, "path": [], "cb": null, "speed": spd, "base": spd,
		"wander": -1, "idle": 1.0 + rng.randf() * 2.0, "act": null, "trip": false, "phase": "", "dest": "", "leash": null, "jump": 0.0, "lift": 0.0,
		"moving": false, "escort": null, "mood": "🙂", "fx_t": 0.0, "happy": false}
	pets[int(g.id)] = e
	return e

func despawn_pet(id: int) -> void:
	var e = pets.get(id)
	if e == null:
		return
	e.m.queue_free()
	pets.erase(id)

func guest_of(e: Dictionary):
	for i in D.NROOMS:
		var g = S.rooms[i]
		if g != null and int(g.id) == e.gid:
			return g
	return null

func room_of(e: Dictionary) -> int:
	for i in D.NROOMS:
		var g = S.rooms[i]
		if g != null and int(g.id) == e.gid:
			return i
	return -1

func nav_pet(e: Dictionary, to: Vector3, cb = null) -> void:
	e.path = world.find_path(e.pos, to)
	e.cb = cb

func go_straight(e: Dictionary, pts: Array, cb = null) -> void:
	e.path = pts
	e.cb = cb

func step_pet(e: Dictionary, dt: float) -> void:
	var moving := false
	if e.leash != null:
		moving = follow_leash(e, dt)
	elif not e.path.is_empty():
		var tg = e.path[0]
		var is_pt: bool = typeof(tg) == TYPE_DICTIONARY
		var p: Vector3 = tg.p if is_pt else tg
		var d: Vector3 = p - e.pos
		d.y = 0
		var dist := d.length()
		var st: float = e.speed * dt
		if dist <= st:
			e.pos = p
			e.path.remove_at(0)
			e.jump = 0.0
			if e.path.is_empty() and e.cb != null:
				var f: Callable = e.cb
				e.cb = null
				f.call()
		else:
			e.pos += d / dist * st
			e.yaw = lerp_angle(e.yaw, atan2(d.x, d.z), min(1.0, dt * 10.0))
			moving = true
			if is_pt and tg.get("h", 0.0) > 0.0:
				if not tg.has("len"):
					tg["len"] = dist
				var fr: float = 1.0 - dist / tg.len
				e.jump = sin(fr * PI) * tg.h
			else:
				e.jump = 0.0
	e.moving = moving
	var m: PetModel = e.m
	m.position = Vector3(e.pos.x, e.jump + e.lift, e.pos.z)
	m.rotation.y = e.yaw
	var a := ""
	if e.act != null:
		a = e.act.type
	m.animate(dt, moving, e.speed, a, e.happy)

func leader_pos(e: Dictionary):
	var L = e.leash
	if L == null:
		return null
	if L.kind == "player":
		return player.global_position
	var npc = L.npc
	if npc != null and is_instance_valid(npc.m):
		return npc.pos
	return null

func leader_trail(e: Dictionary) -> Array:
	if e.leash.kind == "player":
		return player_trail
	return e.leash.npc.trail

func follow_leash(e: Dictionary, dt: float) -> bool:
	var lp = leader_pos(e)
	if lp == null:
		return false
	var trail := leader_trail(e)
	var need: float = 1.4 if e.m.height < 1.2 else 2.2
	var px: float = lp.x
	var pz: float = lp.z
	var tx := px
	var tz := pz
	for k in range(trail.size() - 1, -1, -1):
		var q: Vector3 = trail[k]
		var dd := sqrt((q.x - px) * (q.x - px) + (q.z - pz) * (q.z - pz))
		if dd >= need:
			var f := need / dd
			tx = px + (q.x - px) * f
			tz = pz + (q.z - pz) * f
			need = 0.0
			break
		need -= dd
		px = q.x
		pz = q.z
		tx = px
		tz = pz
	var tgt := Vector3(tx, 0, tz)
	var d: Vector3 = tgt - e.pos
	var dist := d.length()
	if dist > 12.0:
		e.pos = tgt
		return false
	if dist > 0.12:
		var st: float = min(dist, max(e.speed, 3.4) * 1.1 * dt)
		e.pos += d / dist * st
		e.yaw = lerp_angle(e.yaw, atan2(d.x, d.z), min(1.0, dt * 10.0))
		return true
	return false

func set_leash(e: Dictionary, L, phase: String) -> void:
	e.leash = L
	e.phase = phase
	e.path = []
	e.cb = null
	e.act = null
	e.lift = 0.0

func leading_pet(who):
	for id in pets:
		var e = pets[id]
		if e.leash != null and ((typeof(who) == TYPE_STRING and e.leash.kind == "player") or (typeof(who) != TYPE_STRING and e.leash.get("npc") == who)):
			return e
	return null

# o animal passeia no quarto e vai às coisas
func pet_idle(e: Dictionary, dt: float) -> void:
	var g = guest_of(e)
	if g == null or e.wander < 0 or e.trip:
		return
	if e.act != null:
		e.act.t += dt
		if e.act.t >= e.act.dur:
			if e.act.type == "bath":
				world.set_bath(e.wander, false)
			e.act = null
			e.lift = 0.0
		return
	if not e.path.is_empty():
		return
	e.idle -= dt
	if e.idle > 0:
		return
	e.idle = 3.0 + rng.randf() * 4.0
	if rng.randf() < 0.25 and g.fome + g.sede > 120:
		pet_do(e, "sleep")
	else:
		nav_pet(e, world.random_in_room(e.wander, rng))

func pet_do(e: Dictionary, a: String) -> void:
	var i := room_of(e)
	if i < 0 or e.trip:
		return
	var spot: Vector3
	var lift := 0.0
	var dur := 3.0
	var kind := D.room_kind(i)
	match a:
		"eat":
			spot = world.room_point(i, "food") + (world.room_point(i, "center") - world.room_point(i, "food")).normalized() * (0.35 + e.m.height * 0.3)
		"drink":
			spot = world.room_point(i, "water") + (world.room_point(i, "center") - world.room_point(i, "water")).normalized() * (0.35 + e.m.height * 0.3)
		"bath":
			spot = world.room_point(i, "tub")
			lift = 0.12 if kind == "" else 0.0
			dur = 4.0
		"sleep":
			spot = world.room_point(i, "bed")
			lift = 0.3 if kind == "" else (1.45 if kind == "avi" else 0.05)
			dur = 8.0 + rng.randf() * 6.0
		"play":
			spot = world.W(i, 3.4, -0.7)
			dur = 3.0
		_:
			spot = e.pos
			dur = 2.0
	var center := world.room_point(i, "center")
	var near: Vector3 = spot + (center - spot).normalized() * 0.9
	nav_pet(e, near, func():
		go_straight(e, [spot], func():
			e.lift = lift
			e.act = {"type": a, "t": 0.0, "dur": dur}
			if a == "bath":
				world.set_bath(i, true)
			if a == "eat" or a == "drink" or a == "play":
				var tgt: Vector3 = world.room_point(i, "food" if a == "eat" else "water") if a != "play" else world.W(i, 3.4, -0.7)
				var d: Vector3 = tgt - e.pos
				if d.length() > 0.05:
					e.yaw = atan2(d.x, d.z)
			sound.emit("pet_" + a, e.pos)
		)
	)

# ===================== pessoas =====================
func make_human(look: Dictionary, label := "") -> Dictionary:
	var h := HumanModel.new()
	npc_root.add_child(h)
	h.setup(look)
	if label != "":
		h.set_label(label)
	return {"m": h, "pos": Vector3.ZERO, "yaw": 0.0, "path": [], "cb": null, "trail": [], "speed": HUMAN_SPEED, "walking": false, "pose": ""}

func walk(npc: Dictionary, goal: Vector3, cb = null) -> void:
	npc.path = world.find_path(npc.pos, goal)
	npc.cb = cb
	npc.walking = true

func step_human(npc: Dictionary, dt: float) -> void:
	var moving := false
	if not npc.path.is_empty():
		var p: Vector3 = npc.path[0]
		var d: Vector3 = p - npc.pos
		d.y = 0
		var dist := d.length()
		var st: float = npc.speed * dt
		if dist <= st:
			npc.pos = p
			npc.path.remove_at(0)
			if npc.path.is_empty():
				npc.walking = false
				if npc.cb != null:
					var f: Callable = npc.cb
					npc.cb = null
					f.call()
		else:
			npc.pos += d / dist * st
			npc.yaw = lerp_angle(npc.yaw, atan2(d.x, d.z), min(1.0, dt * 8.0))
			moving = true
	var h: HumanModel = npc.m
	h.position = npc.pos
	h.rotation.y = npc.yaw
	h.animate(dt, moving, npc.speed, npc.pose)
	var tr: Array = npc.trail
	if tr.is_empty() or tr[tr.size() - 1].distance_to(npc.pos) > 0.3:
		tr.append(npc.pos)
		if tr.size() > 60:
			tr.remove_at(0)

func face(npc: Dictionary, target: Vector3) -> void:
	var d: Vector3 = target - npc.pos
	if d.length() > 0.01:
		npc.yaw = atan2(d.x, d.z)

func street_point(left: bool) -> Vector3:
	return Vector3(-26.0 if left else 26.0, 0, 24.2)

func spawn_owner(q: Dictionary) -> Dictionary:
	var look := HumanModel.random_look(rng)
	var hats := ["", "", "", "bone", "gorro", "cartola"]
	look.hat = hats[rng.randi() % hats.size()]
	look.hatc = HumanModel.SHIRTS[rng.randi() % HumanModel.SHIRTS.size()]
	look.female = q.owner.begins_with("D.") or q.owner.begins_with("Avó") or q.owner in ["Inês", "Beatriz", "Carla", "Marta", "Leonor", "Sofia"]
	var npc := make_human(look, q.owner)
	npc.pos = street_point(rng.randf() < 0.5)
	npc.m.position = npc.pos
	owners[int(q.id)] = npc
	return npc

func owner_leave(id: int) -> void:
	var o = owners.get(id)
	if o == null:
		return
	owners.erase(id)
	o.pose = ""
	walk(o, street_point(rng.randf() < 0.5), func(): o.m.queue_free(); o["dead"] = true)
	leavers.append(o)

# ===================== chegada de clientes =====================
func available() -> Array:
	var out := []
	for k in D.SPECIES_ORDER:
		var s: Dictionary = D.SPECIES[k]
		var ok: bool = (not s.has("req") or int(S.up.get(s.req, 0)) > 0) and (not s.has("reqFr") or int(S.fr.get(s.reqFr, 0)) > 0)
		if s.get("place", "") == "barn" and int(S.up.estabulo) == 0:
			ok = false
		if k == "unicornio" and stars() < 4:
			ok = false
		if ok:
			out.append(k)
	return out

func pick_coat(sp: String) -> int:
	var n: int = D.COATS[sp].size()
	if n > 2 and rng.randf() < 0.06:
		return n - 1
	return rng.randi_range(0, n - 2 if n > 2 else n - 1)

func new_guest() -> Dictionary:
	var all := available()
	var fit := []
	for k in all:
		if free_room_for(k) >= 0:
			fit.append(k)
	var pool: Array = fit if (not fit.is_empty() and rng.randf() < 0.85) else all
	var sp: String = pool[rng.randi() % pool.size()]
	var q := {"id": int(S.uid), "sp": sp, "coat": pick_coat(sp), "pet": D.PETS[rng.randi() % D.PETS.size()], "owner": D.OWNERS[rng.randi() % D.OWNERS.size()],
		"stay": rng.randi_range(70, 120), "wait": 60.0, "waitMax": 60.0, "fome": 55.0 + rng.randi_range(0, 35), "sede": 55.0 + rng.randi_range(0, 35),
		"banho": 55.0 + rng.randi_range(0, 35), "diver": 55.0 + rng.randi_range(0, 35), "mess": 0, "parks": 0}
	S.uid = int(S.uid) + 1
	if not S.regs.is_empty() and rng.randf() < 0.3:
		var r = S.regs[rng.randi() % S.regs.size()]
		var ok := true
		for x in queue:
			if x.owner == r.owner:
				ok = false
		for g in S.rooms:
			if g != null and g.owner == r.owner and g.pet == r.pet:
				ok = false
		if ok and r.sp in all:
			q.sp = r.sp
			q.coat = int(r.coat)
			q.pet = r.pet
			q.owner = r.owner
			q.reg = int(r.visits)
	if rng.randf() < 0.4:
		q.req = {"t": D.REQ_IDS[rng.randi() % D.REQ_IDS.size()], "p": 0, "fail": false}
	var r2 := rng.randf()
	if r2 < 0.04:
		q.vip = "insp"
	elif r2 < 0.08:
		q.vip = "infl"
	elif r2 < 0.1:
		q.vip = "fam"
	return q

func arrival_interval() -> float:
	var s: float = 13.0 * pow(0.85, int(S.up.ads)) * (1.15 - stars() * 0.07) + rng.randf() * 4.0
	if boost > 0:
		s *= 0.6
	if season == "verao":
		s *= 0.85
	return s

func seat_pos(k: int) -> Vector3:
	var a: float = [150.0, 165.0, 15.0][k % 3]
	return World.Pc(World.LOB, a, 3.9)

func desk_spot(k: int) -> Vector3:
	return Vector3(-1.3 + k * 1.3, 0, 11.4)

func add_to_queue() -> void:
	var q := new_guest()
	queue.append(q)
	var k := queue.size() - 1
	var npc := spawn_owner(q)
	var pe := spawn_pet(q, npc.pos + Vector3(0.6, 0, 0.4))
	pe.leash = {"kind": "npc", "npc": npc}
	pe.phase = "arrive"
	walk(npc, Vector3(desk_spot(k).x + 0.7, 0, 12.2), func():
		set_leash(pe, null, "")
		nav_pet(pe, desk_spot(k), func(): pe.yaw = PI)
		walk(npc, seat_pos(k), func():
			npc.pose = "sit"
			face(npc, World.LOB)
		)
	)
	toast("{o} chegou com {p} ({e}).", {"o": q.owner, "p": q.pet, "e": D.SPECIES[q.sp].e})
	if q.has("reg"):
		toast("⭐ {o} voltou com {p}! Cliente habitual.", {"o": q.owner, "p": q.pet})
		emit_ev("regs", 1)
	sound.emit("bell", World.DESK)
	dirty = true

func accept(id: int, staff_name := "") -> bool:
	var qi := -1
	for k in queue.size():
		if int(queue[k].id) == id:
			qi = k
	if qi < 0:
		return false
	var q: Dictionary = queue[qi]
	var i := free_room_for(q.sp)
	if i < 0:
		if staff_name == "":
			var place := D.place_of(q.sp)
			if place == "barn":
				toast("O celeiro não tem celas livres." if int(S.up.estabulo) > 0 else "Os cavalos e unicórnios precisam do celeiro.")
			elif place == "avi":
				toast("O aviário não tem viveiros livres." if int(S.up.aviario) > 0 else "Os papagaios precisam do aviário.")
			else:
				toast("Não há quartos livres. Constrói mais um.")
		return false
	queue.remove_at(qi)
	var g := q
	g.left = float(g.stay)
	g.hs = 0.0
	g.ht = 0.0
	g.room = i
	g.erase("wait")
	g.erase("waitMax")
	S.rooms[i] = g
	var e = pets.get(int(g.id))
	if e != null:
		set_leash(e, null, "")
		e.speed = e.base * 1.4
		nav_pet(e, world.room_point(i, "center"), func():
			e.speed = e.base
			e.wander = i
			e.idle = 0.5
		)
	owner_leave(int(g.id))
	mark_seen(g)
	hint = {"pos": world.room_point(i, "center"), "t": t + 12.0}
	if staff_name != "":
		toast("{s} recebeu {p} de {o}. Vai para {r}.", {"s": staff_name, "p": g.pet, "o": g.owner, "r": room_name(i)})
	else:
		toast("{o} deixou {p}. Vai para {r}.", {"o": g.owner, "p": g.pet, "r": room_name(i)})
	sound.emit("ok", World.DESK)
	emit_ev("accept", 1)
	dirty = true
	return true

func room_name(i: int) -> Array:
	var k := D.room_kind(i)
	return ["Cela {r}" if k == "barn" else ("Viveiro {r}" if k == "avi" else "Quarto {r}"), {"r": D.room_no(i)}]

func decline(id: int, silent := false) -> void:
	for k in queue.size():
		var q: Dictionary = queue[k]
		if int(q.id) == id:
			queue.remove_at(k)
			var o = owners.get(id)
			var e = pets.get(id)
			if e != null and o != null:
				e.leash = {"kind": "npc", "npc": o}
				e.phase = "leave"
			elif e != null:
				despawn_pet(id)
			if o != null:
				owners.erase(id)
				o.pose = ""
				walk(o, street_point(rng.randf() < 0.5), func():
					o.m.queue_free()
					o["dead"] = true
					despawn_pet(id)
				)
				leavers.append(o)
			if not silent:
				toast("{o} foi embora.", {"o": q.owner})
			_reflow_queue()
			dirty = true
			return

func _reflow_queue() -> void:
	for k in queue.size():
		var q: Dictionary = queue[k]
		var e = pets.get(int(q.id))
		if e != null and e.leash == null:
			nav_pet(e, desk_spot(k), func(): e.yaw = PI)

# ===================== saída e pagamento =====================
const REVIEW_TXT := {5: "Cinco estrelas, sem dúvida!", 4: "Gostámos muito.", 3: "Razoável.", 2: "Não ficámos convencidos.", 1: "Não ficámos convencidos."}

func is_night() -> bool:
	return day_hour >= 19.5 or day_hour < 6.5

func checkout(i: int) -> void:
	var g: Dictionary = S.rooms[i]
	var sp: Dictionary = D.SPECIES[g.sp]
	var avg: float = g.hs / g.ht if g.ht > 0 else D.happy(g)
	if OS.get_environment("HP_DEBUG") != "":
		print("  checkout %s avg=%.0f f=%.0f s=%.0f b=%.0f d=%.0f mess=%d sick=%s rep=%.0f" % [g.sp, avg, g.fome, g.sede, g.banho, g.diver, int(g.get("mess", 0)), g.get("sick", false), S.rep])
	var night := is_night()
	var mult := 1.0
	if g.has("reg"):
		mult *= 1.0 + 0.08 * min(4, int(g.reg))
	if g.get("req") != null:
		var r: Dictionary = g.req
		var ok := false
		var R: Dictionary = D.REQS[r.t]
		match r.t:
			"parque":
				ok = int(g.get("parks", 0)) >= 2
			"banho", "mimos":
				ok = int(r.p) >= int(R.n)
			"limpo":
				ok = not r.fail
			"feliz":
				ok = avg > 80
		var txt := [R.t, {"n": R.get("n", 0)}]
		if ok:
			mult *= 1.35
			emit_ev("reqs", 1)
			toast("📝 Pedido cumprido: {t}! O dono pagou mais.", {"t": txt})
		else:
			S.rep = max(0, S.rep - 1)
			toast("📝 {o} queria: {t}. Ficou desiludido.", {"o": g.owner, "t": txt})
	if g.get("vip", "") == "fam":
		mult *= 3.0
	elif g.get("vip", "") == "infl":
		mult *= 1.2
	if g.get("leak", false):
		mult *= 0.85
	if season == "verao":
		mult *= 1.15
	elif season == "natal":
		mult *= 1.1
	elif season == "halloween" and night:
		mult *= 1.1
	var pay: float = sp.pay * (float(g.stay) / 60.0) * (0.25 + 0.75 * avg / 100.0) * (1.0 + 0.15 * int(S.up.decor)) * (0.8 + 0.1 * stars()) * (1.0 + 0.05 * min(3, int(g.get("parks", 0)))) * (1.1 if (int(S.up.luzes) > 0 and night) else 1.0) * mult
	var tip := int(round(pay * 0.2)) if avg > 85 else 0
	var payi: int = max(1, int(round(pay)))
	S.money += payi + tip
	S.earned += payi + tip
	S.served = int(S.served) + 1
	var before := stars()
	S.rep = clamp(S.rep + (3 if avg > 80 else (1 if avg > 60 else (-4 if avg < 40 else 0))), 0, 100)
	var say := "Está tão feliz! Volto cá de certeza." if avg > 85 else ("Muito bem tratado, obrigado." if avg > 65 else ("Hum… podia estar melhor." if avg > 40 else "O meu {p} está miserável!"))
	toast("{o}: \"{s}\" +{m}", {"o": g.owner, "s": [say, {"p": g.pet}], "m": D.fmt(payi + tip)})
	sound.emit("coin", world.room_point(i, "door"))
	var st := 5 if avg > 85 else (4 if avg > 68 else (3 if avg > 50 else (2 if avg > 35 else 1)))
	if g.get("wasSick", false):
		st = max(1, st - 1)
	var txt2 := [REVIEW_TXT[st]]
	if g.get("wasSick", false):
		txt2.append("Voltou doente!")
	if int(g.get("messMax", 0)) == 0 and st >= 4:
		txt2.append("O quarto estava sempre limpinho.")
	if D.room_kind(i) == "barn" and st >= 3:
		txt2.append("O estábulo é impecável.")
	if g.has("reg") and st >= 4:
		txt2.append("Volto sempre!")
	S.reviews.push_front({"o": g.owner, "p": g.pet, "e": sp.e, "s": st, "t": txt2, "d": Time.get_unix_time_from_system(), "r": D.room_no(i), "vip": g.get("vip", "")})
	while S.reviews.size() > 30:
		S.reviews.pop_back()
	month_add(st)
	var vip: String = g.get("vip", "")
	if vip == "insp":
		S.rep = clamp(S.rep + (5 if st >= 4 else -5), 0, 100)
		toast("🕵️ {o} era um inspetor incógnito! A reputação subiu." if st >= 4 else "🕵️ {o} era um inspetor incógnito! A reputação baixou.", {"o": g.owner})
	elif vip == "infl" and st >= 4:
		boost = 300.0
		toast("📸 {o} publicou fotos do hotel: vêm aí mais clientes!", {"o": g.owner})
	elif vip == "fam" and st >= 4:
		S.rep = min(100, S.rep + 3)
		toast("🌟 O famoso {p} adorou a estadia!", {"p": g.pet})
	if avg > 60:
		var found := false
		for r in S.regs:
			if r.owner == g.owner and r.pet == g.pet:
				r.visits = int(r.visits) + 1
				found = true
		if not found:
			S.regs.append({"owner": g.owner, "pet": g.pet, "sp": g.sp, "coat": int(g.coat), "visits": 1})
			if S.regs.size() > 12:
				S.regs.remove_at(0)
	emit_ev("served", 1)
	if avg > 80:
		emit_ev("happyOut", 1)
	for k in claims.keys():
		if str(k).begins_with(str(g.id) + ":"):
			claims.erase(k)
	clear_mess(int(g.id))
	var e = pets.get(int(g.id))
	S.rooms[i] = null
	if e != null:
		set_leash(e, null, "")
		e.trip = false
		e.wander = -1
		e.happy = st >= 4
		e.speed = e.base * 1.2
		# o dono vem buscá-lo à entrada e vão-se embora juntos
		var look := HumanModel.random_look(rng)
		look.female = g.owner.begins_with("D.") or g.owner.begins_with("Avó") or g.owner in ["Inês", "Beatriz", "Carla", "Marta", "Leonor", "Sofia"]
		var o := make_human(look, g.owner)
		o.pos = street_point(rng.randf() < 0.5)
		o.m.position = o.pos
		var meet := Vector3(rng.randf_range(-1.0, 1.0), 0, 13.6)
		leavers.append(o)
		var gid := int(g.id)
		var met := {"pet": false, "owner": false}
		var go_away := func():
			if met.pet and met.owner:
				var ee = pets.get(gid)
				if ee != null:
					ee.leash = {"kind": "npc", "npc": o}
					ee.phase = "leave"
				walk(o, street_point(rng.randf() < 0.5), func():
					o.m.queue_free()
					o["dead"] = true
					despawn_pet(gid)
				)
		nav_pet(e, meet + Vector3(0, 0, -0.9), func():
			met.pet = true
			go_away.call()
		)
		walk(o, meet, func():
			met.owner = true
			face(o, meet + Vector3(0, 0, -2))
			go_away.call()
		)
	if stars() > before:
		toast("Subiste para {n} estrelas! Agora és um {h}.", {"n": stars(), "h": [D.HOTEL_NAMES[stars() - 1], {}]})
		sound.emit("fanfare", Vector3.ZERO)
		refresh_world()
	dirty = true

# ===================== cuidados =====================
func near_room(i: int, dmax := 3.0) -> bool:
	var p := player.global_position
	return world.in_room(i, p) or p.distance_to(world.room_point(i, "door")) < dmax

func use_stock(a: String) -> float:
	for p in D.PRODUCTS:
		if p.act == a and int(S.stock.get(p.id, 0)) > 0:
			S.stock[p.id] = int(S.stock[p.id]) - 1
			if int(S.stock[p.id]) == 0:
				toast("🛒 Acabou: {n}.", {"n": [p.n, {}]})
			return 20.0
	return 0.0

# o animal está mesmo dentro do quarto (já chegou e não saiu)?
func pet_present(i: int) -> bool:
	if i < 0 or i >= D.NROOMS:
		return false
	var g = S.rooms[i]
	if g == null:
		return false
	var e = pets.get(int(g.id))
	return e != null and not e.trip and int(e.wander) == i

func care(i: int, a: String) -> void:
	if i < 0 or i >= D.NROOMS:
		return
	var g = S.rooms[i]
	if g == null:
		return
	var e = pets.get(int(g.id))
	var mine_go: bool = a == "parque" and e != null and e.trip and e.leash != null and e.leash.kind == "player" and e.phase == "go"
	if not mine_go and a != "reparar" and a != "limpar" and not (e != null and e.trip) and not pet_present(i):
		toast("{p} ainda não está no quarto.", {"p": g.pet})
		return
	if a == "parque":
		if e != null and e.trip and e.leash != null and e.leash.kind == "player" and e.phase == "go":
			arrive_room(e)
			return
		var led = leading_pet("player")
		if led != null:
			var lg = guest_of(led)
			toast("Já levas {p} pela trela.", {"p": lg.pet if lg else ""})
			return
		if not near_room(i, 4.0):
			toast("Aproxima-te do quarto para cuidar dele.")
			return
		if not pet_trip(g, {"kind": "player"}, "park"):
			toast("{p} já está ocupado. Tenta daqui a pouco.", {"p": g.pet})
			return
		toast("Leva {p} ao parque! Vai atrás de ti pela trela.", {"p": g.pet})
		sound.emit("pet_happy", e.pos)
		return
	if a == "vet":
		if not g.get("sick", false):
			toast("{p} não está doente.", {"p": g.pet})
			return
		var fee := vet_fee()
		if S.money < fee:
			toast("Não tens dinheiro suficiente.")
			return
		if leading_pet("player") != null:
			toast("Já levas {p} pela trela.", {"p": ""})
			return
		if not pet_trip(g, {"kind": "player"}, "vet"):
			toast("{p} já está ocupado. Tenta daqui a pouco.", {"p": g.pet})
			return
		toast("Leva {p} ao veterinário (segue a seta). A consulta custa {m}.", {"p": g.pet, "m": D.fmt(fee)})
		return
	if a == "reparar":
		if not g.get("leak", false):
			return
		if S.money < 20:
			toast("Não tens dinheiro suficiente.")
			return
		S.money -= 20
		g.erase("leak")
		toast("🔧 Fuga reparada!")
		set_leak_fx(i, false)
		dirty = true
		return
	if not near_room(i, 4.0):
		toast("Aproxima-te do quarto para cuidar dele.")
		return
	if e != null and e.trip:
		toast("{p} já está ocupado. Tenta daqui a pouco.", {"p": g.pet})
		return
	if a == "limpar":
		if int(g.get("mess", 0)) == 0:
			toast("Está tudo limpo.")
			return
		emit_ev("cleans", int(g.mess))
		g.mess = 0
		clear_mess(int(g.id))
		toast("🧹 Quarto limpo!")
		sound.emit("clean", world.room_point(i, "center"))
		dirty = true
		return
	if a == "mimos":
		g.diver = clamp(g.diver + 10, 0, 100)
		g.loveN = int(g.get("loveN", 0)) + 1
		if g.get("req") != null and g.req.t == "mimos":
			g.req.p = int(g.req.p) + 1
		emit_ev("pets", 1)
		if e != null:
			fx(e, "💕")
			e.happy = true
			sound.emit("pet_happy", e.pos)
		dirty = true
		return
	if a == "fome":
		if S.money < 1:
			toast("Não tens dinheiro suficiente.")
			return
		S.money -= 1
		emit_ev("feed", 1)
	if a == "banho":
		if g.get("req") != null and g.req.t == "banho":
			g.req.p = int(g.req.p) + 1
		emit_ev("baths", 1)
	if not (a in NEEDS):
		return
	g[a] = clamp(g[a] + (45.0 if a == "banho" else 34.0) + use_stock(a), 0, 100)
	if e != null:
		pet_do(e, {"fome": "eat", "sede": "drink", "banho": "bath", "diver": "play"}[a])
	update_levels()
	dirty = true

func fx(e: Dictionary, txt: String) -> void:
	var l := Label3D.new()
	l.text = txt
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.font_size = 72
	l.pixel_size = 0.006
	l.no_depth_test = true
	l.position = Vector3(0, e.m.height + 0.5, 0)
	e.m.add_child(l)
	var tw := create_tween()
	tw.tween_property(l, "position:y", e.m.height + 1.4, 1.5)
	tw.parallel().tween_property(l, "modulate:a", 0.0, 1.5)
	tw.tween_callback(l.queue_free)

func pet_trip(g: Dictionary, L: Dictionary, dest: String) -> bool:
	var e = pets.get(int(g.id))
	if e == null or e.wander < 0 or e.trip:
		return false
	var i: int = e.wander
	if e.act != null and e.act.type == "bath":
		world.set_bath(i, false)
	e.act = null
	e.lift = 0.0
	e.wander = -1
	e.trip = true
	e.dest = dest
	e.speed = e.base * 1.4
	set_leash(e, L, "go")
	dirty = true
	return true

func arrive_room(e: Dictionary) -> void:
	var g = guest_of(e)
	var by_player: bool = e.leash != null and e.leash.kind == "player"
	set_leash(e, null, "")
	e.dest = ""
	e.escort = null
	if g == null:
		e.trip = false
		return
	var i := room_of(e)
	nav_pet(e, world.room_point(i, "center"), func():
		e.trip = false
		e.speed = e.base
		e.wander = i
		e.idle = 1.0
	)
	if by_player:
		toast("{p} voltou ao quarto.", {"p": g.pet})
	dirty = true

func vet_fee() -> int:
	if int(S.up.clinica) > 0:
		for k in staff_ents:
			if staff_ents[k].role == "vet":
				return 0
		return int(round((20 + 5 * stars()) / 2.0))
	return 20 + 5 * stars()

func vet_spot() -> Array:
	if int(S.up.clinica) > 0 and world.built.has("clinic"):
		return [World.CLINIC.table, World.CLINIC.wait, 1.6]
	return [World.TOWN_VET.table, World.TOWN_VET.walk, 1.7]

func in_park(p: Vector3) -> bool:
	return p.z < -15.6 and p.z > -35.5 and abs(p.x) < 16.0

func trip_tick(e: Dictionary) -> void:
	var g = guest_of(e)
	if g == null:
		return
	var i := room_of(e)
	var p: Vector3 = e.pos
	if e.leash != null:
		var lp = leader_pos(e)
		if lp == null:
			return
		if e.phase == "go" and e.dest == "park" and in_park(p) and in_park(lp):
			start_course(e)
		elif e.phase == "go" and e.dest == "vet":
			var vs := vet_spot()
			if Vector2(p.x - vs[0].x, p.z - vs[0].z).length() < vs[2] + 0.8 and Vector2(lp.x - vs[0].x, lp.z - vs[0].z).length() < vs[2] + 1.8:
				start_vet(e)
		elif e.phase == "back" and world.in_room(i, p):
			arrive_room(e)
	elif e.phase == "wait" and e.escort == null and e.path.is_empty() and leading_pet("player") == null:
		var pp := player.global_position
		if Vector2(pp.x - p.x, pp.z - p.z).length() < 1.6:
			set_leash(e, {"kind": "player"}, "back")
			if e.dest == "esc":
				e.dest = ""
			toast("{p} vai contigo de volta ao quarto.", {"p": g.pet})
			sound.emit("pet_happy", e.pos)

func start_course(e: Dictionary) -> void:
	set_leash(e, null, "course")
	e.speed = e.base * 1.9
	var pts := []
	for c in World.COURSE:
		pts.append({"p": c[0], "h": c[1]})
	if int(S.up.piscina) > 0:
		pts.insert(14, {"p": World.POOL + Vector3(-2.4, 0, 0)})
		pts.insert(15, {"p": World.POOL + Vector3(2.4, 0, 0)})
	nav_pet(e, pts[0].p, func():
		go_straight(e, pts, func():
			var gg = guest_of(e)
			e.speed = e.base * 1.4
			if gg == null:
				return
			gg.diver = clamp(gg.diver + (70 if int(S.up.piscina) > 0 else 55), 0, 100)
			var dirt := -8.0 if not raining else -22.0
			gg.banho = clamp(gg.banho + (12 if int(S.up.piscina) > 0 else dirt), 0, 100)
			gg.parks = int(gg.get("parks", 0)) + 1
			if gg.get("req") != null and gg.req.t == "parque":
				gg.req.p = int(gg.req.p) + 1
			emit_ev("parks", 1)
			fx(e, "🏆")
			e.happy = true
			sound.emit("pet_happy", e.pos)
			var n := 0
			for id in pets:
				if pets[id].phase == "wait":
					n += 1
			e.phase = "wait"
			go_straight(e, [World.PARK_WAIT + Vector3(-2.5 + (n % 6) * 1.0, 0, -0.6 - floor(n / 6.0) * 1.0)])
			if e.escort == null:
				toast("{p} acabou o percurso. Vai buscá-lo ao parque!", {"p": gg.pet})
			dirty = true
		)
	)

func start_vet(e: Dictionary) -> void:
	var vs := vet_spot()
	set_leash(e, null, "treat")
	go_straight(e, [vs[0]], func():
		e.act = {"type": "sleep", "t": 0.0, "dur": 999.0}
		e.lift = 0.9
		fx(e, "💉")
		get_tree().create_timer(4.5).timeout.connect(func():
			var gg = guest_of(e)
			e.act = null
			e.lift = 0.0
			if gg == null:
				return
			gg.erase("sick")
			gg.sickR = 0.0
			var fee := vet_fee()
			if fee > 0:
				S.money = max(0, S.money - fee)
			emit_ev("vet", 1)
			fx(e, "✚")
			if fee > 0:
				toast("🩺 {p} está curado! Consulta: −{m}. Leva-o de volta ao quarto.", {"p": gg.pet, "m": D.fmt(fee)})
			else:
				toast("🩺 {p} está curado! Leva-o de volta ao quarto.", {"p": gg.pet})
			e.phase = "wait"
			go_straight(e, [vs[1]])
			dirty = true
		)
	)

# ===================== cocós, xixis e doenças =====================
func add_mess_part(g: Dictionary, e: Dictionary) -> void:
	var id := int(g.id)
	if not mess_nodes.has(id):
		mess_nodes[id] = []
	var pos: Vector3 = e.pos + Vector3(rng.randf_range(-0.3, 0.3), 0, rng.randf_range(-0.3, 0.3))
	var mi := MeshInstance3D.new()
	if rng.randf() < 0.55:
		var sm := SphereMesh.new()
		sm.radius = 0.09
		sm.height = 0.12
		mi.mesh = sm
		mi.material_override = Mats.glossy("#5a3a1e", 0.45)
		mi.position = pos + Vector3(0, 0.08, 0)
		var top := MeshInstance3D.new()
		var sm2 := SphereMesh.new()
		sm2.radius = 0.055
		sm2.height = 0.09
		top.mesh = sm2
		top.material_override = mi.material_override
		top.position = Vector3(0, 0.07, 0)
		mi.add_child(top)
	else:
		var cm := CylinderMesh.new()
		cm.top_radius = 0.28
		cm.bottom_radius = 0.28
		cm.height = 0.005
		mi.mesh = cm
		var pm := StandardMaterial3D.new()
		pm.albedo_color = Color(0.9, 0.8, 0.25, 0.55)
		pm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		pm.roughness = 0.05
		mi.material_override = pm
		mi.position = pos + Vector3(0, 0.05, 0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	mess_nodes[id].append(mi)

func clear_mess(id: int) -> void:
	for n in mess_nodes.get(id, []):
		n.queue_free()
	mess_nodes.erase(id)

func mess_tick(g: Dictionary, e: Dictionary, dt: float) -> void:
	if e.trip or e.wander < 0:
		return
	if not g.has("messT"):
		g.messT = 30.0 + rng.randf() * 25.0
	g.messT -= dt
	if g.messT > 0:
		return
	g.messT = 38.0 + rng.randf() * 30.0
	if int(g.get("mess", 0)) >= 4:
		return
	g.mess = int(g.get("mess", 0)) + 1
	g.messMax = max(int(g.get("messMax", 0)), g.mess)
	if g.get("req") != null and g.req.t == "limpo" and g.mess >= 2:
		g.req.fail = true
	add_mess_part(g, e)
	dirty = true

func sick_tick(g: Dictionary, e: Dictionary, dt: float) -> void:
	if e.trip or g.get("sick", false):
		return
	var bad: bool = int(g.get("mess", 0)) >= 3 or min(min(g.fome, g.sede), min(g.banho, g.diver)) < 12
	g.sickR = float(g.get("sickR", 0.0)) + dt * (1.0 if bad else 0.0) + (40.0 if rng.randf() < dt * 0.0018 else 0.0)
	if g.sickR > 28:
		g.sick = true
		g.wasSick = true
		g.sickR = 0.0
		fx(e, "🤒")
		var has_vet := false
		for k in staff_ents:
			if staff_ents[k].role == "vet":
				has_vet = true
		toast("🤒 {p} ficou doente! A veterinária vai tratar dele." if has_vet else "🤒 {p} ficou doente! Leva-o ao veterinário.", {"p": g.pet})
		sound.emit("sick", e.pos)
		dirty = true

# ===================== ajudantes =====================
const HATS := {"comida": "chef", "banho": "gorro", "brincar": "bone", "rece": "rece", "vet": "vet"}

func new_staff(role: String) -> Dictionary:
	var used := {}
	for s in S.staff:
		used[s.name] = true
	var free := []
	for n in D.STAFF_NAMES:
		if not used.has(n):
			free.append(n)
	var names: Array = free if not free.is_empty() else D.STAFF_NAMES
	return {"role": role, "name": names[rng.randi() % names.size()], "lvl": 1, "xp": 0, "trait": D.TRAIT_IDS[rng.randi() % D.TRAIT_IDS.size()], "en": 100.0, "skin": HumanModel.SKINS[rng.randi() % HumanModel.SKINS.size()], "female": rng.randf() < 0.5, "hair": HumanModel.HAIRS[rng.randi() % HumanModel.HAIRS.size()], "style": rng.randi() % 5}

func sync_staff(walk_in: bool) -> void:
	for u in D.UPS:
		if u.has("role"):
			var have := 0
			for s in S.staff:
				if s.role == u.role:
					have += 1
			for k in range(have, int(S.up.get(u.id, 0))):
				var st := new_staff(u.role)
				S.staff.append(st)
				if walk_in:
					toast("{n} juntou-se à equipa!", {"n": st.name})
	for k in S.staff.size():
		if not staff_ents.has(k):
			spawn_staff(S.staff[k], k, walk_in)

func rest_spot(k: int) -> Vector3:
	var pts := [World.Pc(World.C, 246, 9.6), World.Pc(World.C, 252, 9.6), World.Pc(World.C, 258, 10.2), World.Pc(World.C, 282, 10.4), World.Pc(World.C, 296, 9.8), World.Pc(World.C, 242, 8.3)]
	return pts[k % pts.size()]

func spawn_staff(st: Dictionary, k: int, walk_in: bool) -> void:
	var R: Dictionary = D.ROLES[st.role]
	var look := {"skin": st.get("skin", "#e8b68e"), "shirt": R.shirt, "pants": "#2f3542", "shoes": "#22252b", "hair": st.get("hair", "#2a1d15"), "style": int(st.get("style", 0)), "female": st.get("female", false), "hat": HATS.get(st.role, ""), "hatc": R.shirt, "coat": st.role == "vet", "apron": "#ffffff" if st.role == "comida" else ""}
	var npc := make_human(look, R.ic + " " + st.name)
	npc.role = st.role
	npc.st = st
	npc.slot = k
	npc.wait = 1.0
	npc.cool = 2.0
	npc.doing = 0.0
	npc.task = null
	npc.job = null
	npc.escort = null
	npc.speed = staff_speed(st)
	staff_ents[k] = npc
	var home: Vector3
	if st.role == "rece":
		home = Vector3(0, 0, 8.6)
	elif st.role == "vet" and world.built.has("clinic"):
		home = World.CLINIC.stand
	else:
		home = rest_spot(k)
	if walk_in:
		npc.pos = street_point(true)
		walk(npc, home, func():
			npc.at_rest = true
			if st.role == "rece":
				face(npc, World.DESK + Vector3(0, 0, 5))
		)
	else:
		npc.pos = home
		npc.at_rest = true
		if st.role == "rece":
			npc.yaw = 0.0
	npc.m.position = npc.pos

func staff_speed(st: Dictionary) -> float:
	var s := 1.6 * (1.0 + 0.06 * (int(st.lvl) - 1))
	if st.trait == "rapido":
		s *= 1.2
	elif st.trait == "perfeccionista":
		s *= 0.9
	if float(st.en) < 20:
		s *= 0.7
	return s

func staff_work(h: Dictionary) -> void:
	var st: Dictionary = h.st
	st.xp = int(st.xp) + 10
	st.en = max(0.0, float(st.en) - (10.0 if st.trait == "preguicoso" else 6.0))
	var nl := 0
	for x in D.LVL_XP:
		if int(st.xp) >= int(x):
			nl += 1
	if nl > int(st.lvl) and nl <= 5:
		st.lvl = nl
		toast("⭐ {n} subiu para o nível {l}!", {"n": st.name, "l": nl})
	h.speed = staff_speed(st)

func staff_salary(st: Dictionary) -> int:
	return int(D.ROLES[st.role].get("salary", 8)) + 2 * (int(st.get("lvl", 1)) - 1) + (-3 if st.trait == "preguicoso" else 0)

func helper_think(h: Dictionary) -> void:
	var st: Dictionary = h.st
	if h.role == "rece":
		return
	if float(st.en) < 15:
		h.tired = true
	if h.get("tired", false) and float(st.en) > 80:
		h.tired = false
	var best = null
	var bv := 58.0
	if not h.get("tired", false):
		for i in D.NROOMS:
			var g = S.rooms[i]
			if g == null:
				continue
			var e = pets.get(int(g.id))
			if e == null or e.wander < 0 or e.trip:
				continue
			if h.role == "banho" and int(g.get("mess", 0)) > 0:
				var key := "%d:limpar" % int(g.id)
				if not claims.has(key) or claims[key] == h:
					var v := 40.0 - 12.0 * int(g.mess)
					if v < bv:
						bv = v
						best = {"i": i, "gid": int(g.id), "k": "limpar", "key": key}
			for k in D.ROLES[h.role].needs:
				var key2 := "%d:%s" % [int(g.id), k]
				if (not claims.has(key2) or claims[key2] == h) and g[k] < bv:
					bv = g[k]
					best = {"i": i, "gid": int(g.id), "k": k, "key": key2}
	if best == null:
		if not h.get("at_rest", false):
			h.at_rest = true
			walk(h, rest_spot(h.slot), func(): h.pose = "sit")
		elif not h.walking:
			st.en = min(100.0, float(st.en) + (6.0 if st.trait == "preguicoso" else 10.0))
		return
	h.at_rest = false
	h.pose = ""
	claims[best.key] = h
	h.task = best
	var spot: Vector3
	match best.k:
		"fome":
			spot = world.room_point(best.i, "hfood")
		"sede":
			spot = world.room_point(best.i, "hwater")
		"banho":
			spot = world.room_point(best.i, "htub")
		_:
			spot = world.room_point(best.i, "hplay")
	walk(h, spot, func():
		var g = S.rooms[best.i]
		if g == null or int(g.id) != best.gid or h.task != best:
			claims.erase(best.key)
			h.task = null
			return
		h.pose = "work"
		h.doing = 1.6 * (1.3 if st.trait == "perfeccionista" else 1.0) / (1.0 + 0.08 * (int(st.lvl) - 1))
	)

func helper_tick(h: Dictionary, dt: float) -> void:
	var st: Dictionary = h.st
	if h.role == "rece":
		h.cool -= dt
		if h.cool <= 0:
			h.cool = 2.5
			for q in queue:
				if free_room_for(q.sp) >= 0:
					if accept(int(q.id), st.name):
						staff_work(h)
						h.pose = "work"
						get_tree().create_timer(1.2).timeout.connect(func(): h.pose = "")
					break
		return
	if h.role == "vet":
		vet_tick(h, dt)
		return
	if h.escort != null:
		var e = h.escort
		if not pets.has(e.gid) or not e.trip:
			h.escort = null
			h.wait = 0.5
			return
		if h.get("escort_ph", "") == "waitPet" and e.phase == "wait" and e.path.is_empty():
			var i := room_of(e)
			if i >= 0:
				set_leash(e, {"kind": "npc", "npc": h}, "back")
				h.escort_ph = "back"
				walk(h, world.room_point(i, "in"), func(): h.escort_ph = "done")
		if h.get("escort_ph", "") == "done" and e.leash == null:
			h.escort = null
			h.wait = 0.5
		return
	if h.walking:
		return
	if h.doing > 0:
		h.doing -= dt
		if h.doing <= 0:
			h.pose = ""
			var tk = h.task
			h.task = null
			if tk != null:
				claims.erase(tk.key)
			var g = S.rooms[tk.i] if tk != null else null
			if g != null and int(g.id) == tk.gid:
				if tk.k == "limpar":
					emit_ev("cleans", int(g.mess))
					g.mess = 0
					clear_mess(int(g.id))
				elif tk.k == "diver" and g.diver < 45 and rng.randf() < 0.6 and pet_trip(g, {"kind": "npc", "npc": h}, "park"):
					toast("{h} levou {p} ao parque!", {"h": st.name, "p": g.pet})
					h.escort = pets[int(g.id)]
					pets[int(g.id)].escort = h
					h.escort_ph = "go"
					walk(h, World.GIN + Vector3(0, 0, -0.5), func(): h.escort_ph = "waitPet")
				else:
					var bonus := 5.0 * (int(st.lvl) - 1) + (15.0 if st.trait == "perfeccionista" else (8.0 if st.trait == "alegre" else 0.0))
					g[tk.k] = clamp(g[tk.k] + 40.0 + bonus * 0.4 + use_stock(tk.k), 0, 100)
					if tk.k == "banho":
						if g.get("req") != null and g.req.t == "banho":
							g.req.p = int(g.req.p) + 1
						emit_ev("baths", 1)
					var e2 = pets.get(int(g.id))
					if e2 != null:
						pet_do(e2, {"fome": "eat", "sede": "drink", "banho": "bath", "diver": "play"}[tk.k])
				staff_work(h)
				update_levels()
				dirty = true
			h.wait = 0.4
		return
	h.wait -= dt
	if h.wait <= 0:
		h.wait = 1.2
		helper_think(h)

func vet_tick(h: Dictionary, dt: float) -> void:
	var J = h.job
	var stand: Vector3 = World.CLINIC.stand if world.built.has("clinic") else rest_spot(h.slot)
	if J != null:
		var e = pets.get(J.gid)
		var g = guest_of(e) if e != null else null
		if e == null or g == null:
			if e != null and e.leash != null and e.leash.get("npc") == h:
				set_leash(e, null, "")
			h.job = null
			walk(h, stand)
			return
		if J.ph == "treat":
			J.t -= dt
			h.pose = "work"
			if J.t <= 0:
				h.pose = ""
				g.erase("sick")
				g.sickR = 0.0
				emit_ev("vet", 1)
				staff_work(h)
				e.act = null
				e.lift = 0.0
				fx(e, "✚")
				toast("🩺 {h} curou {p}.", {"h": h.st.name, "p": g.pet})
				set_leash(e, {"kind": "npc", "npc": h}, "back")
				e.trip = true
				J.ph = "back"
				walk(h, world.room_point(room_of(e), "in"), func(): J.ph = "done")
				dirty = true
		elif J.ph == "done" and e.leash == null:
			h.job = null
			walk(h, stand)
		return
	if h.walking:
		return
	h.cool -= dt
	if h.cool > 0:
		return
	h.cool = 1.5
	if not world.built.has("clinic") or leading_pet(h) != null:
		return
	for i in D.NROOMS:
		var g = S.rooms[i]
		if g == null or not g.get("sick", false):
			continue
		var e = pets.get(int(g.id))
		if e == null or e.trip or e.wander < 0:
			continue
		h.job = {"gid": int(g.id), "ph": "fetch"}
		toast("🩺 {h} vai buscar {p} para o tratar.", {"h": h.st.name, "p": g.pet})
		walk(h, world.room_point(i, "in"), func():
			if h.job == null or h.job.gid != int(g.id):
				return
			if not pet_trip(g, {"kind": "npc", "npc": h}, "clinicV"):
				h.job = null
				return
			h.job.ph = "go"
			walk(h, World.CLINIC.stand, func():
				var ee = pets.get(int(g.id))
				if ee == null or ee.leash == null or ee.leash.get("npc") != h:
					h.job = null
					return
				set_leash(ee, null, "treat")
				go_straight(ee, [World.CLINIC.table], func():
					ee.act = {"type": "sleep", "t": 0.0, "dur": 999.0}
					ee.lift = 0.9
					fx(ee, "💉")
					if h.job != null:
						h.job.ph = "treat"
						h.job.t = 4.5
				)
			)
		)
		return

func salary_tick(dt: float) -> void:
	var tot := 0
	for st in S.staff:
		tot += staff_salary(st)
	if tot == 0:
		S.payT = 0.0
		return
	S.payT = float(S.payT) + dt
	if S.payT < D.PAY_EVERY:
		return
	S.payT = 0.0
	if S.money >= tot:
		S.money -= tot
		toast("💼 Salários pagos à equipa: −{m}", {"m": D.fmt(tot)})
	else:
		S.money = 0
		S.rep = max(0, S.rep - 3)
		toast("💼 Não chegou para os salários! A reputação baixou.")

# ===================== missões, conquistas, álbum, prémio do mês =====================
func day_key(ts := -1.0) -> String:
	var d := Time.get_date_dict_from_unix_time(int(ts if ts >= 0 else Time.get_unix_time_from_system()))
	return "%04d-%02d-%02d" % [d.year, d.month, d.day]

func month_key() -> String:
	var d := Time.get_date_dict_from_system()
	return "%04d-%02d" % [d.year, d.month]

func ensure_missions() -> void:
	var day := day_key()
	if S.mis != null and S.mis.day == day:
		return
	var h := 7
	for k in day.length():
		h = (h * 31 + day.unicode_at(k)) % 2147483647
	var pool: Array = D.MISSION_POOL.duplicate()
	var sc := 1.0 + (stars() - 1) * 0.25
	var lst := []
	while lst.size() < 3 and not pool.is_empty():
		h = (h * 1103515245 + 12345) % 2147483648
		var m: Dictionary = pool[h % pool.size()]
		pool.erase(m)
		if not (m.id == "vet" and stars() < 2):
			lst.append({"id": m.id, "ev": m.ev, "goal": max(1, int(round(m.g * (1.0 if m.id == "vet" else sc)))), "p": 0, "done": false})
	S.mis = {"day": day, "list": lst, "bonus": false}

func mission_reward() -> int:
	return int(round((40 + 30 * stars()) / 10.0)) * 10

func emit_ev(ev: String, n := 1) -> void:
	if ev != "accept" and ev != "feed":
		S.cnt[ev] = int(S.cnt.get(ev, 0)) + n
	ensure_missions()
	for m in S.mis.list:
		if not m.done and m.ev == ev:
			m.p = min(int(m.goal), int(m.p) + n)
			if int(m.p) >= int(m.goal):
				m.done = true
				var r := mission_reward()
				S.money += r
				S.earned += r
				var dd = null
				for x in D.MISSION_POOL:
					if x.id == m.id:
						dd = x
				toast("🎯 Missão cumprida: {t}! +{m}", {"t": [dd.t, {"n": m.goal}], "m": D.fmt(r)})
				sound.emit("fanfare", Vector3.ZERO)
	var all := true
	for m in S.mis.list:
		if not m.done:
			all = false
	if all and not S.mis.bonus:
		S.mis.bonus = true
		var r2 := mission_reward() * 2
		S.money += r2
		S.earned += r2
		toast("🎉 Todas as missões de hoje! Bónus +{m}", {"m": D.fmt(r2)})
	check_ach()
	dirty = true

func ach_prog(a: Dictionary) -> Array:
	match a.get("special", ""):
		"stars":
			return [stars(), int(a.g)]
		"rooms":
			return [int(S.up.rooms), int(a.g)]
		"team":
			return [S.staff.size(), int(a.g)]
	return [min(int(a.g), int(S.cnt.get(a.c, 0))), int(a.g)]

func check_ach() -> void:
	for a in D.ACH:
		if not S.ach.get(a.id, false):
			var pr := ach_prog(a)
			if pr[0] >= pr[1]:
				S.ach[a.id] = true
				S.money += int(a.r)
				S.earned += int(a.r)
				toast("🏆 Conquista: {n}! +{m}", {"n": [a.n, {}], "m": D.fmt(a.r)})
				sound.emit("fanfare", Vector3.ZERO)

func mark_seen(g: Dictionary) -> void:
	var a = S.seen.get(g.sp)
	if a == null:
		a = {}
		S.seen[g.sp] = a
	var key := str(int(g.coat))
	if a.has(key):
		return
	var first: bool = a.is_empty()
	a[key] = true
	var r := 0
	if first:
		r += 25
		toast("📖 Nova espécie no álbum: {e} {n}! +{m}", {"e": D.SPECIES[g.sp].e, "n": [D.SPECIES[g.sp].n, {}], "m": D.fmt(25)})
	if D.is_rare(g.sp, int(g.coat)):
		r += 60
		toast("✨ Pelagem rara de {n}! +{m}", {"n": [D.SPECIES[g.sp].n, {}], "m": D.fmt(60)})
	if a.size() == D.COATS[g.sp].size():
		r += 120
	S.money += r
	S.earned += r

func month_add(st: int) -> void:
	month_roll()
	S.month.sum = float(S.month.sum) + st
	S.month.n = int(S.month.n) + 1

func month_roll() -> void:
	var k := month_key()
	var M = S.month
	if M != null and M.k != k and int(M.n) >= 8 and float(M.sum) / int(M.n) >= 4.5:
		S.trophies.append({"k": M.k})
		S.money += 1000
		S.earned += 1000
		toast("🏆 Ganhaste o prémio «Melhor Hotel do Algarve» de {m}! +{v}", {"m": M.k, "v": D.fmt(1000)})
	if M == null or M.k != k:
		S.month = {"k": k, "sum": 0.0, "n": 0}

# ===================== franquias, loja, animal próprio, regresso =====================
func fr_income() -> float:
	var n := 0.0
	for f in D.FRANCH:
		n += float(f.inc) * int(S.fr.get(f.id, 0))
	return n

func fr_buy(id: String) -> void:
	var f = null
	for x in D.FRANCH:
		if x.id == id:
			f = x
	if f == null:
		return
	var L := int(S.fr.get(id, 0))
	if L >= 5:
		return
	if stars() < int(f.stars):
		toast("Precisas de {n} estrelas.", {"n": f.stars})
		return
	var c: int = int(f.cost) if L == 0 else int(floor(float(f.cost) * 0.5 * L))
	if S.money < c:
		toast("Não tens dinheiro suficiente.")
		return
	S.money -= c
	S.fr[id] = L + 1
	if L == 0:
		toast("🏙️ Abriste o hotel de {n}!", {"n": [f.n, {}]})
	else:
		toast("🏙️ {n} melhorado para o nível {l}.", {"n": [f.n, {}], "l": L + 1})
	sound.emit("coin", Vector3.ZERO)
	dirty = true

func buy_product(id: String) -> void:
	for p in D.PRODUCTS:
		if p.id == id:
			if S.money < int(p.c):
				toast("Não tens dinheiro suficiente.")
				return
			S.money -= int(p.c)
			S.stock[id] = int(S.stock.get(id, 0)) + int(p.pack)
			toast("🛒 +{k} {n}", {"k": p.pack, "n": [p.n, {}]})
			sound.emit("coin", Vector3.ZERO)
			dirty = true

func set_mine(data: Dictionary) -> void:
	var sp: String = data.get("sp", "cao")
	if not (sp in D.MINE_SP):
		return
	var nm: String = str(data.get("name", "")).strip_edges().substr(0, 14)
	if nm == "":
		nm = "Patudo"
	if S.mine == null:
		if S.money < 150:
			toast("Não tens dinheiro suficiente.")
			return
		S.money -= 150
		toast("🐾 {n} é agora o teu companheiro!", {"n": nm})
	S.mine = {"sp": sp, "coat": int(data.get("coat", 0)), "name": nm, "collar": data.get("collar", D.COLLARS[0])}
	spawn_mine()
	dirty = true

func spawn_mine() -> void:
	if mine != null:
		mine.m.queue_free()
		mine = null
	if S.mine == null:
		return
	var m := PetModel.new()
	pets_root.add_child(m)
	m.setup(S.mine.sp, int(S.mine.coat), S.mine.collar)
	var p := player.global_position + Vector3(0.8, 0, 0.8)
	mine = {"gid": -1, "m": m, "pos": Vector3(p.x, 0, p.z), "yaw": 0.0, "path": [], "cb": null, "speed": 3.2, "base": 3.2, "leash": {"kind": "player"}, "jump": 0.0, "lift": 0.0, "act": null, "happy": true, "moving": false, "wander": -1, "trip": false, "phase": "mine"}
	var tag := Label3D.new()
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tag.font_size = 40
	tag.pixel_size = 0.005
	tag.outline_size = 10
	tag.text = "🐾 " + S.mine.name
	tag.position = Vector3(0, m.height + 0.25, 0)
	tag.visibility_range_end = 20.0
	m.add_child(tag)

func pet_mine() -> void:
	if mine == null:
		return
	fx(mine, "💕")
	emit_ev("pets", 1)
	toast("💕 {n} adorou as festinhas!", {"n": S.mine.name})
	sound.emit("pet_happy", mine.pos)

func welcome_back():
	var now := Time.get_unix_time_from_system()
	var today := day_key(now)
	var yk := day_key(now - 86400)
	var daily := 0
	if S.daily.last != today:
		S.daily.streak = min(7, int(S.daily.streak) + 1) if S.daily.last == yk else 1
		S.daily.last = today
		daily = int(round(D.DAILY[int(S.daily.streak) - 1] * (1.0 + (stars() - 1) * 0.25) / 10.0)) * 10
	var mins := 0.0
	if float(S.lastPlay) > 0:
		mins = clamp((now - float(S.lastPlay)) / 60.0, 0.0, 480.0)
	var team := int(S.staff.size() * 3 * mins) if mins >= 3 else 0
	var frv := int(fr_income() * mins) if mins >= 3 else 0
	if daily + team + frv <= 0:
		return null
	pending_back = daily + team + frv
	return {"daily": daily, "streak": int(S.daily.streak), "team": team, "fr": frv, "mins": int(mins), "total": daily + team + frv}

func collect_back() -> void:
	S.money += pending_back
	S.earned += pending_back
	pending_back = 0
	sound.emit("coin", Vector3.ZERO)
	dirty = true

# ===================== concursos, imprevistos e meteorologia =====================
func events_tick(dt: float) -> void:
	if contest == null and t >= ev_next:
		var any := false
		for g in S.rooms:
			if g != null:
				any = true
		if any:
			var ty := "agilidade" if last_ev == "beleza" else "beleza"
			last_ev = ty
			contest = {"type": ty, "ends": t + 120.0}
			toast("🏅 Concurso de beleza daqui a 2 minutos! Banhos e mimos ajudam." if ty == "beleza" else "🏃 Prova de agilidade daqui a 2 minutos! Leva os animais ao parque.")
		else:
			ev_next = t + 60.0
	if contest != null and t >= contest.ends:
		var ty2: String = contest.type
		contest = null
		ev_next = t + 480.0 + rng.randf() * 300.0
		var best = null
		var bs := 0.0
		for g in S.rooms:
			if g == null:
				continue
			var sc: float = (g.banho * 0.5 + D.happy(g) * 0.5 + int(g.get("loveN", 0)) * 3) if ty2 == "beleza" else (int(g.get("parks", 0)) * 30 + g.diver * 0.4)
			if sc > bs:
				bs = sc
				best = g
		if best != null and bs >= (72 if ty2 == "beleza" else 60):
			var pr := 60 + 40 * stars()
			S.money += pr
			S.earned += pr
			best.diver = clamp(best.diver + 15, 0, 100)
			S.cnt.wins = int(S.cnt.get("wins", 0)) + 1
			var e = pets.get(int(best.id))
			if e != null:
				fx(e, "🏅")
			toast("🏅 {p} ganhou o concurso! +{m}", {"p": best.pet, "m": D.fmt(pr)})
			sound.emit("fanfare", Vector3.ZERO)
		else:
			toast("Nenhum animal estava pronto para o concurso.")
		dirty = true

var leak_nodes := {}
func set_leak_fx(i: int, on: bool) -> void:
	if on and not leak_nodes.has(i):
		var mi := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 1.0
		cm.bottom_radius = 1.0
		cm.height = 0.005
		mi.mesh = cm
		mi.material_override = world.get_water_mat()
		mi.position = world.W(i, 4.4, 0.4) + Vector3(0, 0.06, 0)
		add_child(mi)
		leak_nodes[i] = mi
	elif not on and leak_nodes.has(i):
		leak_nodes[i].queue_free()
		leak_nodes.erase(i)

func mishap_tick() -> void:
	if t < mis_next:
		return
	mis_next = t + 420.0 + rng.randf() * 360.0
	var runners := []
	var leaky := []
	for i in D.NROOMS:
		var g = S.rooms[i]
		if g == null:
			continue
		var e = pets.get(int(g.id))
		if e != null and not e.trip and e.wander >= 0 and g.sp != "tartaruga":
			runners.append(g)
		if not g.get("leak", false) and D.room_kind(i) == "":
			leaky.append(i)
	var opts := []
	if not runners.is_empty():
		opts.append("fuga")
	if not leaky.is_empty():
		opts.append("agua")
	if opts.is_empty():
		return
	if opts[rng.randi() % opts.size()] == "fuga":
		var g = runners[rng.randi() % runners.size()]
		var e = pets[int(g.id)]
		e.act = null
		e.lift = 0.0
		e.wander = -1
		e.trip = true
		e.dest = "esc"
		e.phase = "run"
		e.speed = e.base * 1.8
		var spots := [Vector3(-20, 0, 6), Vector3(20, 0, 8), Vector3(-9, 0, 19), Vector3(9, 0, 20), Vector3(-17, 0, -10), Vector3(18, 0, -11)]
		nav_pet(e, spots[rng.randi() % spots.size()], func():
			if e.trip:
				e.phase = "wait"
		)
		toast("🏃 {p} fugiu para o relvado! Vai apanhá-lo.", {"p": g.pet})
	else:
		var i: int = leaky[rng.randi() % leaky.size()]
		S.rooms[i].leak = true
		set_leak_fx(i, true)
		toast("💧 Fuga de água em {r}! Repara-a no cartão do animal.", {"r": room_name(i)})
	dirty = true

func weather_tick(variable: bool) -> void:
	if not variable:
		if raining:
			raining = false
		return
	if t < weather_next:
		return
	raining = not raining
	weather_next = t + (rng.randf_range(120, 220) if raining else rng.randf_range(700, 1300))
	toast("Está a chover: o parque tem lama e os animais voltam sujos." if raining else "Já parou de chover.")

# ===================== compras =====================
func can_buy(u: Dictionary) -> Array:
	var L := int(S.up.get(u.id, 0))
	var mx := D.up_max(u.id, S.up)
	if L >= mx:
		return [false, "max"]
	if u.has("needStars") and stars() < int(u.needStars):
		return [false, "stars"]
	if u.has("needRooms") and int(S.up.rooms) < int(u.needRooms):
		return [false, "rooms"]
	if u.has("needUp") and int(S.up.get(u.needUp, 0)) == 0:
		return [false, "up"]
	if S.money < D.up_cost(u.id, L):
		return [false, "money"]
	return [true, ""]

func buy(id: String) -> void:
	var u: Dictionary = D.UP_BY_ID.get(id, {})
	if u.is_empty():
		return
	var cb := can_buy(u)
	if not cb[0]:
		if cb[1] == "money":
			toast("Não tens dinheiro suficiente.")
		return
	var L := int(S.up.get(id, 0))
	S.money -= D.up_cost(id, L)
	S.up[id] = L + 1
	if u.has("role"):
		sync_staff(true)
	else:
		toast("{n} construído!", {"n": [u.n, {}]})
	sound.emit("build", Vector3.ZERO)
	refresh_world()
	check_ach()
	dirty = true

func set_decor(i: int, dec: Dictionary) -> void:
	S.decor[str(i)] = dec
	refresh_world()

# ===================== ciclo =====================
func record_trail() -> void:
	var p := player.global_position
	p.y = 0
	if player_trail.is_empty() or player_trail[player_trail.size() - 1].distance_to(p) > 0.25:
		player_trail.append(p)
		if player_trail.size() > 90:
			player_trail.remove_at(0)

func update(dt: float) -> void:
	record_trail()
	for id in pets.keys():
		if pets.has(id):
			step_pet(pets[id], dt)
	if mine != null:
		step_pet(mine, dt)
	for id in owners.keys():
		step_human(owners[id], dt)
	for k in staff_ents:
		step_human(staff_ents[k], dt)
	for o in leavers.duplicate():
		if o.get("dead", false):
			leavers.erase(o)
		else:
			step_human(o, dt)
	draw_leashes()
	acc += dt
	if acc >= 0.25:
		var d := acc
		acc = 0.0
		tick(d)

func draw_leashes() -> void:
	leash_mesh.clear_surfaces()
	var any := false
	var all_pets := pets.values()
	if mine != null:
		all_pets.append(mine)
	for e in all_pets:
		if e.leash == null:
			continue
		var a: Vector3
		if e.leash.kind == "player":
			a = player.hand_pos()
		else:
			var npc = e.leash.get("npc")
			if npc == null or not is_instance_valid(npc.m):
				continue
			a = npc.m.hand_pos()
		var m: PetModel = e.m
		var b := m.global_position + Vector3(0, m.body_h + m.height * 0.25, 0) + Basis(Vector3.UP, e.yaw) * Vector3(0, 0, m.height * 0.25)
		if not any:
			leash_mesh.surface_begin(Mesh.PRIMITIVE_TRIANGLES)
			any = true
		var n := 10
		var sag: float = clamp(2.0 - a.distance_to(b), 0.0, 1.2) * 0.35
		var prev := a
		for k in range(1, n + 1):
			var tt := float(k) / n
			var p := a.lerp(b, tt) - Vector3(0, sin(tt * PI) * sag, 0)
			var dir := (p - prev).normalized()
			var side := dir.cross(Vector3.UP).normalized() * 0.012
			if side.length() < 0.001:
				side = Vector3(0.012, 0, 0)
			var up2 := Vector3(0, 0.012, 0)
			for q in [[prev - side, prev + side, p + side, p - side], [prev - up2, prev + up2, p + up2, p - up2]]:
				for v in [q[0], q[1], q[2], q[0], q[2], q[3]]:
					leash_mesh.surface_set_normal(Vector3.UP)
					leash_mesh.surface_add_vertex(v)
			prev = p
	if any:
		leash_mesh.surface_end()

func tick(dt: float) -> void:
	t += dt
	S.lastPlay = Time.get_unix_time_from_system()
	if boost > 0:
		boost -= dt
	next_arrival -= dt
	if next_arrival <= 0:
		if queue.size() < 3:
			add_to_queue()
		next_arrival = arrival_interval()
	for k in range(queue.size() - 1, -1, -1):
		var q: Dictionary = queue[k]
		q.wait -= dt
		if q.wait <= 0:
			toast("{o} cansou-se de esperar e foi embora.", {"o": q.owner})
			S.rep = max(0, S.rep - 1)
			decline(int(q.id), true)
	var kb := 1.0 - 0.12 * int(S.up.beds)
	for i in D.NROOMS:
		var g = S.rooms[i]
		if g == null:
			continue
		var e = pets.get(int(g.id))
		var d: float = float(D.SPECIES[g.sp].dec) * kb * dt * (1.3 if g.get("sick", false) else 1.0)
		g.fome = clamp(g.fome - 1.3 * d + int(S.up.feeder) * 0.45 * dt, 0, 100)
		g.sede = clamp(g.sede - 1.15 * d + int(S.up.fonte) * 0.45 * dt, 0, 100)
		g.banho = clamp(g.banho - 0.85 * d - (0.35 * dt if g.get("leak", false) else 0.0), 0, 100)
		g.diver = clamp(g.diver - 1.1 * d, 0, 100)
		if e != null:
			mess_tick(g, e, dt)
			sick_tick(g, e, dt)
			if e.trip:
				trip_tick(e)
			else:
				pet_idle(e, dt)
			var h := D.happy(g)
			e.happy = h > 75 or e.happy and e.act != null
			var low := ""
			for k in NEEDS:
				if g[k] < 25:
					low = k
			var mood := ""
			if e.trip:
				mood = "🦮" if e.leash != null else ("⏳" if e.phase == "wait" else "🤸")
			elif g.get("sick", false):
				mood = "🤒"
			elif low != "":
				mood = {"fome": "🍖", "sede": "💧", "banho": "🛁", "diver": "🎾"}[low]
			elif int(g.get("mess", 0)) >= 2:
				mood = "💩"
			elif e.act != null and e.act.type == "sleep":
				mood = "💤"
			elif h > 75:
				mood = "😍"
			elif h > 55:
				mood = "🙂"
			elif h > 35:
				mood = "😐"
			else:
				mood = "😢"
			if e.mood != mood:
				e.mood = mood
				e.tag.text = mood + " " + g.pet
		g.hs = float(g.get("hs", 0.0)) + D.happy(g) * dt
		g.ht = float(g.get("ht", 0.0)) + dt
		g.left = float(g.left) - dt
		if g.left <= 0 and not g.get("out", false):
			g.out = true
			checkout(i)
	for k in staff_ents:
		helper_tick(staff_ents[k], dt)
	salary_tick(dt)
	fr_acc += fr_income() * dt / 60.0
	fr_t += dt
	if fr_t >= 120:
		fr_t = 0.0
		var m := int(floor(fr_acc))
		fr_acc -= m
		if m > 0:
			S.money += m
			S.earned += m
			toast("🏙️ As franquias renderam +{m}", {"m": D.fmt(m)})
	events_tick(dt)
	mishap_tick()
	level_acc += dt
	if level_acc > 2:
		level_acc = 0.0
		update_levels()
		ensure_missions()
		check_ach()
	changed.emit()

# seta-guia: para onde levar o animal que vai pela trela, ou onde está o que espera
func arrow_target():
	var led = leading_pet("player")
	if led != null:
		if led.phase == "go":
			return vet_spot()[0] if led.dest == "vet" else World.PARK_WAIT
		elif led.phase == "back":
			var i := room_of(led)
			if i >= 0:
				return world.room_point(i, "center")
	else:
		for id in pets:
			var e = pets[id]
			if e.trip and e.phase == "wait" and e.escort == null:
				return e.pos
	if hint != null and t < hint.t:
		return hint.pos
	return null

func snapshot() -> Dictionary:
	S.lastPlay = Time.get_unix_time_from_system()
	for g in S.rooms:
		if g != null:
			g.erase("out")
	return S
