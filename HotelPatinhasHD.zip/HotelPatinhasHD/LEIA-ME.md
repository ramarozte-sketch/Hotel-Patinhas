# Hotel Patinhas HD (Godot 4)

Versão nova do Hotel Patinhas feita no motor de jogos **Godot 4.7**, com gráficos mais realistas.
É uma app **separada** ("Hotel Patinhas HD", pacote `pt.patinhas.hotelhd`): instala-se ao lado da versão normal e não mexe no progresso dela.

## O que tem

- O mesmo hotel: receção redonda com balcão curvo, átrio com fonte, quartos em leque, sala do pessoal, parque de acrobacias nas traseiras, pavilhões Nascente e Poente com galerias cobertas, gabinete veterinário, celeiro (6 celas, só cavalos e unicórnios), aviário (4 viveiros, só papagaios), lago gelado, piscina, luzes de festa, rua com lojas, carros e peões, e o veterinário do bairro.
- Todas as fases: hóspedes e fila na receção, pedidos especiais, clientes habituais, visitas surpresa, cuidados (ração, água, banho, brincar, mimos, limpar), cocós e xixis, doenças e veterinário, passeios pela trela até ao parque com percurso de obstáculos, fugas e fugas de água, ajudantes com nível, feitios, energia e salários, rececionista e veterinária, missões diárias, conquistas, álbum de pelagens raras, prémio do mês, franquias (também fora do jogo), prémio diário, concursos, épocas do ano, chuva com lama no parque, o teu próprio animal, decoração dos quartos, personagem, mapa com viagem rápida, modo foto e donativos por PayPal.
- Gráficos: materiais realistas com relevo (madeira, azulejo, pedra, telha, reboco, pelo), relva que ondula, árvores com folhas, água com reflexos e ondas, céu com nuvens, sol, lua e estrelas, sombras suaves, brilho das luzes à noite, nevoeiro ao longe e ciclo de dia e noite segundo a hora do telemóvel.
- Quatro opções de gráficos: **Ultra**, **Alta**, **Média** e **Leve** (Opções).
- Câmara: vista de cima, terceira pessoa e primeira pessoa. Zoom com dois dedos, rodar arrastando um dedo.
- Português, inglês e francês. As notificações aparecem no canto superior esquerdo.
- O progresso guarda-se sozinho no telemóvel.

## Como gerar o APK no GitHub

O mais simples é usar o mesmo repositório da versão normal:

1. No repositório, carrega em **Add file → Create new file** e escreve o nome `.github/workflows/apk-hd.yml`.
2. Abre o ficheiro `.github/workflows/apk-hd.yml` que vem dentro deste zip, copia o conteúdo todo, cola-o e carrega em **Commit changes**.
3. Envia o **HotelPatinhasHD.zip** para o repositório (Add file → Upload files), como fazes com o zip da versão normal.
4. Em **Actions**, abre "Gerar APK (Hotel Patinhas HD)". Quando acabar, o APK está em **Artifacts** (HotelPatinhasHD-apk).

Nas próximas versões basta enviar o zip novo. A primeira compilação demora mais (descarrega o Godot, ~1,3 GB); as seguintes usam a cópia guardada.

A chave de assinatura está em `android/hotelhd.jks` (palavra-passe `patinhas`). Mantém o repositório **privado** e não apagues esse ficheiro: todas as versões têm de ser assinadas com a mesma chave para instalarem por cima.

## Onde mexer

- `scripts/world.gd` — o mundo (edifícios, quartos, parque, celeiro, aviário, colisões e caminhos)
- `scripts/sim.gd` — as regras do jogo (hóspedes, cuidados, ajudantes, economia, missões…)
- `scripts/ui.gd` — a interface (topo, cartões, painéis, opções, donativos)
- `scripts/pet_model.gd`, `scripts/human_model.gd` — animais e pessoas
- `scripts/mats.gd`, `shaders/` — materiais, relva, água e céu
- `scripts/data.gd`, `scripts/data_gen.gd` — dados e traduções
