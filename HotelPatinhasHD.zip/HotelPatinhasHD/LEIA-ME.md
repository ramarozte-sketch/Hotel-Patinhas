# Hotel Patinhas HD (Godot 4)

Versão nova do Hotel Patinhas feita no motor de jogos **Godot 4.7**, com gráficos mais realistas.
É uma app **separada** ("Hotel Patinhas HD", pacote `pt.patinhas.hotelhd`): instala-se ao lado da versão normal e não mexe no progresso dela.

## O que tem

- O mesmo hotel: receção redonda com balcão curvo, átrio com fonte, quartos em leque, sala do pessoal, parque de acrobacias nas traseiras, pavilhões Nascente e Poente com galerias cobertas, gabinete veterinário, celeiro (6 celas, só cavalos e unicórnios), aviário (4 viveiros, só papagaios), lago gelado, piscina, luzes de festa, rua com lojas, carros e peões, e o veterinário do bairro.
- Todas as fases: hóspedes e fila na receção, pedidos especiais, clientes habituais, visitas surpresa, cuidados (ração, água, banho, brincar, mimos, limpar), cocós e xixis, doenças e veterinário, passeios pela trela até ao parque com percurso de obstáculos, fugas e fugas de água, ajudantes com nível, feitios, energia e salários, rececionista e veterinária, missões diárias, conquistas, álbum de pelagens raras, prémio do mês, franquias (também fora do jogo), prémio diário, concursos, épocas do ano, chuva com lama no parque, o teu próprio animal, decoração dos quartos, personagem, mapa com viagem rápida, modo foto e donativos por PayPal.
- Gráficos: materiais realistas com relevo (madeira, azulejo, pedra, telha, reboco, pelo), relva que ondula, árvores com folhas, água com reflexos e ondas, céu com nuvens, sol, lua e estrelas, sombras suaves, brilho das luzes à noite, nevoeiro ao longe e ciclo de dia e noite segundo a hora do telemóvel.
- Quatro opções de gráficos: **Ultra**, **Alta**, **Média** e **Leve** (Opções).
- Câmara: vista de cima, terceira pessoa e primeira pessoa. Zoom com dois dedos, rodar arrastando um dedo.
- Português, inglês e francês. As notificações aparecem no canto superior esquerdo.
- O progresso guarda-se sozinho no telemóvel.

## Novidades da versão 1.5

- Bairro novo à volta do hotel: lojas com traseiras e quintais, duas travessas com passadeiras, rua de trás com moradias algarvias (paredes brancas com barra colorida, portadas, azulejos, varandas, chaminés algarvias, jardins com muro, laranjeiras e caixa do correio), carros estacionados, praça com chafariz, calçada, bancos, quiosque, parque infantil e igreja com torre sineira, aldeia branca num monte com moinho, colinas no horizonte, mais carros e peões, pessoas a passear o cão e pássaros a voar. Pode-se andar por todo o bairro.

## Novidades da versão 1.4

- Pessoas redesenhadas em estilo fofinho: cabeça grande e redonda, olhos grandes com brilhos, bochechas rosadas, nariz pequenino e sorriso, corpo roliço, mãos e sapatos arredondados, penteados novos (franja, cabelo comprido, carrapito, marias-chiquinhas, topete) e passinhos mais saltitantes.

## Novidades da versão 1.3

- Nova opção **Cores** (em Opções): **Colorido** (cores vivas, a pensar nas crianças), **Natural** (o aspeto de sempre) ou **Realista** (cores sóbrias e verdes mais naturais, a pensar nos adultos). Ao mudar, o mundo volta a ser montado com as cores novas.

## Novidades da versão 1.2

- Ecrã de carregamento ao abrir o jogo: pegada a saltar, barra de progresso, o que está a ser preparado e dicas.

## Novidades da versão 1.1

- Entrada do hotel nova: fachada com pilares, pala com colunas e luzes, letreiro por cima, portas de vidro que abrem sozinhas e vasos com arbustos. As aberturas da receção para as galerias ficam fechadas com parede e janelas até comprares os pavilhões; depois passam a ter portas de vidro automáticas.
- Músicas novas, gravadas com instrumentos modelados (piano, guitarra, contrabaixo, acordeão, piano elétrico, vibrafone, cordas e escovas) e reverberação. Campainha da receção, moedas e fanfarra também soam mais naturais.
- Modo **Ultra** com muito mais pormenor: formas mais redondas, sombras mais finas, relva mais densa, árvores mais cheias, flores, pedras, folhas caídas, cogumelos e arbustos espalhados, mobiliário de rua, objetos no balcão; pessoas com dedos, gola, botões, cinto, relógio e madeixas; animais com íris, dedos, bigodes e tufos de pelo. Os pormenores pequenos só se desenham perto da câmara e os modelos ficam mais simples ao longe, para o jogo continuar fluido.

## Como gerar o APK no GitHub

O mais simples é usar o mesmo repositório da versão normal:

1. No repositório, carrega em **Add file → Create new file** e escreve o nome `.github/workflows/apk-hd.yml`.
2. Abre o ficheiro `.github/workflows/apk-hd.yml` que vem dentro deste zip, copia o conteúdo todo, cola-o e carrega em **Commit changes**.
3. Envia o **HotelPatinhasHD.zip** para o repositório (Add file → Upload files), como fazes com o zip da versão normal.
4. Em **Actions**, abre "Gerar APK (Hotel Patinhas HD)". Quando acabar, o APK está em **Artifacts** (HotelPatinhasHD-apk).

Nas próximas versões basta enviar o zip novo. A primeira compilação demora mais (descarrega o Godot, ~1,3 GB); as seguintes usam a cópia guardada.

A chave de assinatura está em `android/hotelhd.jks` (palavra-passe `patinhas`). Mantém o repositório **privado** e não apagues esse ficheiro: todas as versões têm de ser assinadas com a mesma chave para instalarem por cima.

## Onde mexer

- `scripts/world.gd` — o mundo (edifícios, quartos, parque, celeiro, aviário, colisões e caminhos)
- `scripts/sim.gd` — as regras do jogo (hóspedes, cuidados, ajudantes, economia, missões…)
- `scripts/ui.gd` — a interface (topo, cartões, painéis, opções, donativos)
- `scripts/pet_model.gd`, `scripts/human_model.gd` — animais e pessoas
- `scripts/mats.gd`, `shaders/` — materiais, relva, água e céu
- `scripts/data.gd`, `scripts/data_gen.gd` — dados e traduções
- `music/`, `sfx/` — músicas e sons; `tools/musica/` tem o programa (Python) que os gera
