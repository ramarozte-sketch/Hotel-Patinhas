#!/usr/bin/env bash
# Compila o APK do Hotel Patinhas HD (usado pelo GitHub Actions).
# Uso: bash ci/build.sh   (a partir de qualquer pasta)
set -euo pipefail

GODOT_VERSION="${GODOT_VERSION:-4.7.2}"
PROJ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${GITHUB_WORKSPACE:-$PROJ}/out"
G="$HOME/godot"
VER=$(grep -m1 -oP '^version/name="\K[^"]+' "$PROJ/export_presets.cfg" || echo "1.0")
echo "==> Projeto: $PROJ (versão $VER)"

# 1. Godot e modelos de exportação (ficam em cache em ~/godot)
mkdir -p "$G"
base="https://github.com/godotengine/godot/releases/download/${GODOT_VERSION}-stable"
if [ ! -x "$G/godot" ]; then
  echo "==> A descarregar o Godot $GODOT_VERSION"
  curl -fsSL -o "$G/godot.zip" "$base/Godot_v${GODOT_VERSION}-stable_linux.x86_64.zip"
  unzip -q -o "$G/godot.zip" -d "$G"
  rm "$G/godot.zip"
  mv -f "$G/Godot_v${GODOT_VERSION}-stable_linux.x86_64" "$G/godot"
  chmod +x "$G/godot"
fi
if [ ! -f "$G/templates/android_release.apk" ]; then
  echo "==> A descarregar os modelos de exportação (cerca de 1,3 GB)"
  rm -rf "$G/templates"
  curl -fsSL -o "$G/templates.tpz" "$base/Godot_v${GODOT_VERSION}-stable_export_templates.tpz"
  unzip -q -o "$G/templates.tpz" -d "$G" 'templates/android*' 'templates/version.txt'
  rm "$G/templates.tpz"
fi
ls -la "$G/templates"

TPL="$HOME/.local/share/godot/export_templates/${GODOT_VERSION}.stable"
mkdir -p "$TPL"
for t in android_debug.apk android_release.apk android_source.zip version.txt; do
  cp -f "$G/templates/$t" "$TPL/"
done

# 2. Chave de teste e definições do editor
rm -f "$HOME/debug.keystore"
keytool -genkeypair -noprompt -keystore "$HOME/debug.keystore" \
  -storepass android -keypass android -alias androiddebugkey \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -dname "CN=Android Debug,O=Android,C=US" < /dev/null

SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/usr/local/lib/android/sdk}}"
JDK="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")}"
echo "==> SDK: $SDK  Java: $JDK"
mkdir -p "$HOME/.config/godot"
MINOR=$(echo "$GODOT_VERSION" | cut -d. -f1,2)
for f in editor_settings-4.tres "editor_settings-${MINOR}.tres"; do
  cat > "$HOME/.config/godot/$f" <<EOF
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/android_sdk_path = "$SDK"
export/android/java_sdk_path = "$JDK"
export/android/debug_keystore = "$HOME/debug.keystore"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
EOF
done

# 3. Importar e exportar
cd "$PROJ"
"$G/godot" --headless --path . --import || true
"$G/godot" --headless --path . --import

export GODOT_ANDROID_KEYSTORE_RELEASE_PATH="$PROJ/android/hotelhd.jks"
export GODOT_ANDROID_KEYSTORE_RELEASE_USER="hotelhd"
export GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD="patinhas"
mkdir -p "$OUT"
APK="$OUT/HotelPatinhasHD-v${VER}.apk"
"$G/godot" --headless --path . --export-release "Android" "$APK"
ls -la "$OUT"
test -f "$APK"
echo "==> APK pronto: $APK"
