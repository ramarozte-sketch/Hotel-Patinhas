#!/usr/bin/env python3
# Hotel Patinhas HD · gera as músicas (instrumentos modelados + reverberação) e grava em .ogg
import numpy as np
from scipy import signal
import subprocess, sys, os

SR = 44100
rng = np.random.default_rng(7)

def midi_f(n):
    return 440.0 * 2 ** ((n - 69) / 12.0)

def adsr(n, a, d, s, r, hold):
    """envelope de n amostras: ataque a, decaimento d até s, solta r no fim da nota (hold amostras)"""
    t = np.arange(n) / SR
    env = np.ones(n)
    env = np.where(t < a, t / max(a, 1e-4), env)
    dm = (t >= a) & (t < a + d)
    env = np.where(dm, 1 - (1 - s) * (t - a) / max(d, 1e-4), env)
    env = np.where(t >= a + d, s, env)
    rel = t >= hold
    env = np.where(rel, env * np.exp(-(t - hold) / max(r, 1e-4)), env)
    return env

# ---------------- instrumentos ----------------
def piano(f, dur, vel=0.7):
    L = dur + 1.8
    n = int(L * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    B = 0.00035 * (f / 261.0) ** 0.5
    bright = 0.5 + vel * 0.8
    for k in range(1, 16):
        fk = k * f * np.sqrt(1 + B * k * k)
        if fk > 12000:
            break
        a = (1.0 / k ** (1.35 - 0.35 * bright)) * (1.0 if k == 1 else 0.85)
        # duas fases de decaimento (rápida e lenta), mais rápida nos agudos e nas parciais altas
        d1 = 0.25 / (1 + k * 0.35) * (440 / max(f, 80)) ** 0.25
        d2 = 2.6 / (1 + k * 0.22) * (440 / max(f, 80)) ** 0.45
        env = 0.55 * np.exp(-t / d1) + 0.45 * np.exp(-t / d2)
        for det in (-0.6, 0.6):
            ph = rng.random() * 6.28
            out += a * env * np.sin(2 * np.pi * fk * (1 + det / 1730.0) * t + ph) * 0.5
    # martelo
    hn = int(0.02 * SR)
    ham = rng.standard_normal(hn) * np.exp(-np.arange(hn) / (0.003 * SR)) * 0.25 * vel
    b, a2 = signal.butter(2, [min(f * 2, 5000) / (SR / 2), min(f * 8, 15000) / (SR / 2)], "band")
    out[:hn] += signal.lfilter(b, a2, ham)
    # soltar a tecla: abafador
    rel = t > dur
    out[rel] *= np.exp(-(t[rel] - dur) / 0.18)
    return out * vel

def ep(f, dur, vel=0.6):
    # piano elétrico (FM): carrier 1:1 com índice que decai + "tine" agudo
    L = dur + 1.4
    n = int(L * SR)
    t = np.arange(n) / SR
    idx = (1.4 * vel + 0.3) * np.exp(-t / 0.35) + 0.25
    mod = np.sin(2 * np.pi * f * t) * idx
    env = (0.6 * np.exp(-t / 0.5) + 0.4 * np.exp(-t / 2.4))
    out = np.sin(2 * np.pi * f * t + mod) * env
    out += 0.12 * vel * np.sin(2 * np.pi * f * 14.0 * t) * np.exp(-t / 0.05)
    out += 0.18 * np.sin(2 * np.pi * f * 2.0 * t + mod * 0.5) * np.exp(-t / 0.4)
    rel = t > dur
    out[rel] *= np.exp(-(t[rel] - dur) / 0.25)
    return out * vel * 0.8

def vibes(f, dur, vel=0.6):
    L = dur + 2.5
    n = int(L * SR)
    t = np.arange(n) / SR
    out = np.sin(2 * np.pi * f * t) * np.exp(-t / 1.8)
    out += 0.35 * np.sin(2 * np.pi * f * 4.0 * t) * np.exp(-t / 0.5)
    out += 0.15 * np.sin(2 * np.pi * f * 10.0 * t) * np.exp(-t / 0.12)
    out *= 1 + 0.25 * np.sin(2 * np.pi * 5.2 * t)  # motor do vibrafone
    rel = t > dur + 0.4
    out[rel] *= np.exp(-(t[rel] - dur - 0.4) / 0.5)
    return out * vel * 0.7

def guitar(f, dur, vel=0.6, pluck=0.18, steel=False):
    # guitarra modal: parciais com amplitude da posição de dedilhar e decaimento por frequência
    L = dur + 1.2
    n = int(L * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for k in range(1, 22):
        fk = k * f * (1 + 0.00008 * k * k)
        if fk > 11000:
            break
        a = abs(np.sin(np.pi * k * pluck)) / k ** (1.05 if steel else 1.35)
        dec = (3.2 if steel else 2.2) / (1 + 0.012 * fk ** 0.95 / 10)
        dec *= (196 / max(f, 70)) ** 0.25
        out += a * np.exp(-t / dec) * np.sin(2 * np.pi * fk * t + rng.random() * 6.28)
    att = int(0.004 * SR)
    out[:att] *= np.linspace(0, 1, att)
    nz = int(0.012 * SR)
    out[:nz] += rng.standard_normal(nz) * np.exp(-np.arange(nz) / (0.002 * SR)) * 0.08
    rel = t > dur
    out[rel] *= np.exp(-(t[rel] - dur) / 0.12)
    return out * vel * 0.55

def bass(f, dur, vel=0.7):
    L = dur + 0.6
    n = int(L * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for k, a in enumerate([1.0, 0.55, 0.3, 0.16, 0.08, 0.04], start=1):
        out += a * np.sin(2 * np.pi * f * k * t + rng.random()) * np.exp(-t / (1.6 / k ** 0.6))
    att = int(0.012 * SR)
    out[:att] *= np.linspace(0, 1, att) ** 0.5
    th = int(0.03 * SR)
    out[:th] += np.sin(2 * np.pi * 2 * f * np.arange(th) / SR) * np.exp(-np.arange(th) / (0.006 * SR)) * 0.4
    rel = t > dur
    out[rel] *= np.exp(-(t[rel] - dur) / 0.07)
    return np.tanh(out * 1.2) * vel * 0.8

def reed(f, dur, vel=0.6):
    # acordeão: duas palhetas ligeiramente desafinadas (musette), fole a respirar
    L = dur + 0.35
    n = int(L * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    vib = 1 + 0.002 * np.sin(2 * np.pi * 5.0 * t)
    for det in (-4.0, 4.0):
        ff = f * (1 + det / 1730.0)
        ph = 2 * np.pi * ff * np.cumsum(vib) / SR
        for k in range(1, 16):
            if k * ff > 9000:
                break
            a = (1.0 / k ** 1.1) * (0.6 if k % 2 == 0 else 1.0)
            out += a * np.sin(k * ph)
    env = adsr(n, 0.04, 0.15, 0.85, 0.12, dur)
    env *= 1 + 0.06 * np.sin(2 * np.pi * 1.3 * t)
    return out * env * vel * 0.18

def strings(f, dur, vel=0.5):
    L = dur + 1.2
    n = int(L * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for det in (-7, 0, 7):
        ff = f * (1 + det / 1730.0)
        vib = 1 + 0.003 * np.sin(2 * np.pi * (4.8 + det * 0.05) * t + rng.random() * 6)
        ph = 2 * np.pi * ff * np.cumsum(vib) / SR
        for k in range(1, 18):
            if k * ff > 7000:
                break
            out += (1.0 / k ** 1.3) * np.sin(k * ph + rng.random() * 6)
    env = adsr(n, 0.6, 0.4, 0.8, 0.7, dur)
    return out * env * vel * 0.07

# ---------------- percussão ----------------
def kick(vel=0.8):
    n = int(0.5 * SR)
    t = np.arange(n) / SR
    fr = 48 + 70 * np.exp(-t / 0.035)
    ph = 2 * np.pi * np.cumsum(fr) / SR
    out = np.sin(ph) * np.exp(-t / 0.18)
    out[:200] += rng.standard_normal(200) * 0.15 * np.exp(-np.arange(200) / 40)
    return out * vel

def brush(vel=0.5, long=False):
    n = int((0.7 if long else 0.25) * SR)
    t = np.arange(n) / SR
    nz = rng.standard_normal(n)
    b, a = signal.butter(2, [900 / (SR / 2), 9000 / (SR / 2)], "band")
    nz = signal.lfilter(b, a, nz)
    if long:
        env = np.minimum(t / 0.25, 1.0) * np.exp(-t / 0.25)
    else:
        env = np.exp(-t / 0.07)
    tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t / 0.05) * 0.3
    return (nz * env * 0.6 + tone * (0 if long else 1)) * vel

def shaker(vel=0.3):
    n = int(0.09 * SR)
    t = np.arange(n) / SR
    nz = rng.standard_normal(n)
    b, a = signal.butter(2, 5000 / (SR / 2), "high")
    nz = signal.lfilter(b, a, nz)
    env = np.minimum(t / 0.012, 1) * np.exp(-t / 0.03)
    return nz * env * vel * 0.5

def hat(vel=0.3, open_=False):
    n = int((0.35 if open_ else 0.06) * SR)
    t = np.arange(n) / SR
    nz = rng.standard_normal(n)
    b, a = signal.butter(2, 7000 / (SR / 2), "high")
    nz = signal.lfilter(b, a, nz)
    return nz * np.exp(-t / (0.12 if open_ else 0.018)) * vel * 0.35

def cajon(vel=0.6, slap=False):
    n = int(0.3 * SR)
    t = np.arange(n) / SR
    if slap:
        nz = rng.standard_normal(n)
        b, a = signal.butter(2, [1500 / (SR / 2), 8000 / (SR / 2)], "band")
        out = signal.lfilter(b, a, nz) * np.exp(-t / 0.05) * 0.8 + np.sin(2 * np.pi * 320 * t) * np.exp(-t / 0.03) * 0.4
    else:
        out = np.sin(2 * np.pi * (75 + 40 * np.exp(-t / 0.02)) * t) * np.exp(-t / 0.12)
    return out * vel

def rim(vel=0.4):
    n = int(0.08 * SR)
    t = np.arange(n) / SR
    return (np.sin(2 * np.pi * 1700 * t) * 0.6 + np.sin(2 * np.pi * 820 * t)) * np.exp(-t / 0.012) * vel * 0.5

def bird(vel=0.2):
    # pequeno chilrear (para a faixa do parque, ao longe)
    n = int(0.5 * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    k = rng.integers(2, 5)
    for j in range(k):
        s = j * 0.11
        d = 0.07
        m = (t >= s) & (t < s + d)
        tt = t[m] - s
        f0 = rng.uniform(2800, 4200)
        fr = f0 + 1500 * np.sin(np.pi * tt / d) * rng.choice([-1, 1])
        ph = 2 * np.pi * np.cumsum(fr) / SR
        out[m] += np.sin(ph) * np.sin(np.pi * tt / d) ** 2
    return out * vel

# ---------------- mistura ----------------
class Mix:
    def __init__(self, seconds):
        self.n = int(seconds * SR)
        self.L = int((seconds + 4.0) * SR)
        self.buses = {}

    def add(self, bus, sig, at, pan=0.0, gain=1.0):
        if bus not in self.buses:
            self.buses[bus] = np.zeros((self.L, 2))
        i = int(at * SR)
        if i >= self.L:
            return
        sig = sig[: self.L - i] * gain
        l = np.cos((pan + 1) * np.pi / 4)
        r = np.sin((pan + 1) * np.pi / 4)
        self.buses[bus][i:i + len(sig), 0] += sig * l
        self.buses[bus][i:i + len(sig), 1] += sig * r

def make_ir(rt=1.8, pre=0.012):
    n = int(rt * 1.3 * SR)
    t = np.arange(n) / SR
    ir = np.zeros((n, 2))
    for c in range(2):
        nz = rng.standard_normal(n)
        env = np.exp(-6.9 * t / rt)
        # agudos morrem mais depressa
        lo = signal.lfilter(*signal.butter(1, 2500 / (SR / 2)), nz)
        mixw = np.exp(-t / (rt * 0.25))
        sig = (nz * mixw + lo * (1 - mixw)) * env
        p = int(pre * SR)
        ir[p:, c] = sig[: n - p]
        for d, g in ((0.017, 0.5), (0.023, 0.4), (0.031, 0.3), (0.043, 0.25)):
            k = int((d + c * 0.003) * SR)
            ir[k, c] += g
    ir /= np.sqrt((ir ** 2).sum(axis=0, keepdims=True))
    return ir

def eq_bus(x, hp=None, lp=None, low_shelf=None):
    if hp:
        b, a = signal.butter(2, hp / (SR / 2), "high")
        x = signal.lfilter(b, a, x, axis=0)
    if lp:
        b, a = signal.butter(2, lp / (SR / 2), "low")
        x = signal.lfilter(b, a, x, axis=0)
    return x

def guitar_body(x):
    # ressonâncias do corpo da guitarra
    out = x.copy()
    for f0, q, g in ((105, 4, 0.5), (220, 5, 0.35), (420, 3, 0.2)):
        b, a = signal.iirpeak(f0 / (SR / 2), q)
        out += signal.lfilter(b, a, x, axis=0) * g
    return out

def master(mix, sends, rt, wet):
    dry = np.zeros((mix.L, 2))
    rev_in = np.zeros((mix.L, 2))
    for bus, x in mix.buses.items():
        dry += x
        rev_in += x * sends.get(bus, 0.25)
    ir = make_ir(rt)
    wetsig = np.stack([signal.fftconvolve(rev_in[:, c], ir[:, c])[: mix.L] for c in range(2)], axis=1)
    out = dry + wetsig * wet
    # fecha o ciclo: o que passa do fim volta ao início (loop sem corte)
    n = mix.n
    tail = out[n:]
    out = out[:n].copy()
    out[: len(tail)] += tail
    out = eq_bus(out, hp=35)
    # compressão suave
    env = np.sqrt(signal.lfilter([0.0005], [1, -0.9995], (out ** 2).mean(axis=1)))
    thr = 0.18
    gain = np.where(env > thr, (thr / np.maximum(env, 1e-9)) ** 0.35, 1.0)
    out *= gain[:, None]
    out /= np.abs(out).max() / 0.89
    return out

def write_ogg(out, path):
    pcm = (np.clip(out, -1, 1) * 32767).astype("<i2")
    raw = path + ".raw"
    pcm.tofile(raw)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "s16le", "-ar", str(SR), "-ac", "2", "-i", raw,
                    "-c:a", "libvorbis", "-q:a", "4", path], check=True)
    os.remove(raw)

# ---------------- composição ----------------
def chord_notes(root, kind):
    q = {"maj": [0, 4, 7], "min": [0, 3, 7], "7": [0, 4, 7, 10], "maj7": [0, 4, 7, 11], "m7": [0, 3, 7, 10],
         "6": [0, 4, 7, 9], "m6": [0, 3, 7, 9], "sus": [0, 5, 7], "add9": [0, 4, 7, 14]}[kind]
    return [root + x for x in q]

def melody_line(chords, beats_per_bar, scale, lo, hi, seed, density=0.6, motif_bars=2):
    """melodia com motivos repetidos: notas do acorde nos tempos fortes, passagens por graus conjuntos"""
    r = np.random.default_rng(seed)
    rhythms4 = [[1, 1, 1, 1], [1.5, 0.5, 1, 1], [2, 1, 1], [1, 0.5, 0.5, 2], [0.5, 0.5, 1, 2], [3, 1], [1, 1, 2], [2, 2]]
    rhythms3 = [[1, 1, 1], [2, 1], [1.5, 0.5, 1], [3], [1, 0.5, 0.5, 1]]
    pool = rhythms4 if beats_per_bar == 4 else rhythms3
    motif = [pool[r.integers(len(pool))] for _ in range(motif_bars)]
    notes = []
    prev = (lo + hi) // 2
    t = 0.0
    for bi, ch in enumerate(chords):
        rh = motif[bi % motif_bars] if (bi // motif_bars) % 4 != 3 else pool[r.integers(len(pool))]
        tones = [c % 12 for c in ch]
        bt = 0.0
        for j, d in enumerate(rh):
            strong = bt == 0 or (beats_per_bar == 4 and bt == 2)
            cands = []
            for m in range(lo, hi + 1):
                pc = m % 12
                if strong and pc not in tones:
                    continue
                if not strong and pc not in scale:
                    continue
                cands.append(m)
            w = np.array([np.exp(-abs(m - prev) / (2.2 if not strong else 3.0)) for m in cands])
            if strong:
                w *= np.array([1.6 if m % 12 == tones[0] else 1.0 for m in cands])
            m = int(r.choice(cands, p=w / w.sum()))
            rest = (not strong) and r.random() > density
            if bi % (motif_bars * 2) == motif_bars * 2 - 1 and j == len(rh) - 1:
                # fim de frase: nota longa no acorde
                m = min(cands, key=lambda x: abs(x - prev)) if strong else m
            if not rest:
                notes.append((t + bt, d, m))
                prev = m
            bt += d
        t += beats_per_bar
    return notes

def render_parque():
    bpm = 100
    beat = 60 / bpm
    bars = 48
    key = 62  # Ré maior
    prog = [(0, "maj"), (7, "maj"), (9, "min"), (5, "maj"), (2, "min"), (7, "maj"), (0, "add9"), (7, "sus")]
    progB = [(5, "maj"), (0, "maj"), (2, "min"), (7, "maj"), (5, "maj"), (4, "min"), (2, "min"), (7, "7")]
    chords = []
    for sec in range(bars // 8):
        p = progB if sec in (2, 4) else prog
        chords += [chord_notes(key - 12 + r, k) for r, k in p]
    mix = Mix(bars * 4 * beat)
    scale = [(key + x) % 12 for x in (0, 2, 4, 5, 7, 9, 11)]
    mel = []
    for sec in range(bars // 8):
        seg = chords[sec * 8:(sec + 1) * 8]
        seed = 11 if sec in (0, 1, 3, 5) else 23
        if sec == 1 or sec == 5:
            seed = 11
        for (st, d, m) in melody_line(seg, 4, scale, key + 7, key + 21, seed, 0.75):
            mel.append((sec * 32 + st, d, m))
    for (st, d, m) in mel:
        if (st // 32) == 0 and st < 16:
            continue  # entra devagar
        sw = 0.06 if (st % 1) == 0.5 else 0
        mix.add("piano", piano(midi_f(m), d * beat * 0.95, 0.55 + rng.random() * 0.15), (st + sw) * beat, 0.1)
    # guitarra: dedilhado em colcheias com balanço
    patt = [(0, 0), (0.5, 2), (1, 1), (1.5, 2), (2, 0), (2.5, 2), (3, 1), (3.5, 3)]
    for bi, ch in enumerate(chords):
        voic = sorted(set([ch[0] + 12] + [c + 12 for c in ch[1:]] + [ch[1] + 24]))
        for (bt, idx) in patt:
            sw = 0.07 if bt % 1 else 0
            m = voic[idx % len(voic)]
            mix.add("gtr", guitar(midi_f(m), beat * 1.6, 0.45 + 0.1 * (bt == 0)), (bi * 4 + bt + sw) * beat, -0.35)
        # piano: acordes suaves nos tempos 1 e 3 (meio da música)
        if 8 <= bi < 40 and bi % 2 == 0:
            for c in ch[:3]:
                mix.add("keys", piano(midi_f(c + 12), beat * 3.5, 0.28), bi * 4 * beat + 0.01 * rng.random(), 0.3)
    # contrabaixo: tónica e quinta com notas de passagem
    for bi, ch in enumerate(chords):
        nxt = chords[(bi + 1) % len(chords)][0]
        r0 = ch[0] - 12 if ch[0] - 12 >= 36 else ch[0]
        line = [r0, r0 + 7, r0 + 12 if bi % 2 else r0 + 7, nxt - 12 + (1 if nxt > ch[0] else -1)]
        if line[3] < 33:
            line[3] += 12
        for k, m in enumerate(line):
            if bi < 4:
                break
            mix.add("bass", bass(midi_f(m), beat * 0.9, 0.7), (bi * 4 + k) * beat, 0.0)
    # bateria com escovas
    for bi in range(bars):
        if bi < 4:
            continue
        for k in range(4):
            tb = (bi * 4 + k) * beat
            if k in (0, 2):
                mix.add("drums", kick(0.55), tb, 0.0)
            if k in (1, 3):
                mix.add("drums", brush(0.45), tb, 0.1)
            mix.add("drums", shaker(0.35 if k % 2 else 0.22), tb, -0.5)
            mix.add("drums", shaker(0.2), tb + beat * 0.57, -0.5)
        if bi % 8 == 7:
            mix.add("drums", brush(0.4, True), (bi * 4 + 3) * beat, 0.2)
    # pássaros ao longe
    for k in range(18):
        mix.add("birds", bird(0.05 + rng.random() * 0.04), rng.uniform(0, bars * 4 * beat - 1), rng.uniform(-0.9, 0.9))
    mix.buses["gtr"] = guitar_body(eq_bus(mix.buses["gtr"], hp=90))
    mix.buses["bass"] = eq_bus(mix.buses["bass"], lp=2500)
    mix.buses["drums"] *= 0.8
    mix.buses["keys"] *= 0.8
    return master(mix, {"piano": 0.35, "gtr": 0.25, "keys": 0.3, "bass": 0.05, "drums": 0.15, "birds": 0.5}, 1.6, 0.35)

def render_algarve():
    bpm = 132  # valsa (3/4) ao estilo de fado ligeiro
    beat = 60 / bpm
    bars = 64
    key = 57  # Lá menor
    progA = [(0, "min"), (0, "min"), (5, "min"), (5, "min"), (7, "7"), (7, "7"), (0, "min"), (0, "min")]
    progB = [(3, "maj"), (3, "maj"), (10, "maj"), (10, "maj"), (5, "min"), (7, "7"), (0, "min"), (7, "7")]
    chords = []
    for sec in range(bars // 8):
        chords += [chord_notes(key - 12 + r, k) for r, k in (progB if sec % 4 in (2,) or sec == 5 else progA)]
    mix = Mix(bars * 3 * beat)
    scale = [(key + x) % 12 for x in (0, 2, 3, 5, 7, 8, 11)]
    for sec in range(bars // 8):
        seg = chords[sec * 8:(sec + 1) * 8]
        seed = 5 if sec % 4 != 2 else 9
        if sec == 0:
            continue
        line = melody_line(seg, 3, scale, key + 3, key + 19, seed, 0.8)
        for (st, d, m) in line:
            inst = reed if sec % 2 == 1 else (lambda f, du, v: guitar(f, du, v * 1.3, 0.12, True))
            gain = 1.0 if inst is reed else 0.9
            mix.add("lead", inst(midi_f(m), d * beat * 0.97, 0.6), (sec * 24 + st) * beat, 0.15, gain)
    # guitarra: baixo no 1, acorde no 2 e 3 (valsa), arpejo nos compassos pares
    for bi, ch in enumerate(chords):
        root = ch[0]
        while root > 52:
            root -= 12
        while root < 40:
            root += 12
        mix.add("gtr", guitar(midi_f(root), beat * 2.5, 0.6, 0.2), bi * 3 * beat, -0.3)
        up = [c + 12 for c in ch[1:3]] + [ch[0] + 24]
        if bi % 2 == 0:
            for k, m in enumerate(up):
                mix.add("gtr", guitar(midi_f(m), beat * 1.5, 0.42, 0.25), (bi * 3 + 1 + k * 0.5) * beat + 0.003 * k, -0.25)
        else:
            for b2 in (1, 2):
                for k, m in enumerate(up):
                    mix.add("gtr", guitar(midi_f(m), beat * 0.9, 0.35, 0.25), (bi * 3 + b2) * beat + 0.012 * k, -0.25)
    # baixo
    for bi, ch in enumerate(chords):
        if bi < 8:
            continue
        r0 = ch[0] - 12
        if r0 < 33:
            r0 += 12
        mix.add("bass", bass(midi_f(r0), beat * 1.8, 0.6), bi * 3 * beat, 0.0)
        if bi % 2 == 1:
            mix.add("bass", bass(midi_f(r0 + 7), beat * 0.9, 0.5), (bi * 3 + 2) * beat, 0.0)
    # cajón e pandeireta suaves
    for bi in range(bars):
        if bi < 8:
            continue
        mix.add("perc", cajon(0.5), bi * 3 * beat, 0.0)
        mix.add("perc", cajon(0.28, True), (bi * 3 + 1) * beat, 0.1)
        mix.add("perc", cajon(0.24, True), (bi * 3 + 2) * beat, 0.1)
        for k in range(6):
            mix.add("perc", shaker(0.14 if k % 2 else 0.2), (bi * 3 + k * 0.5) * beat, 0.5)
    mix.buses["gtr"] = guitar_body(eq_bus(mix.buses["gtr"], hp=80))
    mix.buses["bass"] = eq_bus(mix.buses["bass"], lp=2000)
    return master(mix, {"lead": 0.35, "gtr": 0.3, "bass": 0.05, "perc": 0.2}, 1.9, 0.38)

def render_noite():
    bpm = 70
    beat = 60 / bpm
    bars = 32
    key = 60  # Dó maior, balada de jazz
    prog = [(0, "maj7"), (9, "m7"), (2, "m7"), (7, "7"), (4, "m7"), (9, "7"), (2, "m7"), (7, "7")]
    progB = [(5, "maj7"), (5, "m6"), (4, "m7"), (9, "7"), (2, "m7"), (7, "7"), (0, "maj7"), (7, "7")]
    chords = []
    for sec in range(bars // 8):
        chords += [chord_notes(key - 12 + r, k) for r, k in (progB if sec == 2 else prog)]
    mix = Mix(bars * 4 * beat)
    scale = [(key + x) % 12 for x in (0, 2, 4, 5, 7, 9, 11)]
    for sec in range(bars // 8):
        if sec == 0:
            continue
        seg = chords[sec * 8:(sec + 1) * 8]
        for (st, d, m) in melody_line(seg, 4, scale, key + 4, key + 19, 31 if sec != 2 else 37, 0.45):
            sw = 0.12 if st % 1 else 0
            mix.add("lead", vibes(midi_f(m), d * beat, 0.5 + rng.random() * 0.1), (sec * 32 + st + sw) * beat, 0.2)
    for bi, ch in enumerate(chords):
        # piano elétrico: acordes sem tónica (vozes de jazz) no 1 e no "e" do 2
        voic = [c + 12 for c in ch[1:]] + [ch[0] + 26]
        for (bt, v) in ((0, 0.45), (1.62, 0.32)) if bi % 2 == 0 else ((0, 0.42), (2.62, 0.3)):
            for k, m in enumerate(voic):
                mix.add("ep", ep(midi_f(m), beat * 1.4, v), (bi * 4 + bt) * beat + 0.008 * k, -0.3 + 0.2 * k)
        for c in ch[:3]:
            mix.add("pad", strings(midi_f(c + 12), beat * 4.0, 0.5), bi * 4 * beat, 0.0)
    # contrabaixo a caminhar (semínimas)
    for bi, ch in enumerate(chords):
        nxt = chords[(bi + 1) % len(chords)][0]
        r0 = ch[0] - 12
        if r0 < 31:
            r0 += 12
        third = ch[1] - 12 if ch[1] - 12 >= r0 else ch[1]
        line = [r0, third, ch[2] - 12 if ch[2] - 12 > r0 else ch[2], (nxt - 12) + 1]
        for k, m in enumerate(line):
            while m > r0 + 12:
                m -= 12
            mix.add("bass", bass(midi_f(m), beat * 0.95, 0.65 if k == 0 else 0.55), (bi * 4 + k) * beat, 0.0)
    # escovas: varrimento contínuo + toque no 2 e 4 + prato de condução leve
    for bi in range(bars):
        for k in range(4):
            tb = (bi * 4 + k) * beat
            mix.add("drums", brush(0.22, True), tb, -0.2)
            if k in (1, 3):
                mix.add("drums", brush(0.3), tb, 0.15)
            mix.add("drums", hat(0.16), tb, 0.4)
            if k in (1, 3):
                mix.add("drums", hat(0.1), tb + beat * 0.66, 0.4)
        if bi % 4 == 0:
            mix.add("drums", kick(0.3), bi * 4 * beat, 0.0)
    mix.buses["bass"] = eq_bus(mix.buses["bass"], lp=1800)
    mix.buses["ep"] = eq_bus(mix.buses["ep"], lp=6000)
    for k in range(mix.L):
        break
    # trémulo estéreo no piano elétrico
    t = np.arange(mix.L) / SR
    tr = 0.5 + 0.5 * np.sin(2 * np.pi * 3.2 * t)
    mix.buses["ep"][:, 0] *= 0.7 + 0.3 * tr
    mix.buses["ep"][:, 1] *= 0.7 + 0.3 * (1 - tr)
    return master(mix, {"lead": 0.4, "ep": 0.3, "pad": 0.5, "bass": 0.06, "drums": 0.2}, 2.4, 0.42)

if __name__ == "__main__":
    outdir = sys.argv[1] if len(sys.argv) > 1 else "."
    which = sys.argv[2:] or ["parque", "algarve", "noite"]
    os.makedirs(outdir, exist_ok=True)
    for name in which:
        out = {"parque": render_parque, "algarve": render_algarve, "noite": render_noite}[name]()
        write_ogg(out, os.path.join(outdir, name + ".ogg"))
        print(name, "%.1f s" % (len(out) / SR))
