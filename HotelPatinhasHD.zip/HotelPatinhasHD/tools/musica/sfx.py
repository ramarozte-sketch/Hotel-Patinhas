# efeitos sonoros mais naturais: campainha da receção, moedas, fanfarra, confirmação
import numpy as np, sys, os
from scipy.io import wavfile
from synth import piano, guitar, vibes, midi_f, SR, rng
out = sys.argv[1]
os.makedirs(out, exist_ok=True)
def save(name, x):
    x = x / max(np.abs(x).max(), 1e-6) * 0.85
    wavfile.write(os.path.join(out, name + ".wav"), SR, (x * 32767).astype(np.int16))
def place(parts, L):
    buf = np.zeros(int(L * SR))
    for t0, sig in parts:
        i = int(t0 * SR)
        n = min(len(sig), len(buf) - i)
        buf[i:i + n] += sig[:n]
    return buf
# campainha de balcão: parciais inarmónicas de uma campânula metálica
t = np.arange(int(1.6 * SR)) / SR
bell = np.zeros_like(t)
for r, a, d in ((1.0, 1.0, 1.1), (2.76, 0.55, 0.6), (5.4, 0.3, 0.3), (8.93, 0.15, 0.15), (1.002, 0.6, 1.0)):
    bell += a * np.sin(2 * np.pi * 2350 * r * t + rng.random()) * np.exp(-t / d)
bell[:60] += rng.standard_normal(60) * 0.4
save("bell", bell)
# moedas: dois tilintares metálicos
def ting(f, L=0.5):
    t = np.arange(int(L * SR)) / SR
    s = sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t / d) for r, a, d in ((1, 1, 0.18), (2.4, 0.5, 0.08), (4.1, 0.3, 0.05)))
    return s
save("coin", place([(0, ting(2600)), (0.07, ting(3300) * 0.8), (0.13, ting(2950) * 0.5)], 0.7))
save("fanfare", place([(0, piano(midi_f(72), 0.12, 0.8)), (0.12, piano(midi_f(76), 0.12, 0.8)), (0.24, piano(midi_f(79), 0.12, 0.8)),
                        (0.36, piano(midi_f(84), 0.6, 0.9) + piano(midi_f(76), 0.6, 0.6) + piano(midi_f(79), 0.6, 0.6))], 2.0))
save("ok", place([(0, vibes(midi_f(84), 0.1, 0.7)), (0.09, vibes(midi_f(91), 0.2, 0.7))], 1.0))
save("click", place([(0, guitar(midi_f(88), 0.03, 0.5, 0.3, True)[: int(0.08 * SR)])], 0.09))
print("ok")
